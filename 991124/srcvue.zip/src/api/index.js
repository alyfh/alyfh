import axios from 'axios';
import router from '../router';
import * as util from '../assets/util.js';

const instance = axios.create({
	baseURL: '/api',
	timeout: 10000
});

instance.defaults.headers.post['Content-Type'] = 'application/json';
//错误处理
instance.interceptors.response.use(function(response) {
	// token 已过期，重定向到登录页面  
	if(response.data.errcode == -1) {
		sessionStorage.clear();
		router.replace({
			path: '/login',
			query: {
				redirect: router.currentRoute.fullPath
			}
		})
	}

	return response;
}, util.catchError);

export default instance;