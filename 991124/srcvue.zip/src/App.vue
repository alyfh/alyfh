<style>

</style>

<template>
	<router-view id="app" @login="loginDirect" @logout="logoutDirect"></router-view>
</template>

<script>
	import Vue from 'vue';
	import instance from './api';
	import axios from 'axios';
	import userPath from './router/fullpath';
	import moudle from './router/modulepath';
	import * as util from './assets/util.js';

	//请求拦截句柄
	let myInterceptor;

	export default {
		data() {
			return {
				menuData: null,
				userData: null
			}
		},
		methods: {
			getPermission: function(userInfo) {
				let resourcePermission = {};
				if(Array.isArray(userInfo.resources)) {
					userInfo.resources.forEach(function(e, i) {
						let key = e.method.toLowerCase() + ',' + e.url;
						resourcePermission[key] = true;
					});
				}
				return resourcePermission;
			},
			setInterceptor: function(resourcePermission) {
				let vm = this;
				myInterceptor = instance.interceptors.request.use(function(config) {
					//得到类权限路径
					let perName = config.url.replace(config.baseURL, '').replace('/GET', '').replace('/POST', '').split('?')[0];
					//转成权限格式
					let reg1 = perName.match(/^(\/[^\/]+\/)[^\/]+$/);
					// /path/${param}
					if(reg1) {
						perName = reg1[1] + '**';
					}
					let reg2 = perName.match(/^\/[^\/]+\/([^\/]+)\/[^\/]+$/);
					// /path/${param}/path
					if(reg2) {
						perName = perName.replace(reg2[1], '*');
					}
					//匹配权限
					if(!resourcePermission[config.method + ',' + perName]) {
						console.warn(resourcePermission, config.method + ',' + perName);
						vm.$message({
							message: '无访问权限，请联系企业管理员',
							type: 'warning'
						});
						return Promise.reject({
							message: 'no permission'
						});
					}
					return config;
				});
			},
			getRoutes: function(userInfo) {
				if(!userInfo.data) {
					return console.warn(userInfo);
				}
				let vm = this;
				let allowedRouter = [];
				//转成多维数组
				//  let arrayMenus = util.buildMenu(userInfo.menus);
				let arrayMenus = userInfo.data;
				//转成hash
				let hashMenus = {};
				//遍历菜单
				let setMenu2Hash = function(array, base) {
					array.map(key => {
						if(key.code) {
							let hashKey = ((base ? base + '/' : '') + key.code).replace(/^\//, '');
							hashMenus['/' + hashKey] = true;
							if(Array.isArray(key.navigations)) {
								setMenu2Hash(key.navigations, hashKey);
							}
							if(Array.isArray(key.modules)) {
								setMenu2HashBymodule(key.modules, hashKey);
							}
						}
					});
				};
				//遍历菜单模块
				let setMenu2HashBymodule = function(array, base) {
					array.map(key => {
						if(key.moduleCode) {
							let hashKey = ((base ? base + '/' : '') + key.moduleCode).replace(/^\//, '');
							hashMenus['/' + hashKey] = true;
						}
					});
				};
				setMenu2Hash(arrayMenus);
				//遍历本地路由
				let findLocalRoute = function(array, base) {
					let replyResult = [];
					array.forEach(function(route) {
						let pathKey = (base ? base + '/' : '') + route.path;
						if(hashMenus[pathKey]) {
							if(Array.isArray(route.children)) {
								// route.children = findLocalRoute(route.children, route.path);
								route.children = findLocalRoute(route.children, pathKey);
							}
							replyResult.push(route);
						}
					});
					if(base) {
						return replyResult;
					} else {
						allowedRouter = allowedRouter.concat(replyResult);
					}
				}
				let originPath = util.deepcopy(userPath[0].children);
				findLocalRoute(originPath);
				return allowedRouter;
			},
			extendRoutes: function(allowedRouter) {
				let originPath = util.deepcopy(userPath);
				originPath[0].children = allowedRouter;
				this.$router.addRoutes(originPath.concat(moudle, [{
					path: '*',
					redirect: '/404'
				}]));
			},
			storageMenu: function(allowedRouter) {
				allowedRouter.forEach(route => {
					if(route.children) {
						if(!route.meta) route.meta = {};
						route.meta.children = route.children;
					}
				});
				this.menuData = allowedRouter;
			},
			signin: function(cb) {
				let vm = this;
				let localUser = util.session('loginInfo');
				if(!localUser || !localUser.token) {
					return vm.$router.push({
						path: '/login',
						query: {
							from: vm.$router.currentRoute.path
						}
					});
				}
				instance.defaults.headers.common['token'] = localUser.token;
				//获取用户信息及权限
				instance.get('/navi/findUserNavigationModules', {
					params: {
						//   Authorization: localUser.data.token
					}
				}).then((res) => {
					let userInfo = res.data;
					//取得资源权限
					let resourcePermission = vm.getPermission(userInfo);
					//请求拦截
					/***    vm.setInterceptor(resourcePermission);  ***/
					//获得路由
					let allowedRouter = vm.getRoutes(userInfo);
					/***    if (!allowedRouter || !allowedRouter.length) {
          util.session('token','');
          return document.body.innerHTML = ('<h1>账号访问受限，请联系系统管理员！</h1>');
        }

		***/
					//注入动态路由
					vm.extendRoutes(allowedRouter);
					//保存菜单数据
					vm.storageMenu(allowedRouter);
					//用户信息持久化
					//vm.storageUser(Object.assign(localUser || {}, userInfo));
					vm.userData = userInfo;
					//权限检查方法
					Vue.prototype.$_has = function(actionsList, actionCode) {
						let permission = false;
						actionsList.forEach(function(a) {
							if(a.actionCode == actionCode) {
								permission = true;
							}
						});
						return permission;
					}
					/*
					Vue.prototype.$_has = function(rArray) {
					  let resources = [];
					  let permission = true;
					  if (Array.isArray(rArray)) {
					    rArray.forEach(function(e) {
					      resources = resources.concat(e.p);
					    });
					  } else {
					    resources = resources.concat(rArray.p);
					  }
					  resources.forEach(function(p) {
					    if (!resourcePermission[p]) {
					      return permission = false;
					    }
					  });
					  //console.log(resources, permission);
					  return permission;
					}
					*/

					typeof cb === 'function' && cb();
				})
			},
			loginDirect: function(newPath) {
				this.signin(() => {
					this.$router.replace({
						path: newPath || '/'
					});
				});
			},
			logoutDirect: function() {
				//清除路由权限控制
				instance.interceptors.request.eject(myInterceptor);
				instance.post('/logout', {}).then((res) => {
					if(res.data.errcode == '0') {
						util.session('loginInfo', "");
						this.$router.replace({
							path: '/login'
						});
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}

				})

			}
		},
		created: function(newPath) {
			this.signin();
		}
	}
</script>