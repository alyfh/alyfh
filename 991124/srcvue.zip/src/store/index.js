import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

const state = {
	layerShow: false, // 弹窗状态
	pageSize: 10, //每页多少条
	pageLarge: 3, //分页显示个数//pageLarge是奇数//显示几个分页块
	cityJson: {}, //省县市字典（高德地图接口获取）
	adviceStatus: {
		"1": "未跟进",
		"2": "跟进中",
		"3": "考虑中",
		"4": "有意向",
		"5": "无意向",
		"6": "已放弃",
		"7": "已成单"
	},//线索状态
	adviceLevel: {
		"1": "未知客户",
		"2": "潜在客户",
		"3": "目标客户",
		"4": "发展中客户",
		"5": "交易客户",
		"6": "后续介绍客户",
		"7": "非客户"
	},//客户等级
    shifouByDigit:{
    	0:'是',
    	1:'否'
    },
    classTypeDict:{
    	0:'一对一',
    	1:'一对多'
    },//班级类别
    arriveStatusDict:{
    	0:'已到场',
    	1:'未到场'
    },//到场状态
    registStatusDict:{
    	0:'已报名',
    	1:'未报名'
    },//报名状态
     listenTypeDict:{
    	0:'正常试听',
    	1:'跟班试听'
    },//试听类型
    listenMinuteDict:{
    	30:'30分钟',
    	45:'45分钟',
    	60:'60分钟',
    	90:'90分钟'
    },//试听时长
    payStateDict:{
    	1:'待支付',
    	2:'已支付',
    	3:'支付失败',
    },//支付状态
    paymentDict:{
    	1:"现金",
    	2:"支付宝",
    	3:"微信",
    	4:"POS机",
    	5:"转账",
    },//支付方式
    refundDict:{
    	1:"现金",
    	2:"转账",
    	3:"原路退回"
    },//支付方式（退费）
    approveStatusDict:{
    	1:"待审核",
    	2:"已通过",
    	3:"已取消",
    },//审核状态
    userSexDict:{
    	0:"男",
    	1:"女",
    },//性别
    userMarriageDict:{
    	0:"未婚",
    	1:"已婚",
    	2:"离异",
    	3:"丧偶",
    },//婚姻状况
    userEducationDict:{
    	"高中":"高中",
    	"大专":"大专",
    	"本科":"本科",
    	"硕士":"硕士",
    	"博士":"博士",
    },//学历信息
    userWorkingDict:{
    	0:"在职",
    	1:"离职",
    },//在职状况
    userTeachDict:{
    	0:"是",
    	1:"否",
    },//是否授课
    userOfficialDict:{
    	0:"已转正",
    	1:"试用期",
    },//转正状态
    lessonStatusDict:{
    	1:"上课",
    	2:"请假",
    	3:"旷课",
    	4:"补课",
    	5:"停课",
    },//考勤状态
    receiveStatusDict:{
    	0:"已收款",
    	1:"未收款"
    }//收款状态
}

const mutations = {

	setLayerShow(state, payload) {
		state.layerShow = payload.layerShow

	},
	setCityJson(state, payload) {
		state.cityJson = payload.cityJson

	}
}

const actions = {

}

export default new Vuex.Store({
	state,
	mutations,
	actions,
})
