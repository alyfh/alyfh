<!--<title>编辑员工</title>-->
<style>
	.el-input__inner {
		height: 25px;
	}
</style>
<template>
	<form id="addemployee" method="post" action="" class="ue_form_add">
		<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
        	<span>编辑员工(</span>
        	<span class='h5_mark_xx2'>★</span>
        	<span>为必填)</span>
    	</h3>
		<ul class='h5_02_info_per_addlist'>
			<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
        	<span>基本信息</span>
    	    </h3>
			<li>
				<span>★</span>
				<span>姓名:</span>
				<span><input type="text" class='per_addperson_txt' v-model="sources.realName"></span>
			</li>
			<li>
				<span>★</span>
				<span>性别:</span>
				<span>
		            <select name="" id="" class='per_addperson_txt' v-model="sources.sex">
              			<option  value="">请选择</option>
              			<option v-for = "(item,key) in userSexDict" :value="key">{{item}}</option>
           			</select>
    			</span>
			</li>
			<li>
				<span></span>
				<span>出生日期:</span>
				<span>
            		<el-date-picker type="date" style="width:100%" v-model="sources.birthday" value-format="yyyy-MM-dd"></el-date-picker>
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>手机:</span>
				<span>
    				<input type="text"class='per_addperson_txt' v-model="sources.telephone">
    			</span>
			</li>
			<li>
				<span></span>
				<span>民族:</span>
				<span>
					<input type="text" class='per_addperson_txt' v-model="sources.nation">
				</span>
			</li>
			<li>
				<span></span>
				<span>婚姻状况:</span>
				<span>
    				<select name="" id="" class='per_addperson_txt' v-model="sources.marriage">
    				  	<option  value="">请选择</option>
			            <option v-for="(item,key) in userMarriageDict" :value="key">{{item}}</option>
            		</select>
    			</span>
			</li>
			<li>
				<span></span>
				<span>学历:</span>
				<span>
		    		<select name="" id="" class='per_addperson_txt' v-model="sources.education">
		    		  	<option  value="">请选择</option>
		              	<option v-for = "(item,key) in userEducationDict" :value="key">{{item}}</option>
		            </select>
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>身份证号:</span>
				<span>
					<input type="text" class='per_addperson_txt' v-model="sources.idNumber">
				</span>
			</li>
			<li>
				<span></span>
				<span>毕业院校:</span>
				<span>
					<input type="text" class='per_addperson_txt' v-model="sources.graduate">
				</span>
			</li>
			<li>
				<span></span>
				<span>现住址:</span>
				<span>
					<input type="text" class='per_addperson_txt' v-model="sources.address">
				</span>
			</li>
			<li>
				<span></span>
				<span>户籍所在地:</span>
				<span>
					<input type="text" class='per_addperson_txt' v-model="sources.domicilePlace">
				</span>
			</li>
			<br class="p_zwf">
			<li style="width:100%;">
				<span></span>
				<span>简历:</span>
				<span style="min-height: 100px;width:550px;">
                    <el-upload
					  class="upload-demo"
					  action="/api/attach/upload"
					  :on-preview="handlePreview"
					  :on-remove="handleRemove"
					  :before-remove="beforeRemove"
					  :limit="1"
					  :on-exceed="handleExceed"
					  :on-success="handleSuccessed"
					  :file-list="fileList">
					  <el-button size="small" type="primary">点击上传</el-button>
					  <div slot="tip" class="el-upload__tip">目前只支持doc、docx、pdf格式文件上传</div>
					</el-upload>
				</span>
			</li>
			<br class="p_zwf">
			<br class="p_zwf">
			<li style="width:100%;">
				<span></span>
				<span>备注:</span>
				<textarea v-model="sources.descr" cols="30" rows="4" placeholder="" class='per_addperson_texarea'></textarea>
			</li>
			<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
        	<span>入职信息</span>
    	    </h3>
			<li>
				<span></span>
				<span>账号:</span>
				<span>
					<!--<input type="text" class='per_addperson_txt' v-model="sources.username" placeholder="帐号规则：4-20位字母或数字">-->
						{{sources.username}}
				</span>
			</li>
			<li>
				<span></span>
				<span><!--初始密码:--></span>
				<span>
					<!--<input type="text" class='per_addperson_txt' v-model="sources.password" placeholder="密码规则：6-20位字母或数字">-->
				</span>
			</li>
			<li>
				<span></span>
				<span>在职状况:</span>
				<span>
					<select class='per_addperson_txt' v-model="sources.working" >
		                <option v-for="(item,key) in userWorkingDict" :value="key">{{item}}</option>
		            </select>
				</span>
			</li>
			<li style="width:100%;">
				<span></span>
				<span>入职校区:</span>
				<el-checkbox :indeterminate="isIndeterminate" v-model="checkAll" @change="handleCheckAllChange">全选</el-checkbox>
    			<el-select style="padding-left:5px;width:76%" v-model="schoolsArray" multiple placeholder="请选择">
					<el-option v-for="school in schoolList" :key="school.id" :label="school.schoolName" :value="school.id">
					</el-option>
				</el-select>
			</li>
			<br class="p_zwf">
			<li>
				<span></span>
				<span>入职部门:</span>
				<span>
					<select name="" id="" class='per_addperson_txt' v-model="sources.departmentId">
		                <option disabled value="">请选择</option>
		                <option v-for="department in departmentList" :value="department.id" >
		                {{department.departmentName}}</option>
		            </select>
				</span>
			</li>
			<li>
				<span></span>
				<span>入职职务:</span>
				<span>
    				<select name="" id="" class='per_addperson_txt' v-model="sources.dutyId">
			            <option  value="">请选择</option>
			            <option v-for = "duty in dutyList" :value="duty.id">{{duty.dutyName}}</option>
			        </select>
    			</span>
			</li>
			<li>
				<span></span>
				<span>入职日期:</span>
				<span>
            		<el-date-picker type="date" value-format="yyyy-MM-dd" style="width:100%" v-model="sources.entryDate" ></el-date-picker>
    			</span>
			</li>
			<li>
				<span></span>
				<span>是否授课:</span>
				<span>
		    		<select name="" id="" class='per_addperson_txt' v-model="sources.teach">
		    		  	<option value="">请选择</option>
		              	<option v-for = "(item,key) in userTeachDict" :value="key">{{item}}</option>
		            </select>
    			</span>
			</li>
			<li>
				<span></span>
				<span>转正状态:</span>
				<span>
		    		<select class='per_addperson_txt' v-model="sources.official">
		              	<option v-for = "(item,key) in userOfficialDict" :value="key" >{{item}}</option>
		            </select>
    			</span>
			</li>
			<li>
				<span></span>
				<span>转正日期:</span>
				<span>
            		<el-date-picker type="date" style="width:100%" v-model="sources.officialDate" value-format="yyyy-MM-dd"></el-date-picker>
    			</span>
			</li>
			<li>
				<span></span>
				<span>离职日期:</span>
				<span>
            		<el-date-picker type="date" style="width:100%" v-model="sources.leaveDate" value-format="yyyy-MM-dd"></el-date-picker>
    			</span>
			</li>
			<br class="p_zwf">
			<li style="width:100%;">
				<span></span>
				<span>角色:</span>

				<!--
                    	作者：offline
                    	时间：2018-01-31
                    	描述：
                    <select name="" id="" class='per_addperson_txt' v-model="sources.roles.id">
	              		<option  value="">请选择</option>
	              		<option v-for = "role in roleList" :value="role.roleCode">{{role.roleName}}</option>
	            	</select>-->

				<el-select style="padding-left:5px;width:80%" v-model="rolesArray" multiple placeholder="请选择">
					<el-option v-for="role in roleList" :key="role.id" :label="role.roleName" :value="role.id">
					</el-option>
				</el-select>

			</li>
		</ul>
		<br class="p_zwf">
		<div class="p_btn_group p_clear_float">
			<input type="button" value="取消" @click="cancel()" class="p_btn p_btn_siz_2 p_btn_col_ora p_btn_pos_r">
			<input type="button" value="保存" @click="changeEmployee(sources)" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r">
		</div>
	</form>
</template>
<script>
	import instance from '../../../api/index.js';
	import axios from 'axios';
	import { mapState } from 'vuex';
	import * as util from '../../../assets/util.js';
	let Base64 = require('js-base64').Base64; //引入base64算法
	export default {
		props: ['id'], //传入的流水号
		data() {
			return {
				sources: {
					realName: "",
					sex: "",
					birthday: "",
					telephone: "",
					nation: "",
					marriage: "",
					education: "",
					idNumber: "",
					graduate: "",
					address: "",
					domicilePlace: "",
					resume: "",
					working: "0",
					schools: [{
						id: ""
					}],
					departmentName: "",
					departmentId: "",
					dutyId: "",
					entryDate: "",
					teach: "",
					official: "0",
					officialDate: "",
					leaveDate: "",
					roles: []
				},
				schoolList: [],
				dutyList: [],
				roleList: [],
				departmentList: [],
				fileList: [], //附件列表区域
				rolesArray: [],
				schoolsArray: [],
				checkAll: false,
				isIndeterminate: true
			};
		},
		created() {
			// 组件创建完后获取数据，
			instance.get('/user/findUser/' + this.id).then((res) => {
				this.sources = res.data.data;

				//清空密码
				this.sources.password = "";

				//附件名称
				//this.sources.resumeAttachName = Base64.decode(this.sources.resume.split("_")[1]);
				//附件下载地址
				//this.sources.resumeAttachPath = '/api/attach/'+this.sources.resume;

				//处理附件列表区域
				let attach = {};
				attach['name'] = Base64.decode(this.sources.resume.split("_")[1]);
				attach['url'] = '/api/attach/' + this.sources.resume;
				this.fileList.push(attach);

				//处理角色默认选中
				res.data.data.roles.forEach(function(r) {
					this.rolesArray.push(r.id);
				}, this);
				
				//处理校区默认选中
				res.data.data.schools.forEach(function(r) {
					this.schoolsArray.push(r.id);
				}, this);
			})
		},
		methods: {
			changeEmployee: function() {
				//清空角色数组
				this.sources.roles = [];
				this.rolesArray.forEach(function(r) {
					let role = {};
					role['id'] = r;
					this.sources.roles.push(role);
				}, this);
				
				//清空校区数组
				this.sources.schools = [];
				this.schoolsArray.forEach(function(s) {
					let school = {};
					school['id'] = s;
					this.sources.schools.push(school);
				}, this);

				instance.post('/user/changeUser', this.sources).then((res) => {
					if(res.data.errcode == '0') {
						this.$message.success('信息编辑成功！');
						//this.$router.go(-1);
						this.$router.push({
							path: `/renshiguanli/yuangongguanli/quanbuyuangong`
						});
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}
				})
			},
			getSchool: function() { //取入职校区
				//从session中获取用户登陆json
				this.loginInfo = util.session('loginInfo').login;
				instance.post('/school/findUserSchools/'+this.loginInfo.userId, {}).then((res) => {
					this.schoolList = res.data.data;
				})
			},
			getDuty: function() { //取职务
				instance.post('/duty/findSimpleDutys', {}).then((res) => {
					this.dutyList = res.data.data;
				})
			},
			getRoles: function() { //取角色
				instance.post('/role/findSchoolSimpleRoles', {}).then((res) => {
					this.roleList = res.data.data;
				})
			},
			getDepartments: function() { //取入职部门
				instance.post('/dept/findSimpleDepartments', {}).then((res) => {
					this.departmentList = res.data.data;
				})
			},
			cancel: function() {
				//this.$router.go(-1)
				this.$router.push({
					path: `/renshiguanli/yuangongguanli/quanbuyuangong`
				});
			},
			handleRemove(file, fileList) {
				console.log(file, fileList);
			},
			handlePreview(file) {
				//下载附件
				window.location.href = '/api/attach/' + this.sources.resume;
			},
			handleExceed(files, fileList) {
				this.$message.warning(`当前限制只能上传 1 个文件`);
			},
			beforeRemove(file, fileList) {
				//return this.$confirm(`确定移除 ${ file.name }？`);
				return this.$confirm(`是否确定删除此员工简历？`);
			},
			handleSuccessed(res, file, fileList) {				
				if(res.errcode === 0) {
					this.sources.resume = res.data.file;
				} else {
					//this.$message.error('操作失败！' + res.errmsg);
					this.$message.error('操作失败！不支持此简历格式文件！');
					//fileList.clearFiles();
					this.fileList=[];
				}
			},
			handleCheckAllChange:function(){  //校区全选
				if(this.checkAll){
					//清理上次选中数据
					this.schoolsArray = [];
					//全部选中
					this.schoolList.forEach(function(s) {
						this.schoolsArray.push(s.id);
					}, this);
					this.isIndeterminate = false;
					this.checkAll = true;
				}else{
					//取消全选
					this.schoolsArray = [];
					this.checkAll = false;
				}
			}
		},
		computed: {
			// Getting Vuex State from store/index
			...mapState({
				//用户性别
				userSexDict: state => state.userSexDict,
				//婚姻状况
				userMarriageDict: state => state.userMarriageDict,
				//学历
				userEducationDict: state => state.userEducationDict,
				//在职状况
				userWorkingDict: state => state.userWorkingDict,
				//是否授课
				userTeachDict: state => state.userTeachDict,
				//转正状态
				userOfficialDict: state => state.userOfficialDict,
			})
		},
		mounted: function() {
			this.getDepartments();
			this.getSchool();
			this.getDuty();
			this.getRoles();
		}
	};
</script>