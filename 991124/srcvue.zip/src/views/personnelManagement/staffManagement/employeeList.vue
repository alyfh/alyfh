<!--<title>全部员工</title>-->
<style scoped>
	.p_table_la tr>td:nth-child(14):hover {
		cursor: pointer;
		color: #0d8ddb;
	}
</style>
<style>
	.p_btn_pos_r {
		float: right;
		margin-right: 10px;
	}
</style>
<template>
	<section class="p_chi_con">
		<div class="p_con_sea">
			<ul class="p_con_sea_list p_clear_float">
				<li>
					<span>账号:</span>
					<span>
						<input type="text" class="p_con_form_input" v-model="findEmployee.qUsername">
					</span>
				</li>
				<li>
					<span>姓名:</span>
					<span>
						<input type="text" class="p_con_form_input" v-model="findEmployee.qRealName">
					</span>
				</li>
				<li>
					<span>身份证号:</span>
					<span>
						<input type="text" class="p_con_form_input" v-model="findEmployee.qIdNumber">
					</span>
				</li>
				<li>
					<span>手机:</span>
					<span>
						<input type="text" class="p_con_form_input" v-model="findEmployee.qTelephone">
					</span>
				</li>
				<li>
					<span>在职状态:</span>
					<span>
						<select name="" id="" class="p_con_form_select" v-model="findEmployee.qWorking">
			             	<option value="">--请选择--</option>
			              	<option v-for="(item,key) in userWorkingDict" :value="key">{{item}}</option>
			           </select>
					</span>
				</li>
				<li>
					<span>转正状态:</span>
					<span>
			            <select name="" id="" class="p_con_form_select" v-model="findEmployee.qOfficial">
			                <option value="">--请选择--</option>
			                <option v-for="(item,key) in userOfficialDict" :value="key">{{item}}</option>
			            </select>
					</span>
				</li>
				<li>
					<span>校区:</span>
					<span>
			            <select name=""  class="p_con_form_select" v-model="findEmployee.qSchoolId">
			              	<option value="">--请选择--</option>
			              	<option v-for="school in schoolNames" :value="school.id">{{ school.schoolName}}</option>
			            </select>
					</span>
				</li>
				<li>
					<span>部门:</span>
					<span>
			            <select name="" id="" class="p_con_form_select" v-model="findEmployee.qDepartmentId" @change="getClassSub(findEmployee.qCourseId)">
			                <option value="">--请选择--</option>
			               	<option v-for="deparment in departNames" :value="deparment.id">{{deparment.departmentName}}</option>
			            </select>
					</span>
				</li>
				<li>
					<span>职务:</span>
					<span>
			            <select name="" id="" class="p_con_form_select" v-model="findEmployee.qDutyId">
			             	<option value="">--请选择--</option>
			              	<option v-for="duty in dutyNames" :value="duty.id">{{duty.dutyName}}</option>
			            </select>
					</span>
				</li>
				<!--<li>
					<span>课程大类:</span>
					<span>
			            <select name="" id="" class="p_con_form_select" v-model="findEmployee.qCourseId">
			             		<option value="">--请选择--</option>
			                  <option v-for = "courses in coursesNames" :value="courses.id">{{courses.courseName}}</option>
			            </select>
					</span>
				</li>-->
				<li>
					<span>角色:</span>
					<span>
			            <select name="" id="" class="p_con_form_select" v-model="findEmployee.qRoleId">
			             		<option value="">--请选择--</option>
			                  <option v-for = "role in roles" :value="role.id">{{role.roleName}}</option>
			            </select>
					</span>
				</li>
			</ul>
			<div class="p_btn_group p_clear_float">
				<input type="button" value="查询" @click="query" class="p_btn p_btn_siz_2 p_btn_col_gre p_btn_pos_r">
			</div>
		</div>

		<div class="p_con_tab">
			<div class="p_table_la_over">
				<table class="p_table_la" cellspacing="0" cellpadding="0">
					<tr>
						<td>账号</td>
						<td>姓名</td>
						<td>性别</td>
						<td>身份证号</td>
						<td>手机</td>
						<td>在职状态</td>
						<td>转正状态</td>
						<td>部门</td>
						<td>校区</td>
						<td>职务</td>
						<td>角色</td>
						<td>是否授课</td>
						<td v-if="$_has(actionsList,'leave')||$_has(actionsList,'official')||$_has(actionsList,'update')||$_has(actionsList,'read')">操作</td>
					</tr>
					<tr v-for="employee in employeeList">
						<td>{{employee.username}}</td>
						<td>{{employee.realName}}</td>
						<td>{{userSexDict[employee.sex]}}</td>
						<td>{{employee.idNumber}}</td>
						<td>{{employee.telephone}}</td>
						<td>{{userWorkingDict[employee.working]}}</td>
						<td>{{userOfficialDict[employee.official]}}</td>
						<td>{{employee.departmentName}}</td>
						<td>
							<span v-for="(item,key) in employee.schools">{{item.schoolName}}<br/></span>
						</td>
						<td>{{employee.dutyName}}</td>
						<td>
							<span v-for="(item,key) in employee.roles">{{item.roleName}}<br/></span>
						</td>
						<td>{{userTeachDict[employee.teach]}}</td>
						<td v-if="$_has(actionsList,'leave')||$_has(actionsList,'official')||$_has(actionsList,'update')||$_has(actionsList,'read')">
							<template v-if="employee.working==='0'">
								<input type="button" v-if="$_has(actionsList,'leave')" value="离职" @click="leaveEmployee(employee.id)" class="p_btn p_btn_siz_2 p_btn_col_k_red p_btn_pos_r">
							</template>
							<template v-if="employee.official==='1' && employee.working==='0'">
								<input type="button" v-if="$_has(actionsList,'official')" value="转正" @click="officialEmployee(employee.id)" class="p_btn p_btn_siz_2 p_btn_col_k_red p_btn_pos_r">
							</template>
							<input type="button" v-if="$_has(actionsList,'update')" value="编辑" @click="updateEmployee(employee.id)" class="p_btn p_btn_siz_2 p_btn_col_k_oran p_btn_pos_r">
							<input type="button" v-if="$_has(actionsList,'read')" value="查看" @click="readEmployee(employee.id)" class="p_btn p_btn_siz_2 p_btn_col_k_blu p_btn_pos_r">
						</td>
					</tr>
				</table>
				<!--<router-view></router-view>-->
			</div>
		</div>
		<div class='h5_page_container' id="con">
			<page :record-count="recordCount" v-on:change-page="changePage">
			</page>
		</div>

	</section>
</template>
<script>
	import instance from '../../../api/index.js';
	import { mapState } from 'vuex';
	export default {
		computed: {
			// Getting Vuex State from store/index
			...mapState({
				//在职状态
				userWorkingDict: state => state.userWorkingDict,
				//转正状态
				userOfficialDict: state => state.userOfficialDict,
				//性别
				userSexDict: state => state.userSexDict,
				//是否授课
				userTeachDict: state => state.userTeachDict,
				pageSize: state => state.pageSize,
				pageLarge: state => state.pageLarge,
			})
		},
		data() {
			return {
				actionsList:[],//获取当前用户对当前模块授权操作
				actionType: "",
				findEmployee: { //查询条件

				},
				employeeList: [], //全部员工列表
				schoolNames: [], //校区,
				departNames: [], //部门
				dutyNames: [], //职务
				coursesNames: [], //课程大类
				roles: [], //课程大类
				recordCount: 0,
				pageNum: 1 //当前页码
			};
		},
		components: {
			page: () =>
				import("../../common/page.vue"),
		},
		methods: {
			query: function() {
				this.getEmployeeList(this.findEmployee);
				this.getEmployeeCount(this.findEmployee); //全部员工数量
			},
			getEmployeeCount: function(lis) { //获取全部员工数量
				instance.post('/user/findUsersCount', lis).then((res) => {
					this.recordCount = res.data.data.count;
				});
			},
			getEmployeeList: function(lis) { //获取全部员工列表
				lis.beginRow = (this.pageNum - 1) * this.pageSize;
				lis.pageSize = this.pageSize;
				instance.post('/user/findUsers', lis).then((res) => {
					this.employeeList = res.data.data;
				});

			},
			getSchool: function() { //获取校区数据 
				instance.post('/school/findSimpleSchools', {}).then((res) => {
					this.schoolNames = res.data.data;
				});
			},
			getDepartment: function() { //取入职部门
				instance.post('/dept/findSimpleDepartments', {}).then((res) => {
					this.departNames = res.data.data;
				});
			},
			getDuty: function() { //取职务
				instance.post('/duty/findSimpleDutys', {}).then((res) => {
					this.dutyNames = res.data.data;
				});
			},
			getCourses: function() { //取课程大类数据
				instance.post('/course/findCourses', {}).then((res) => {
					this.coursesNames = res.data.data;
				});
			},
			getRoles: function() { //取角色
				instance.post('/role/findSimpleRoles', {}).then((res) => {
					this.roles = res.data.data;
				});
			},
			changePage: function(pageNum) {
				//  console.info("change-page:" + pageNum);
				this.pageNum = pageNum;
				this.getEmployeeList(this.findEmployee);
			},
			readEmployee: function(id) { //员工查看
				this.$router.push({
					path: `/renshiguanli/readEmployee/${id}`
				});
			},
			updateEmployee: function(id) { //员工编辑
				this.$router.push({
					path: `/renshiguanli/updateEmployee/${id}`
				});
			},

			officialEmployee: function(id) { //员工转正
				this.$confirm('<strong>是否确定将此员工转为正式员工？</strong><br/><em>转正日期默认为当前日期,可再员工详情中进行编辑!</em>', '', {
					dangerouslyUseHTMLString: true
				}).then(() => {
					instance.post('/user/official/' + id, {}).then((res) => {
						if(res.data.errcode == 0) {
							this.$message.success('员工转正成功!');
						} else {
							this.$message.error('操作失败！' + res.data.errmsg);
						}
						//刷新列表
						this.query();
					});
				}).catch(() => {
					this.$message.info('已取消转正操作!');
				});
			},
			leaveEmployee: function(id) { //员工离职
				this.$confirm('<strong>是否确定将此员工离职处理？</strong><br/><span style=color:red;><em>注意:员工离职后,账号将不可使用!<br/>离职日期默认为当前日期,可在员工详情中进行编辑!</em></span>', '', {
					dangerouslyUseHTMLString: true
				}).then(() => {
					instance.post('/user/leave/' + id, {}).then((res) => {
						if(res.data.errcode == 0) {
							this.$message.success('员工离职成功!');
						} else {
							this.$message.error('操作失败！' + res.data.errmsg);
						}
						//刷新列表
						this.query();
					});
				}).catch(() => {
					this.$message.info('已取消离职操作!');
				});
			},
			getModuleActions:function(){
				 let  routeCodes=this.$route.path.split("/");
				  let  routeCode=routeCodes[routeCodes.length-1]; 
					instance.get('/navi/findUserActions2/'+routeCode).then((res) => {
						if(res.data.errcode == '0') {
							this.actionsList=res.data.data;					
						} else {
							//this.$message.error('操作失败！' + res.data.info);
						}
						//console.info("json:" + res.data);

					})
			}
		},
		mounted: function() {
			this.getEmployeeCount(this.findEmployee); //数量
			this.getEmployeeList(this.findEmployee); //列表数据
			this.getSchool(); //校区
			this.getDepartment(); //部门
			this.getDuty(); //职务
			//this.getCourses(); //课程大类
			this.getRoles(); //查询角色
			this.getModuleActions(); //模块操作权限
		}
	};
</script>