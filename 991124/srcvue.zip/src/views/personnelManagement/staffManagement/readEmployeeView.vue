<!--<title>查看员工</title>-->
<style>
	.el-input__inner {
		height: 25px;
	}
</style>
<template>
	<form id="addemployee" method="post" action="" class="ue_form_add">
		<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
        	<span>查看员工(</span>
        	<span class='h5_mark_xx2'>★</span>
        	<span>为必填)</span>
    	</h3>
		<ul class='h5_02_info_per_addlist'>
			<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
        	<span>基本信息</span>
    	    </h3>
			<li>
				<span>★</span>
				<span>姓名:</span>
				<span>{{sources.realName}}</span>
			</li>
			<li>
				<span>★</span>
				<span>性别:</span>
				<span>
           			{{userSexDict[sources.sex]}}
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>出生日期:</span>
				<span>
					{{sources.birthday}}
				</span>
			</li>
			<li>
				<span>★</span>
				<span>手机:</span>
				<span>
    				{{sources.telephone}}
    			</span>
			</li>
			<li>
				<span></span>
				<span>民族:</span>
				<span>
					{{sources.nation}}
				</span>
			</li>
			<li>
				<span></span>
				<span>婚姻状况:</span>
				<span>
            		{{userMarriageDict[sources.marriage]}}
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>学历:</span>
				<span>
		            {{userEducationDict[sources.education]}}
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>身份证号:</span>
				<span>
					{{sources.idNumber}}
				</span>
			</li>
			<li>
				<span>★</span>
				<span>毕业院校:</span>
				<span>
					{{sources.graduate}}
				</span>
			</li>
			<li>
				<span>★</span>
				<span>现住址:</span>
				<span>
					{{sources.address}}
				</span>
			</li>
			<li>
				<span>★</span>
				<span>户籍所在地:</span>
				<span>
					{{sources.domicilePlace}}
				</span>
			</li>
			<br class="p_zwf">
			<li style="width:100%;">
				<span>★</span>
				<span>简历:</span>
				<span>
					<a :href="sources.resumeAttachPath">{{sources.resumeAttachName}}</a>
				</span>
			</li>
			<br class="p_zwf">
			<li style="width:100%;">
				<span></span>
				<span>备注:</span>
				<span>{{sources.descr}}</span>
			</li>
			<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
        	<span>入职信息</span>
    	    </h3>
			<li>
				<span></span>
				<span>账号:</span>
				<span>
					{{sources.username}}
				</span>
			</li>
			<li>
				<span></span>
				<span>初始密码:</span>
				<span>
					
				</span>
			</li>
			<li>
				<span>★</span>
				<span>在职状况:</span>
				<span>
		            {{userWorkingDict[sources.working]}}
				</span>
			</li>
			<li>
				<span>★</span>
				<span>入职校区:</span>
				<span>
					<template v-for="school in sources.schools">
						{{school.schoolName}}
					</template>
				</span>
			</li>
			<br class="p_zwf">
			<li>
				<span></span>
				<span>入职部门:</span>
				<span>
		            {{sources.departmentName}}
				</span>
			</li>
			<li>
				<span></span>
				<span>入职职务:</span>
				<span>
			        {{sources.dutyName}}
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>入职日期:</span>
				<span>
            		{{sources.entryDate}}
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>是否授课:</span>
				<span>
		            {{userTeachDict[sources.teach]}}
    			</span>
			</li>
			<li>
				<span></span>
				<span>转正状态:</span>
				<span>
		            {{userOfficialDict[sources.official]}}
    			</span>
			</li>
			<li>
				<span></span>
				<span>转正日期:</span>
				<span>
					{{sources.officialDate}}
    		</span>
			</li>
			<li>
				<span></span>
				<span>离职日期:</span>
				<span>
            		{{sources.leaveDate}}
    			</span>

			</li>
			<br class="p_zwf">
			<li style="width:100%;">
				<span></span>
				<span>角色:</span>
				<span>
					<template v-for="role in sources.roles">
						{{role.roleName}}
					</template>
				</span>
			</li>
		</ul>
		<br class="p_zwf">
		<div class="p_btn_group p_clear_float">
			<input type="button" value="返回" @click="cancel()" class="p_btn p_btn_siz_2 p_btn_col_ora p_btn_pos_r">
		</div>
	</form>
</template>
<script>
	import instance from '../../../api/index.js';
	import axios from 'axios';
	import { mapState } from 'vuex';
	let Base64 = require('js-base64').Base64; //引入base64算法
	export default {
		props: ['id'], //传入的流水号
		data() {
			return {
				sources: {
					realName: "",
					sex: "",
					birthday: "",
					telephone: "",
					nation: "",
					marriage: "",
					education: "",
					idNumber: "",
					graduate: "",
					address: "",
					domicilePlace: "",
					resume: "",
					working: "0",
					schools: [{
						id: ""
					}],
					departmentName: "",
					departmentId: "",
					dutyId: "",
					entryDate: "",
					teach: "",
					official: "0",
					officialDate: "",
					leaveDate: "",
					roles: [],
					resumeAttachName: "", //附件原始名称
					resumeAttachPath: "", //附件地址
				},
				schoolList: [],
				dutyList: [],
				roleList: [],
				departmentList: [],
				fileList: [],
				rolesArray: []
			};
		},
		created() {
			// 组件创建完后获取数据，
			instance.get('/user/findUser/' + this.id).then((res) => {
				this.sources = res.data.data;

				//附件名称
				this.sources.resumeAttachName = Base64.decode(this.sources.resume.split("_")[1]);
				//附件下载地址
				this.sources.resumeAttachPath = '/api/attach/' + this.sources.resume;
			})
		},
		methods: {
			getSchool: function() { //取入职校区
				instance.post('/school/findSimpleSchools', {}).then((res) => {
					this.schoolList = res.data.data;
				})
			},
			getDuty: function() { //取职务
				instance.post('/duty/findSimpleDutys', {}).then((res) => {
					this.dutyList = res.data.data;
				})
			},
			getRoles: function() { //取角色
				instance.post('/role/findSimpleRoles', {}).then((res) => {
					this.roleList = res.data.data;
				})
			},
			getDepartments: function() { //取入职部门
				instance.post('/dept/findSimpleDepartments', {}).then((res) => {
					this.departmentList = res.data.data;
				})
			},
			cancel: function() {
				//this.$router.go(-1)
				this.$router.push({
					path: `/renshiguanli/yuangongguanli/quanbuyuangong`
				});
			}
		},
		computed: {
			// Getting Vuex State from store/index
			...mapState({
				//用户性别
				userSexDict: state => state.userSexDict,
				//婚姻状况
				userMarriageDict: state => state.userMarriageDict,
				//学历
				userEducationDict: state => state.userEducationDict,
				//在职状况
				userWorkingDict: state => state.userWorkingDict,
				//是否授课
				userTeachDict: state => state.userTeachDict,
				//转正状态
				userOfficialDict: state => state.userOfficialDict,
			})
		},
		mounted: function() {
			this.getDepartments();
			this.getSchool();
			this.getDuty();
			this.getRoles();
		}
	};
</script>