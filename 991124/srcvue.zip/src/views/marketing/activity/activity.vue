<!-- <title>活动管理</title> -->
<style scoped>
.activity {
  width: calc(100% - 40px);
  height: auto;
  padding: 0 20px;
  background: white;
}
.activity_btn {
  outline: none;
  background: none;
  border: 1px solid;
  width: 20px;
  height: 20px;
  margin-bottom: 10px;
}
.activity_btn:hover {
  cursor: pointer;
}
</style>
<template>
    <div class="activity">
        <div class="">
          <step></step>
        </div>
        <div class="activity_mian">
            <button type="button" class="activity_btn" @click="newAdd">+</button>
            <div class="activity_table">
                <el-table
                    :data="tableData"
                    border
                    style="width: 100%">
                    <el-table-column
                    prop="activityNumber"
                    label="活动编号"
                    width="80"
                    align="center"
                    fixed="left">
                    </el-table-column>
                    <el-table-column
                    prop="activityName"
                    label="活动名"
                    width="80"
                    align="center">
                    </el-table-column>
                    <el-table-column
                    prop="activityClass"
                    label="活动分类"
                    width="80"
                    align="center">
                    </el-table-column>
                    <el-table-column
                    prop="activityStart"
                    label="活动开始时间"
                    width="105"
                    align="center">
                    </el-table-column>
                    <el-table-column
                    prop="activityEnd"
                    label="活动截止时间"
                    width="105"
                    align="center">
                    </el-table-column>
                    <el-table-column
                    prop="worksTjStart"
                    label="作品提交开始时间"
                    width="100">
                    </el-table-column>
                    <el-table-column
                    prop="worksTjEnd"
                    label="作品提交截止时间"
                    width="100">
                    </el-table-column>
                    <el-table-column
                    prop="voteStart"
                    label="投票开始时间"
                    width="105"
                    align="center">
                    </el-table-column>
                    <el-table-column
                    prop="voteEnd"
                    label="投票截止时间"
                    width="105"
                    align="center">
                    </el-table-column>
                    <el-table-column
                    prop="SubmiPeopl"
                    label="提交人"
                    width="80"
                    align="center">
                    </el-table-column>
                    <el-table-column
                    prop="SubmiDate"
                    label="提交日期"
                    width="100"
                    align="center">
                    </el-table-column>
                    <el-table-column label="操作" width="150" align="center" fixed="right">
                        <template slot-scope="scope">
                            <el-button
                            size="mini"
                            @click="activityClass(scope.$index, scope.row)">编辑</el-button>
                            <el-button
                            size="mini"
                            type="danger"
                            @click="del(scope.$index, scope.row)">删除</el-button>
                        </template>
                    </el-table-column>
                </el-table>
            </div>
        </div>
    </div>
</template>

<script>
import step from "../step";
export default {
  components: {
    step
  },
  data() {
    return {
      tableData: [
        {
          activityNumber: "0001", //活动编号
          activityName: "歌曲比赛", //活动名
          activityClass: "音乐", //活动分类
          activityStart: "2018-11-28", //活动开始
          activityEnd: "2018-11-28", //活动截止
          worksTjStart: "2018-11-28", //作品提交开始
          worksTjEnd: "2018-11-28", //作品提交截止
          voteStart: "2018-11-28", //投票开始
          voteEnd: "2018-11-28", //投票截止
          SubmiPeopl: "零", //提交人
          SubmiDate: "2018-11-28" //提交时间
        },
        {
          activityNumber: "0001", //活动编号
          activityName: "歌曲比赛", //活动名
          activityClass: "音乐", //活动分类
          activityStart: "2018-11-28", //活动开始
          activityEnd: "2018-11-28", //活动截止
          worksTjStart: "2018-11-28", //作品提交开始
          worksTjEnd: "2018-11-28", //作品提交截止
          voteStart: "2018-11-28", //投票开始
          voteEnd: "2018-11-28", //投票截止
          SubmiPeopl: "零", //提交人
          SubmiDate: "2018-11-28" //提交时间
        }
      ]
    };
  },
  methods: {
    //新增活动
    newAdd() {
      this.$router.push("/toupiaoguanli/huodongguanli/addActivity");
    },
    activityClass(index,row){
      this.$router.push("/toupiaoguanli/huodongguanli/activityClass");
       console.log(index, row);
    },

    //删除
    del() {
      this.$confirm("是否确认删除此条活动", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
        center: true
      })
        .then(() => {
          this.$message({
            type: "success",
            message: "删除成功!"
          });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    }
  }
};
</script>