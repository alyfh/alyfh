<!-- <title></title> -->
<style scoped>
ul>li{
    margin: 5px 0;
}
</style>
<template>
    <div class="activityClass">
        活动编辑
        <ul style="width: 300px;text-align: right;">
            <li v-for="i in tree">
                <span>{{i.title}}</span><input type="text" name="" id="" style="width: 190px;"><button @click="add">add</button>
                <ul>
                    <li v-for="sub in i.children">
                        <span>{{sub.title}}</span><input type="text" name="" id="" style="width: 170px;">
                        <ul>
                            <li v-for="subi in sub.children">
                                <span>{{subi.title}}</span><input type="text" name="" id="" style="width: 150px;">
                            </li>
                        </ul>
                    </li>
                </ul>
            </li>
        </ul>
    </div>
</template>
<script>
export default {
  data() {
    return {
      tree: [
        {
          id: "1",
          title: "父级",
          children: [
            {
              id: "2",
              title: "子级",
              children: [
                {
                  id: "2_1",
                  title: "子子级"
                }
              ]
            }
          ]
        },
        {
          id: "3",
          title: "父级"
        }
      ]
    };
  },
  methods:{
      add(){
          this.tree.push({id: "1",title: "父级"})
      }
  }
};
</script>