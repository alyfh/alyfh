<!-- <title>新增活动</title> -->
<style scoped>
.addActivity {
  width: calc(100% - 40px);
  height: auto;
  padding: 0 20px;
  background: white;
}
.addActivity_head {
  font-size: 25px;
  font-weight: bold;
  text-align: center;
  line-height: 50px;
}
.addActivity_mian {
  width: 100%;
}
.ul_automatic {
  overflow: hidden;
}
.ul_automatic li {
  float: left;
  width: 33%;
}
.ul_automatic li p {
  display: inline-block;
  font-size: 0.9rem;
}
.title {
  font-size: 0.9rem;
}
.ul_noAutomatic {
  overflow: hidden;
}
.ul_noAutomatic li {
  float: left;
  margin: 5px 0;
  margin-right: 20px;
}
.ul_noAutomatic li p{
    display: inline-block;
}
.activity_date{
    width: 300px;
}
</style>
<template>
    <div class="addActivity">
        <div>  
            <step></step>
        </div>
        <div class="addActivity_head">
            <h3>新增活动</h3>
        </div>
        <div class="addActivity_mian">
            <div class="addActivity_mian_top">
                <ul class="ul_automatic">
                    <li>
                        <span class="title">活动编号:</span>
                        <p>000001</p>
                    </li>
                    <li>
                        <span class="title">提交人:</span>
                        <p>零</p>
                    </li>
                    <li>
                        <span class="title">提交日期:</span>
                        <p>2018年11月28日</p>
                    </li>
                </ul>
            </div>
            <div class="addActivity_mian_bottom">
                <ul class="ul_noAutomatic">
                    <li>
                        <p><span style="color: red;">*</span>活动名: <el-input class="activity_input" size="mini" placeholder="请输入内容" style="width: 550px;"></el-input></p>
                    </li>
                    <li>
                        <p><span style="color: red;">*</span>活动分类:</p>
                        <el-select v-model="value" class="activity_select" placeholder="请选择" size="mini">
                            <el-option
                                v-for="item in options"
                                :key="item.value"
                                :label="item.label"
                                :value="item.value">
                            </el-option>
                        </el-select>
                        <el-button size="mini">编辑</el-button>
                    </li>
                    <li>
                        <p><span style="color: red;">*</span>活动开始时间:</p>
                        <el-date-picker
                            v-model="value1"
                            type="datetime"
                            placeholder="选择日期时间"
                            class="activity_date"
                            size="mini">
                        </el-date-picker>
                    </li>
                    <li>
                        <p><span style="color: red;">*</span>活动截止时间:</p>
                        <el-date-picker
                            v-model="value2"
                            type="datetime"
                            placeholder="选择日期时间"
                            class="activity_date"
                            size="mini">
                        </el-date-picker> 
                    </li>
                    <li>
                        <p><span style="color: red;">*</span>作品提交开始时间:</p>
                        <el-date-picker
                            v-model="value3"
                            type="datetime"
                            placeholder="选择日期时间"
                            class="activity_date"
                            style="width:275px;"
                            size="mini">
                        </el-date-picker> 
                    </li>
                    <li>
                        <p><span style="color: red;">*</span>作品提交截止时间:</p>
                        <el-date-picker
                            v-model="value4"
                            type="datetime"
                            placeholder="选择日期时间"
                            class="activity_date"
                            style="width:275px;"
                            size="mini">
                        </el-date-picker> 
                    </li>
                    <li>
                        <p><span style="color: red;">*</span>投票开始时间:</p>
                        <el-date-picker
                            v-model="value5"
                            type="datetime"
                            placeholder="选择日期时间"
                            class="activity_date"
                            size="mini">
                        </el-date-picker> 
                    </li>
                    <li>
                        <p><span style="color: red;">*</span>投票截止时间:</p>
                        <el-date-picker
                            v-model="value6"
                            type="datetime"
                            placeholder="选择日期时间"
                            class="activity_date"
                            size="mini">
                        </el-date-picker> 
                    </li>
                    <li>
                        <p style="width: 100%;"><span style="color: red;">*</span>活动规则:</p>
                        <el-input
                            type="textarea"
                            :rows="2"
                            placeholder="请输入内容"
                            v-model="textarea"
                            style="width: 950px;"
                            :autosize="{ minRows: 4, maxRows: 4}">
                        </el-input>
                    </li>
                    <li>
                        <p style="width: 100%;"><!--<span style="color: red;">*</span>-->备注:</p>
                        <el-input
                            type="textarea"
                            :rows="2"
                            placeholder="请输入内容"
                            v-model="textarea2"
                            style="width: 950px;">
                        </el-input>
                    </li>
                </ul>
            </div>
        </div>
        <div class="" style="text-align: center;padding: 10px 0 15px;">
            <el-button style="background: #03a9f4;color:white;width: 120px;margin-right: 100px;" @click="cancel()">确认</el-button>
            <el-button style="width: 120px;" @click="cancel()">取消</el-button>
        </div>
    </div>
</template>
<script>
import step from "../step";
export default {
  components: {
    step
  },
  data() {
    return {
      options: [
        {
          value: "选项1",
          label: "投票后有奖品"
        },
        {
          value: "选项2",
          label: "投票后没奖品"
        }
      ],
      value: "",
      value1: '',
      value2: '',
      value3: '',
      value4: '',
      value5: '',
      value6: '',
      textarea: ''
    };
  }
};
</script>