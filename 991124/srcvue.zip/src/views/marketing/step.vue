<!-- <title>步骤</title> -->
<style scoped>
.step_con{
    padding: 25px 0 50px;
    position: relative;
}
.step_xian{
    width: 80%;
    border-top: 1px solid #ccc;
}
.step_con ul{
    overflow: hidden;
    position: absolute;
    left: 0;
    top: 20px;
    width: 100%;
}
.step_con ul li{
    width: 16%;
    float: left;
}
</style>
<template>
    <div class="step">
        <div class="step_con">
            <div class="step_xian"></div>
            <ul>
                <li>
                    <input type="radio" name="step_radio" disabled id="" :checked="a">
                    <p>1.新增活动分类</p>
                </li>
                <li>
                    <input type="radio" name="step_radio" disabled id="" :checked="xzhd">
                    <p>2.新增活动</p>
                </li>
                <li>
                    <input type="radio" name="step_radio" disabled id="">
                    <p>3.新增活动作品</p>
                </li>
                <li>
                    <input type="radio" name="step_radio" disabled id="" :checked="fbzp">
                    <p>4.发布作品</p>
                </li>
                <li>
                    <input type="radio" name="step_radio" disabled id="" >
                    <p>5.投票</p>
                </li>
                <li>
                    <input type="radio" name="step_radio" disabled id="" :checked="tjfx">
                    <p>6.统计分析</p>
                </li>
            </ul>
        </div>
    </div>
</template>
<script>
export default {
    data () {
        return {
            a: false,
            xzhd: false,
            fbzp: false,
            tjfx: false
        }
    },
    mounted() {
        this.radioChecked();
    },
    methods: {
        radioChecked(){
            // alert(this.$route.path)
            if(this.$route.path=="/toupiaoguanli/zuopinguanli/comment") this.a = true
            else this.a = false
            if(this.$route.path=="/toupiaoguanli/huodongguanli/addActivity") this.xzhd = true
            else this.xzhd = false
            if(this.$route.path=="/toupiaoguanli/zuopinguanli/releaseWorks") this.fbzp = true
            else this.fbzp = false
            if(this.$route.path=="/tongjibaobiao/toupiaotongjifenxi/zuopintongji") this.tjfx = true
            else this.tjfx = false
        }
    }
}
</script>
