<!-- <title>作品评论管理</title> -->
<style scoped>
.comment {
  width: calc(100% - 40px);
  height: auto;
  padding: 0 20px;
  background: white;
}
.comment_head {
  font-size: 25px;
  font-weight: bold;
  text-align: center;
  line-height: 50px;
}
</style>
<template>
  <div class="comment">
      <div class="">
          <step></step>
      </div>
      <div class="comment_head">
            <h3>发布作品</h3>
      </div>
      <div class="comment_mian">
          <div class="comment_mian_top" style="margin-bottom: 10px;">
            <el-input v-model="search" size="mini" placeholder="输入关键字搜索" style="width:300px;"/>
            <el-button size="mini" @click="del">搜索</el-button>
            <el-button size="mini" @click="releaseWorks">关键字维护</el-button>
            <el-button size="mini">批量隐藏</el-button>
            <el-button size="mini" @click="del">批量删除</el-button>
          </div>
          <div class="comment_mian_bottom">
            <!-- .filter(data => !search || data.commentContent.toLowerCase().includes(search.toLowerCase())) -->
            <el-table
              :data="commentData"
              style="width: 100%"
              border>
              <el-table-column
                label="选择"
                align="center">
                <template slot-scope="scope">{{scope.row.serialNumber}}{{commentDataDel}}
                  <input type="checkbox" name="" :id="scope.row.serialNumber" :value="scope.row.serialNumber" v-model="commentDataDel">
                </template>
              </el-table-column>
              <el-table-column
                label="序号"
                prop="serialNumber"
                align="center">
              </el-table-column>
              <el-table-column
                label="作品号"
                prop="worksNumber"
                align="center">
              </el-table-column>
              <el-table-column
                label="作品名"
                prop="worksName"
                align="center">
              </el-table-column>
              <el-table-column
                label="作者"
                prop="author"
                align="center">
              </el-table-column>
              <el-table-column
                label="评论时间"
                prop="commentaryTime"
                align="center">
              </el-table-column>
              <el-table-column
                label="评论人昵称"
                prop="commentatorName"
                align="center">
              </el-table-column>
              <el-table-column
                label="评论内容"
                prop="commentContent"
                align="center">
              </el-table-column>
              <el-table-column
                align="center"
                label="显示状态">
                <template slot-scope="scope">
                    <input type="radio" name="a" id="i" @click="handleEdit(scope.$index, scope.row.id)">
                    显示
                    <input type="radio" name="a" id="l" @click="handleEdit(scope.$index, scope.row.id)">
                    隐藏
                  <!-- <el-button
                    size="mini"
                    @click="handleEdit(scope.$index, scope.row.date)">Edit</el-button>
                  <el-button
                    size="mini"
                    type="danger"
                    @click="handleDelete(scope.$index, scope.row)">Delete</el-button> -->
                </template>
              </el-table-column>
            </el-table>
          </div>
      </div>
  </div>
</template>

<script>
import step from "../step";
export default {
  components: {
    step
  },
  data() {
    return {
      search: "",
      commentData: [
        {
          id: "1",
          serialNumber: "1", //序号
          worksNumber: "0001", //作品号
          worksName: "零", //作品名
          author: "零", //作者
          commentaryTime: "2018-11-30", //评论时间
          commentatorName: "零", //评论人昵称
          commentContent: "aaa啊啊" //评论内容
        },
        {
          id: "2",
          serialNumber: "2", //序号
          worksNumber: "0001", //作品号
          worksName: "零", //作品名
          author: "零", //作者
          commentaryTime: "2018-11-30", //评论时间
          commentatorName: "零", //评论人昵称
          commentContent: "啊啊啊啊" //评论内容
        },
        {
          id: "3",
          serialNumber: "3", //序号
          worksNumber: "0001", //作品号
          worksName: "零", //作品名
          author: "零", //作者
          commentaryTime: "2018-11-30", //评论时间
          commentatorName: "零", //评论人昵称
          commentContent: "啊啊1123啊啊" //评论内容
        }
      ],
      commentDataDel: []
    };
  },

  methods: {
    //关键字维护
    releaseWorks(){
      this.$router.push("/xitongshezhi/xitongshezhi_pinlunguanjianziweihu");
    },
    handleEdit(index, row) {
      console.log(index, row);
    },
    //删除
    del() {
      this.$confirm("此操作将永久删除该文件, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "再想想",
        type: "warning"
      })
        .then(() => {
          this.$message({
            type: "success",
            message: "删除成功"
          });
          var commentData = this.commentData;
          var commentDataDel = this.commentDataDel;
          /*循环查找选中项*/
          commentDataDel.forEach(function(itemDel, index) {
            commentData.forEach(function(itemList, i) {
              if (itemList.id == itemDel) {
                commentData.splice(i, 1);
              }
            });
          });
          this.commentData = commentData;
          this.commentDataDel = [];
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    }
  }
};
</script>
