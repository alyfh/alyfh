<!-- <title>发布作品</title> -->
<style scoped>
.releaseWorks {
  width: calc(100% - 40px);
  height: auto;
  padding: 0 20px;
  background: white;
}
.releaseWorks_head {
  font-size: 25px;
  font-weight: bold;
  text-align: center;
  line-height: 50px;
}
.releaseWorks_mian_top ul {
  overflow: hidden;
}
.releaseWorks_mian_top ul li {
  float: left;
  width: 350px;
  margin: 8px 0;
}
.releaseWorks_mian_top ul li p {
  display: inline-block;
  line-height: 28px;
}
.releaseWorks_mian_bottom ul {
  overflow: hidden;
}
.releaseWorks_mian_bottom ul li {
  float: left;
  width: 350px;
  margin: 8px 0;
}
.releaseWorks_mian_bottom ul li p {
  display: inline-block;
  line-height: 28px;
  margin-bottom: 5px;
}
.zpImg {
  width: 340px;
  height: 159px;
  background: lime;
  background-image: url("~@/../static/img/zpimgbj.png");
  background-size: 100% 100%;
}
.zpImg img {
  width: 100%;
  height: 100%;
}
</style>
<template>
    <div class="releaseWorks">
        <div class="">
            <step></step>
        </div>
        <div class="releaseWorks_head">
            <h3>发布作品</h3>
        </div>
        <div class="releaseWorks_mian">
            <div class="releaseWorks_mian_top">
                <ul class="">
                    <li>
                        <p><span style="color:red;">*</span>所属活动:</p>
                        <el-select v-model="releaseWorks.sshdValue" placeholder="请选择" size="mini">
                            <el-option
                            v-for="item in sshdOptions"
                            :key="item.sshdValue"
                            :label="item.sshdLabel"
                            :value="item.sshdValue">
                            </el-option>
                        </el-select>
                    </li>
                    <li style="width: 150px;">
                        <p><span></span>作品号: <span>1</span></p>
                    </li>
                    <li>
                        <p><span style="color:red;">*</span>作品分类:</p>
                        <el-select v-model="releaseWorks.zpflValue" placeholder="请选择" size="mini">
                            <el-option
                            v-for="item in zpflOptions"
                            :key="item.zpflValue"
                            :label="item.zpflLabel"
                            :value="item.zpflValue">
                            </el-option>
                        </el-select>
                        <el-button size="mini">编辑</el-button>
                    </li>
                </ul>
            </div>
            <div class="releaseWorks_mian_bottom">
                <ul>
                    <li>
                        <p><span style="color:red;">*</span>作品名:</p>
                        <el-input v-model="releaseWorks.worksName" placeholder="请输入内容" style="width: 200px;" size="mini"></el-input>
                    </li>
                    <li style="width: 330px;">
                        <p><span style="color:red;">*</span>作者:</p>
                        <el-input v-model="releaseWorks.name" placeholder="请输入内容" style="width: 200px;" size="mini"></el-input>
                    </li>
                    <li>
                        <p><span style="color:red;">*</span>年龄</p>
                        <el-input v-model="releaseWorks.age" placeholder="请输入内容" style="width: 100px;" size="mini"></el-input>
                    </li>
                    <li>
                        <p><span></span>推荐校区</p>
                        <el-select v-model="releaseWorks.tjxqValue" placeholder="请选择" size="mini">
                            <el-option
                            v-for="item in tjxqOptions"
                            :key="item.tjxqValue"
                            :label="item.tjxqLabel"
                            :value="item.tjxqValue">
                            </el-option>
                        </el-select>
                    </li>
                    <li>
                        <p><span></span>指导教师</p>
                        <el-select v-model="releaseWorks.zdjsValue" placeholder="请选择" size="mini">
                            <el-option
                            v-for="item in zdjsOptions"
                            :key="item.zdjsValue"
                            :label="item.zdjsLabel"
                            :value="item.zdjsValue">
                            </el-option>
                        </el-select>
                    </li>
                    <li style="width: 480px;">
                        <p><span style="color:red;">*</span>作品预览:</p>
                        <el-upload
                            class="upload-demo"
                            action="https://jsonplaceholder.typicode.com/posts/"
                            :on-preview="handlePreview"
                            :on-remove="handleRemove"
                            :before-remove="beforeRemove"
                            multiple
                            :limit="3"
                            :on-exceed="handleExceed"
                            :file-list="fileList" 
                            style="display: inline-block;">
                            <el-button size="small" type="primary" style="background: white;border: 1px solid #ccc;color:#ccc;">+</el-button>
                        </el-upload>
                        <el-button size="mini">x</el-button>
                        <div class="zpImg">
                            <img src="" alt="">        
                        </div>
                    </li>
                    <li style="width: 480px;">
                        <p style="width: 100%;"><span style="color:red;">*</span>作品简介:</p>
                        <el-input
                        type="textarea"
                        :rows="2"
                        placeholder="请输入内容"
                        v-model="textarea"
                        style="width: 340px;"
                        :autosize="{ minRows: 7, maxRows: 7}">
                        </el-input>
                    </li>
                </ul>
            </div>
        </div>
        <div class="" style="text-align: center;padding: 10px 0 15px;">
            <el-button style="width: 120px;margin-right: 200px;" @click="addKword()">确认</el-button>
            <el-button style="width: 120px;margin-right: 350px;" @click="cancel()">取消</el-button>
        </div>
    </div>
</template>
<script>
import step from "../step";
export default {
  components: {
    step
  },
  data() {
    return {
      sshdOptions: [
        {
          sshdValue: "歌曲", //所属活动
          sshdLabel: "歌曲"
        },
        {
          sshdValue: "跳舞",
          sshdLabel: "跳舞"
        },
        {
          sshdValue: "呆",
          sshdLabel: "呆"
        }
      ],
      zpflOptions: [
        {
          zpflValue: "歌曲1", //作品分类
          zpflLabel: "歌曲1"
        },
        {
          zpflValue: "跳舞1",
          zpflLabel: "跳舞1"
        },
        {
          zpflValue: "呆1",
          zpflLabel: "呆1"
        }
      ],
      tjxqOptions:[{
          tjxqValue: "1",
          tjxqLabel: "1"
      }],
      zdjsOptions:[{
          zdjsValue: "1",
          zdjsLabel: "1"
      }],
      
      releaseWorks: [{
        sshdValue: "",  //所属活动
        zpflValue: "",  //作品分类
        worksName: "",  //作品名
        name: "",  //作者
        age: "",  //年龄
        tjxqValue: "",  //推荐校区
        zdjsValue: ""
      }],
      fileList: [],
      textarea: ""
    };
  },
  methods: {
    handleRemove(file, fileList) {
      console.log(file, fileList);
    },
    handlePreview(file) {
      console.log(file);
    },
    handleExceed(files, fileList) {
      this.$message.warning(
        `当前限制选择 3 个文件，本次选择了 ${
          files.length
        } 个文件，共选择了 ${files.length + fileList.length} 个文件`
      );
    },
    beforeRemove(file, fileList) {
      return this.$confirm(`确定移除 ${file.name}？`);
    }
  }
};
</script>