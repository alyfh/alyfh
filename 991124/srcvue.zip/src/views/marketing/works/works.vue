<!-- <title>作品管理</title> -->
<style scoped>
.works {
  width: calc(100% - 40px);
  height: auto;
  padding: 0 20px;
  background: white;
}
.works_btn {
  outline: none;
  background: none;
  border: 1px solid;
  width: 20px;
  height: 20px;
  margin-bottom: 10px;
}
</style>
<template>
    <div class="works">
        <div class="">
          <step></step>
        </div>
        <div class="works_mian">
            <button type="button" class="works_btn" @click="newAdd">+</button>
            <div class="works_table">
                <el-table
                    :data="tableData"
                    border
                    style="width: 100%">
                    <el-table-column
                    prop="date"
                    label="所属活动"
                    width="78"
                    align="center"
                    fixed="left">
                    </el-table-column>
                    <el-table-column
                    prop="worksNumber"
                    label="作品号"
                    width="70"
                    align="center">
                    </el-table-column>
                    <el-table-column
                    prop="worksName"
                    label="作品名"
                    width="70"
                    align="center">
                    </el-table-column>
                    <el-table-column
                    prop="name"
                    label="作者"
                    width="100"
                    align="center">
                    </el-table-column>
                    <el-table-column
                    prop="age"
                    label="年龄"
                    width="50"
                    align="center">
                    </el-table-column>
                    <el-table-column
                    prop="worksClass"
                    label="作品分类"
                    width="100"
                    align="center">
                    </el-table-column>
                    <el-table-column
                    prop="name"
                    label="推荐校区"
                    width="100"
                    align="center">
                    </el-table-column>
                    <el-table-column
                    prop="name"
                    label="指导教师"
                    width="100"
                    align="center">
                    </el-table-column>
                    <el-table-column
                    prop="name"
                    label="作品预览"
                    width="105"
                    align="center">
                    </el-table-column>
                    <el-table-column
                    prop="SubmiPeopl"
                    label="提交人"
                    width="100"
                    align="center">
                    </el-table-column>
                    <el-table-column
                    prop="SubmiDate"
                    label="提交日期"
                    width="100"
                    align="center">
                    </el-table-column>
                    <el-table-column label="操作" width="260" align="center" fixed="right">
                        <template slot-scope="scope">
                            <el-button
                            size="mini"
                            @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
                            <el-button
                            size="mini"
                            @click="comment(scope.$index, scope.row)">评论管理</el-button>
                            <el-button
                            size="mini"
                            type="danger"
                            @click="handleDelete(scope.$index, scope.row)">删除</el-button>
                        </template>
                    </el-table-column>
                </el-table>
            </div>
        </div>
    </div>
</template>

<script>
import step from "../step"
export default {
  components:{
    step
  },
  data() {
    return {
      tableData: [
        {
          date: '2016-05-04',
          name: '王虎',
          address: '上海市普'
        }
      ]
    };
  },
  methods: {
    //新增作品
    newAdd() {
      this.$router.push("/toupiaoguanli/zuopinguanli/releaseWorks");
    },
    comment(index,row) {
      alert(index, row);
      this.$router.push("/toupiaoguanli/zuopinguanli/comment");
    },
    handleEdit(index, row) {
      console.log(index, row);
    },
    handleDelete(index, row) {
      console.log(index, row);
    }
  }
};
</script>