<!--<title>新增咨询</title>-->
<style scoped>
	.el-input__inner {
		height: 25px;
	}
</style>
<template>
	<form id="addstu" method="post" action="" class="ue_form_add">
		<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
        	<span>编辑咨询(</span>
        	<span class='h5_mark_xx2'>★</span>
        	<span>为必填)</span>
    	</h3>
		<ul class='h5_02_info_per_addlist'>
			<li>
				<span>★</span>
				<span>姓名:</span>
				<span><input type="text" class='per_addperson_txt' v-model="adviceDetail.studentName"></span>
			</li>
			<li>
				<span>★</span>
				<span>性别:</span>
				<span>
					 <select name=""  class='per_addperson_txt' v-model="adviceDetail.sex">
                       <option value="男">男</option>
                       <option value="女">女</option>
                   </select>
				</span>
			</li>
			<li>
				<span>★</span>
				<span>年龄:</span>
				<span><input type="text" class='per_addperson_txt' v-model="adviceDetail.age"></span>
			</li>
			<li>
				<span>★</span>
				<span>联系人手机:</span>
				<span>
    				<input type="text"class='per_addperson_txt' v-model="adviceDetail.telephone">

    			</span>
			</li>
			<li>
				<span>★</span>
				<span>与之关系:</span>
				<span>
          <!--<input type="text" class='per_addperson_txt' v-model="adviceDetail.relationShip">-->
          <select name="" id="" class='per_addperson_txt' v-model="adviceDetail.relationShip">
    				  <option  value="" >请选择</option>
              <option value="爸爸">爸爸</option>
              <option value="妈妈">妈妈</option>
              <option value="祖父母">祖父母</option>
              <option value="其他">其他</option>
            </select>
        </span>
			</li>
			<li>
				<span></span>
				<span>邮箱:</span>
				<span>
    				<input type="text" class='per_addperson_txt' v-model="adviceDetail.email">

    			</span>
			</li>

			<li>
				<span></span>
				<span>QQ:</span>
				<span>
    				<input type="text" class='per_addperson_txt' v-model="adviceDetail.qq">
    			</span>
			</li>
			<li>
				<span></span>
				<span>微信:</span>
				<span><input type="text" class='per_addperson_txt' v-model="adviceDetail.wechat"></span>
			</li>

			<li>
				<span>★</span>
				<span>来源大类:</span>
				<span>
    				<select name="" id="" class='per_addperson_txt' v-model="adviceDetail.sourceId" @change="getSourceSub(adviceDetail.sourceId,1)">
                <option disabled value="">请选择</option>
                <option v-for="sourceName in sourceNames" :value="sourceName.id">{{sourceName.sourceName}}</option>
            </select>
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>来源小类:</span>
				<span>
    				<select name="" id="" class='per_addperson_txt' v-model="adviceDetail.sourceSubId">
              <option v-for="sourceSubName in sourceNameSubs" :value="sourceSubName.id">{{sourceSubName.sourceSubName}}</option>
            </select>
    			</span>
			</li>

			<li>
				<span>★</span>
				<span>课程大类:</span>
				<span>
    				<select  class='per_addperson_txt' v-model="adviceDetail.courseId" @change="getClassSub(adviceDetail.courseId,adviceDetail.schoolId,1)">
                <option disabled value="">请选择</option>
                <option v-for="className in classNames" :value="className.id">{{className.courseName}}</option>
            </select>
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>课程小类:</span>
				<span>
    				<select name="" id="" class='per_addperson_txt' v-model="adviceDetail.courseSubId">
              <option v-for="classNameSub in classNameSubs" :value="classNameSub.id">{{classNameSub.courseSubName}}</option>
            </select>
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>所属校区:</span>
				<span>
    				<select name=""  class='per_addperson_txt' v-model="adviceDetail.schoolId" @change="getQueryInfo(adviceDetail.schoolId,1)">
    						 <option  value="">请选择</option>
              <option v-for="sName in schoolNames" :value="sName.id">{{ sName.schoolName }}</option>
            </select>
    			</span>
			</li>
			<li>
				<span></span>
				<span>咨询师:</span>
				<span>
    				<select name="" id="" class='per_addperson_txt' v-model="adviceDetail.counselorId">
              <option v-for="counselorName in counselorNames" :value="counselorName.id">{{counselorName.realName}}</option>
            </select>
    			</span>
			</li>
			<li>
				<span></span>
				<span>课程顾问:</span>
				<span>
    				<select name="" id="" class='per_addperson_txt' v-model="adviceDetail.courseCounselorId">
              <option v-for="consultant in consultants" :value="consultant.id">{{consultant.realName}}</option>
            </select>
    			</span>
			</li>
			<li>
				<span></span>
				<span>主动联系:</span>
				<span>
    				<select name="" id="" class='per_addperson_txt' v-model="adviceDetail.initiative">
    				  <option  value="">请选择</option>
              <option value="0">是</option>
              <option value="1">否</option>
            </select>
    			</span>
			</li>

			<li>
				<span></span>
				<span>推荐人:</span>
				<span><input type="text" class='per_addperson_txt' v-model="adviceDetail.referrerName"></span>
			</li>
			<li>
				<span>★</span>
				<span>线索状态:</span>
				<span>
    				<select name="" id="" class='per_addperson_txt' v-model="adviceDetail.status">
             <option  value="">请选择</option>
            <option v-for = "(item,key) in adviceStatus" :value="key">{{item}}</option>
            </select>
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>客户等级:</span>
				<span>
    				<select name="" id="" class='per_addperson_txt' v-model="adviceDetail.studentLevel">
              <option  value="">请选择</option>
              <option v-for = "(item,key) in adviceLevel" :value="key">{{item}}</option>
            </select>
    			</span>
			</li>
			<li>
				<span></span>
				<span>所属活动:</span>
				<span><input type="text" class='per_addperson_txt' v-model="adviceDetail.fromEvent"></span>
			</li>

			<li>
				<span></span>
				<span>家庭住址(省):</span>
				<span>
    				<select name="" id="" class='per_addperson_txt' v-model="adviceDetail.provinceId" @change="getCity(adviceDetail.provinceId)">
              <option v-for="province in provinces" :value="province.adcode">{{province.name}}</option>
            </select>
    			</span>
			</li>
			<li>
				<span></span>
				<span>市:</span>
				<span>
    				<select name="" id="" class='per_addperson_txt' v-model="adviceDetail.cityId" @change="getDistrict(adviceDetail.cityId)">
              <option v-for="city in citys" :value="city.adcode">{{city.name}}</option>
            </select>
    			</span>
			</li>
			<li>
				<span></span>
				<span>区县:</span>
				<span>
    				<select name="" id="" class='per_addperson_txt' v-model="adviceDetail.areaId">
              <option v-for="district in districts" :value="district.adcode">{{district.name}}</option>
            </select>
    			</span>
			</li>
			<li>
				<span></span>
				<span>小区:</span>
				<span><input type="text" class='per_addperson_txt' v-model="adviceDetail.biotope"></span>
			</li>
			<li>
				<span></span>
				<span>详细地址:</span>
				<span><input type="text" class='per_addperson_txt' v-model="adviceDetail.address"></span>
			</li>
			<li>
				<span></span>
				<span>就读学校:</span>
				<span><input type="text" class='per_addperson_txt' v-model="adviceDetail.school"></span>
			</li>
			<li>
				<span>★</span>
				<span>班级类别:</span>
				<span>
    				<select name="" id="" class='per_addperson_txt' v-model="adviceDetail.classType">
              <option  value="">请选择</option>
              <option value="0">一对一</option>
               <option value="1">一对多</option>
            </select>
    			</span>
			</li>
			<li>
				<span></span>
				<span>备注:</span>
				<span><input type="text" class='per_addperson_txt' v-model="adviceDetail.descr"></span>
			</li>
			<br class="p_zwf">
			<li class="per_addperson_li_w per_addperson_li_h2" style="color:red;height:40px">
				<span></span>
				<span>说明:</span>
				<span>咨询师/课程顾问二者必填其中一项</span>
			</li>
		</ul>

		<br class="p_zwf">
		<div class="p_btn_group p_clear_float">
			<!--<input type="button" value="返回"  class="p_btn p_btn_siz_2 p_btn_col_red p_btn_pos_r">-->
			<!--<router-link :to="{path:activeMenu.path+'/'+route.path+'/'+cRoute.path}">{{cRoute.name}}</router-link>-->
			<input type="button" value="返回" @click="$router.go(-1)" class="p_btn p_btn_siz_2 p_btn_col_ora p_btn_pos_r">
			<input type="button" value="保存" @click="saveAdvice(adviceDetail)" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r">
		</div>
	</form>
</template>
<script>
	import instance from '../../../api/index.js';
	import * as util from '../../../assets/util.js';
	import { mapState } from 'vuex';
	import axios from 'axios';
	export default {
		props: ['id'],
		data() {
			return {
				adviceDetail: {
					initiative: "",
					courseId: "",
					sourceId: ""
				},
				schoolNames: [],
				classNames: [],
				classNameSubs: [],
				sourceNames: [],
				sourceNameSubs: [],
				counselorNames: [], //咨询师
				consultants: [], //课程顾问
				provinces: [], //全国省份
				citys: [], //当前选中省份下的所有城市
				districts: [] //当前选 中城市下的所有区县
			};
		},

		computed: {
			// Getting Vuex State from store/index
			...mapState({
				cityJson: state => state.cityJson,
				adviceStatus: state => state.adviceStatus,
				adviceLevel: state => state.adviceLevel,
			})
		},
		created() {
			// 组件创建完后获取数据，
			// 此时 data 已经被 observed 了
			instance.get('/infor/findInformation/' + this.id).then((res) => {
				this.adviceDetail = res.data.data;
				if(this.adviceDetail.courseId != "")
					this.getClassSub(this.adviceDetail.courseId,this.adviceDetail.schoolId, 0);

				if(this.adviceDetail.sourceId != "")
					this.getSourceSub(this.adviceDetail.sourceId, 0);

				if(this.adviceDetail.schoolId != "") {
					this.getQueryInfo(this.adviceDetail.schoolId, 0);
				}

				this.getCity(this.adviceDetail.provinceId);
				this.getDistrict(this.adviceDetail.cityId);
			})
		},
		methods: {
			saveAdvice: function(item) {

				item.id ? this.updateAdvice(item) : this.createAdvice(item)
			},
			createAdvice: function(item) {
				instance.post('/infor/createInformation', item).then((res) => {
					if(res.data.errcode == '0') {
						this.$message.info('信息创建成功！');
						this.adviceDetail.id = res.data.data.id;
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}
				})
			},
			updateAdvice: function(item) {
				instance.post('/infor/changeInformation', item).then((res) => {
					if(res.data.errcode == '0') {
						this.$message.info('信息修改成功！');
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}
				})
			},

			getSchool: function() { //获取校区数据
				//获取当前登录人
				let loginInfo = util.session("loginInfo");
				instance.get('/school/findUserSchools/' + loginInfo.login.userId).then((res) => {

					if(res.data.data != null && res.data.data != "") {
						this.schoolNames = res.data.data;
					}
				})

			},
			getClass: function(schoolId,type) { //获取课程大类数据
				// course/findCourses
				// /course/findSimpleCourse
				if(type == 1) { //值变更
					this.adviceDetail.courseId = "";
					this.adviceDetail.courseName = "";
				}
				instance.post('/course/findCourses', {qSchoolId:schoolId}).then((res) => {
					this.classNames = res.data.data;
				})
			},
			getClassSub: function(id,schoolId,type) { //获取课程小类数据
				// /course/findSimpleCourseSubs
				if(type == 1) { //值变更
					this.adviceDetail.courseSubId = "";
					this.adviceDetail.courseSubName = "";
				}
				instance.post('/course/findSimpleCourseSubs', {
					qCourseId: id,
					qSchoolId:schoolId
				}).then((res) => {
					this.classNameSubs = res.data.data;
					// console.info(res.data);
				})
			},
			getSource: function() { //获取来源大类数据
				instance.post('/source/findSimpleSources', {}).then((res) => {
					this.sourceNames = res.data.data;
				})
			},
			getSourceSub: function(id, type) { //获取来源小类数据
				// alert(id);
				if(type == 1) { //值变更
					this.adviceDetail.sourceSubId = "";
					this.adviceDetail.sourceSubName = "";
				}
				instance.get('/source/findSourceSubs4Source/' + id).then((res) => {
					this.sourceNameSubs = res.data.data;
				})
			},
			getConsult: function(schoolId, type) { //获取咨询师列表
				instance.post('/user/findSystemRoleSimpleUser', {
					qSchoolId: schoolId,
					qRoleCode: "counselor",
				}).then((res) => {
					this.counselorNames = res.data.data;

				})
			},
			getconsultant: function(schoolId, type) { //获取课程顾问列表
				instance.post('/user/findSystemRoleSimpleUser', {
					qSchoolId: schoolId,
					qRoleCode: "coursecounselor",
				}).then((res) => {
					this.consultants = res.data.data;
				})
			},
			getQueryInfo: function(schoolId, type) { //联动查询咨询师，课程顾问
				if(type == 1) { //值变更
					this.adviceDetail.counselorId = "";
					this.adviceDetail.courseCounselorId = "";
					this.adviceDetail.counselorName = "";
					this.adviceDetail.courseCounselorName = "";
				}
				this.getConsult(schoolId, type);
				this.getconsultant(schoolId, type);
				this.getClass(schoolId, type);
				

			},
			getProvince: function() {

				if(typeof(this.cityJson.status) == "undefined") { //首次加载 调接口高德地图

					axios.get('/restapi/v3/config/district?subdistrict=3&key=84b4e40f86d5c8087078673175324d9b').then((res) => {
						//this.consultants = res.data.status;
						if(res.data.status == '1') {
							this.$store.commit({
								type: 'setCityJson',
								cityJson: res.data
							})
							this.provinces = res.data.districts[0].districts;
						} else {
							this.$message.error('操作失败！' + res.data.info);
						}

						console.info("json:" + res.data);

					})
				} else {
					this.provinces = this.cityJson.districts[0].districts;
				}

				//console.info("provinces:" + this.cityJson.districts[0].districts);
			},
			getCity: function(provinceId) { //根据省份获取城市
				let vm = this;
				this.provinces.forEach(function(e, i) {
					if(e.adcode == provinceId) {
						vm.citys = e.districts;
					}

				});
			},
			getDistrict: function(cityId) { //根据城市获取区县
				let vm = this;
				this.citys.forEach(function(e, i) {
					if(e.adcode == cityId) {
						vm.districts = e.districts;
					}

				});
			}
		},
		mounted: function() {
			this.getProvince();
			this.getSchool();
			//this.getClass();

			this.getSource();

			//this.getConsult();
			//this.getconsultant();
		}
	};
</script>
