<style scoped>
	.h5_02_info_per_exportRules_h3 {
		border-bottom: solid 1px #e7e7e7;
		padding: 10px 20px 10px 30px;
		color: #979494
	}
	
	.ue_time_block {
		border-bottom: solid 1px #e7e7e7;
		margin-bottom: 15px;
		position: relative;
	}
	
	.ue_time_block_btn {
		position: absolute;
		bottom: 5px;
		right: 10px;
		width: 20px;
		height: 20px;
		border-radius: 10px;
		background-color: #424242;
		color: #fff;
		text-align: center;
		line-height: 20px;
		cursor: pointer;
	}
</style>

<template>
	<div class="addlayer" id='templayer' v-if="show&&(actionType==='transfer')">
		<header>
			<span class="h5_layerLOGO">转移</span>
			<span class="h5_layerOFFbtn" @click="setLayerShow">╳</span>
		</header>
		<div class="addlayerBox">
			<form id="" method="post" action="" class="ue_form_add">
				<h3 class='h5_02_info_per_exportRules_h3'>
        	<span>转移信息(</span>
        	<span class='h5_mark_xx2'>★</span>
        	<span>为必填)</span>
    	</h3>
				<ul class='h5_01_info_per_addlist'>
					<li>
						<span>★</span>
						<span>转移前所属咨询师为:</span>
						<span>{{transferAdivce[0].counselorName}}</span>

					</li>
					<li>
						<span>★</span>
						<span>转移前所属课程顾问为:</span>
						<span>	{{transferAdivce[0].courseCounselorName}}</span>

					</li>
					<li>
						<span>★</span>
						<span>转移后所属咨询师为:</span>
						<span> 
							<select name="" id="counselorId" class='per_addperson_txt' v-model="counselorId">
              <option v-for="counselorName in counselorNames" :value="counselorName.id">{{counselorName.realName}}</option>
            </select>
						
				</span>

					</li>
					<li>
						<span>★</span>
						<span>转移后所属课程顾问为:</span>
						<span> 
							<select name="" id="courseCounselorId" class='per_addperson_txt' v-model="courseCounselorId">
              <option v-for="consultant in consultants" :value="consultant.id">{{consultant.realName}}</option>
              </select>
				</span>

					</li>

				</ul>

				<br class="p_zwf">
				<div class="p_btn_group p_clear_float">
					<input type="button" value="取消" class="p_btn p_btn_siz_2 p_btn_col_red p_btn_pos_r" @click="setLayerShow">
					<input type="button" value="确定" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r" @click="saveTransfer">
				</div>
			</form>
		</div>
	</div>

</template>

<script>
	import instance from '../../../api/index.js';

	export default {
		props: ['show', 'actionType', 'transferAdivce'],

		data() {
			return {
				counselorId: "",
				courseCounselorId: "",
				counselorNames: [], //咨询师
				consultants: [], //课程顾问
			};
		},
		watch: {
			$route: function(to, from) {
				// this.activeMenuName = this.$route.name;
				//this.breadcrumbs = (this.$route && this.$route.matched) || [];
			}
		},
		methods: {
			setLayerShow: function() {
				this.$store.commit({ //将弹层隐藏
					type: 'setLayerShow',
					layerShow: false
				})
			},
			getConsult: function() { //获取咨询师列表
				instance.get('/user/findSimpleCounselors').then((res) => {
					this.counselorNames = res.data.data;
				})
			},
			getconsultant: function() { //获取课程顾问列表
				instance.get('/user/findSimpleCourseCounselors').then((res) => {
					this.consultants = res.data.data;
				})
			},
			saveTransfer: function() {
				if(this.counselorId == "" && this.courseCounselorId == "") {
					this.$message.error('您好，咨询师/课程顾问二者必填其中一项！！！');
					return;
				}
				let params = {
					id: this.transferAdivce[0].id,
					counselorId: this.counselorId,
					courseCounselorId: this.courseCounselorId,
					counselorName:  $("#counselorId").find("option:selected").text(),
					courseCounselorName:  $("#courseCounselorId").find("option:selected").text(),
					

				};
				this.$emit('save-transfer', params);
				

			}

		},
		created: function() {
			// console.info("bbbbbbbbbbbb:"+this.organizeDetail);
		},
		mounted: function() {
			this.getConsult();
			this.getconsultant();
		}

	};
</script>