<!--<title>新增咨询</title>-->
<style scoped>
	.el-input__inner {
		height: 25px;
	}
</style>
<template>
	<form id="addstu" method="post" action="" class="ue_form_add">
		<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
        	<span>咨询信息(</span>
        	<span class='h5_mark_xx2'>★</span>
        	<span>为必填)</span>
    	</h3>
		<ul class='h5_02_info_per_addlist'>
			<li>
				<span>★</span>
				<span>姓名:</span>
				<span>{{adviceDetail.studentName}}</span>
			</li>
			<li>
				<span>★</span>
				<span>性别:</span>
				<span>{{adviceDetail.sex}}</span>
			</li>
			<li>
				<span>★</span>
				<span>年龄:</span>
				<span>{{adviceDetail.age}}</span>
			</li>
			<li>
				<span>★</span>
				<span>联系人手机:</span>
				<span>
    				{{adviceDetail.telephone}}

    			</span>
			</li>
			<li>
				<span>★</span>
				<span>与之关系:</span>
				<span>{{adviceDetail.relationShip}}</span>
			</li>
			<li>
				<span></span>
				<span>邮箱:</span>
				<span>
    				{{adviceDetail.email}}

    			</span>
			</li>

			<li>
				<span></span>
				<span>QQ:</span>
				<span>
    				{{adviceDetail.qq}}
    			</span>
			</li>
			<li>
				<span></span>
				<span>微信:</span>
				<span>{{adviceDetail.wechat}}</span>
			</li>

			<li>
				<span>★</span>
				<span>来源大类:</span>
				<span>
    				{{adviceDetail.sourceName}}

    			</span>
			</li>
			<li>
				<span>★</span>
				<span>来源小类:</span>
				<span>
    				{{adviceDetail.sourceSubName}}
    			</span>
			</li>

			<li>
				<span>★</span>
				<span>课程大类:</span>
				<span>
    				{{adviceDetail.courseName}}
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>课程小类:</span>
				<span>
    				{{adviceDetail.courseSubName}}
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>所属校区:</span>
				<span>
    				{{adviceDetail.schoolName}}
    			</span>
			</li>
			<li>
				<span></span>
				<span>咨询师:</span>
				<span>
    				{{adviceDetail.counselorName}}
    				</span>
			</li>
			<li>
				<span></span>
				<span>课程顾问:</span>
				<span>
    				{{adviceDetail.courseCounselorName}}
    			</span>
			</li>
			<li>
				<span></span>
				<span>主动联系:</span>
				<span>
					{{shifouByDigit[adviceDetail.initiative]}}

    			</span>
			</li>

			<li>
				<span></span>
				<span>推荐人:</span>
				<span>{{adviceDetail.referrerName}}</span>
			</li>
			<li>
				<span>★</span>
				<span>线索状态:</span>
				<span>
					{{adviceStatus[adviceDetail.status]}}

    			</span>
			</li>
			<li>
				<span>★</span>
				<span>客户等级:</span>
				<span>
					{{adviceLevel[adviceDetail.studentLevel]}}
    			</span>
			</li>
			<li>
				<span></span>
				<span>所属活动:</span>
				<span>{{adviceDetail.fromEvent}}</span>
			</li>

			<li>
				<span></span>
				<span>家庭住址(省):</span>
				<span>
    				{{provinceName}}
    			</span>
			</li>
			<li>
				<span></span>
				<span>市:</span>
				<span>
    				{{cityName}}
    			</span>
			</li>
			<li>
				<span></span>
				<span>区县:</span>
				<span>
    				{{districtName}}
    			</span>
			</li>
			<li>
				<span></span>
				<span>小区:</span>
				<span>{{adviceDetail.biotope}}</span>
			</li>
			<li>
				<span></span>
				<span>详细地址:</span>
				<span>{{adviceDetail.address}}</span>
			</li>
			<li>
				<span></span>
				<span>就读学校:</span>
				<span>{{adviceDetail.school}}</span>
			</li>
			<li>
				<span>★</span>
				<span>班级类别:</span>
				<span>
					{{classTypeDict[adviceDetail.classType]}}

    			</span>
			</li>
			<li class="per_addperson_li_w ">
				<span></span>
				<span>备注:</span>
				<span class="text_scroll">{{adviceDetail.descr}}</span>
			</li>

		</ul>
		<div class="zxt">
			<div class='zxt_nav p_clear_float'>
				<div :class="{'zxt_nav_click':ind === 1}" name="tab1" @click="changeBgc(1)">回访记录</div>
				<div :class="{'zxt_nav_click':ind === 2}" name="tab2" @click="changeBgc(2)">试听记录</div>
				<div :class="{'zxt_nav_click':ind === 3}" name="tab3" @click="changeBgc(3)">反馈记录</div>
			</div>
			<div class="p_table_la_over">
				<table class="p_table_la" cellspacing="0" cellpadding="0" id="tab1" v-show="ind==1">
					<tr>
						<td>回访日期</td>
						<td>咨询师</td>
						<td>课程顾问</td>
						<td>客户等级</td>
						<td>线索状态</td>
						<td>下次回访日期</td>
						<td>回访内容</td>
					</tr>
					<tr v-for="visit in visitList">
						<td>{{visit.visitTime}}</td>
						<td>{{visit.counselorName}}</td>
						<td>{{visit.courseCounselorName}}</td>
						<td>{{adviceLevel[visit.studentLevel]}} </td>
						<td>{{adviceStatus[visit.status]}}</td>
						<td>{{visit.nextVisitTime}}</td>
						<td>{{visit.visitContent}}</td>
					</tr>
				</table>
				<table class="p_table_la" cellspacing="0" cellpadding="0" id="tab2" v-show="ind==2">
					<tr>
						<td>校区</td>
						<td>课程大类</td>
						<td>课程小类</td>
						<td>上课日期</td>
						<td>教室</td>
						<td>授课教师</td>
						<td>开始时间</td>
						<td>结束时间</td>
						<td>试听类型</td>
						<td>试听时长(分钟)</td>
					</tr>
					<tr v-for="listen in listenList">
						<td>{{listen.schoolName}}</td>
						<td>{{listen.courseName}}</td>
						<td>{{listen.courseSubName}}</td>
						<td>{{listen.listenDate}}</td>
						<td>{{listen.classRoomName}}</td>
						<td>{{listen.teacherName}}</td>
						<td>{{listen.beginTime}}</td>
						<td>{{listen.endTime}}</td>
						<td>{{listenTypeDict[listen.listenType]}}</td>
						<td>{{listen.listenMinute}}</td>
					</tr>
				</table>
				<table class="p_table_la" cellspacing="0" cellpadding="0" id="tab3" v-show="ind==3">
					<tr>
						<td>反馈日期</td>
						<td>反馈人</td>
						<td>到场状态</td>
						<td>报名状态</td>
						<td>备注</td>
					</tr>
					<tr v-for="lReply in listenReplysList">
						<td>{{lReply.replyDate}}</td>
						<td>{{lReply.creatorName}}</td>
						<td>{{arriveStatusDict[lReply.arriveStatus]}}</td>
						<td>{{registStatusDict[lReply.registStatus]}}</td>
						<td>{{lReply.replyContent}}</td>
					</tr>
				</table>
			</div>
		</div>
		<br class="p_zwf">
		<div class="p_btn_group p_clear_float">
			<!--<input type="button" value="返回"  class="p_btn p_btn_siz_2 p_btn_col_red p_btn_pos_r">-->
			<!--<router-link :to="{path:activeMenu.path+'/'+route.path+'/'+cRoute.path}">{{cRoute.name}}</router-link>-->
			<input type="button" value="返回" @click="$router.go(-1)" class="p_btn p_btn_siz_2 p_btn_col_ora p_btn_pos_r">

		</div>
	</form>
</template>
<script>
	import instance from '../../../api/index.js';
	import { mapState } from 'vuex';
	import axios from 'axios';
	export default {
		props: ['id'],
		data() {
			return {
				adviceDetail: {
					initiative: "",
					courseId: "",
					sourceId: ""
				},
				schoolNames: [],
				classNames: [],
				classNameSubs: [],
				sourceNames: [],
				sourceNameSubs: [],
				counselorNames: [], //咨询师
				consultants: [], //课程顾问
				provinceName: "",
				cityName: "",
				districtName: "",
				ind: 1,
				visitList: [],
				listenReplysList: [],
				listenList: []

			};
		},

		computed: {
			// Getting Vuex State from store/index
			...mapState({
				cityJson: state => state.cityJson,
				adviceStatus: state => state.adviceStatus,
				adviceLevel: state => state.adviceLevel,
				shifouByDigit: state => state.shifouByDigit,
				classTypeDict: state => state.classTypeDict,
				listenTypeDict: state => state.listenTypeDict,
				arriveStatusDict: state => state.arriveStatusDict,
				registStatusDict: state => state.registStatusDict,
			})
		},
		created() {
			// 组件创建完后获取数据，
			// 此时 data 已经被 observed 了
			instance.get('/infor/findInformation/' + this.id).then((res) => {
				this.adviceDetail = res.data.data;
				this.getProvince();

			})
		},
		methods: {
			changeBgc: function(index) {
				this.ind = index;
			},
			getVisitList: function() {
				instance.post('/visit/findVisits', {
					informationId: this.id,
					beginRow: 0,
					pageSize: 50
				}).then((res) => {
					this.visitList = res.data.data;
				})
			},
			getListenReplysList: function() {
				instance.post('/listen/findListenReplys', {
					informationId: this.id,
					beginRow: 0,
					pageSize: 50
				}).then((res) => {
					this.listenReplysList = res.data.data;
				})
			},
			getListenList: function() {
				instance.post('/listen/findListens', {
					informationId: this.id,
					beginRow: 0,
					pageSize: 50
				}).then((res) => {
					this.listenList = res.data.data;
				})
			},
			getProvince: function() {
				let vm = this;
				if(typeof(this.cityJson.status) == "undefined") { //首次加载 调接口高德地图

					axios.get('/restapi/v3/config/district?subdistrict=3&key=84b4e40f86d5c8087078673175324d9b').then((res) => {
						//this.consultants = res.data.status;
						if(res.data.status == '1') {
							this.$store.commit({
								type: 'setCityJson',
								cityJson: res.data
							})
							//this.provinces = res.data.districts[0].districts;

							res.data.districts[0].districts.forEach(function(e, i) {
								if(e.adcode == vm.adviceDetail.provinceId) {
									vm.provinceName = e.name;
									e.districts.forEach(function(e, i) {
										if(e.adcode == vm.adviceDetail.cityId) {
											vm.cityName = e.name;
											e.districts.forEach(function(e, i) {
												if(e.adcode == vm.adviceDetail.areaId) {
													vm.districtName = e.name;

												}

											})
										}

									})
								}

							});

						} else {
							this.$message.error('操作失败！' + res.data.info);
						}

						console.info("json:" + res.data);

					})
				} else {
					//this.provinces = this.cityJson.districts[0].districts;
					this.cityJson.districts[0].districts.forEach(function(e, i) {
						if(e.adcode == vm.adviceDetail.provinceId) {
							vm.provinceName = e.name;
							e.districts.forEach(function(e, i) {
								if(e.adcode == vm.adviceDetail.cityId) {
									vm.cityName = e.name;
									e.districts.forEach(function(e, i) {
										if(e.adcode == vm.adviceDetail.areaId) {
											vm.districtName = e.name;

										}

									})
								}

							})
						}

					});
				}

				//console.info("provinces:" + this.cityJson.districts[0].districts);
			}
		},
		mounted: function() {
			this.getVisitList();
			this.getListenReplysList();
			this.getListenList();
		}
	};
</script>
