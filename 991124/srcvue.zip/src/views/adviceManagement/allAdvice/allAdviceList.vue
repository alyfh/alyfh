<!--<title>全部咨询</title>-->
<style scoped>

</style>
<template>
	<section class="p_chi_con">
		<div class="p_con_sea">
			<ul class="p_con_sea_list p_clear_float">
				<li>
					<span>姓名:</span>
					<span>
						<input type="text" class="p_con_form_input" v-model="findAdvices.qStudentName">
					</span>
				</li>
				<li>
					<span>联系人手机:</span>
					<span>
						<input type="text" class="p_con_form_input" v-model="findAdvices.qTelephone">
					</span>
				</li>
				<li>
					<span>所属校区:</span>
					<span>
            <select name=""  class="p_con_form_select" v-model="findAdvices.qSchoolId">
              		<option value="">--请选择--</option>
              <option v-for="sName in schoolNames" :value="sName.id">{{ sName.schoolName }}</option>
            </select>
					</span>
				</li>
				<li>
					<span>来源大类:</span>
					<span>
            <select name="" id="" class="p_con_form_select" v-model="findAdvices.qSourceId" @change="getSourceSub(findAdvices.qSourceId)">
                		<option value="">--请选择--</option>
                <option v-for="sourceName in sourceNames" :value="sourceName.id">{{sourceName.sourceName}}</option>
            </select>
					</span>
				</li>
				<li>
					<span>来源小类:</span>
					<span>
            <select name="" id="" class="p_con_form_select" v-model="findAdvices.qSourceSubId">
             		<option value="">--请选择--</option>
              <option v-for="sourceSubName in sourceNameSubs" :value="sourceSubName.id">{{sourceSubName.sourceSubName}}</option>
            </select>
					</span>
				</li>

				<li>
					<span>课程大类:</span>
					<span>
            <select name="" id="" class="p_con_form_select" v-model="findAdvices.qCourseId" @change="getClassSub(findAdvices.qCourseId)">
                		<option value="">--请选择--</option>
               <option v-for="className in classNames" :value="className.id">{{className.courseName}}</option>
            </select>
					</span>
				</li>
				<li>
					<span>课程小类:</span>
					<span>
            <select name="" id="" class="p_con_form_select" v-model="findAdvices.qCourseSubId">
             		<option value="">--请选择--</option>
              <option v-for="classNameSub in classNameSubs" :value="classNameSub.id">{{classNameSub.courseSubName}}</option>
            </select>
					</span>
				</li>

				<li>
					<span>客户等级:</span>
					<span>
            <select name="" id="" class="p_con_form_select" v-model="findAdvices.qStudentLevel">
             		<option value="">--请选择--</option>
                  <option v-for = "(item,key) in adviceLevel" :value="key">{{item}}</option>
             
            </select>
					</span>
				</li>

				<li>
					<span>线索状态:</span>
					<span>
            <select name="" id="" class="p_con_form_select" v-model="findAdvices.qStatus">
             		<option value="">--请选择--</option>
             		 <option v-for = "(item,key) in adviceStatus" :value="key">{{item}}</option>
             
            </select>
					</span>
				</li>

				<li>
					<span>咨询师:</span>
					<span>
							<input type="text" class="p_con_form_input" v-model="findAdvices.qCounselorName">
					</span>
				</li>
				<li>
					<span>课程顾问:</span>
					<span>
							<input type="text" class="p_con_form_input" v-model="findAdvices.qCourseCounselorName">
					</span>
				</li>

			</ul>
			<div class="p_btn_group p_clear_float">
				<input type="button" value="查询" @click="query" class="p_btn p_btn_siz_2 p_btn_col_gre p_btn_pos_r">
			</div>
		</div>

		<div class="p_con_tab">
			<div class="p_btn_group p_clear_float">

				<input v-if="$_has(actionsList,'tansfer')" type="button" value="转移" @click="transfer" class="p_btn p_btn_siz_2 p_btn_col_oran p_btn_pos_r">

			</div>
			<div class="p_table_la_over">
				<table class="p_table_la" cellspacing="0" cellpadding="0">
					<tr>
						<td v-if="$_has(actionsList,'tansfer')">选择</td>
						<td>姓名</td>
						<td>性别</td>
						<td>所属校区</td>
						<td>联系人手机</td>
						<td>与之关系</td>
						<td>咨询课<br>程大类</td>
						<td>咨询课<br>程小类</td>
						<td>来源大类</td>
						<td>来源小类</td>
						<td>客户等级</td>
						<td>线索状态</td>
						<td>下次回访时间</td>
						<td>创建时间</td>
						<td v-if="$_has(actionsList,'delete')||$_has(actionsList,'edit')||$_has(actionsList,'read')">
							操作
						</td>
					</tr>
					<tr v-for="adivce in adviceList">
						<td v-if="$_has(actionsList,'tansfer')">
							<input type="checkbox" :value="adivce" v-model="transferAdivce">
						</td>
						<td>{{adivce.studentName}}</td>
						<td>{{adivce.sex}}</td>
						<td>{{adivce.schoolName}}</td>
						<td>{{adivce.telephone}}</td>
						<td>{{adivce.relationShip}}</td>
						<td>{{adivce.courseName}}</td>
						<td>{{adivce.courseSubName}}</td>
						<td>{{adivce.sourceName}}</td>
						<td>{{adivce.sourceSubName}}</td>
						<td>{{adviceLevel[adivce.studentLevel]}}</td>
						<td>{{adviceStatus[adivce.status]}}</td>
						<td>{{adivce.nextVisitTime}}</td>
						<td>{{adivce.createTime}}</td>
						<td v-if="$_has(actionsList,'delete')||$_has(actionsList,'edit')||$_has(actionsList,'read')">
							<!--转正不能删除（1未转正）-->
							<input v-if="$_has(actionsList,'delete')&&adivce.official==1" type="button" value="删除" @click="deleteAdvice(adivce.id)" class="p_btn p_btn_siz_2 p_btn_col_k_red p_btn_pos_r">
							<input v-if="$_has(actionsList,'edit')" type="button" value="编辑" @click="editAdivce(adivce.id)" class="p_btn p_btn_siz_2 p_btn_col_k_oran p_btn_pos_r">
							<input v-if="$_has(actionsList,'read')" type="button" value="详情" @click="readAdivce(adivce.id)" class="p_btn p_btn_siz_2 p_btn_col_k_blu p_btn_pos_r">

						</td>
					</tr>
				</table>
				<!--<router-view></router-view>-->
			</div>
		</div>
		<div class='h5_page_container' id="con">
			<page :record-count="recordCount" v-on:change-page="changePage">
			</page>
		</div>
		<!-- 弹窗 -->
		<modal-dialog :show="layerShow" :action-type="actionType" :transfer-adivce="transferAdivce" v-on:save-transfer="saveTransfer">
		</modal-dialog>
	</section>
</template>
<script>
	import instance from '../../../api/index.js';
	import * as util from '../../../assets/util.js';
	import { mapState } from 'vuex';

	export default {
		computed: {
			// Getting Vuex State from store/index
			...mapState({
				layerShow: state => state.layerShow,
				pageSize: state => state.pageSize,
				pageLarge: state => state.pageLarge,
				adviceStatus: state => state.adviceStatus,
				adviceLevel: state => state.adviceLevel,
			})
		},
		data() {
			return {
				actionType: "",
				actionsList: [], //获取当前用户对当前模块授权操作
				findAdvices: { //查询条件

				},
				adviceList: [], //咨询列表
				schoolNames: [], //校区,
				sourceNames: [], //来源大类
				sourceNameSubs: [], //来源小类
				classNames: [],
				classNameSubs: [],
				counselorNames: [], //咨询师
				consultants: [], //课程顾问
				teachers: [], //授课教师
				recordCount: 0,
				pageNum: 1, //当前页码
				transferAdivce: [] //转移

			};
		},
		components: {
			page: () =>
				import("../../common/page.vue"),
			modalDialog: () =>
				import("./transferComponent.vue")
		},
		methods: {
			query: function() {
				this.getAdviceList(this.findAdvices);
				this.getAdviceCount(this.findAdvices); //数量
			},
			getAdviceCount: function(lis) { //获取数量
				instance.post('/infor/findInformationsCount', lis).then((res) => {
					this.recordCount = res.data.data.count;
				});
			},
			getAdviceList: function(lis) { //获取列表
				lis.beginRow = (this.pageNum - 1) * this.pageSize;
				lis.pageSize = this.pageSize;
				instance.post('/infor/findInformations', lis).then((res) => {
					this.adviceList = res.data.data;
				})

			},
			getSchool: function() { //获取校区数据

				//获取当前登录人
				let loginInfo = util.session("loginInfo");
				instance.get('/school/findUserSchools/' + loginInfo.login.userId).then((res) => {

					if(res.data.data != null && res.data.data != "") {
						this.schoolNames = res.data.data;
						if(res.data.data != null && res.data.data.length == 1) {
							this.findAdvices.qSchoolId = res.data.data[0].id;
						}
						this.query();

					}

				})
			},
			getConsult: function() { //获取咨询师列表
				instance.get('/user/findSimpleCounselors', {}).then((res) => {
					this.counselorNames = res.data.data;
				})
			},
			getconsultant: function() { //获取课程顾问列表
				instance.get('/user/findSimpleCourseCounselors').then((res) => {
					this.consultants = res.data.data;
				})
			},
			getTeacher: function() { //获取授课教师列表
				instance.post('/teacher/findSimpleTeachers', {}).then((res) => {
					this.teachers = res.data.data;
				})
			},
			getSource: function() { //获取来源大类数据
				instance.post('/source/findSimpleSources', {}).then((res) => {
					this.sourceNames = res.data.data;
				})
			},
			getSourceSub: function(id) { //获取来源小类数据
				if(id == "") id = "-1";
				instance.get('/source/findSourceSubs4Source/' + id).then((res) => {
					this.sourceNameSubs = res.data.data;
				})
			},
			getClass: function() { //获取课程大类数据
				// course/findCourses
				// /course/findSimpleCourse
				instance.post('/course/findCourses', {}).then((res) => {
					this.classNames = res.data.data;
				})
			},
			getClassSub: function(id) { //获取课程小类数据
				// /course/findSimpleCourseSubs
				instance.post('/course/findSimpleCourseSubs', {
					qCourseId: id
				}).then((res) => {
					this.classNameSubs = res.data.data;
					// console.info(res.data);
				})
			},
			changePage: function(pageNum) {
				//  console.info("change-page:" + pageNum);
				this.pageNum = pageNum;
				this.getAdviceList(this.findAdvices);
			},
			editAdivce: function(id) {

				// this.$router.push('/xueyuanguanli/buyCard/'+id);
				this.$router.push({
					path: `/zhaoshengguanli/updateAdvice/${id}`
				});

			},
			readAdivce: function(id) {

				// this.$router.push('/xueyuanguanli/buyCard/'+id);
				this.$router.push({
					path: `/zhaoshengguanli/readAdvice/${id}`
				});

			},
			deleteAdvice: function(id) {

				this.$confirm("是否确定对此咨询信息进行删除？删除后，此咨询信息将不可恢复！请谨慎操作", "提示", {
						confirmButtonText: "确定",
						cancelButtonText: "取消",
						type: "info"
					})
					.then(() => {
						instance.get('/infor/removeInformation/' + id).then((res) => {
							this.$message.info('数据删除成功！');
							this.query();
						})
					})
					.catch(() => {});

				//this.actionType="read";
			},
			transfer: function() {
				if(this.transferAdivce.length == 0) {
					this.$message.error('请选择需要转移的咨询！！！');
					return;
				} else if(this.transferAdivce.length > 1) {
					this.$message.error('您好，每次只能选择一个咨询进行转移！！！');
					return;
				}
				this.$store.commit({
					type: 'setLayerShow',
					layerShow: true
				})
				this.actionType = "transfer";
			},
			saveTransfer: function(item) {
				let counselorName = this.transferAdivce[0].counselorName ? this.transferAdivce[0].counselorName : " ";
				let courseCounselorName = this.transferAdivce[0].courseCounselorName ? this.transferAdivce[0].courseCounselorName : " ";
				this.$confirm("是否确定将这些数据由咨询师" + counselorName + "转移至咨询师" + item.counselorName + "，由课程顾问" + courseCounselorName + "转移至" + item.courseCounselorName + "?", "提示", {
						confirmButtonText: "确定",
						cancelButtonText: "取消",
						type: "info"
					})
					.then(() => {
						instance.post('/infor/transferInformation', item).then((res) => {
							if(res.data.errcode == '0') {
								this.$message.info('转移成功！');
								this.$store.commit({
									type: 'setLayerShow',
									layerShow: false
								});
								this.query();
								this.transferAdivce = [];
							} else {
								this.$message.error('操作失败！' + res.data.errmsg);
							}
						})

					})
					.catch(() => {});

			},
			getModuleActions: function() {
				let routeCodes = this.$route.path.split("/");
				let routeCode = routeCodes[routeCodes.length - 1];
				instance.get('/navi/findUserActions2/' + routeCode).then((res) => {
					if(res.data.errcode == '0') {
						this.actionsList = res.data.data;
					} else {
						//this.$message.error('操作失败！' + res.data.info);
					}
					console.info("json:" + res.data);

				})
			}
		},
		mounted: function() {
			//this.getAdviceList(this.findAdvices);
			//this.getAdviceCount(this.findAdvices); //数量

			this.getSchool(); //校区
			//this.getConsult(); //咨询师
			//this.getTeacher(); //授课教师
			//this.getconsultant(); //课程顾问
			this.getSource(); //来源大类
			this.getClass(); //课程大类
			this.getModuleActions();

		}
	};
</script>