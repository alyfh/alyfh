<!--<title>学员档案</title>-->
<style>
	.zxt {
		width: 80%;
		position: relative;
		margin: auto;
		margin-top: 15px;
	}
	
	.zxt_nav {
		left: 20px;
		top: 0px
	}
	
	.h5_iframe1_table_page {
		width: calc(100% - 30px);
		margin-bottom: 15px;
		background-color: #f0f0f0;
		margin-left: 10px;
		padding: 1px
	}
</style>
<template>
	<div class="zxt">
		<div class='zxt_nav p_clear_float'>
			<div v-for="(lists, index) in list" :class="{'zxt_nav_click':ind === index}" @click="changeBgc(index)">{{lists.name}}</div>
		</div>
		<div class="h5_iframe1_table_page">
			<router-view @changeTab="myChangeTab"></router-view>
		</div>
	</div>
</template>
<script>
	import instance from '../../../api/index.js';
	import { mapState } from 'vuex';
	export default {
		data() {
			return {
				list: [{
						'name': '基本信息',
						'url': '/baseInfo'
					},
					{
						'name': '回访记录',
						'url': '/visitList'
					},
					{
						'name': '试听记录',
						'url': '/listenList'
					},
					{
						'name': '反馈记录',
						'url': '/listenReplyList'
					}
				],
				ind: 0
			};
		},
		methods: {
			changeBgc: function(index) {
				this.ind = index;
				var str = this.list[index]['url'];
				this.linkStudentInfo(str);

			},
			linkStudentInfo: function(url) {
				this.$router.push('/zhaoshengguanli/adviceinfo/' + this.$route.params.id + url);
			},
			myChangeTab: function(tagFlag) {
				if(tagFlag=="baseInfo"){
					this.ind=0;
				}else if(tagFlag=="visitList"){
					this.ind=1;
				}else if(tagFlag=="addVisit"){
					this.ind=1;
				}else if(tagFlag=="listenList"){
					this.ind=2;
				}else if(tagFlag=="addListen"){
					this.ind=2;
				}else if(tagFlag=="addListenReply"){
					this.ind=2;
				}else if(tagFlag=="listenReplyList"){
					this.ind=3;
				}
//				console.info("tagFlag="+tagFlag+" this.ind="+this.ind);
			}
		},
		mounted: function() {
			// this.linkStudentInfo('/baseInfo');

		}
	};
</script>