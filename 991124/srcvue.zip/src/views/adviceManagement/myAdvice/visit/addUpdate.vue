<!--<title>新增学员</title>-->
<style>
	.el-input__inner {
		height: 25px;
	}
</style>
<template>
	<form id="addstu" method="post" action="" class="ue_form_add">
		<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
        	<span>回访信息(</span>
        	<span class='h5_mark_xx2'>★</span>
        	<span>为必填)</span>
    	</h3>
		<ul class='h5_02_info_per_addlist'>
			<li>
				<span>★</span>
				<span>回访日期:</span>
				<span> <el-date-picker type="date"   value-format="yyyy-MM-dd" placeholder="Pick a date" style="width:100%" v-model="visitDetail.visitTime"></el-date-picker>
    				</span>
			</li>

			<li>
				<span></span>
				<span>咨询师:</span>
				<span>
    				<select name="" id="" class='per_addperson_txt' v-model="visitDetail.counselorId">
              <option v-for="counselorName in counselorNames" :value="counselorName.id">{{counselorName.realName}}</option>
            </select>
    			</span>
			</li>
			<li>
				<span></span>
				<span>课程顾问:</span>
				<span>
    				<select name="" id="" class='per_addperson_txt' v-model="visitDetail.courseCounselorId">
              <option v-for="consultant in consultants" :value="consultant.id">{{consultant.realName}}</option>
            </select>
    			</span>
			</li>

			<li>
				<span>★</span>
				<span>线索状态:</span>
				<span>
    				<select name="" id="" class='per_addperson_txt' v-model="visitDetail.status">
             <option  value="">请选择</option>
            <option v-for = "(item,key) in adviceStatus" :value="key">{{item}}</option>
            </select>
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>客户等级:</span>
				<span>
    				<select name="" id="" class='per_addperson_txt' v-model="visitDetail.studentLevel">
              <option  value="">请选择</option>
              <option v-for = "(item,key) in adviceLevel" :value="key">{{item}}</option>
            </select>
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>下次回访日期:</span>
				<span> <el-date-picker type="date"   value-format="yyyy-MM-dd" placeholder="Pick a date" style="width:100%" v-model="visitDetail.nextVisitTime"></el-date-picker>
    				</span>
			</li>

			<li class="per_addperson_li_w per_addperson_li_h2">
				<span>★</span>
				<span>回访内容:</span>
				<span>   <textarea v-model="visitDetail.visitContent" cols="30" rows="4" placeholder="" class='per_addperson_texarea'></textarea>
              </span>
			</li>

		</ul>

		<br class="p_zwf">
		<div class="p_btn_group p_clear_float">
			<!--<input type="button" value="返回"  class="p_btn p_btn_siz_2 p_btn_col_red p_btn_pos_r">-->
			<!--<router-link :to="{path:activeMenu.path+'/'+route.path+'/'+cRoute.path}">{{cRoute.name}}</router-link>-->
			<input type="button" value="返回" @click="$router.go(-1)" class="p_btn p_btn_siz_2 p_btn_col_ora p_btn_pos_r">

			<input type="button" value="保存" @click="saveVisit(visitDetail)" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r">
		</div>
	</form>
</template>
<script>
	import instance from '../../../../api/index.js';
	import axios from 'axios';
	import { mapState } from 'vuex';
	export default {
		data() {
			return {
				visitDetail: {
					visitTime:this.getNow(),
					counselorId:'',
					courseCounselorId:'',
					status:'',
					studentLevel:''
					
				},
				visitDetailTmp: {
					visitTime:this.getNow()
				},
				counselorNames: [], //咨询师
				consultants: [] //课程顾问
			};
		},
		computed: {
			// Getting Vuex State from store/index
			...mapState({
				adviceStatus: state => state.adviceStatus,
				adviceLevel: state => state.adviceLevel,
			})
		},
		methods: {
			getNow: function() {
				var date = new Date();
				let nowDay = date.getFullYear() + "-" + 
				((date.getMonth() + 1) < 10 ? "0" + (date.getMonth() + 1) : (date.getMonth() + 1)) +"-" + 
				((date.getDate() + 1) < 10 ? "0" + (date.getDate() ) : (date.getDate() ));
				return nowDay;
			},
			getAdivceInfo: function(id) { //获取咨询信息信息
				instance.get('/infor/findInformation/' + id).then((res) => {
					//this.adviceDetail = res.data.data;
					this.visitDetailTmp = res.data.data;
					this.visitDetail.counselorId = this.visitDetailTmp.counselorId;
					this.visitDetail.courseCounselorId = this.visitDetailTmp.courseCounselorId;
					this.visitDetail.status = this.visitDetailTmp.status;
					this.visitDetail.studentLevel = this.visitDetailTmp.studentLevel;
					this.visitDetail.visitTime=this.getNow();
					
					this.getConsult(this.visitDetailTmp.schoolId);
					this.getconsultant(this.visitDetailTmp.schoolId);
				})
			},
			getEditAdivceInfo: function(id) { //编辑时 获取咨询信息信息
				instance.get('/infor/findInformation/' + id).then((res) => {
					//this.adviceDetail = res.data.data;
					this.visitDetailTmp = res.data.data;
					
					this.getConsult(this.visitDetailTmp.schoolId);
					this.getconsultant(this.visitDetailTmp.schoolId);
				})
			},
			
			getConsult: function(id) { //获取咨询师列表
				instance.post('/user/findSystemRoleSimpleUser', {qSchoolId:id,qRoleCode: "counselor"}).then((res) => {
					this.counselorNames = res.data.data;
				})
			},
			getconsultant: function(id) { //获取课程顾问列表
				instance.get('/user/findSchoolsSimpleCourseCounselors/'+id,{}).then((res) => {
					this.consultants = res.data.data;
				})
			},
			saveVisit: function(item) {
				item.id ? this.updateVisit(item) : this.createVisit(item)
			},
			createVisit: function(item) {

				instance.post('/visit/createVisit', item).then((res) => {
					if(res.data.errcode == '0') {
						this.$message.info('信息创建成功！');
						this.$router.push('/zhaoshengguanli/adviceinfo/' + this.$route.params.id + "/visitList");

					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}

				})
			},
			getVisitInfo: function(id) {
				instance.get('/visit/findVisit/' + id).then((res) => {
					this.visitDetail = res.data.data;
					this.getEditAdivceInfo(this.visitDetail.informationId);
				})
			},
			updateVisit: function(item) {
				instance.post('/visit/changeVisit', item).then((res) => {
					if(res.data.errcode == '0') {
						this.$message.info('信息修改成功！');
						this.$router.push('/zhaoshengguanli/adviceinfo/' + this.$route.params.id + "/visitList");
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}
				})
			}

		},

		mounted: function() {
			//this.getAdivceInfo(this.$route.params.id);
			
			if(this.$route.params.visitId) {
				this.getVisitInfo(this.$route.params.visitId);
			} else {
				this.getAdivceInfo(this.$route.params.id);
				this.visitDetail.informationId = this.$route.params.id; //咨询id
			
			}
			//this.getConsult();
			//this.getconsultant();
			
			//向父组件传参数，解决此组件复用问题
			this.$emit("changeTab","addVisit");
		}
	};
</script>