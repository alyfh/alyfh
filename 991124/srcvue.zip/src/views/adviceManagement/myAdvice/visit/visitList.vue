<!--<title>购课信息</title>-->
<style scoped>
	.p_table_la tr:nth-child(1)>td {
		word-break: keep-all;
		word-break: keep-all;
		white-space: nowrap;
	}
</style>
<template>
	<div class="p_con_tab">
		<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
      <span>回访记录{{message}}</span>
    </h3>
		<div class="p_btn_group p_clear_float">
			<input type="button" value="新增" class="p_btn p_btn_siz_2 p_btn_col_gre p_btn_pos_r" @click="addVisit">

		</div>
		<div class="p_table_la_over">
			<table class="p_table_la" cellspacing="0" cellpadding="0">
				<tr>
					<td>回访日期</td>
					<td>咨询师</td>
					<td>课程顾问</td>
					<td>客户等级</td>
					<td>线索状态</td>
					<td>下次回访日期</td>
					<td>回访内容</td>
					<td>操作</td>
				</tr>
				<tr v-for="visit in visitList">
					<td>{{visit.visitTime}}</td>
					<td>{{visit.counselorName}}</td>
					<td>{{visit.courseCounselorName}}</td>
					<td>{{adviceLevel[visit.studentLevel]}} </td>
					<td>{{adviceStatus[visit.status]}}</td>
					<td>{{visit.nextVisitTime}}</td>
					<td>{{visit.visitContent}}</td>
					<td>
						<input type="button" value="编辑" @click="editVisit(visit.id)" class="p_btn p_btn_siz_2 p_btn_col_k_oran p_btn_pos_r">
					</td>
				</tr>
			</table>
		</div>
		<!-- 分页 -->
		<div class='h5_page_container' id="con">
			<page :record-count="recordCount" v-on:change-page="changePage">
			</page>
		</div>
	</div>
</template>
<script>
	import instance from '../../../../api/index.js';
	import { mapState } from 'vuex';
	export default {
		components: {
			page: () =>
				import("../../../common/page.vue")
		},
		data() {
			return {
				visitList: [],
				message: "",
				recordCount: 0,
				pageNum: 1 //当前页码
			};
		},

		computed: {
			// Getting Vuex State from store/index
			...mapState({
				adviceStatus: state => state.adviceStatus,
				adviceLevel: state => state.adviceLevel,
			})
		},
		methods: {
			getVisitList: function(id) { //获取回访列表信息
				instance.post('/visit/findVisits', {
					informationId: id,
					"beginRow": (this.pageNum - 1) * this.pageSize,
					"pageSize": this.pageSize
				}).then((res) => {
					if(res.data.data == null) {
						this.message = '(' + res.data.errmsg + ')';
					} else {
						this.message = "";
						this.visitList = res.data.data;
					}
				})
			},
			getVisitCount: function(id) {
				instance.post('/visit/findVisitsCount', {
					informationId: id
				}).then((res) => {
					this.recordCount = res.data.data.count;
				})

			},
			addVisit: function() {
				this.$router.push('/zhaoshengguanli/adviceinfo/' + this.$route.params.id + "/addVisit");
			},
			editVisit: function(visitId) {
				this.$router.push('/zhaoshengguanli/adviceinfo/' + this.$route.params.id + "/editVisit/" + visitId);
			},
			changePage: function(pageNum) {
				console.info("change-page:" + pageNum);
				this.pageNum = pageNum;
				this.getVisitList(this.$route.params.id);
			}
		},
		mounted: function() {
			this.getVisitList(this.$route.params.id);
			this.getVisitCount(this.$route.params.id);
			
			//向父组件传参数，解决此组件复用问题
			this.$emit("changeTab","visitList");
		}
	};
</script>