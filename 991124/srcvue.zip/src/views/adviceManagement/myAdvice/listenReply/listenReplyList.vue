<!--<title>购课信息</title>-->
<style scoped>
	.p_table_la tr:nth-child(1)>td {
		word-break: keep-all;
		word-break: keep-all;
		white-space: nowrap;
	}
</style>
<template>
	<div class="p_con_tab">
		<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
      <span>反馈记录{{message}}</span>
    </h3>
		<div class="p_btn_group p_clear_float">
			
		</div>
		<div class="p_table_la_over">
			<table class="p_table_la" cellspacing="0" cellpadding="0">
				<tr>
						<td>反馈日期</td>
						<td>反馈人</td>
						<td>到场状态</td>
						<td>报名状态</td>
						<td>备注</td>
						<td>操作</td>
					</tr>
						<tr v-for="lReply in listenReplyList">
						<td>{{lReply.replyDate}}</td>
						<td>{{lReply.courseCounselorName}}</td>
						<td>{{arriveStatusDict[lReply.arriveStatus]}}</td>
						<td>{{registStatusDict[lReply.registStatus]}}</td>
						<td>{{lReply.replyContent}}</td>
							<td>
						<input type="button" value="编辑" @click="editListenReply(lReply.id)" class="p_btn p_btn_siz_2 p_btn_col_k_oran p_btn_pos_r">
					</td>
					</tr>
					
				
			</table>
		</div>
		<!-- 分页 -->
		<div class='h5_page_container' id="con">
			<page :record-count="recordCount" v-on:change-page="changePage">
			</page>
		</div>
	</div>
</template>
<script>
	import instance from '../../../../api/index.js';
	import { mapState } from 'vuex';
	export default {
		components: {
			page: () =>
				import("../../../common/page.vue")
		},
		data() {
			return {
				listenReplyList: [],
				message: "",
				recordCount: 0,
				pageNum: 1 //当前页码
			};
		},

		computed: {
			// Getting Vuex State from store/index
			...mapState({
			    arriveStatusDict: state => state.arriveStatusDict,
				registStatusDict: state => state.registStatusDict,
			})
		},
		methods: {
			getListenReplyList: function(id) { //获取回访列表信息
				instance.post('/listen/findListenReplys', {
					informationId: id,
					"beginRow": (this.pageNum - 1) * this.pageSize,
					"pageSize": this.pageSize
				}).then((res) => {
					if(res.data.data == null) {
						this.message = '(' + res.data.errmsg + ')';
					} else {
						this.message = "";
						this.listenReplyList = res.data.data;
					}
				})
			},
			getListenReplyCount: function(id) {
				instance.post('/listen/findListenReplysCount', {
					informationId: id
				}).then((res) => {
					this.recordCount = res.data.data.count;
				})

			},
			addListenReply: function() {
				this.$router.push('/zhaoshengguanli/adviceinfo/' + this.$route.params.id + "/addListenReply");
			},
			editListenReply: function(listenReplyId) {
				this.$router.push('/zhaoshengguanli/adviceinfo/' + this.$route.params.id + "/editListenReply/" + listenReplyId);
			},
			changePage: function(pageNum) {
				console.info("change-page:" + pageNum);
				this.pageNum = pageNum;
				this.getListenReplyList(this.$route.params.id);
			}
		},
		mounted: function() {
			this.getListenReplyList(this.$route.params.id);
			this.getListenReplyCount(this.$route.params.id);
			
			//向父组件传参数，解决此组件复用问题
			this.$emit("changeTab","listenReplyList");
		}
	};
</script>