<!--<title>新增学员</title>-->
<style>
	.el-input__inner {
		height: 25px;
	}
</style>
<template>
	<form id="addstu" method="post" action="" class="ue_form_add">
		<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
        	<span>基本信息</span>
        	<!--<span class='h5_mark_xx2'>★</span>-->
        	<!--<span>为必填)</span>-->
    </h3>
		<ul class='h5_02_info_per_addlist'>
			<li>
				<span>★</span>
				<span>姓名:</span>
				<span>{{adviceDetail.studentName}}</span>
			</li>
			<li>
				<span>★</span>
				<span>性别:</span>
				<span>{{adviceDetail.sex}}</span>
			</li>
			<li>
				<span>★</span>
				<span>年龄:</span>
				<span>{{adviceDetail.age}}</span>
			</li>
			<li>
				<span>★</span>
				<span>联系人手机:</span>
				<span>
    				{{adviceDetail.telephone}}

    			</span>
			</li>
			<li>
				<span>★</span>
				<span>与之关系:</span>
				<span>{{adviceDetail.relationShip}}</span>
			</li>
			<li>
				<span></span>
				<span>邮箱:</span>
				<span>
    				{{adviceDetail.email}}

    			</span>
			</li>

			<li>
				<span></span>
				<span>QQ:</span>
				<span>
    				{{adviceDetail.qq}}
    			</span>
			</li>
			<li>
				<span></span>
				<span>微信:</span>
				<span>{{adviceDetail.wechat}}</span>
			</li>

			<li>
				<span>★</span>
				<span>来源大类:</span>
				<span>
    				{{adviceDetail.sourceName}}

    			</span>
			</li>
			<li>
				<span>★</span>
				<span>来源小类:</span>
				<span>
    				{{adviceDetail.sourceSubName}}
    			</span>
			</li>

			<li>
				<span>★</span>
				<span>课程大类:</span>
				<span>
    				{{adviceDetail.courseName}}
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>课程小类:</span>
				<span>
    				{{adviceDetail.courseSubName}}
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>所属校区:</span>
				<span>
    				{{adviceDetail.schoolName}}
    			</span>
			</li>
			<li>
				<span></span>
				<span>咨询师:</span>
				<span>
    				{{adviceDetail.counselorName}}
    				</span>
			</li>
			<li>
				<span></span>
				<span>课程顾问:</span>
				<span>
    				{{adviceDetail.courseCounselorName}}
    			</span>
			</li>
			<li>
				<span></span>
				<span>主动联系:</span>
				<span>
					{{shifouByDigit[adviceDetail.initiative]}}

    			</span>
			</li>

			<li>
				<span></span>
				<span>推荐人:</span>
				<span>{{adviceDetail.referrerName}}</span>
			</li>
			<li>
				<span>★</span>
				<span>线索状态:</span>
				<span>
					{{adviceStatus[adviceDetail.status]}}

    			</span>
			</li>
			<li>
				<span>★</span>
				<span>客户等级:</span>
				<span>
					{{adviceLevel[adviceDetail.studentLevel]}}
    			</span>
			</li>
			<li>
				<span></span>
				<span>所属活动:</span>
				<span>{{adviceDetail.fromEvent}}</span>
			</li>

			<li>
				<span></span>
				<span>家庭住址(省):</span>
				<span>
    				{{provinceName}}
    			</span>
			</li>
			<li>
				<span></span>
				<span>市:</span>
				<span>
    				{{cityName}}
    			</span>
			</li>
			<li>
				<span></span>
				<span>区县:</span>
				<span>
    				{{districtName}}
    			</span>
			</li>
			<li>
				<span></span>
				<span>小区:</span>
				<span>{{adviceDetail.biotope}}</span>
			</li>
			<li>
				<span></span>
				<span>详细地址:</span>
				<span>{{adviceDetail.address}}</span>
			</li>
			<li>
				<span></span>
				<span>就读学校:</span>
				<span>{{adviceDetail.school}}</span>
			</li>
			<li>
				<span>★</span>
				<span>班级类别:</span>
				<span>
					{{classTypeDict[adviceDetail.classType]}}

    			</span>
			</li>
			<li class="per_addperson_li_w ">
				<span></span>
				<span>备注:</span>
				<span class="text_scroll">{{adviceDetail.descr}}</span>
			</li>

		</ul>

	</form>
</template>
<script>
	import instance from '../../../api/index.js';
	import axios from 'axios';
	import { mapState } from 'vuex';
	export default {
		data() {
			return {
				adviceDetail: {},
				provinceName: "",
				cityName: "",
				districtName: "",
			};
		},
		computed: {
			// Getting Vuex State from store/index
			...mapState({
				cityJson: state => state.cityJson,
				adviceStatus: state => state.adviceStatus,
				adviceLevel: state => state.adviceLevel,
				shifouByDigit: state => state.shifouByDigit,
				classTypeDict: state => state.classTypeDict
			})
		},
		methods: {
			getAdivceInfo: function(id) { //获取信息
				instance.get('/infor/findInformation/' + id).then((res) => {
					this.adviceDetail = res.data.data;
					this.getProvince();
				})
			},
			getProvince: function() {
				let vm = this;
				if(typeof(this.cityJson.status) == "undefined") { //首次加载 调接口高德地图

					axios.get('/restapi/v3/config/district?subdistrict=3&key=84b4e40f86d5c8087078673175324d9b').then((res) => {
						//this.consultants = res.data.status;
						if(res.data.status == '1') {
							this.$store.commit({
								type: 'setCityJson',
								cityJson: res.data
							})
							//this.provinces = res.data.districts[0].districts;

							res.data.districts[0].districts.forEach(function(e, i) {
								if(e.adcode == vm.adviceDetail.provinceId) {
									vm.provinceName = e.name;
									e.districts.forEach(function(e, i) {
										if(e.adcode == vm.adviceDetail.cityId) {
											vm.cityName = e.name;
											e.districts.forEach(function(e, i) {
												if(e.adcode == vm.adviceDetail.areaId) {
													vm.districtName = e.name;

												}

											})
										}

									})
								}

							});

						} else {
							this.$message.error('操作失败！' + res.data.info);
						}

						console.info("json:" + res.data);

					})
				} else {
					//this.provinces = this.cityJson.districts[0].districts;
					this.cityJson.districts[0].districts.forEach(function(e, i) {
						if(e.adcode == vm.adviceDetail.provinceId) {
							vm.provinceName = e.name;
							e.districts.forEach(function(e, i) {
								if(e.adcode == vm.adviceDetail.cityId) {
									vm.cityName = e.name;
									e.districts.forEach(function(e, i) {
										if(e.adcode == vm.adviceDetail.areaId) {
											vm.districtName = e.name;

										}

									})
								}

							})
						}

					});
				}

				//console.info("provinces:" + this.cityJson.districts[0].districts);
			}
		},
		mounted: function() {
			this.getAdivceInfo(this.$route.params.id);
			//向父组件传参数，解决此组件复用问题
			this.$emit("changeTab","baseInfo");
		}
	};
</script>
