<!--<title>购课信息</title>-->
<style scoped>
	.p_table_la tr:nth-child(1)>td {
		word-break: keep-all;
		word-break: keep-all;
		white-space: nowrap;
	}
</style>
<template>
	<div class="p_con_tab">
		<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
      <span>试听记录{{message}}</span>
    </h3>
		<div class="p_btn_group p_clear_float">
			<input type="button" value="新增" class="p_btn p_btn_siz_2 p_btn_col_gre p_btn_pos_r" @click="addListen">

		</div>
		<div class="p_table_la_over">
			<table class="p_table_la" cellspacing="0" cellpadding="0">
				<tr>
					<td>校区</td>
					<td>课程大类</td>
					<td>课程小类</td>
					<td>上课日期</td>
					<td>教室</td>
					<td>授课教师</td>
					<td>开始时间</td>
					<td>结束时间</td>
					<td>试听类型</td>
					<td>试听时长(分钟)</td>
					<td>操作</td>
				</tr>
				<tr v-for="listen in listenList">
					<td>{{listen.schoolName}}</td>
					<td>{{listen.courseName}}</td>
					<td>{{listen.courseSubName}}</td>
					<td>{{listen.listenDate}}</td>
					<td>{{listen.classRoomName}}</td>
					<td>{{listen.teacherName}}</td>
					<td>{{listen.beginTime}}</td>
					<td>{{listen.endTime}}</td>
					<td>{{listenTypeDict[listen.listenType]}}</td>
					<td>{{listen.listenMinute}}</td>
					<td>
						<input type="button" value="反馈" @click="addListenReply(listen.id)" class="p_btn p_btn_siz_2 p_btn_col_k_oran p_btn_pos_r">
					
						<input type="button" value="编辑" @click="editListen(listen.id)" class="p_btn p_btn_siz_2 p_btn_col_k_oran p_btn_pos_r">
					</td>
				</tr>
			</table>
		</div>
		<!-- 分页 -->
		<div class='h5_page_container' id="con">
			<page :record-count="recordCount" v-on:change-page="changePage">
			</page>
		</div>
	</div>
</template>
<script>
	import instance from '../../../../api/index.js';
	import { mapState } from 'vuex';
	export default {
		components: {
			page: () =>
				import("../../../common/page.vue")
		},
		data() {
			return {
				listenList: [],
				message: "",
				recordCount: 0,
				pageNum: 1 //当前页码
			};
		},

		computed: {
			// Getting Vuex State from store/index
			...mapState({
				listenTypeDict: state => state.listenTypeDict,
			})
		},
		methods: {
			getListenList: function(id) { //获取回访列表信息
				instance.post('/listen/findListens', {
					informationId: id,
					"beginRow": (this.pageNum - 1) * this.pageSize,
					"pageSize": this.pageSize
				}).then((res) => {
					if(res.data.data == null) {
						this.message = '(' + res.data.errmsg + ')';
					} else {
						this.message = "";
						this.listenList = res.data.data;
					}
				})
			},
			getListenCount: function(id) {
				instance.post('/listen/findListensCount', {
					informationId: id
				}).then((res) => {
					this.recordCount = res.data.data.count;
				})

			},
			addListen: function() {
				this.$router.push('/zhaoshengguanli/adviceinfo/' + this.$route.params.id + "/addListen");
			},
			editListen: function(listenId) {
				this.$router.push('/zhaoshengguanli/adviceinfo/' + this.$route.params.id + "/editListen/" + listenId);
			},
			addListenReply: function(listenId) {
				this.$router.push('/zhaoshengguanli/adviceinfo/' + this.$route.params.id + "/addListenReply/"+listenId);
			},
			changePage: function(pageNum) {
				console.info("change-page:" + pageNum);
				this.pageNum = pageNum;
				this.getListenList(this.$route.params.id);
			}
		},
		mounted: function() {
			this.getListenList(this.$route.params.id);
			this.getListenCount(this.$route.params.id);
			
			//向父组件传参数，解决此组件复用问题
			this.$emit("changeTab","listenList");
		}
	};
</script>