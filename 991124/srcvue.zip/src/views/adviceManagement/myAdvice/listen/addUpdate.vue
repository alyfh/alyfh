<!--<title>全部咨询</title>-->
<style scoped>
	.el-input__inner {
		height: 25px;
	}
</style>
<template>
	<section class="p_chi_con">
		<div class="p_con_sea">
			<ul class="p_con_sea_list p_clear_float">

				<li>
					<span>所属校区:</span>
					<span>
            <select name=""  class="p_con_form_select" v-model="findListens.qSchoolId" @change="getTeacherAndRoom(findListens.qSchoolId)">
              		<option value="">--请选择--</option>
              <option v-for="sName in schoolNames" :value="sName.id">{{ sName.schoolName }}</option>
            </select>
					</span>
				</li>

				<li>
					<span>课程大类:</span>
					<span>
            <select name="" id="qCourseName" class="p_con_form_select" v-model="findListens.qCourseId" @change="getClassSub(findListens.qCourseId)">
                		<option value="">--请选择--</option>
               <option v-for="className in classNames" :value="className.id">{{className.courseName}}</option>
            </select>
					</span>
				</li>
				<li>
					<span>课程小类:</span>
					<span>
            <select name="" id="qCourseSubName" class="p_con_form_select" v-model="findListens.qCourseSubId">
             		<option value="">--请选择--</option>
              <option v-for="classNameSub in classNameSubs" :value="classNameSub.id">{{classNameSub.courseSubName}}</option>
            </select>
					</span>
				</li>

				<li>
					<span>试听类型:</span>
					<span>
            <select name="" id="" class="p_con_form_select" v-model="findListens.qListenType">
             		<option value="">--请选择--</option>
                    <option v-for = "(item,key) in listenTypeDict" :value="key">{{item}}</option>

            </select>
					</span>
				</li>
				<li>
					<span>试听时长:</span>
					<span>
            <select name="" id="" class="p_con_form_select" v-model="findListens.qListenMinute" @change="calculateDate($event)">
             		<option value="">--请选择--</option>
                    <option v-for = "(item,key) in listenMinuteDict" :value="key">{{item}}</option>

            </select>
					</span>
				</li>

				<li>
					<span>开始时间:</span>
					<span>
						<el-time-picker   value-format="HH:mm:ss"  placeholder="Pick a time" style="width:95%" v-model="findListens.qBeginTime" @change="calculateDate($event)"></el-time-picker>
					</span>
				</li>
				<li>
					<span>结束时间:</span>
					<span>
						<el-time-picker  value-format="HH:mm:ss"  placeholder="Pick a time" style="width:95%" v-model="findListens.qEndTime"></el-time-picker>
    				</span>
				</li>
				<li>
					<span>授课教师:</span>
					<span>
            <select name="" id="" class="p_con_form_select" v-model="findListens.qTeacherId">
             		<option value="">--请选择--</option>
                    <option v-for = "(item,index) in teachers" :value="item.id">{{item.realName}}</option>

            </select>
					</span>
				</li>

				<!--li>
					<span>上课日期:</span>
					<span>
           <el-date-picker type="date"   value-format="yyyy-MM-dd" placeholder="Pick a date" style="width:100%" @change="setWeekDay" v-model="listenDetail.listenDate"></el-date-picker>


            </select>
					</span>
				</li-->

				<li>
					<span>试听教室:</span>
					<span>
            <select name="" id="" class="p_con_form_select" v-model="findListens.qClassRoomId">
             		<option value="">--请选择--</option>
                    <option v-for = "(item,index) in classRooms" :value="item.id">{{item.classRoomName}}</option>

            </select>
					</span>
				</li>

			</ul>
			<div class="p_btn_group p_clear_float">
				<!--input type="button" value="保存预约" @click="saveListen" class="p_btn p_btn_siz_2 p_btn_col_ora p_btn_pos_r"-->
				<input type="button" value="查询" @click="query" class="p_btn p_btn_siz_2 p_btn_col_gre p_btn_pos_r">
			</div>
		</div>

		<div class="p_con_tab">
			<div class="p_btn_group p_clear_float">
				<input type="button" value="下周" class="p_btn p_btn_siz_2 p_btn_col_gre p_btn_pos_r" @click="nextWeek()">
				<input type="button" value="本周" class="p_btn p_btn_siz_2 p_btn_col_ora p_btn_pos_r" @click="nowWeek()">
				<input type="button" value="上周" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r" @click="previousWeek()">

			</div>
			<div class="p_table_la_over">
				<table class="p_table_la" cellspacing="0" cellpadding="0">
					<tr v-if="listenList!=null">

						<td v-for=" listen in listenList">{{listen.listenDate}} {{weekDay[listen.weekday]}}</td>

					</tr>
					<tr v-if="listenList!=null" v-for="num in maxNumOfWeek">

						<td v-for=" listen in listenList">
							<span v-if="listen.children.length>=num" @click="writeListen(listen.children[num-1])" style="cursor: pointer;color: #0d8ddb;">
							<template v-if="listen.children[num-1].className!=null">
								{{listen.children[num-1].className}}<br>
							</template>
							{{listen.children[num-1].beginTime}}-{{listen.children[num-1].endTime}}<br>
							{{listen.children[num-1].classRoomName}}-{{listen.children[num-1].teacherName}}
							</span></td>

					</tr>
					<tr v-if='JSON.stringify(listenList)=="[]" && isQueryFlag'>
						<td>无符合查询条件的记录！</td>
					</tr>
				</table>
				<!--<router-view></router-view>-->
			</div>
		</div>

	</section>
</template>
<script>
	import instance from '../../../../api/index.js';
	import * as util from '../../../../assets/util.js';
	import { mapState } from 'vuex';

	export default {
		computed: {
			// Getting Vuex State from store/index
			...mapState({
				listenTypeDict: state => state.listenTypeDict,
				listenMinuteDict: state => state.listenMinuteDict,
				layerShow: state => state.layerShow,
				pageSize: state => state.pageSize,
				pageLarge: state => state.pageLarge,
				adviceStatus: state => state.adviceStatus,
				adviceLevel: state => state.adviceLevel,
			})
		},
		data() {
			return {
				actionType: "",
				findListens: { //查询条件
					qSchoolId: "",
					qCourseId: "",
					qCourseSubId: "",
					qListenType: "",
					qEndTime: ""

				},
				listenDetail: { //查询条件
					beginTime: "",
					endTime: ""
				},
				schoolNames: [], //校区,
				classNames: [], //课程大类
				classNameSubs: [], //课程小类
				teachers: [], //授课教师
				classRooms: [], //教室
				listenList: [], //可预约试听列表
				maxNumOfWeek: 0,
				weekDay: {
					"1": "星期一",
					"2": "星期二",
					"3": "星期三",
					"4": "星期四",
					"5": "星期五",
					"6": "星期六",
					"7": "星期日"
				},
				isQueryFlag: false //是否操作过查询按钮；点击查询按钮 无数据，显示"无符合查询条件的记录！"
			};
		},
		methods: {
			query: function() {
				let findListen = util.deepcopy(this.findListens);
				this.getListens(findListen);

			},
			getListens: function(lis) { //获取列表
				let vm = this;
				let axiosUrl = "";
				if(lis.qSchoolId == "") {
					vm.$message.error('请选择校区！！！');
					return;
				}
				if(lis.qCourseId == "") {
					vm.$message.error('请选择课程大类！！！');
					return;
				}
				if(lis.qCourseSubId == "") {
					vm.$message.error('请选择课程小类！！！');
					return;
				}
				if(lis.qListenType == "") {
					vm.$message.error('请选择试听类型！！！');
					return;
				} else if(lis.qListenType == "0" && (!lis.qListenMinute || lis.qListenMinute == "")) {
					vm.$message.error('请选择试听时长！！！');
					return;
				}
				if(lis.qListenType == "0") {
					axiosUrl = "/listen/findListenables";
				} else {
					axiosUrl = "/lesson/findWeekLessonTimeTables2";
					delete lis['qListenType'];
					delete lis['qListenMinute'];
				}
				instance.post(axiosUrl, lis).then((res) => {
					//this.recordCount = res.data.data.count;
					if(res.data.errcode == "0") {
						vm.listenList = [];
						vm.maxNumOfWeek = 0;
						if(res.data.data != null) {
							res.data.data.forEach(function(parentNode, i) {
								let flag = false; //默认不存在
								vm.listenList.forEach(function(node, i) {
									if(parentNode.listenDate) { //正常试听
										if(parentNode.listenDate == node.listenDate) {
											node.children.push(parentNode);
											flag = true;
										}
									} else { //跟班
										if(parentNode.lessonDate == node.listenDate) {
											parentNode.listenDate = parentNode.lessonDate;
											node.children.push(parentNode);
											flag = true;
										}
									}
								});
								if(!flag) {
									let item = {};
									parentNode.listenDate = parentNode.listenDate || parentNode.lessonDate;
									item.listenDate = parentNode.listenDate || parentNode.lessonDate;
									item.weekday = parentNode.weekday;
									item.children = [parentNode];
									vm.listenList.push(item);
								}
							})
						}
						this.isQueryFlag = true;

					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}

					for(var i in vm.listenList) { //计算最大行数
						console.info(i + ":" + vm.listenList[i].children.length);
						if(vm.listenList[i].children.length > vm.maxNumOfWeek)
							vm.maxNumOfWeek = vm.listenList[i].children.length;
						//console.info(vm.maxNumOfWeek);
					}
				});
				console.info("vm.listenList==" + vm.listenList + "  vm.listenList=[]" + vm.listenList == null + "222" + vm.listenList == []);
			},

			getSchool: function() { //获取校区数据
				//获取当前登录人
				let loginInfo = util.session("loginInfo");
				instance.get('/school/findUserSchools/' + loginInfo.login.userId).then((res) => {
					this.schoolNames = res.data.data;
				})
			},
			getTeacher: function(schoolId) { //获取授课教师列表
				instance.post('/teacher/findSimpleTeachers', {
					qSchoolId: schoolId
				}).then((res) => {
					this.teachers = res.data.data;
				})
			},
			getClassRooms: function(schoolId) { //获取授课教室列表
				instance.post('/classroom/findSimpleClassRooms', {
					qSchoolId: schoolId
				}).then((res) => {
					this.classRooms = res.data.data;
				})
			},

			getClass: function() { //获取课程大类数据
				// course/findCourses
				// /course/findSimpleCourse
				instance.post('/course/findCourses', {}).then((res) => {
					this.classNames = res.data.data;
				})
			},
			getClassSub: function(id) { //获取课程小类数据
				// /course/findSimpleCourseSubs
				instance.post('/course/findSimpleCourseSubs', {
					qCourseId: id
				}).then((res) => {
					this.classNameSubs = res.data.data;
					// console.info(res.data);
				})
			},
			calculateDate: function() { //计算试听时间
				//console.log("listenMinuteDict="+event.target.value);
				var listenMinute = this.findListens.qListenMinute; //试听时长
				var btime = this.findListens.qBeginTime; //开始时间
				var etime = this.findListens.qEndTime; //结束时间
				//已知试听时长和开始时间  得到结束时间
				if(btime != null && btime != "" && btime != "NAN" && listenMinute != null && listenMinute != "" && listenMinute != "NAN") {
					var arr_time = btime.split(":");
					var bhour = arr_time[0];
					var bminute = parseInt(arr_time[1]) + parseInt(listenMinute);
					if(120 > bminute && bminute >= 60) {
						bhour = parseInt(arr_time[0]) + 1;
						bminute = bminute - 60;
					} else if(bminute >= 120) {
						bhour = parseInt(arr_time[0]) + 2;
						bminute = bminute - 120;
					}
					etime = bhour + ":" + bminute + ":" + arr_time[2];
					this.findListens.qEndTime = etime;
					return this.findListens.qEndTime
				}

			},
			getTeacherAndRoom: function(schoolId) {
				this.getTeacher(schoolId);
				this.getClassRooms(schoolId);
			},
			writeListen: function(item) { //弹框确认并保存试听信息

				this.listenDetail.beginTime = item.beginTime;
				this.listenDetail.endTime = item.endTime;
				this.listenDetail.teacherId = item.teacherId;
				this.listenDetail.listenDate = item.listenDate;
				this.listenDetail.classRoomId = item.classRoomId;
				this.listenDetail.weekday = item.weekday;
				this.listenDetail.classId = item.classId;

				let qCourseName = $("#qCourseName").find("option:selected").text();
				let qCourseSubName = $("#qCourseSubName").find("option:selected").text();

				let message = "<strong>您正在预约" + qCourseName + "-" + qCourseSubName + (this.findListens.qListenType == 0 ? '正常试听' : '跟班试听') + "</strong><br/>" +
					"预约试听时间：" + item.listenDate + "，" + this.weekDay[item.weekday] + "<br/>" +
					item.beginTime + "-" + item.endTime + "<br/>" +
					"上课教室：" + item.classRoomName + "<br/>" +
					"上课教师：" + item.teacherName + "<br/>";
				if(this.findListens.qListenType == 1)
					message += "跟班班级：" + item.className + "<br/>";

				this.$confirm(message, '', {
					dangerouslyUseHTMLString: true
				}).then(() => {
					this.saveListen();
				}).catch(() => {

				});
			},
			setWeekDay: function(dateValue) {
				//console.info(new Date(dateValue).getDay())
				let weekdayInt = new Date(dateValue).getDay();
				if(weekdayInt == 0)
					weekdayInt = 7;
				this.listenDetail.weekday = weekdayInt;
			},
			getListenInfo: function(id) {
				instance.get('/listen/findListen/' + id).then((res) => {
					this.listenDetail = res.data.data;
					this.getTeacherAndRoom(this.listenDetail.schoolId);
					this.getClassSub(this.listenDetail.courseId);
					this.findListens.qSchoolId = this.listenDetail.schoolId;
					this.findListens.qCourseId = this.listenDetail.courseId;
					this.findListens.qCourseSubId = this.listenDetail.courseSubId;
					this.findListens.qListenType = this.listenDetail.listenType;
					this.findListens.qListenMinute = this.listenDetail.listenMinute;

				})
			},
			saveListen: function() {
				let item = {};
				item.schoolId = this.findListens.qSchoolId;
				item.courseId = this.findListens.qCourseId;
				item.courseSubId = this.findListens.qCourseSubId;
				item.listenType = this.findListens.qListenType;
				item.listenMinute = this.findListens.qListenMinute;

				item.beginTime = this.listenDetail.beginTime;
				item.endTime = this.listenDetail.endTime;
				item.teacherId = this.listenDetail.teacherId;
				item.listenDate = this.listenDetail.listenDate;
				item.classRoomId = this.listenDetail.classRoomId;
				item.informationId = this.listenDetail.informationId;
				item.weekday = this.listenDetail.weekday;
				item.classId = this.listenDetail.classId;
				item.id = this.listenDetail.id;
				this.listenDetail.id ? this.updateListen(item) : this.createListen(item)
			},
			createListen: function(item) {

				instance.post('/listen/createListen', item).then((res) => {
					if(res.data.errcode == '0') {
						this.$message.info('信息创建成功！');
						this.$router.push('/zhaoshengguanli/adviceinfo/' + this.$route.params.id + "/listenList");

					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}

				})
			},
			updateListen: function(item) {
				instance.post('/listen/changeListen', item).then((res) => {
					if(res.data.errcode == '0') {
						this.$message.info('信息修改成功！');
						this.$router.push('/zhaoshengguanli/adviceinfo/' + this.$route.params.id + "/listenList");
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}
				})
			},
			nextWeek: function() {

				this.findListens.qBeginDate = window.util_date.getNextMonday(window.util_date.getMonday()).pattern("yyyy-MM-dd");
				this.findListens.qEndDate = window.util_date.getNextSunday(window.util_date.getMonday()).pattern("yyyy-MM-dd");
				//this.dateDetail = window.util_date.getDays(window.util_date.getNextMonday(window.util_date.getMonday()), 'yyyy-MM-dd');
				window.util_date.newToday(window.util_date.getNextMonday(window.util_date.getMonday()));
				this.query();

			},
			previousWeek: function() {
				this.findListens.qBeginDate = window.util_date.getPreviousMonday(window.util_date.getMonday()).pattern("yyyy-MM-dd");
				this.findListens.qEndDate = window.util_date.getPreviousSunday(window.util_date.getMonday()).pattern("yyyy-MM-dd");
				//this.dateDetail = window.util_date.getDays(window.util_date.getPreviousMonday(window.util_date.getMonday()), 'yyyy-MM-dd');
				window.util_date.newToday(window.util_date.getPreviousMonday(window.util_date.getMonday()));
				this.query();

			},
			nowWeek: function() {
				window.util_date.newToday(new Date());
				this.findListens.qBeginDate = window.util_date.getMonday().pattern("yyyy-MM-dd");
				this.findListens.qEndDate = window.util_date.getSunday().pattern("yyyy-MM-dd");
				this.query();
			},

		},
		mounted: function() {
			if(this.$route.params.listenId) { //修改
				this.getListenInfo(this.$route.params.listenId);
			} else {
				this.listenDetail.informationId = this.$route.params.id; //咨询id
			}
			this.getSchool(); //校区
			this.getClass(); //课程大类
			window.util_date.newToday(new Date());
			this.findListens.qBeginDate = window.util_date.getMonday().pattern("yyyy-MM-dd");
			this.findListens.qEndDate = window.util_date.getSunday().pattern("yyyy-MM-dd");

			//向父组件传参数，解决此组件复用问题
			this.$emit("changeTab", "addListen");
		}
	};
</script>