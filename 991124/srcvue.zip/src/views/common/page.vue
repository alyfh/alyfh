<style scoped>
 @import '../../assets/css/paging.css';
</style>

<template>
<div class="page_container" :style="{ marginRight: mright + 'px' }">
<div class="page_input">第<input autocomplete="off" type="text" v-model="temp_pageNum">页<span id="page_btn" @click="page_btn_click">确定</span>
</div>
<ul class="page_num">
<template v-for="n in list">
<li  :class="{page_num_click_blue:n==pageNum}" @click="li_click($event)">
{{n}}
</li>
</template>
</ul>
<div class="tRecordCount">共{{recordCount}}条&nbsp;分{{pageCount}}页</div>
</div>
</template>




<script>
import { mapState } from 'vuex';

export default {

  props: ['recordCount'],
  data() {
    return {
      list: [],
      mright:0,
      allwidth:0,
      mixwidth:0,
      	  pageNum:1,//当前页码
	    //  pageCount:0,//共几页
		  temp_pageNum:""//用户输入页码

    };
  },
   computed: {
    // Getting Vuex State from store/index
    ...mapState({
	  pageSize: state => state.pageSize,
	  pageLarge: state => state.pageLarge
    }),
	 pageCount: function () {
      // `this` points to the vm instance
	  let pageCount_temp=Math.ceil(this.recordCount/this.pageSize);
	   this.getData(pageCount_temp,this.pageNum,this.pageLarge);
      return pageCount_temp;//共几页
    }

  },

  methods: {

  page_btn_click:function(){

        if(this.temp_pageNum>0 && this.temp_pageNum<=this.pageCount){
            this.pageNum=parseInt(this.temp_pageNum);
	        this.$emit('change-page', this.pageNum);
	        this.pageCount;
           //this.getData(this.pageCount,this.pageNum,this.pageLarge);
        }else{
            alert('请输入范围内数字');
        }
    },
	li_click:function(event){
        this.pageNum=parseInt($(event.currentTarget).html());
		this.temp_pageNum=this.pageNum;
		 // this.$emit('change-page', this.pageNum);
       // this.getData(this.pageCount,this.pageNum,this.pageLarge);
        //getData(parentNode,t_recordCount,pageNum,t_pageSize,t_pageLarge,funname);
        this.$emit('change-page', this.pageNum);//刷新页面数据
         this.pageCount;
    },
 getData:function(pageCount,pageNum,pageLarge){
     this.list=[];
    let pageMin=parseInt(this.pageLarge/2);
    let pageMax=pageLarge-1;

    //生成分页
    if(pageCount<pageLarge){//页码小于pageLarge个
        for(var i=1;i<=pageCount;i++){
            this.list.push(i);
        };
    }
    else if((pageNum-pageMin)>0 && ((pageCount-pageNum)>=pageMin)){//前后都能渐增
        for(var i=pageNum-pageMin;i<=pageNum+pageMin;i++){
    	  this.list.push(i);
        };
    }else if(pageNum-pageMin>0 && ((pageCount-pageNum)<pageMin)){//后面不渐增
    	for(var i=pageCount-pageMax;i<=pageCount;i++){
    		this.list.push(i);
    	};
    }else if(pageNum-pageMin<=0 && ((pageCount-pageNum)>=pageMin)){//前面不能渐增
    	for(var i=1;i<=pageLarge;i++){
    		this.list.push(i);
    	};
    };
    this.mixwidth=$('.page_container').css('width');
    this.allwidth=$('.h5_page_container').css('width');
    this.mright=(parseInt(this.allwidth)-parseInt(this.mixwidth))/2;
    // window.onresize = function(){
    //   this.allwidth=$('.h5_page_container').css('width');
    //   this.mright=(parseInt(this.allwidth)-parseInt(width))/2;
    //   console.log(mright);
    // }
    //$('.page_container').css('margin-right',parseInt(width)/2);
    //this.$emit('change-page', this.pageNum);//刷新页面数据
	//console.info("lsit:"+this.list);
  },

    //const that = this;


  },
  // mounted () {
  //   // 注：window.onresize只能在项目内触发1次
  //   window.onresize = function windowResize () {
  //     // 通过捕获系统的onresize事件触发我们需要执行的事件
  //     this.mixwidth=$('.page_container').css('width');
  //     this.allwidth=$('.h5_page_container').css('width');
  //     //console.log(parseInt(this.mixwidth));
  //     this.mright=(parseInt(this.allwidth)-parseInt(this.mixwidth))/2;
  //       console.log(mright);
  //   }
  // },
  mounted () {
    //const that = this
    window.onresize = () => {
      return (() => {
        this.mixwidth=$('.page_container').css('width');
            this.allwidth=$('.h5_page_container').css('width');
            //console.log(parseInt(this.mixwidth));
            this.mright=(parseInt(this.allwidth)-parseInt(this.mixwidth))/2;
              console.log(this.mright);
      })()
    }
  },
  watch: {
    mright(val) {
       // console.log(mright);
      this.mright = val
    }
  },
  created() {
      //console.info("recordCount"+this.recordCount);
  }
};
</script>
