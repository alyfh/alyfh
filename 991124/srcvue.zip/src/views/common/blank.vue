<template>
<div style="display: table;height:100%;width:100%">
	<div class="g-center">
		<h1 style="text-align:center">空白页</h1>
	</div>
</div>
</template>
