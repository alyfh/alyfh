<style scoped>
		#stop_page{

			/*background-image: url("../../assets/img/01.jpg");*/
			background-repeat: no-repeat;
			background-size: 100%;

		}
		#zl_sto_con{
			width: 80%;
			margin: auto;
			margin-top: 300px;

		}
		#zl_sto_con>div:nth-child(1){
			width: 178px;
			height: 166px;
			margin: auto;
			background-image: url('../../assets/img/empty.png');
			/*background-size: 2em;*/
		}
		#zl_sto_con>div:nth-child(2){
			width: 100%;
			margin-top: 15px;
			text-align: center;
			font-size: 2em;
			font-weight: bold;
			color: #747c85;
			text-align: center;
		}
		#zl_sto_con a{
			color: #747c85;
		}
</style>

<template>
    <div>
	<div id="stop_page">
	<div id="zl_sto_con">
		<div></div>
		<div>
			哇哦，你的页面不见了！你可以
			<router-link :to="{path:'/'}">返回主页</router-link>
		</div>
	</div>
	</div>
	</div>
</template>
<script>

export default {
  created() {

  }
}
</script>
