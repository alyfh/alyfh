<style>
	/*///////////////////////////////////*/
	.list_line_title{
		width: 500px;
		margin:40px auto 20px auto;
		font-size: 1.5rem;
		text-align: center;
	}
	.list_line_con{
		width: 415px;
		margin:auto;
	}
	.p_btn_group1{
		display: inline-block;
		width: 49%;
		margin: auto;
		margin-top: 20px
	}
	
	.p_btn_pos_l{
		float:left;
		margin-left: 15px;
		margin-bottom: 3px;
	}
</style>
<template>
	<div>
		<h5 class="list_line_title">修改密码</h5>
		<ul class="list_line_con">
			<li>
				<span>用户名:</span>
				<span><input type="text" readonly="readonly" v-model="realName" class="p_con_form_input"></span>
			</li>
			<li>
				<span>当前密码:</span>
				<span><input type="password" v-model="sources.oldPassword"  class="p_con_form_input"></span>
				<span class="pass_eye pass_eye_hide"></span>
			</li>
			<li>
				<span>新密码:</span>
				<span><input type="password" v-model="sources.password"  class="p_con_form_input"></span>
				<span class="pass_eye pass_eye_hide"></span>
			</li>
			<li>
				<span>确认密码:</span>
				<span><input type="password" v-model="sources.rePassword"  class="p_con_form_input"></span>
				<span class="pass_eye pass_eye_hide"></span>
			</li>
		</ul>
		<div class="p_btn_group p_clear_float p_btn_group1">
			<input type="button" value="确定" @click="save" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r">
				
		</div>
		<div class="p_btn_group p_clear_float p_btn_group1">
			<input type="button" value="取消" @click="cancel" class="p_btn p_btn_siz_2 p_btn_col_oran p_btn_pos_l">
		</div>
	</div>
</template>
<script>
	import instance from '../api/index.js';
	import axios from 'axios';
	import { changePw } from "../api/account";
	import { mapState } from 'vuex';
	import * as util from '../assets/util.js';
	export default {
		data() {
			return {
				sources: {
					oldPassword : "",
					password:"",
					rePassword:""
				},
				realName : "",
				loginInfo : []
			}
		},
		created() {
			//从session中获取用户登陆json
			this.loginInfo = util.session('loginInfo').login;
			//设置用户名称
			this.realName = this.loginInfo.realName;
		},methods: {
			cancel : function(){ //取消
				this.$router.go(-1)
			},
			save: function() { //保存密码修改
				instance.post('/user/changePwd', this.sources).then((res) => {
					if(res.data.errcode == '0') {
						this.$message.success('修改密码成功！');
						this.$router.go(-1);
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}
				});
			}
		},
		mounted() {
			$('.pass_eye').click(function(event){
		if($(this).hasClass('pass_eye_hide')){
			$(this).removeClass('pass_eye_hide');
			$(this).addClass('pass_eye_show');
			$(this).parent().find('input').attr('type','text')
		}else{
			$(this).removeClass('pass_eye_show');
			$(this).addClass('pass_eye_hide');
			$(this).parent().find('input').attr('type','password')
		}
	})	
		}
	};

</script>

