<style scoped>

</style>

<template>
  <div>
    <el-row>
    </el-row>
  </div>
</template>

<script>
export default {
  data() {
    return {

    };
  },
  methods: {

  },
  mounted: () => {
  }
};
</script>
