<!-- <title>发件箱</title> -->
<style scoped>
* {
  margin: 0;
  padding: 0;
}
.hairBox {
  width: calc(100% - 40px);
  height: auto;
  padding: 0 20px;
  background: white;
}
.hairBox:after {
  display: block;
  clear: both;
  content: "";
  visibility: hidden;
  height: 0;
}
.hairBox_xqs {
  width: 100%;
  height: auto;
}
.hairBox_xqs ul {
  overflow: hidden;
  line-height: 40px;
}
.hairBox_xqs ul li {
  float: left;
  margin-right: 15px;
}
.hairBox_xqs ul li img {
  width: 15px;
  vertical-align: middle;
}
.hairBox_xqs ul li span {
  margin-left: 2px;
}
.hairBox_xqs ul li span:hover {
  cursor: pointer;
}
.hairBox_lists {
  width: 100%;
  height: auto;
}
.hairBox_list {
  padding: 5px;
  width: calc(50% - 25px);
  height: 116px;
  border: 1px solid #cbcbcb;
  border-radius: 5px;
  float: left;
  margin-bottom: 15px;
}
.hairBox_list:nth-child(2n) {
  margin-left: 20px;
}
.hairBox_list ul li {
  margin: 2px 0;
}
</style>
<template>
        <div class="hairBox">
            <div class="hairBox_xqs">
                <ul>
                    <li><img src="../../../assets/img/newadd.png" alt=""><span @click="newAdd()">新增</span></li>
                    <li>
                        <label for="ckb">
                            <input type="checkbox" name="" id="ckb" :checked="dataListDel.length===dataList.length"
                   @click="allChecked">
                            <span>全选</span>
                        </label>
                    </li>
                    <li><img src="../../../assets/img/delete.png" alt=""><span @click="del">删除</span></li>
                </ul>
            </div>
            <div class="hairBox_lists">
                <div class="hairBox_list" v-for="(item,index) in dataList">
                  {{item.id}}
                  {{dataListDel}}
                    <ul>
                        <li>
                            <div class="hairBox_tit">
                                <p><span>通知</span> <input type="checkbox" :id="'id'+item.id" :value="item.id" v-model="dataListDel" style="float: right;"></p>
                            </div>
                        </li>
                        <li>
                            <p>2018年4月29日</p>
                        </li>
                        <li>所属校区: <span>亦庄</span></li>
                        <li>接收人员: <span>所有</span></li>
                        <li>标题: <span>校庆</span></li>
                        <li>内容: <span>放假放假放假</span></li>
                    </ul>
                </div>
            </div>
        </div>
</template>
<script>
export default {
  data() {
    return {
      dataList: [
        { id: 1, name: "HTML5", isSelected: false },
        { id: 2, name: "CSS3", isSelected: false },
        { id: 3, name: "Angular", isSelected: false },
        { id: 4, name: "Vue", isSelected: false },
        { id: 5, name: "Linux", isSelected: false },
        { id: 6, name: "JavaScript", isSelected: false }
      ],
      dataListDel: []
    };
  },
  methods: {
    //新增
    newAdd() {
      this.$router.push("/tongzhiguanli/fajianguanli/addNotice");
    },
    // 全选及反选
    allChecked() {
      if (this.dataListDel.length === this.dataList.length) {
        // 全不选
        this.dataListDel = [];
      } else {
        this.dataListDel = [];
        // 全选
        this.dataList.forEach(item => {
          this.dataListDel.push(item.id); // 与checkbox的value统一
        });
      }
    },
    //删除
    del() {
      this.$confirm("此操作将永久删除该文件, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "再想想",
        type: "warning"
      })
        .then(() => {
          this.$message({
            type: "success",
            message: "删除成功"
          });
          var dataList = this.dataList;
          var dataListDel = this.dataListDel;
          /*循环查找选中项*/
          dataListDel.forEach(function(itemDel, index) {
            dataList.forEach(function(itemList, i) {
              if (itemList.id == itemDel) {
                dataList.splice(i, 1);
              }
            });
          });
          this.dataList = dataList;
          this.dataListDel = [];
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    }
  }
};
</script>