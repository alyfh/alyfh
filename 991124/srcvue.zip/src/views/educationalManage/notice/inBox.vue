<!-- <title>收件箱</title> -->
<style scoped>
* {
  margin: 0;
  padding: 0;
}
.hairBox {
  width: calc(100% - 40px);
  height: auto;
  padding: 0 20px;
  background: white;
}
.hairBox:after {
  display: block;
  clear: both;
  content: "";
  visibility: hidden;
  height: 0;
}
.hairBox_xqs {
  width: 100%;
  height: auto;
}
.hairBox_xqs ul {
  overflow: hidden;
  line-height: 40px;
}
.hairBox_xqs ul li {
  float: left;
  margin-right: 15px;
}
.hairBox_xqs ul li img {
  width: 15px;
  vertical-align: middle;
}
.hairBox_xqs ul li span {
  margin-left: 2px;
}
.hairBox_lists {
  width: 100%;
  height: auto;
}
.hairBox_list {
  padding: 5px;
  width: calc(50% - 25px);
  height: 116px;
  border: 1px solid #cbcbcb;
  border-radius: 5px;
  float: left;
  margin-bottom: 15px;
}
.hairBox_list:nth-child(2n) {
  margin-left: 20px;
}
.hairBox_list ul li {
  margin: 2px 0;
}
</style>
<template>
        <div class="hairBox">
            <div class="hairBox_xqs">
                <ul>
                    <li><img src="../../../assets/img/newadd.png" alt=""><span>全部已读</span></li>
                    <!-- <li>
                        <label for="ckb">
                            <input type="checkbox" name="" id="ckb">
                            <span>全选</span>
                        </label>
                    </li>
                    <li><img src="../../../assets/img/delete.png" alt=""><span>删除</span></li> -->
                </ul>
            </div>
            <div class="hairBox_lists">
                <div class="hairBox_list" v-for="i in 6">
                    <ul>
                        <li>
                            <div class="hairBox_tit">
                                <p><span>通知</span> <span style="float: right;color: #69B8AF;">已读</span></p>
                            </div>
                        </li>
                        <li>
                            <p>2018年4月29日</p>
                        </li>
                        <li>所属校区: <span>亦庄</span></li>
                        <li>接收人员: <span>所有</span></li>
                        <li>标题: <span>校庆</span></li>
                        <li>内容: <span>放假放假放假</span></li>
                    </ul>
                </div>
            </div>
        </div>
</template>
<script>
</script>