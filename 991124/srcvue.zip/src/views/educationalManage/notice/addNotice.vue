<!-- <title>新建通知</title> -->
<style scoped>
.addNotice {
  width: calc(100% - 40px);
  height: auto;
  padding: 20px;
  background: white;
}
.addNotice_head {
  font-size: 25px;
  font-weight: bold;
  text-align: center;
  line-height: 50px;
}
.addNotice_mian {
  width: 96%;
  height: auto;
  padding: 30px 2%;
  border: 1px solid #cccccc;
  border-radius: 5px;
}
.addNotice_mian ul li {
  margin: 10px 0 0;
}
label.el-checkbox {
  width: 80px;
}
textarea.el-textarea__inner {
  height: 150px;
}
</style>
<template>
    <div class="addNotice">
        <div class="addNotice_head">
            <h3>新建通知</h3>
        </div>
        <div class="addNotice_mian">
            <ul>
                <li>
                    <span>消息类型:</span>
                    <el-radio v-model="radio" label="1">通知</el-radio>
                </li>
                <li>
                    <span>发送时间:</span>
                    <el-date-picker
                        v-model="value1"
                        type="date"
                        placeholder="选择日期">
                    </el-date-picker>
                </li>
                <li>
                    <span>接收校区:</span>
                    <el-checkbox-group v-model="checkList" style="display:inline-block;">
                        <el-checkbox label="全部校区"></el-checkbox>
                        <el-checkbox label="浦黄榆校区"></el-checkbox>
                        <el-checkbox label="顺义校区"></el-checkbox>
                    </el-checkbox-group>
                </li>
                <li>
                    <span>接收人员:</span>
                    <el-checkbox-group v-model="checkList" style="display:inline-block;">
                        <el-checkbox label="所有人"></el-checkbox>
                        <el-checkbox label="教师"></el-checkbox>
                        <el-checkbox label="学生"></el-checkbox>   
                    </el-checkbox-group>
                </li>
                <li>
                    <span>标题:</span>
                    <el-input v-model="input" placeholder="请输入内容"></el-input>
                </li>
                <li>
                    <span>内容:</span>
                    <el-input
                        type="textarea"
                        :rows="2"
                        placeholder="请输入内容"
                        v-model="textarea">
                    </el-input>
                </li>
            </ul>
        </div>
        <div class="" style="text-align: center;padding: 10px 0 0;">
                <el-button style="background: #3fa599;color:white;width: 120px;margin-right: 100px;" @click="cancel()">确认</el-button>
                <el-button style="width: 120px;" @click="cancel()">取消</el-button>
        </div>
    </div>
</template>
<script>
export default {
  data() {
    return {
      radio: "",
      pickerOptions1: {
        disabledDate(time) {
          return time.getTime() > Date.now();
        },
        shortcuts: [
          {
            text: "今天",
            onClick(picker) {
              picker.$emit("pick", new Date());
            }
          },
          {
            text: "昨天",
            onClick(picker) {
              const date = new Date();
              date.setTime(date.getTime() - 3600 * 1000 * 24);
              picker.$emit("pick", date);
            }
          },
          {
            text: "一周前",
            onClick(picker) {
              const date = new Date();
              date.setTime(date.getTime() - 3600 * 1000 * 24 * 7);
              picker.$emit("pick", date);
            }
          }
        ]
      },
      value1: ""
    };
  },
  methods: {
    cancel() {
      this.$router.push("/jiaowuguanli/tongzhiguanli/fajianguanli");
    }
  }
};
</script>