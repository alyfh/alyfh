<!-- <title>周课表</title> -->
<style>
	.p_monthTable{
		margin:auto;
		margin-bottom: 150px
	}
	.p_monthTable tr>td{
		padding:5px!important;
		width: 150px!important;
		border:solid 1px #f0f0f0;
		cursor: pointer;
	}
	.timeTable_td:hover >.timeTable_hidList{
		display: block;
	}
</style>
<script>
  import instance from '../../../api/index.js';
  import { mapState } from 'vuex';
  export default {
    props: ['classId'],
    data() {
      return {
        seaDetail: {
          qBeginDate: "",
          qEndDate: ""
        },
        dateDetail: [],

        weekDetail: [1,2,3,4,5,6,7],
        tableList:[],
        td:[[],[],[],[],[],[],[]],
        max:0,
        studentList:[]

      };
    },
    methods: {
      nextWeek: function() {
        this.td=[[],[],[],[],[],[],[]];
        this.seaDetail.qBeginDate = window.util_date.getNextMonday(window.util_date.getMonday()).pattern("yyyy-MM-dd");
        this.seaDetail.qEndDate = window.util_date.getNextSunday(window.util_date.getMonday()).pattern("yyyy-MM-dd");
        this.dateDetail = window.util_date.getDays(window.util_date.getNextMonday(window.util_date.getMonday()), 'yyyy-MM-dd');
        this.getSchedule();

      },
      previousWeek: function() {
        this.td=[[],[],[],[],[],[],[]];
        this.seaDetail.qBeginDate = window.util_date.getPreviousMonday(window.util_date.getMonday()).pattern("yyyy-MM-dd");
        this.seaDetail.qEndDate = window.util_date.getPreviousSunday(window.util_date.getMonday()).pattern("yyyy-MM-dd");
        this.dateDetail = window.util_date.getDays(window.util_date.getPreviousMonday(window.util_date.getMonday()), 'yyyy-MM-dd');
        this.getSchedule();

      },
      nowWeek: function() {
        this.td=[[],[],[],[],[],[],[]];
        window.util_date.newToday(new Date());
        this.seaDetail.qBeginDate = window.util_date.getMonday().pattern("yyyy-MM-dd");
        this.seaDetail.qEndDate = window.util_date.getSunday().pattern("yyyy-MM-dd");
        this.dateDetail = window.util_date.getDays(window.util_date.getMonday(), 'yyyy-MM-dd');
        this.getSchedule();

      },
      // getClassInfo:function(){//获取班级信息
      //   instance.get('/class/findClass/'+this.classId).then((res) =>{
      //     this.classInfo=res.data.data;
      //   })
      // },
      getStudent:function(){//获取学员信息
        instance.get('/student/findClassStudents/'+this.classId).then((res) =>{
          this.studentList=res.data.data;
        })
      },
      getSchedule: function() { //获取周课程列表信息
        this.max=0;
        this.seaDetail.qClassId=this.classId;
        instance.post('/lesson/findWeekLessonTimeTables2',this.seaDetail).then((res) => {
          this.tableList = res.data.data;
          for(var i=0;i<this.tableList.length;i++){
            for(var j=0;j<this.dateDetail.length;j++){
              //alert(this.tableList[i]['weekday']+';'+this.weekDetail[j]);
              if(this.tableList[i]['weekday']==this.weekDetail[j]){
                var myDate = new Date();
                var now = myDate.valueOf();
                var time = new Date(this.dateDetail[j]+' '+this.tableList[i]['endTime']).valueOf();
                //alert(now+';'+time);
                if(now>=time){
                  // return true;
                  //alert('上过');
                  this.tableList[i].skindex=1
                }else{
                  //alert('没上过');
                  this.tableList[i].skindex=0
                  // return false;
                };
                //alert(this.tableList[i].skindex);
                this.td[j].push(this.tableList[i]);
              }
            }
          };
          //var max=0;
          for(var n=0;n<this.td.length;n++){
            if(this.td[n].length>=this.max){
              this.max=this.td[n].length;
              //alert(this.max);
            }
          };
          //alert(this.max);
          //console.log(this.td);
          //alert(this.td.toString())
        })
      },

    },
    mounted: function() {
      this.nowWeek();
      this.getStudent();
    }
  };
</script>

<template>
	<div class="p_con_tab">
		<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
            <span>排课表</span>
        </h3>
        <div class="p_btn_group p_clear_float">
            <input type="button" value="下周" class="p_btn p_btn_siz_2 p_btn_col_gre p_btn_pos_r" @click="nextWeek">
          <input type="button" value="本周" class="p_btn p_btn_siz_2 p_btn_col_red p_btn_pos_r" @click="nowWeek">
            <input type="button" value="上周" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r" @click="previousWeek">
        </div>
		<div>
			<table class="p_monthTable" cellspacing="0" cellpadding="0">
				<tr>
          <td v-for="date in dateDetail">{{date}}</td>
				</tr>
				<tr>
					<td>周一</td>
					<td>周二</td>
					<td>周三</td>
					<td>周四</td>
					<td>周五</td>
					<td>周六</td>
					<td>周日</td>
				</tr>
				<tr v-for="(tr,index) in max">
					<td class="timeTable_td" :class="td[index1][index].skindex==1?'timeTable_col_blu':'timeTable_col_gre'" v-for="(line,index1) in dateDetail" v-if="td[index1][index]!=null">
            <ul class="timeTable_showList">
							<li><span>时间:</span><span>{{td[index1][index].beginTime}}-{{td[index1][index].endTime}}</span></li>
							<li><span>课程:</span><span>{{td[index1][index].courseSubName	}}</span></li>
							<li><span>教室:</span><span>{{td[index1][index].classRoomName}}</span></li>
							<li><span>教师:</span><span>{{td[index1][index].teacherName	}}</span></li>
						</ul>
						<ul class="timeTable_hidList">
							<li><span>校区:</span><span>{{td[index1][index].schoolName}}</span></li>
							<li><span>类型:</span><span>{{td[index1][index].oneByOne==1?'一对多':'一对一'}}</span></li>
              <li><span>课程大类:</span><span>{{td[index1][index].courseName}}</span></li>
							<li><span>课程小类:</span><span>{{td[index1][index].courseSubName}}</span></li>
							<li><span>教室:</span><span>{{td[index1][index].classRoomName}}</span></li>
							<li><span>教师:</span><span>{{td[index1][index].teacherName	}}</span></li>
							<li><span>时间:</span><span>{{td[index1][index].beginTime}}-{{td[index1][index].endTime}}</span></li>
							<li><span>课时:</span><span>{{td[index1][index].lessonHour	}}课时</span></li>
							<li><span>学员人数:</span><span>{{studentList.length}}</span></li>
							<li><span>学员姓名:</span><span><span v-for="item in studentList">{{item.studentName}},</span></span></li>
						</ul>
					</td>
          <td v-else></td>
        </tr>
			</table>
		</div>
	</div>
</template>
