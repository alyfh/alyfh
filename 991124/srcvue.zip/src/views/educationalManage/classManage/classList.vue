<!-- <title>班级管理</title> -->
<style>
	.p_btn_group {
		/*border-bottom: solid 1px #e7eaec;*/
		padding-bottom: 10px;
	}

	.el-input__inner {
		height: 25px;
	}
</style>
<template>
	<div>
		<section class="p_chi_con">
			<div class="p_con_sea">
				<ul class="p_con_sea_list p_clear_float">
					<li>
						<span>所属校区:</span>
						<span>
            <select name=""  class='per_addperson_txt' v-model="findClass.qSchoolId">
              <option value="">--请选择--</option>
              <option v-for="sName in schoolNames" :value="sName.id">{{ sName.schoolName }}</option>
            </select>
    			</span>
					</li>
					<li>
						<span>课程大类:</span>
						<span>
    				<select  class='per_addperson_txt' v-model="findClass.qCourseId" @change="getClassSub(findClass.qCourseId)">
                <option  value="">请选择</option>
                <option v-for="className in classNames" :value="className.id">{{className.courseName}}</option>
            </select>
    			</span>
					</li>
					<li>
						<span>课程小类:</span>
						<span>
    				<select name="" id="" class='per_addperson_txt' v-model="findClass.qCourseSubId">
              <option value="">--请选择--</option>
              <option v-for="classNameSub in classNameSubs" :value="classNameSub.id">{{classNameSub.courseSubName}}</option>
            </select>

    			</span>
					</li>
					<li>
						<span>授课类型:</span>
						<span>
    				<select name="" id="" class='per_addperson_txt' v-model="findClass.qOneByOne">
              <option value="">--请选择--</option>
              <option value="1">一对多</option>
              <option value="0">一对一</option>
            </select>
    			</span>
					</li>

					<li>
						<span>班型:</span>
						<span>
    				<select name="" id="" class='per_addperson_txt' v-model="findClass.qClassTypeId">
              <option value="">--请选择--</option>
              <option v-for="classType in classTypes" :value="classType.id">{{classType.classTypeName}}</option>
            </select>
    			</span>
					</li>
					<li>
						<span>招生状态:</span>
						<span>
    				<select name="" id="" class='per_addperson_txt' v-model="findClass.qStudentStatus">
              <option value="">--请选择--</option>
                <option value="1">正在招生</option>
                <option value="2">停止招生</option>
            </select>
    			</span>
					</li>
					<li>
						<span>开课日期:</span>
						<span>
							 <el-date-picker type="date"  value-format="yyyy-MM-dd" placeholder="Pick a date" style="width:100%" v-model="findClass.qBeginBeginDate"></el-date-picker>

						</span>
					</li>
					<li>
						<span>开课日期止:</span>
						<span>
								<el-date-picker type="date"  value-format="yyyy-MM-dd" placeholder="Pick a date" style="width:100%" v-model="findClass.qEndBeginDate"></el-date-picker>

						</span>
					</li>
					<li>
						<span>上课时间:</span>
						<span>
							<el-time-picker style="width:100%" value-format="HH:mm:ss" v-model="findClass.qBeginBeginTime"></el-time-picker>
              <!--<el-time-picker style="width:150px" value-format="HH:mm:ss" v-model="findClass.qBeginEndTime" @change="updata"></el-time-picker>-->
						</span>
					</li>
					<li>
						<span>下课时间:</span>
						<span>
							<!--<el-time-picker style="width:100%" value-format="HH:mm:ss" v-model="findClass.qBeginBeginTime"></el-time-picker>-->
              <el-time-picker style="width:100%" value-format="HH:mm:ss" v-model="findClass.qEndBeginTime" ></el-time-picker>
						</span>
					</li>
					<li>
						<span>授课教师:</span>
						<span>
          <select name="" id="" class='per_addperson_txt' v-model="findClass.qTeacherId">
            <option value="" v-show="!isRole_sigalTeacher">--请选择--</option>
              <option v-for="tea in teachers" :value="tea.id">{{tea.realName}}</option>
          </select>
        </span>
					</li>
					<!--<li class=
                        <!--<li>-->
					<!--<span>学管师:</span>-->
					<!--<span>-->
					<!--<select name="" id="" class="p_con_form_select"></select>-->
					<!--</span>-->
					<!--</li>-->
					<li>
						<span>结学状态:</span>
						<span>
							<select name="" id="" class='per_addperson_txt' v-model="findClass.qClassStatus">
                <option value="0">开课</option>
                <option value="1">结课</option>
              </select>
						</span>
					</li>

				</ul>
				<div class="p_btn_group p_clear_float">
					<input type="button" value="查询" class="p_btn p_btn_siz_2 p_btn_col_k_gre p_btn_pos_r" @click="query">
				</div>
			</div>
			<div class="p_con_tab">
				<!--<div class="p_btn_group p_clear_float" v-if="classList.length!=0">-->
				<!--<input type="button" value="结学" v-if="$_has(actionsList,'jiexue')" class="p_btn p_btn_siz_2 p_btn_col_red p_btn_pos_r" @click="jiexue()">-->
				<!--<input type="button" value="考勤" v-if="$_has(actionsList,'kaoqin')" class="p_btn p_btn_siz_2 p_btn_col_oran p_btn_pos_r" @click="attendance()">-->
				<!--&lt;!&ndash; <input type="button" value="调课" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r"> &ndash;&gt;-->
				<!--<input type="button" value="加课" v-if="$_has(actionsList,'addClass')" class="p_btn p_btn_siz_2 p_btn_col_gre p_btn_pos_r" @click="jiake()">-->
				<!--</div>-->
				<div class="p_table_la_over">
					<table class="p_table_la" cellspacing="0" cellpadding="0">
						<tr>
							<!--<td>选择</td>-->
							<td>所属校区</td>
							<td>课程大类</td>
							<td>课程小类</td>
							<td>班级类别</td>
							<td>班型</td>
							<td>班级名称</td>
							<td>招生状态</td>

							<!--<td>开课日期</td>-->
							<!--<td>上课周期</td>-->
							<td>上课时段</td>
							<!--<td>授课教师</td>-->
							<!--<td>学管师</td>-->
							<!--<td>教室</td>-->
							<td>结学状态</td>
							<td>操作</td>
						</tr>

						<tr v-for="item in classList">
							<!--<td>-->
							<!--<input type="checkbox" :value="item" v-model="transferAdivce">-->
							<!--</td>-->
							<td>{{item.schoolName}}</td>
							<td>{{item.courseName}}</td>
							<td>{{item.courseSubName}}</td>
							<td>{{item.oneByOne==1?'一对多':'一对一'}}</td>
							<td>{{item.classTypeName}}</td>
							<td>{{item.className}}</td>
							<td>{{item.studentStatus == 1 ? '正在招生' : '结束招生'}}</td>
							<!--<td>{{item.beginDate}}</td>-->
							<td>{{item.beginDate}}到{{item.endDate}}</td>
							<!--上课时段-->
							<!--<td><span v-for="time in item.lessons">{{time.beginTime}}-{{time.endTime}}&</span></td>-->
							<!--授课教师-->
							<!--<td><span v-for="tea in item.lessons">{{tea.teacherName}}&</span></td>-->
							<!--学管师-->
							<!--<td>{{item.managerName}}</td>-->
							<!--教室-->
							<!--<td><span v-for="room in item.lessons">{{room.classRoomName}}&</span></td>-->
							<td>{{item.classStatus == 0 ? '开课' : '结课'}}</td>
							<td v-if="item.classStatus == 0" style="text-align: left;max-width: 340px;">
								<input type="button" value="详情" class="p_btn p_btn_siz_2 p_btn_col_k_gre p_btn_pos_l" @click="classInfo(item.id)">
								<input type="button" value="编辑" v-if="$_has(actionsList,'edit')" class="p_btn p_btn_siz_2 p_btn_col_k_oran p_btn_pos_l" @click="classEdit(item.id)">
								<input type="button" value="考勤" v-if="$_has(actionsList,'kaoqin')" class="p_btn p_btn_siz_2 p_btn_col_k_oran p_btn_pos_l" @click="attendance(item.id)">

								<input type="button" value="修改考勤" v-if="$_has(actionsList,'xiaoke')" class="p_btn p_btn_siz_2 p_btn_col_k_blu p_btn_pos_l" @click="classXiaoke(item.id)">
								<input type="button" value="结学" v-if="$_has(actionsList,'jiexue')" class="p_btn p_btn_siz_2 p_btn_col_k_red p_btn_pos_l" @click="jiexue(item.id)">
								<!-- <input type="button" value="调课" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r"> -->
								<input type="button" value="加课" v-if="$_has(actionsList,'addClass')" class="p_btn p_btn_siz_2 p_btn_col_k_gre p_btn_pos_l" @click="jiake(item.id)">

							</td>
							<td v-else>
								<input type="button" value="详情" class="p_btn p_btn_siz_2 p_btn_col_k_gre p_btn_pos_l" @click="classInfo(item.id)">
                <input type="button" value="考勤" v-if="$_has(actionsList,'kaoqin')" class="p_btn p_btn_siz_2 p_btn_col_k_oran p_btn_pos_l" @click="attendance(item.id)">

                <input type="button" value="修改考勤" v-if="$_has(actionsList,'xiaoke')" class="p_btn p_btn_siz_2 p_btn_col_k_blu p_btn_pos_l" @click="classXiaoke(item.id)">
							</td>
						</tr>
					</table>
				</div>
				<!-- 分页 -->
				<div class='h5_page_container' id="con">
					<page :record-count="recordCount" v-on:change-page="changePage">
					</page>
				</div>
			</div>
		</section>
		<!-- 弹窗 -->

	</div>
</template>

<script>
	import instance from '../../../api/index.js';
	import * as util from '../../../assets/util.js';
	import { mapState } from 'vuex';

	export default {
		computed: {
			// Getting Vuex State from store/index
			...mapState({
				layerShow: state => state.layerShow,
				pageSize: state => state.pageSize,
				pageLarge: state => state.pageLarge,
				adviceStatus: state => state.adviceStatus,
				adviceLevel: state => state.adviceLevel,
			})
		},
		data() {
			return {
				actionsList: [], //获取当前用户对当前模块授权操作
				actionType: "",
				findClass: {}, //查询条
				classList: [], //班级列表
				schoolNames: [], //校区,
				classTypes: [],
				// sourceNames: [], //来源大类
				// sourceNameSubs: [], //来源小类
				classNames: [],
				classNameSubs: [],
				// counselorNames: [], //咨询师
				// consultants: [], //课程顾问
				teachers: [], //授课教师
				recordCount: 0,
				pageNum: 1, //当前页码
				transferAdivce: [], //转移
				isRole_teacher: false, //是否教师角色
				isRole_schoolmanager: false, //是否店长角色
				isRole_sigalTeacher: false //只有教师角色时

			};
		},
		components: {
			page: () =>
				import("../../common/page.vue") //,
			// modalDialog: () =>
			//   import("./transferComponent.vue")
		},
		methods: {
			classEdit: function(id) { //编辑
				this.$router.push('/jiaowuguanli/bianjibanji/' + id);
			},
			classInfo: function(id) { //详情
				this.$router.push('/jiaowuguanli/banjixiangqing/' + id);
			},
			classXiaoke: function(id) { //消课
				this.$router.push('/jiaowuguanli/chexiaoxiaoke/' + id);
			},
			jiexue: function(id) { //结学
        // instance.post('/lesson/findLessonRecordsCount',{
        //   'qClassId':id,
        //   'qVerify':1
        // }).then((res) => {

          // if(res.data.data.count==0){
            this.$confirm("您确定对该班级进行结学操作吗?", "提示", {
              confirmButtonText: "确定",
              cancelButtonText: "取消",
              type: "warning"
            })
              .then(() => {
                instance.get('/class/finishClass/' + id).then((res) => {
                  if(res.data.errcode == '0') {

                    this.$message.info('操作成功！');
                    this.query();
                  } else {
                    this.$message.error('操作失败！' + res.data.errmsg);
                  }

                });
              })
              .catch(() => {});
          // }else{
          //   this.$message.error('该班级有未确认的考勤，不能进行结学操作！');
          // }
          // this.recordCount = res.data.data.count;
        // });
        // /lesson/findLessonRecordsCount
				// if(this.transferAdivce.length == 0) {
				//   this.$message.error('请选择需要结学的班级！！！');
				//   return;
				// } else if(this.transferAdivce.length > 1) {
				//   this.$message.error('您好，每次只能选择一个班级进行结学！！！');
				//   return;
				// }else{

				//}

				// this.$store.commit({
				//   type: 'setLayerShow',
				//   layerShow: true
				// })
				// this.actionType = "transfer";
			},
			jiake: function(id) { //加课
				// if(this.transferAdivce.length == 0) {
				//   this.$message.error('请选择需要加课的班级！！！');
				//   return;
				// } else if(this.transferAdivce.length > 1) {
				//   this.$message.error('您好，每次只能选择一个班级进行加课！！！');
				//   return;
				// }else{
				this.$confirm("您确定对该班级进行加课操作吗?", "提示", {
						confirmButtonText: "确定",
						cancelButtonText: "取消",
						type: "info"
					})
					.then(() => {
						// instance.get('/class/finishClass/'+ this.transferAdivce[0].id).then((res) => {
						//   if(res.data.errcode == '0') {
						//
						//     this.$message.info('操作成功！');
						//     this.query();
						//   } else {
						//     this.$message.error('操作失败！' + res.data.errmsg);
						//   }
						//
						//
						// });
						this.$router.push('/jiaowuguanli/banjijiake/' + id);
					})
					.catch(() => {});
				//}

				// this.$store.commit({
				//   type: 'setLayerShow',
				//   layerShow: true
				// })
				// this.actionType = "transfer";

			},
			attendance: function(id) { //考勤
				// if(this.transferAdivce.length == 0) {
				//   this.$message.error('请选择需要记录考勤的班级！！！');
				//   return;
				// } else if(this.transferAdivce.length > 1) {
				//   this.$message.error('您好，每次只能选择一个班级进行考勤记录！！！');
				//   return;
				// }else{
				this.$confirm("您确定对该班级进行考勤记录吗?", "提示", {
						confirmButtonText: "确定",
						cancelButtonText: "取消",
						type: "info"
					})
					.then(() => {
						// instance.get('/class/finishClass/'+ this.transferAdivce[0].id).then((res) => {
						//   if(res.data.errcode == '0') {
						//
						//     this.$message.info('操作成功！');
						//     this.query();
						//   } else {
						//     this.$message.error('操作失败！' + res.data.errmsg);
						//   }
						//
						//
						// });
						this.$router.push('/jiaowuguanli/xueshengkaoqin/' + id);
					})
					.catch(() => {});
				// }

				// this.$store.commit({
				//   type: 'setLayerShow',
				//   layerShow: true
				// })
				// this.actionType = "transfer";

				//this.$router.push('/jiaowuguanli/xueshengkaoqin/'+1);
			},
			query: function() { //查询
				this.getAdviceList(this.findClass);
				this.getAdviceCount(this.findClass); //数量
			},
			getAdviceCount: function(lis) { //获取数量
				instance.post('/class/findClassesCount', lis).then((res) => {
					this.recordCount = res.data.data.count;
				});
			},
			getAdviceList: function(lis) { //获取列表
				lis.beginRow = (this.pageNum - 1) * this.pageSize;
				lis.pageSize = this.pageSize;
				instance.post('/class/findClasses', lis).then((res) => {
					this.classList = res.data.data;
				})

			},
			getSchool: function() { //获取校区数据
				//获取当前登录人
				let loginInfo = util.session("loginInfo");
				instance.get('/school/findUserSchools/' + loginInfo.login.userId).then((res) => {
					this.schoolNames = res.data.data;
				})
			},
			getTeacher: function() { //获取授课教师列表
				let qTeacherParams = {
					"qUsername": ''
				};
				//角色中 只是教师 不包括店长角色
				if(!this.isRole_schoolmanager && this.isRole_teacher) {
					qTeacherParams.qUsername = this.loginInfo.userCode;
					let currTeacher={id:'',realName:''};
					currTeacher.id = this.loginInfo.userId;
					currTeacher.realName = this.loginInfo.realName;
					this.teachers.push(currTeacher);
				} else {
					instance.post('/teacher/findSimpleTeachers', qTeacherParams).then((res) => {
						this.teachers = res.data.data;
					})
				}

			},
			getClassType: function() { //获取班型
				instance.post('/classtype/findSimpleClassTypes', {}).then((res) => {
					this.classTypes = res.data.data;
				})
			},
			getClass: function() { //获取课程大类数据
				instance.post('/course/findCourses', {}).then((res) => {
					this.classNames = res.data.data;
				})
			},
			getClassSub: function(id) { //获取课程小类数据
				instance.post('/course/findSimpleCourseSubs', {
					qCourseId: id
				}).then((res) => {
					this.classNameSubs = res.data.data;
				})
			},
			changePage: function(pageNum) {
				this.pageNum = pageNum;
				this.getAdviceList(this.findClass);
			},

			editAdivce: function(id) {
				this.$router.push({
					path: `/zhaoshengguanli/updateAdvice/${id}`
				});

			},
			readAdivce: function(id) {

				// this.$router.push('/xueyuanguanli/buyCard/'+id);
				this.$router.push({
					path: `/zhaoshengguanli/readAdvice/${id}`
				});

			},
			deleteAdvice: function(id) {

				this.$confirm("您确定删除吗?", "提示", {
						confirmButtonText: "确定",
						cancelButtonText: "取消",
						type: "info"
					})
					.then(() => {
						instance.get('/infor/removeInformation/' + id).then((res) => {
							this.$message.info('数据删除成功！');
							this.query();
						})
					})
					.catch(() => {});

				//this.actionType="read";
			},
			transfer: function() {
				if(this.transferAdivce.length == 0) {
					this.$message.error('请选择需要转移的咨询！！！');
					return;
				} else if(this.transferAdivce.length > 1) {
					this.$message.error('您好，每次只能选择一个咨询进行转移！！！');
					return;
				}
				this.$store.commit({
					type: 'setLayerShow',
					layerShow: true
				})
				this.actionType = "transfer";
			},
			saveTransfer: function(item) {
				this.$confirm("您确定转移吗?", "提示", {
						confirmButtonText: "确定",
						cancelButtonText: "取消",
						type: "info"
					})
					.then(() => {
						instance.post('/infor/transferInformation', item).then((res) => {
							if(res.data.errcode == '0') {
								this.$message.info('转移成功！');
								this.$store.commit({
									type: 'setLayerShow',
									layerShow: false
								});
								this.query();
								this.transferAdivce = [];
							} else {
								this.$message.error('操作失败！' + res.data.errmsg);
							}
						})

					})
					.catch(() => {});

			},
			getModuleActions: function() {
				let routeCodes = this.$route.path.split("/");
				let routeCode = routeCodes[routeCodes.length - 1];
				instance.get('/navi/findUserActions2/' + routeCode).then((res) => {
					if(res.data.errcode == '0') {
						this.actionsList = res.data.data;
					} else {
						//this.$message.error('操作失败！' + res.data.info);
					}
					//console.info("json:" + res.data);

				})
			}
		},
		mounted: function() {

			//从session中获取用户登陆json
			this.loginInfo = util.session('loginInfo').login;
			//查询用户角色
			this.loginInfo.roles.forEach(function(r) {

				//orgadmin	组织管理员；  coursecounselor	课程顾问 ；   schoolmanager	店长；    regionmanager	大区经理
				if(r.roleCode == "schoolmanager" || r.roleCode == "orgadmin" || r.roleCode == "coursecounselor" || r.roleCode == "regionmanager") {
					this.isRole_schoolmanager = true;
				}

				//授课教师
				if(r.roleCode == "teacher" && this.loginInfo.roles.length == 1) {
					this.isRole_teacher = true;
				}

			}, this);
			//角色中 只是教师 不包括店长角色
			if(!this.isRole_schoolmanager && this.isRole_teacher) {
				this.findClass.qTeacherId = this.loginInfo.userId;
				this.isRole_sigalTeacher = true;
			}
			this.getAdviceList(this.findClass);
			this.getAdviceCount(this.findClass); //数量

			this.getSchool(); //校区
			// this.getConsult(); //咨询师
			this.getTeacher(); //授课教师
			// this.getconsultant(); //课程顾问
			// this.getSource(); //来源大类
			this.getClass(); //课程大类
			this.getClassType();
			this.getModuleActions();

		}
	};
</script>
