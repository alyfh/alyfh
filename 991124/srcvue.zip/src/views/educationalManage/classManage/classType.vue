<!-- <title>班型</title> -->
<style>
	.p_btn_group{
		/*border-bottom: solid 1px #e7eaec;*/
		padding-bottom: 10px;
	}
	.p_chi_con_s{
		width: 70%!important
	}
	.h5_02_info_per_exportRules_h3{border-bottom: solid 1px #e7e7e7;
        padding:10px 20px 10px 30px;color: #979494}
  /*.addlayer{display: none}*/
</style>
<template>
	<div>
		<section class="p_chi_con p_chi_con_s" >
			<div class="p_con_tab">
				<div class="p_btn_group p_clear_float">
					<input type="button" value="增加班型" v-if=" $_has(actionsList,'add') " class="p_btn p_btn_siz_2 p_btn_col_gre p_btn_pos_r" @click="addType()">
				</div>
				<div class="p_table_la_over">
					<table class="p_table_la" cellspacing="0" cellpadding="0">
						<tr>
							<td>班型</td>
							<td>备注</td>
							<td>操作</td>
						</tr>
						<tr v-for="type in typeList">
							<td>{{type.classTypeName}}</td>
							<td>{{type.descr}}</td>
							<td>
								<input type="button" value="编辑" v-if=" $_has( actionsList,'edit') " @click="editType(type.id,type.classTypeName,type.descr)" class="p_btn p_btn_siz_2 p_btn_col_k_oran p_btn_pos_r">
								<input type="button" value="删除" v-if=" $_has( actionsList,'del' ) " @click="delType(type.id)" class="p_btn p_btn_siz_2 p_btn_col_k_red p_btn_pos_r">
							</td>
						</tr>
					</table>
				</div>
				<!-- 分页 -->
        <div class='h5_page_container' id="con">
          <page :record-count="recordCount" v-on:change-page="changePage">
          </page>
        </div>
			</div>
		</section>
		<!-- 弹窗 -->
	    <div class="addlayer" id='templayer' v-if="show" >
	        <header>
	            <span class="h5_layerLOGO">增加班型</span>
	            <span class="h5_layerOFFbtn" @click="setLayerShow">╳</span>
	        </header>
	        <div class="addlayerBox">
	        	<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
		        	<span>增加班型(</span>
		        	<span class='h5_mark_xx2'>★</span>
		        	<span>为必填)</span>
		    	  </h3>
				    <ul class='h5_02_info_per_addlist'>
              <li>
                <span>★</span>
                <span>班型:</span>
                <span>
                  <input type="hidden" v-model="returnType.id">
                  <input type="text" class='per_addperson_txt' v-model="returnType.classTypeName">
                </span>
              </li><br>
              <li class="per_addperson_li_w per_addperson_li_h2">
                <span></span>
                <span>备注:</span>
                <span>
                 <textarea name="" id="" cols="30" rows="4" placeholder="其他" class='per_addperson_texarea' v-model="returnType.descr"></textarea>
                </span>
              </li>
	    		  </ul>
	    		<div class="p_btn_group p_clear_float">
		            <input type="button" value="取消" class="p_btn p_btn_siz_2 p_btn_col_red p_btn_pos_r" @click="cancel()">
		            <input type="button" value="确定" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r"  @click="saveType()">
	        	</div>
	        </div>
	    </div>
    </div>
</template>
<script>
  import instance from '../../../api/index.js';
  import { mapState } from 'vuex';

  // import component2 from './components/component2.vue'
  export default {
    data() {
      return {
        actionsList:[],//获取当前用户对当前模块授权操作
        typeList:[],
        returnType:{},
        show: false,
        actionType:'add',
        recordCount: 0,


        pageNum: 1 //当前页码
      };
    },
    components: {
      page: () => import("../../common/page.vue")
    },
    computed: {
      // Getting Vuex State from store/index
      ...mapState({
        layerShow: state => state.layerShow,
       pageSize: state => state.pageSize,
       pageLarge: state => state.pageLarge
      })
    },
    methods: {
      getList:function(){
        instance.post('/classtype/findClassTypes',{}).then((res) => {
          this.typeList = res.data.data;
        })
      },
      addType:function(){
        this.$store.commit({
          type: 'setLayerShow',
          layerShow:true
        });
        this.show=true;
        this.actionType='add';
        this.returnType.id="";
        this.returnType.classTypeName="";
        this.returnType.descr="";

      },
      editType:function(id,name,mark){
        this.$store.commit({
          type: 'setLayerShow',
          layerShow:true
        });
        this.show=true;
        this.actionType='edit';
        this.returnType.id=id;
        this.returnType.classTypeName=name;
        this.returnType.descr=mark;
      },
      saveType:function(){
        if(this.actionType=='edit'){
          instance.post('/classtype/changeClassType',this.returnType).then((res) => {
            if(res.data.errcode == '0') {
              this.$message.success('信息修改成功!');
              this.setLayerShow();
              this.getList();
            } else {
              this.$message.error('操作失败！' + res.data.errmsg);
            }
          })
        }else if(this.actionType=='add'){
          instance.post('/classtype/createClassType',this.returnType).then((res) => {
            if(res.data.errcode == '0') {
              this.$message.success('信息添加成功！');
              this.setLayerShow();
              this.getList();
            } else {
              this.$message.error('操作失败！' + res.data.errmsg);
            }
          })

        }

      },
      cancel:function(){
        this.returnType.id="";
        this.returnType.classTypeName="";
        this.returnType.descr="";
        this.setLayerShow();
        },
      delType:function(id){
        this.$confirm("确定删除选中的班型?", "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "info"
        })
          .then(() => {
            instance.get('/classtype/removeClassType/'+id).then((res) => {
              this.$message.success('信息删除成功！');
              this.getList();
            })

          })
          .catch(() => {});
      },
      setLayerShow: function() {
        this.$store.commit({
          type: 'setLayerShow',
          layerShow: false
        });
        this.show=false
      },
      getTypeCount:function(){//获取学生数量
        instance.post('/classtype/findClassTypesCount',{}).then((res) => {
          this.recordCount=res.data.data.count;
        });
      },
      changePage: function(pageNum) {
        console.info("change-page:" + pageNum);
        this.pageNum = pageNum;
        this.getStudent();
      },
      getModuleActions:function(){
        let  routeCodes=this.$route.path.split("/");
        let  routeCode=routeCodes[routeCodes.length-1];
        instance.get('/navi/findUserActions2/'+routeCode).then((res) => {
          if(res.data.errcode == '0') {
            this.actionsList=res.data.data;
          } else {
            //this.$message.error('操作失败！' + res.data.info);
          }
          //console.info("json:" + res.data);

        })
      }

    },
    created: function() {

    },
    mounted: function() {
      this.getList();
      this.getTypeCount();
      this.getModuleActions();
    }

  };
</script>
