<!-- <title>学生列表</title> -->
<template>
	<table class="p_table_la" cellspacing="0" cellpadding="0" id="tab1">
		<tr>
			<td>学号</td>
			<td>学生姓名</td>
			<td>家长姓名</td>
			<td>联系手机</td>
			<td>年龄</td>
			<td>已用课时</td>
			<td>剩余课时</td>
			<td>操作</td>
		</tr>
		<tr v-for="item in tableList">
			<td>{{item.id}}</td>
			<td>{{item.studentName}}</td>
			<td>{{item.parentName}}</td>
			<td>{{item.telephone}}</td>
			<td>{{jsGetAge(item.birthday)}}</td>
			<!--<td>{{item.sumHour}}</td>-->
			<td>{{(item.studentLessonCard.sumHour-0) - (item.studentLessonCard.hour-0)}}</td>
			<td>{{item.studentLessonCard.hour}}</td>
			<td>
				<input type="button" value="详情" class="p_btn p_btn_siz_2 p_btn_col_k_gre p_btn_pos_r" @click="linkStudentInfo(item.id)">

			</td>
		</tr>
	</table>
</template>
<script>
	import instance from '../../../api/index.js';
	import { mapState } from 'vuex';
	export default {
		props: ['classId'],
		data() {
			return {
				tableList: []
			};
		},
		methods: {
			getData: function() { //
				instance.get('/student/findClassStudents/' + this.classId).then((res) => {
					this.tableList = res.data.data;

				})
			},
			linkStudentInfo: function(id) { //学生姓名点击跳转详情
				this.$router.push('/xueyuanguanli/studentinfo/' + id + "/baseInfo");
			},

			/*根据出生日期算出年龄*/
			jsGetAge: function(strBirthday) {
				if(strBirthday == null || strBirthday == "null" || strBirthday == "") {
					return 0;
				} else {
					var returnAge;
					var strBirthdayArr = strBirthday.split("-");
					var birthYear = strBirthdayArr[0];
					var birthMonth = strBirthdayArr[1];
					var birthDay = strBirthdayArr[2];

					var d = new Date();
					var nowYear = d.getFullYear();
					var nowMonth = d.getMonth() + 1;
					var nowDay = d.getDate();

					if(nowYear == birthYear) {
						returnAge = 0; //同年 则为0岁
					} else {
						var ageDiff = nowYear - birthYear; //年之差
						if(ageDiff > 0) {
							if(nowMonth == birthMonth) {
								var dayDiff = nowDay - birthDay; //日之差
								if(dayDiff < 0) {
									returnAge = ageDiff - 1;
								} else {
									returnAge = ageDiff;
								}
							} else {
								var monthDiff = nowMonth - birthMonth; //月之差
								if(monthDiff < 0) {
									returnAge = ageDiff - 1;
								} else {
									returnAge = ageDiff;
								}
							}
						} else {
							returnAge = -1; //返回-1 表示出生日期输入错误 晚于今天
						}
					}

					return returnAge; //返回周岁年龄
				}
			}

		},
		mounted: function() {
			this.getData();
		}
	};
</script>