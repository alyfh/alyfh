<!-- <title>加课</title> -->
	<style>
		.h5_02_info_per_exportRules_h3{border-bottom: solid 1px #e7e7e7;
            padding:10px 20px 10px 30px;color: #979494}
	</style>
<template>
	<form id="" method="post" action="" class="ue_form_add">
		<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
        	<span>基本信息</span>
        	<!--<span class='h5_mark_xx2'>★</span>-->
        	<!--<span>为必填)</span>-->
    	</h3>
    	<ul class='h5_02_info_per_addlist'>
    		<li>
    			<span>★</span>
    			<span>班级名:</span>
    			<span>{{classDetail.className}}</span>
    		</li>
    		<li>
    			<span>★</span>
    			<span>开课日期:</span>
    			<span>{{classDetail.beginDate}}</span>
    		</li>
        <li>
          <span>★</span>
          <span>结课日期:</span>
          <span>
            {{classDetail.endDate}}
          </span>
        </li>
    		<li>
    			<span>★</span>
    			<span>班型:</span>
    			<span>
    				{{classDetail.classTypeName}}

    			</span>
    		</li>
    		<li>
    			<span>★</span>
    			<span>授课类型:</span>
    			<span>
    				{{classDetail.oneByOne==1?'一对多':'一对一'}}
    			</span>
    		</li>
    		<li>
    			<span>★</span>
    			<span>课程大类:</span>
    			<span>
            {{classDetail.courseName}}
          </span>
    		</li>
    		<li>
    			<span>★</span>
    			<span>课程小类:</span>
    			<span>
            {{classDetail.courseSubName}}
          </span>
    		</li>
    		<!--<li>-->
    			<!--<span>★</span>-->
    			<!--<span>教室:</span>-->
    			<!--<span>-->
    				<!--<input type="text" class='per_addperson_txt'>-->
    				<!--<div class='per_addperson_pic'></div>-->
    				<!--<div class='per_addperson_pic'></div>-->
    			<!--</span>-->
    		<!--</li>-->
    		<!--<li>-->
    			<!--<span>★</span>-->
    			<!--<span>授课教师:</span>-->
    			<!--<span><input type="text" class='per_addperson_txt'></span>-->
    		<!--</li>-->
        <!--<li>-->
            <!--<span>★</span>-->
            <!--<span>学管师:</span>-->
            <!--<span><input type="text" class='per_addperson_txt'></span>-->
        <!--</li>-->
    		<li>
    			<span>★</span>
    			<span>计划课时:</span>
    			<span>
            {{classDetail.planHour}}
          </span>
    		</li>

    		<li>
    			<span>★</span>
    			<span>预招人数:</span>
    			<span>
            {{classDetail.planStudent}}
          </span>
    		</li>
    		<li>
    			<span>★</span>
    			<span>招生状态:</span>
    			<span>
    				{{classDetail.studentStatus == 1 ? '正在招生' : '结束招生'}}
    			</span>
    		</li>
    		<li>
    			<span>★</span>
    			<span>每次课时:</span>
    			<span>
    				{{classDetail.lessonHour}}
    			</span>
    		</li>
        <li class="per_addperson_li_w per_addperson_li_h2">
          <span>★</span>
          <span>备注:</span>
          <span>
            {{classDetail.descr}}
          </span>
        </li>

    	</ul>
    	<h3 class='h5_02_info_per_exportRules_h3 p_clear_float' >
        	<span>上课时间(</span>
        	<span class='h5_mark_xx2'>★</span>
        	<span>为必填)</span>
            <input type="button" value="查看班级课表" class="p_btn p_btn_siz_2 p_btn_col_k_oran p_btn_pos_r" @click="timeTime">
            <input type="button" value="新增上课时间" class="p_btn p_btn_siz_2 p_btn_col_k_gre p_btn_pos_r" @click="addTimeBlock">
    	</h3>
      <timeblock :is="item.component" v-for="(item,index) in items" :key="item.id" :counts="index" @delblock="delTimeBlock"  @uplessons="lesson" :room="roomList" :teacher="teachers" :class-list="classDetail"></timeblock>
      <br class="p_zwf">
        <div class="p_btn_group p_clear_float" v-if="timeShow">
            <input type="button" value="取消" class="p_btn p_btn_siz_2 p_btn_col_red p_btn_pos_r" @click="$router.go(-1)">
            <input type="button" value="确定" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r" @click="saveClass">
        </div>


  <div class="addlayer" id='templayer' v-if="show" >
    <header>
      <span class="h5_layerLOGO">班级课表</span>
      <span class="h5_layerOFFbtn" @click="setLayerShow">╳</span>
    </header>
    <div class="addlayerBox">
      <time-table :class-id="classDetail.id"></time-table>
    </div>
  </div>
  <!-- 弹窗 -->

  </form>
</template>
<script>
  import instance from '../../../api/index.js';
  import { mapState } from 'vuex';
  import timeblock from "./addClassTime.vue";
  import * as util from '../../../assets/util.js';

  export default {
    mounted: function() {
      this.getClassInfo();
    },
    components: {
      timeblock,
      timeTable: () =>
        import("./weekTimetable.vue")
    },
    computed: {
      // Getting Vuex State from store/index
      ...mapState({
        layerShow: state => state.layerShow
      })
    },
    data() {
      return {
        show: false,
        timeShow:false,
        classDetail: {
          schoolId:""
        },
        schoolNames: [],//校区
        classNames: [],//课程大类
        classNameSubs: [],//课程小类
        classTypes: [],//班型
        // counselorNames: [], //咨询师
        // consultants: [], //课程顾问
        teachers:[],//授课教师
        roomList:[],//教室
        updateLessons:[],//已选课程
        createLessons:[],//新增课程
        deleteLessons:[],//删除课程
        items: [],
        pcon:0,

      };
    },
    methods: {
      saveClass:function(){//保存
        var data =  {};
        for(var i=0;i<this.createLessons.length;i++){
          // if(this.createLessons[i]==''){
          if(JSON.stringify(this.createLessons[i]) == "{}"||this.createLessons[i]==null||this.createLessons[i]==''){

            this.createLessons.splice(i,1)
          };
        }
        data.clazz=this.classDetail;
        data.updateLessons=this.updateLessons;
        data.createLessons=this.createLessons;
        data.deleteLessons=this.deleteLessons;

        instance.post('/class/changeClassAndLessons',data).then((res) => {
          if(res.data.errcode == '0') {
            // this.$message.info('保存成功');
            this.$confirm("保存成功！是否跳回列表页面?", "提示", {
              confirmButtonText: "确定",
              cancelButtonText: "取消",
              type: "success"
            }).then(() => {
              this.$router.push('/jiaowuguanli/banjiguanli/banjiliebiao');
            })
              .catch(() => {});

          } else {
            this.$alert(res.data.errmsg, '操作失败', {
              confirmButtonText: '确定',
              type: 'error'
            });
          }
        })
      },
      getClassInfo:function(){//获取班级信息
        instance.get('/class/findClass/'+this.$route.params.id).then((res) => {
          this.updateLessons=res.data.data.lessons;
          delete res.data.data.lessons;
          this.classDetail = res.data.data;
          this.getRoom(this.classDetail.schoolId);
        })
      },
      getTeacher: function(schoolId) { //获取授课教师列表
        instance.post('/teacher/findSimpleTeachers', {
          qSchoolId: schoolId
        }).then((res) => {
          this.teachers = res.data.data;
        })
      },
      getRoom:function(id) { //获取校区教室数据
        instance.post('/classroom/findSimpleClassRooms',{
          "qSchoolId": id,
        }).then((res) => {
          this.roomList = res.data.data;
        });
        this.getTeacher(id);
      },
      addTimeBlock:function(){//查看上课时间
        this.createLessons.push({});
        this.items.push({
          component: 'timeblock',
          id:this.pcon
        });
        this.pcon++;
        this.timeShow=true;
      },
      delTimeBlock:function(id,que){//删除课时
        // alert(que);
        if(que=='update'){
          // alert(id);
          this.deleteLessons.push({'id':this.updateLessons[id]['classId']});
          this.updateLessons.splice(id,1);
          console.log(this.updateLessons);
          this.items.splice(id,1);

        }else{
          // alert(id);
          this.items.splice(id,1,'');
          this.createLessons.splice(id,1,'');
          // alert(this.items.length+';'+this.createLessons.length);

        }

      },
      lesson:function(data,id,que){//添加课时回调
          this.createLessons[id]=data;
          this.createLessons[id]['beginDate']=this.classDetail.beginDate;
          this.createLessons[id]['className']=this.classDetail.className;
          this.createLessons[id]['schoolId']=this.classDetail.schoolId;
          this.createLessons[id]['courseId']=this.classDetail.courseId;
          this.createLessons[id]['courseSubId']=this.classDetail.courseSubId;
          this.createLessons[id]['beginDate']=this.classDetail.beginDate;
          this.createLessons[id]['endDate']=this.classDetail.endDate;
          this.createLessons[id]['lessonHour']=this.classDetail.lessonHour;

      },
      timeTime:function(){//班级课表
        this.$store.commit({
          type: 'setLayerShow',
          layerShow:true
        });
        this.show=true;
      },
      setLayerShow: function() {//关闭弹窗
        this.$store.commit({
          type: 'setLayerShow',
          layerShow: false
        });
        this.show=false;
      },
    },

  };
</script>
