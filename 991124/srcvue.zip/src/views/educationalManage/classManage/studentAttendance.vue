<!-- <title>学生考勤</title> -->
<style>
	.p_btn_group {
		border-bottom: solid 1px #e7eaec;
		padding-bottom: 10px;
	}
	
	.p_txt_square {
		width: 40px;
		height: 25px;
		border-radius: 3px;
		border: solid 1px #cdcdcd;
		margin-right: 5px
	}
	
	.el-input__inner {
		height: 25px;
	}
</style>
<template>
	<div>
		<section class="p_chi_con">
			<div class="p_con_37 p_clear_float">
				<div class="p_con_37_3">
					<h4 class="p_title_strc">基本信息</h4>
					<ul class="p_ul_col">
						<li>
							<span>所属校区:</span>
							<span>
								{{classDetail.schoolName}}
							</span>
						</li>
						<li>
							<span>课程大类:</span>
							<span>
								{{classDetail.courseName}}
							</span>
						</li>
						<li>
							<span>课程小类:</span>
							<span>
								{{classDetail.courseSubName}}
							</span>
						</li>
						<li>
							<span>班级:</span>
							<span>
								{{classDetail.className}}
							</span>
						</li>
						<li>
							<span>授课类型:</span>
							<span>
								{{classDetail.oneByOne==1?'一对多':'一对一'}}
							</span>
						</li>
						<li>
							<span>班型:</span>
							<span>
								{{classDetail.classTypeName}}
							</span>
						</li>
					</ul>
				</div>
				<div class="p_con_37_7">
					<h4 class="p_title_strc">课时信息</h4>
					<ul class="p_ul_col_form">
						<li>
							<span>每次消耗课时</span>
							<span>
                {{classDetail.lessonHour}}
							</span>
						</li>

						<li>
							<span>上课日期:</span>
							<span>
                <!--<el-date-picker type="date"  value-format="yyyy-MM-dd" placeholder="Pick a date" style="width:calc(100% - 8px)" v-model="searDetail.lessonDate" @change="updata"></el-date-picker>-->

								<select name="" id="" class="per_addperson_txt" @change="updata(lessonId)" v-model="lessonId">
                   <option value="ssss">--请选择未确认上课的记录--</option>
                   <option :value="index" v-for="(item,index) in tableList" :checked="index==lessonId?true:false">{{item.lessonDate}}&nbsp;&nbsp;{{item.beginTime}}-{{item.endTime}}&nbsp;星期{{item.xq}}</option>
                </select>
								 <!--第三次上课-->
							</span>
						</li>
						<li>
							<span>教室:</span>
							<span>
                <input type="text" class='per_addperson_txt' :value="classRoomName" readonly>
							</span>
						</li>
						<li>
							<span>授课教师:</span>
							<span>
				                <input v-show="!daike_isshow" type="text" class='per_addperson_txt' :value="teacherName" readonly>
				                <select v-show="daike_isshow" name="" id="" class="per_addperson_txt" @change="updateDaikeTeacher()" v-model="teacherName">
				                   <!--<option value="ssss">--请选择未确认上课的记录--</option>-->
				                   <option :value="item.id" v-for="(item,index) in teacherList" >{{item.realName}}</option>
				                </select>
							</span>
							<!--<input type="button" value="代课教师" class="p_btn p_btn_siz_2 p_btn_col_gre p_btn_pos_r" style="margin-right:350px" @click="daikejiaoshi">-->
						</li>
						<!--<li>-->
						<!--<span>学管师:</span>-->
						<!--<span>-->
						<!--<select name="" id="" class="p_con_form_select"></select>-->
						<!--</span>-->
						<!--</li>-->
					</ul>
				</div>
			</div>
			<table class="p_tab_form_radio">
				<tr style="width:calc(97% - 4px);border-bottom:solid 1px #f0f0f0">
					<td>批量操作:</td>
					<td>
						<input type="radio" id="all1" name="all" value="1" v-model="alllessonStatus" @change="allchoose(true,alllessonStatus)">
						<label for="all1">上课</label>
					</td>
					<td>
						<input type="radio" id="all2" name="all" value="2" v-model="alllessonStatus" @change="allchoose(true,alllessonStatus)">
						<label for="all2">请假</label>
					</td>
					<td>
						<input type="radio" id="all3" name="all" value="3" v-model="alllessonStatus" @change="allchoose(true,alllessonStatus)">
						<label for="all3">旷课</label>
					</td>
					<td>
						<input type="radio" id="all4" name="all" value="4" v-model="alllessonStatus" @change="allchoose(true,alllessonStatus)">
						<label for="all4">补课</label>
					</td>
					<td>
						<input type="radio" id="all5" name="all" value="5" v-model="alllessonStatus" @change="allchoose(true,alllessonStatus)">
						<label for="all5">停课</label>
					</td>
					<td>
						本次课时：<input type="text" class="p_txt_square" value=0 v-model="allcost" @input="allchoose(true,alllessonStatus,'txt')">课时
					</td>
					<td></td>
				</tr>
				<template v-for="(item,index) in studentRecordList">
					<tr>
						<td :id="item.id" style="max-width: 70px">{{item.studentName}}</td>
						<td>
							<input type="radio" :id="item.id+1" :name="index+'kaoqin'" v-model="item.lessonStatus" value="1" @change="allchoose(false,index)">
							<label :for="item.id+1">上课</label>
						</td>
						<td>
							<input type="radio" :id="item.id+2" :name="index+'kaoqin'" v-model="item.lessonStatus" value="2" @change="allchoose(false,index)">
							<label :for="item.id+2">请假</label>
						</td>
						<td>
							<input type="radio" :id="item.id+3" :name="index+'kaoqin'" v-model="item.lessonStatus" value="3" @change="allchoose(false,index)">
							<label :for="item.id+3">旷课</label>
						</td>
						<td>
							<input type="radio" :id="item.id+4" :name="index+'kaoqin'" v-model="item.lessonStatus" value="4" @change="allchoose(false,index)">
							<label :for="item.id+4">补课</label>
						</td>
						<td>
							<input type="radio" :id="item.id+5" :name="index+'kaoqin'" v-model="item.lessonStatus" value="5" @change="allchoose(false,index)">
							<label :for="item.id+5">停课</label>
						</td>
						<td>
							本次课时：<input type="text" class="p_txt_square" v-model="item.realHour" value=classDetail.lessonHour @change="allchoose(false,index)">课时
						</td>
						<td>
							当前会员卡剩余{{item.hour}}课时
						</td>
					</tr>
					<tr>
						<td colspan="8" style="background: rgba(238,238,238,0.5)">
							<ul class='h5_02_info_per_addlist'>
								<li class="per_addperson_li_w per_addperson_li_h2" style="height: 50px">
									<span style="width: 0px"></span>
									<span style="width: 50px">备注:</span>
									<span>
                    <textarea name="" id="" cols="30" rows="1" placeholder="" class='per_addperson_texarea'  v-model="item.descr" style="height: 50px;width: calc(70% - 50px)"></textarea>
                  </span>
								</li>
							</ul>
						</td>
					</tr>
				</template>
			</table>
			<div class="p_btn_group p_clear_float">
				<input type="button" value="取消" class="p_btn p_btn_siz_2 p_btn_col_red p_btn_pos_r" @click="quxiao">
				<input v-if="buttonRead" type="button" value="确定" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r" @click="save">
				<input v-else type="button" value="确定" class="p_btn p_btn_siz_2 p_btn_col_gray p_btn_pos_r" readonly>

			</div>
		</section>
	</div>
</template>
<script>
	import instance from '../../../api/index.js';
	import { mapState } from 'vuex';
	import timeblock from "./addClassTime.vue";
	import * as util from '../../../assets/util.js';

	export default {
		data() {
			return {
				searDetail: {},
				classDetail: {
					// schoolId:""
				},
				classRooms: [{
					'classRoomId': '0'
				}], //教室

				teacherNames: [], //教师
				lessons: [],
				studentList: [],
				seaDetail: {
					// qBeginDate: "",
					// qEndDate: ""
				},
				dateDetail: [],
				tableList: [],
				lessonId: '',
				classRoomName: '',
				teacherName: '',
				seaRecord: {},
				recordList: [],
				studentRecordList: [],
				studentLessonList: [],
				cost: [],
				lessonStatus: [],
				allcost: '',
				alllessonStatus: '',
				sumHourList: [],
				allreadonly: false,
				buttonRead: false,
				first: 0,
				daike_isshow: true, //代课教师 文本域 与下拉域隐藏/显示
				teacherList: [], //教师字典
				isRole_teacher:false //是否包括 教师角色

			};
		},
		methods: {
			getClassInfo: function() { //获取班级信息
				instance.get('/class/findClass/' + this.$route.params.id).then((res) => {
					this.classDetail = res.data.data;
					this.nowWeek();
					instance.get('/student/findClassStudents/' + this.$route.params.id).then((res) => {
						this.studentLessonList = res.data.data;
					})

				})
			},
			nowWeek: function() {
				window.util_date.newToday(new Date());
				this.seaDetail.qBeginLessonDate = window.util_date.getMonday().pattern("yyyy-MM-dd");
				this.seaDetail.qEndLessonDate = window.util_date.getSunday().pattern("yyyy-MM-dd");
				this.dateDetail = window.util_date.getDays(window.util_date.getMonday(), 'yyyy-MM-dd');
				// this.getSchedule();
				this.getclassRecord();

			},
			// getSchedule: function() { //获取周课程列表信息
			//   this.seaDetail.qClassId=this.$route.params.id;
			//   instance.post('/lesson/findWeekLessonTimeTables2',this.seaDetail).then((res) => {
			//     this.tableList = res.data.data;
			//     var ishave=false;
			//     var myDate = new Date();
			//     var y=myDate.getFullYear();
			//     var m=myDate.getMonth()+1;
			//     var d=myDate.getDate();
			//     if(m<10){
			//       m='0'+m;
			//     };
			//     if(d<10){
			//       d='0'+d;
			//     }
			//     var now=y+'-'+m+'-'+d;
			//     for(var i=0;i<this.tableList.length;i++){
			//       this.tableList[i].day=this.dateDetail[this.tableList[i]['weekday']-0-1];
			//       if(now==this.tableList[i].day){
			//         ishave=true;
			//         this.lessonId=i;
			//       }
			//       switch(this.tableList[i]['weekday']){
			//         case '1':{this.tableList[i].xq='一'};break;
			//         case '2':{this.tableList[i].xq='二'};break;
			//         case '3':{this.tableList[i].xq='三'};break;
			//         case '4':{this.tableList[i].xq='四'};break;
			//         case '5':{this.tableList[i].xq='五'};break;
			//         case '6':{this.tableList[i].xq='六'};break;
			//         case '7':{this.tableList[i].xq='日'};break;
			//       };
			//     };
			//     if(ishave){
			//       this.seaRecord.qBeginLessonDate=now;
			//       this.seaRecord.qEndLessonDate=now;
			//       this.seaRecord.qBeginBeginTime=this.tableList[this.lessonId].beginTime;
			//       this.seaRecord.qBeginEndTime=this.tableList[this.lessonId].endTime;
			//       this.updata(this.lessonId);
			//       this.getclassRecord();
			//     }
			//   })
			// },
			getclassRecord: function() { //获取上课记录
				var shangkejilu = {
					'qClassId': this.$route.params.id,
					'qVerify': '1',
					'qTeacherId':''
				}

				//从session中获取用户登陆json
				this.loginInfo = util.session('loginInfo').login;

				//查询用户角色
				this.loginInfo.roles.forEach(function(r) {
					
					//授课教师
					if(r.roleCode == "teacher") {
						this.isRole_teacher = true;
					}
				}, this);
				if(this.isRole_teacher){
					shangkejilu.qTeacherId=this.loginInfo.userId;
				}
				this.seaDetail.qClassId = this.$route.params.id;
				this.seaDetail.qVerify = "1";
				// qVerify
				instance.post('/lesson/findLessonRecords', shangkejilu).then((res) => {
					this.recordList = res.data.data;
					this.tableList = res.data.data;
					var ishave = false;
					var myDate = new Date();
					var y = myDate.getFullYear();
					var m = myDate.getMonth() + 1;
					var d = myDate.getDate();
					if(m < 10) {
						m = '0' + m;
					};
					if(d < 10) {
						d = '0' + d;
					}
					var now = y + '-' + m + '-' + d;
					for(var i = 0; i < this.tableList.length; i++) {
						this.tableList[i].day = this.dateDetail[this.tableList[i]['weekday'] - 0 - 1];
						if(now == this.tableList[i].day) {
							ishave = true;
							this.lessonId = i;
						}
						switch(this.tableList[i]['weekday']) {
							case '1':
								{
									this.tableList[i].xq = '一'
								};
								break;
							case '2':
								{
									this.tableList[i].xq = '二'
								};
								break;
							case '3':
								{
									this.tableList[i].xq = '三'
								};
								break;
							case '4':
								{
									this.tableList[i].xq = '四'
								};
								break;
							case '5':
								{
									this.tableList[i].xq = '五'
								};
								break;
							case '6':
								{
									this.tableList[i].xq = '六'
								};
								break;
							case '7':
								{
									this.tableList[i].xq = '日'
								};
								break;
						};
					};
					// if(this.recordList.length!=0){
					//   this.buttonRead=true;
					// };
					if(ishave) {
						this.daikejiaoshi();
						this.seaRecord.qBeginLessonDate = this.tableList[this.lessonId].day;
						this.seaRecord.qEndLessonDate = this.tableList[this.lessonId].day;
						this.seaRecord.qBeginBeginTime = this.tableList[this.lessonId].beginTime;
						this.seaRecord.qBeginEndTime = this.tableList[this.lessonId].endTime;
						this.classRoomName = this.tableList[this.lessonId].classRoomName;
						this.teacherName = this.tableList[this.lessonId].teacherId;
						// instance.post('/lesson/findStudentLessons',this.seaRecord).then((res) => {
						//   this.studentRecordList = res.data.data;
						//   // alert(this.studentRecordList .length);
						//   for (var i in this.studentRecordList) {
						//     for (var j in this.studentLessonList) {
						//       if (this.studentLessonList[j].id === this.studentRecordList[i].studentId) {
						//         this.studentRecordList[i].hour = this.studentLessonList[j].studentLessonCard.hour;
						//         if (this.studentRecordList[i].lessonStatus === '2' || this.studentRecordList[i].lessonStatus === '5') {
						//           this.studentRecordList[i].read = true;
						//         }
						//       }
						//     }
						//   }
						//
						//
						// })
						this.getStudentLessons();
						// this.buttonRead=true;
					}
					// this.getStudentLessons()
				})

			},
			getStudent: function() { //获取学员信息
				instance.get('/student/findClassStudents/' + this.$route.params.id).then((res) => {
					this.studentList = res.data.data;
				})
			},
			getStudentLessons: function() { //获取学员课时信息
				var xueyuanjiku = {
					'qVerify': '1',
					'qLessonRecordId': this.recordList[this.lessonId].id
				}
				this.seaRecord.qClassId = this.$route.params.id;
				this.seaRecord.qVerify = "1";
				instance.post('/lesson/findStudentLessons', xueyuanjiku).then((res) => {
					this.studentRecordList = res.data.data;
					// alert(this.studentRecordList.length);
					if(this.studentRecordList.length != 0) {
						this.buttonRead = true;
					} else {
						this.buttonRead = false;
					};
					// alert(this.studentRecordList .length);
					for(var i in this.studentRecordList) {
						for(var j in this.studentLessonList) {
							if(this.studentLessonList[j].id === this.studentRecordList[i].studentId) {
								this.studentRecordList[i].hour = this.studentLessonList[j].studentLessonCard.hour;
								// if (this.studentRecordList[i].lessonStatus === '2' || this.studentRecordList[i].lessonStatus === '5') {
								//   this.studentRecordList[i].read = true;
								// }
							}
						}
					}

				})
			},
			updata: function(id) {
				//debugger;
				//alert(id);
				//alert(id!='ssss');
				// alert(id=='undefined');
				// alert(id==null);
				// alert(id=='');
				//设置代课教师失效，变为文本框只读
				this.daike_isshow = true;
				if(id != 'ssss') {
					this.daikejiaoshi();
					this.classRoomName = this.tableList[id - 0].classRoomName;
					this.teacherName = this.tableList[id - 0].teacherId;
					this.seaRecord.qBeginLessonDate = this.tableList[id - 0].day;
					this.seaRecord.qEndLessonDate = this.tableList[id - 0].day;
					this.seaRecord.qBeginBeginTime = this.tableList[this.lessonId].beginTime;
					this.seaRecord.qBeginEndTime = this.tableList[this.lessonId].endTime;
					this.allcost = '';
					this.alllessonStatus = '';
					// this.getclassRecord();
					this.getStudentLessons()
				} else {
					this.studentRecordList = [];
				}

			},
			allchoose: function(index, node, state) {
				if(index) {
					if(node == '2' || node == '5') {
						// this.allcost=0;
						this.allreadonly = false;
					} else if(node == '1') {
						if(state == 'txt') {
							//console.log(this.allreadonly);
							// this.allcost=this.classDetail.lessonHour;
							this.allreadonly = false;
						} else {
							//console.log(this.allreadonly);
							// this.allcost=this.classDetail.lessonHour;
							this.allreadonly = false;
						}

					} else {
						this.allreadonly = false;
					}
					if(state != 'txt') {
						if(this.first == 0) {
							this.allcost = this.classDetail.lessonHour;
						}
					}
					// this.allcost=this.classDetail.lessonHour;
					for(var i in this.studentRecordList) {
						this.studentRecordList[i].lessonStatus = this.alllessonStatus;
						this.studentRecordList[i].realHour = this.allcost;
					};
					// alert(node=='3');

					this.first++
				} else {
					this.allcost = '';
					this.alllessonStatus = '';
					// alert(this.studentRecordList[node].lessonStatus);
					if(this.studentRecordList[node].lessonStatus === '2' || this.studentRecordList[node].lessonStatus === '5') {
						// alert(true);
						this.studentRecordList[node].read = true;
						// this.studentRecordList[node].realHour=0;
					} else if(this.studentRecordList[node].lessonStatus === '1') {
						this.studentRecordList[node].read = false;
						// this.studentRecordList[node].realHour=this.classDetail.lessonHour;
					} else {
						// alert(false);
						this.studentRecordList[node].read = false;
					}
					//console.log(this.studentRecordList[node].lessonStatus+';'+this.studentRecordList[node].read);
				}
			},
			save: function() {
				this.$confirm("确定确认考勤？", "提示", {
						confirmButtonText: "确定",
						cancelButtonText: "取消",
						type: "info"
					}).then(() => {
						this.recordList[this.lessonId].studentLessons = this.studentRecordList;
						this.recordList[this.lessonId].descr = this.descr;
						for(var i in this.recordList[this.lessonId].studentLessons) {
							delete this.recordList[this.lessonId].studentLessons[i].hour;
							delete this.recordList[this.lessonId].studentLessons[i].read;
							// this.recordList[this.lessonId].studentLessons[i].verify="0";
						}
						delete this.recordList[this.lessonId].xq;
						delete this.recordList[this.lessonId].day;
						instance.post('/lesson/verifyLessonRecord', this.recordList[this.lessonId]).then((res) => {
							if(res.data.errcode == 0) {
								this.$message.success('考勤操作成功!');
							} else {
								this.$message.error('操作失败！' + res.data.errmsg);
								this.updata(this.lessonId);
							}
						});
					})
					.catch(() => {});
			},
			quxiao: function() {
//				this.$router.push('/jiaowuguanli/banjiguanli/banjiliebiao');
				this.$router.go(-1);
			},
			//代课教师
			daikejiaoshi: function() {
				this.daike_isshow = true;
				var qTeacherParams = {
					'qWorking': '0', //在职状态
					'qSchoolId': this.classDetail.schoolId, //校区id
					'qCourseId': this.classDetail.courseId, //课程大类id
					'qCourseSubId': this.classDetail.courseSubId, //课程小类id
					'qWeekday': this.tableList[this.lessonId].weekday, //星期
					'qBeginTime': this.tableList[this.lessonId].beginTime, //开始时间
					'qEndTime': this.tableList[this.lessonId].endTime //结束时间
				}
				instance.post('/teacher/findSimpleTeachers', qTeacherParams).then((res) => {
					this.teacherList = res.data.data;
				})
			},

			//更新代课教师信息
			updateDaikeTeacher: function() {
				let vm = this;
				this.tableList[this.lessonId].teacherId = vm.teacherName;
				let selTeacherName = "";
				this.teacherList.forEach(function(teacher, i) {
					if(teacher.id == vm.teacherName) {
						selTeacherName = teacher.realName;
					}
				});
				this.tableList[this.lessonId].teacherName = selTeacherName;

				for(var i in this.studentRecordList) {
					this.studentRecordList[i].teacherId = this.teacherList[this.teacherName].id;
					this.studentRecordList[i].teacherName = this.teacherList[this.teacherName].realName;
				}
				//				console.info("this.recordList[this.lessonId]==" + JSON.stringify(this.recordList[this.lessonId]));
				//				console.info("this.studentRecordList=" + JSON.stringify(this.studentRecordList));
				//				console.info("this.tableList[this.lessonId]=" + JSON.stringify(this.tableList[this.lessonId]));
			}

		},
		mounted: function() {
			this.getClassInfo();
			//this.getStudent();

		}
	};
</script>