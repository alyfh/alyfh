<!-- <title>添加班级</title> -->
<style>
	.h5_02_info_per_exportRules_h3 {
		border-bottom: solid 1px #e7e7e7;
		padding: 10px 20px 10px 30px;
		color: #979494
	}
	
	.el-input__inner {
		height: 25px;
	}
</style>
<template>
	<form id="" method="post" action="" class="ue_form_add">
		<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
        	<span>新增班级(</span>
        	<span class='h5_mark_xx2'>★</span>
        	<span>为必填)</span>
    	</h3>
		<ul class='h5_02_info_per_addlist'>
			<li>
				<span>★</span>
				<span>所属校区:</span>
				<span>
            <select name=""  class='per_addperson_txt' v-model="classDetail.schoolId" @change="getRoom(classDetail.schoolId)">
              <option v-for="sName in schoolNames" :value="sName.id">{{ sName.schoolName }}</option>
            </select>
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>班级名:</span>
				<span>
            <!--<input type="text" class='per_addperson_txt' v-model="classDetail.className" >-->
            <el-input placeholder="请输入内容" v-model="classDetail.className"  clearable></el-input>
          </span>
			</li>
			<li>
				<span>★</span>
				<span>课程大类:</span>
				<span>
    				<select  class='per_addperson_txt' v-model="classDetail.courseId" @change="getClassSub(classDetail.courseId)">
                <option disabled value="">请选择</option>
                <option v-for="className in classNames" :value="className.id">{{className.courseName}}</option>
            </select>
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>课程小类:</span>
				<span>
    				<select name="" id="" class='per_addperson_txt' v-model="classDetail.courseSubId">
              <option v-for="classNameSub in classNameSubs" :value="classNameSub.id">{{classNameSub.courseSubName}}</option>
            </select>

    			</span>
			</li>
			<li>
				<span>★</span>
				<span>授课类型:</span>
				<span>
    				<select name="" id="" class='per_addperson_txt' v-model="classDetail.oneByOne">
              <option value="1">一对多</option>
              <option value="0">一对一</option>
            </select>
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>班型:</span>
				<span>
    				<select name="" id="" class='per_addperson_txt' v-model="classDetail.classTypeId">
              <option v-for="classType in classTypes" :value="classType.id">{{classType.classTypeName}}</option>
            </select>
    			</span>
			</li>

			<li>
				<span>★</span>
				<span>预招人数:</span>
				<span>
    				<input type="text" class='per_addperson_txt' v-model="classDetail.planStudent">
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>开课日期:</span>
				<span>
              <el-date-picker type="date"  value-format="yyyy-MM-dd" placeholder="Pick a date" style="width:100%" v-model="classDetail.beginDate"></el-date-picker>
          </span>
			</li>
			<li>
				<span>★</span>
				<span>结课日期:</span>
				<span>
              <el-date-picker type="date"  value-format="yyyy-MM-dd" placeholder="Pick a date" style="width:100%" v-model="classDetail.endDate"></el-date-picker>
            </span>
			</li>
			<li>
				<span>★</span>
				<span>招生状态:</span>
				<span>
    				<select name="" id="" class='per_addperson_txt' v-model="classDetail.studentStatus">
                <option value="1">正在招生</option>
                <option value="2">停止招生</option>
            </select>
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>计划课时:</span>
				<span>
    				<input type="text" class='per_addperson_txt' v-model="classDetail.planHour">
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>每次课时:</span>
				<span>
    				<input type="text" class='per_addperson_txt' v-model="classDetail.lessonHour">
    			</span>
			</li>
			<li class="per_addperson_li_w per_addperson_li_h2">
				<span></span>
				<span>备注:</span>
				<span>
             <textarea name="" id="" cols="30" rows="4" placeholder="其他" class='per_addperson_texarea' v-model="classDetail.descr"></textarea>
          </span>
			</li>
		</ul>
		<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
        	<span>上课时间(</span>
        	<span class='h5_mark_xx2'>★</span>
        	<span>为必填)</span>
            <input type="button" value="新增上课时间" class="p_btn p_btn_siz_2 p_btn_col_k_gre p_btn_pos_r" id="ue_addclasstime" @click="addTimeBlock()">
    	</h3>
		<timeblock :is="item.component" v-for="(item,index) in items" :key="item.id" :counts="index" @delblock="delTimeBlock" @uplessons="lesson" :room="roomList" :teacher="teachers" :class-list="classDetail"></timeblock>
		<div id></div>
		<br class="p_zwf">
		<div class="p_btn_group p_clear_float">
			<input type="button" value="取消" class="p_btn p_btn_siz_2 p_btn_col_red p_btn_pos_r" @click="$router.go(-1)">
			<input type="button" value="保存" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r" @click="saveClass()">
		</div>
	</form>
</template>
<script>
	import instance from '../../../api/index.js';
	import { mapState } from 'vuex';
	import timeblock from "./addClassTime.vue";
	import * as util from '../../../assets/util.js';

	export default {
		data() {
			return {
				classDetail: {
					schoolId: ""
				},
				lessons: [],
				weekShow: true,
				adviceDetail: {},
				schoolNames: [], //校区
				classNames: [], //课程大类
				classNameSubs: [], //课程小类
				classTypes: [], //班型
				counselorNames: [], //咨询师
				consultants: [], //课程顾问
				teachers: [], //授课教师
				items: [],
				pcon: 0,
				roomList: [],
				loginInfo: {},
				role: []
			};
		},
		methods: {
			saveClass: function() { //保存
				// debugger;
				//alert(this.lessons.length);
				var data = this.classDetail;
				data.lessons = [];
				for(var i = 0; i < this.lessons.length; i++) {
					if(this.lessons[i] == '') {
						// this.lessons.splice(i, 1);
						// i--
					} else {
						data.lessons.push(this.lessons[i]);
					}
				}
				//alert(this.lessons.length);
				// for(var i=0;i<this.lessons.length;i++){
				//   // if(this.lessons[i]==''){
				//   //   this.lessons.splice(i,1)
				//   // };
				//   this.lessons[i]['beginDate']=this.classDetail.beginDate;
				//   this.lessons[i]['className']=this.classDetail.className;
				//   this.lessons[i]['schoolId']=this.classDetail.schoolId;
				//   this.lessons[i]['courseId']=this.classDetail.courseId;
				//   this.lessons[i]['courseSubId']=this.classDetail.courseSubId;
				//   this.lessons[i]['endDate']=this.classDetail.endDate;
				//   this.lessons[i]['lessonHour']=this.classDetail.lessonHour;
				// }
				for(var i = 0; i < data.lessons.length; i++) {
					// if(this.lessons[i]==''){
					//   this.lessons.splice(i,1)
					// };
					data.lessons[i]['beginDate'] = this.classDetail.beginDate;
					data.lessons[i]['className'] = this.classDetail.className;
					data.lessons[i]['schoolId'] = this.classDetail.schoolId;
					data.lessons[i]['courseId'] = this.classDetail.courseId;
					data.lessons[i]['courseSubId'] = this.classDetail.courseSubId;
					data.lessons[i]['endDate'] = this.classDetail.endDate;
					data.lessons[i]['lessonHour'] = this.classDetail.lessonHour;
				}

				// data.lessons=this.lessons;
				instance.post('/class/createClass', data).then((res) => {
					if(res.data.errcode == '0') {
						// this.$message.info('保存成功');
						// this.$confirm("保存成功！是否跳回列表页面?", "提示", {
						//   confirmButtonText: "确定",
						//   cancelButtonText: "取消",
						//   type: "info"
						// }).then(() => {
						//   this.$router.push('/jiaowuguanli/banjiguanli/banjiliebiao');
						// })
						//   .catch(() => {});
						this.$alert('保存成功！', '提示', {
							confirmButtonText: '确定',
							type: 'success'
						}).then(() => {
							this.$router.push('/jiaowuguanli/banjiguanli/banjiliebiao');
						}).catch(() => {
							this.$router.push('/jiaowuguanli/banjiguanli/banjiliebiao');
						});
					} else {
						////////////
						this.$alert(res.data.errmsg, '操作失败', {
							confirmButtonText: '确定',
							type: 'error'
						});
						// callback: action => {
						//   this.$message({
						//
						//     message: `action: ${ action }`
						//   });
						// }
					}
				})
			},
			lesson: function(data, id, que, teacheris) {
				this.lessons[id] = data;
				// this.lessons[id]['beginDate']=this.classDetail.beginDate;
				// this.lessons[id]['className']=this.classDetail.className;
				// this.lessons[id]['schoolId']=this.classDetail.schoolId;
				// this.lessons[id]['courseId']=this.classDetail.courseId;
				// this.lessons[id]['courseSubId']=this.classDetail.courseSubId;
				// this.lessons[id]['beginDate']=this.classDetail.beginDate;
				// this.lessons[id]['endDate']=this.classDetail.endDate;
				// this.lessons[id]['lessonHour']=this.classDetail.lessonHour;
			},
			getUserSchool: function() { //获取当前用户校区字典
				//获取当前登录人
				this.loginInfo = util.session("loginInfo", void(0));
				this.role = this.loginInfo.login.roles;
				// for(var i in this.role){
				//   if(this.role[i]['roleName']=='大区经理'){
				//
				//   }
				// }
				// alert(this.role);
				//alert(this.loginInfo.roles.userId);
				instance.get('/school/findUserSchools/' + this.loginInfo.login.userId, {}).then((res) => {
					this.schoolNames = res.data.data;
				})
			},
			getSchool: function() { //获取校区数据
				instance.post('/school/findSimpleSchools', {}).then((res) => {
					this.schoolNames = res.data.data;
				})
			},
			getClass: function() { //获取课程大类数据
				instance.post('/course/findCourses', {
					'qSchoolId': this.classDetail.schoolId
				}).then((res) => {
					this.classNames = res.data.data;
				})
			},
			getClassSub: function(id) { //获取课程小类数据
				instance.post('/course/findSimpleCourseSubs', {
					qCourseId: id,
					qSchoolId: this.classDetail.schoolId
				}).then((res) => {
					this.classNameSubs = res.data.data;
				})
			},
			getClassType: function() { //获取班型
				instance.post('/classtype/findSimpleClassTypes', {}).then((res) => {
					this.classTypes = res.data.data;
				})
			},
			// getTeacher: function(schoolId) { //获取授课教师列表
			//   instance.post('/teacher/findSimpleTeachers', {
			//     qSchoolId: schoolId,
			//     qWorking:0,
			//     qCourseSubId:this.classDetail.courseSubId
			//   }).then((res) => {
			//     this.teachers = res.data.data;
			//   })
			// },
			getRoom: function(id) { //获取校区教室数据
				instance.post('/classroom/findSimpleClassRooms', {
					"qSchoolId": id,
				}).then((res) => {
					this.roomList = res.data.data;
				});
				//this.getTeacher(id);
				this.getClass(id);
			},
			addTimeBlock: function() { //添加课时
				this.lessons.push({});
				this.items.push({
					component: 'timeblock',
					id: this.pcon
				});
				this.pcon++;
			},
			delTimeBlock: function(id) {
				//alert(id);//删除课时
				this.items.splice(id, 1, '');
				this.lessons.splice(id, 1, '');
			},
		},
		components: {
			timeblock
		},
		mounted: function() {
			this.getUserSchool();
			// this.getSchool();
			this.getClassType();
		}
	};
</script>