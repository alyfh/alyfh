<!-- <title>班级详情</title> -->
<style>
	.el-input__inner{
		height: 25px;
	}
	.classinfo>li{
		width: calc(25% - 7px);
  }
</style>
<template>
	<!--<title>新增学员</title>-->
  <form id="addstu" method="post" action="" class="ue_form_add">
    <h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
      <span>班级详情</span>
    </h3>
    <ul class='h5_02_info_per_addlist classinfo'>
      <li>
        <span>★</span>
        <span>班级名:</span>
        <span>{{classDetail.className}}</span>
      </li>
      <li>
        <span>★</span>
        <span>开课日期:</span>
        <span>{{classDetail.beginDate}}</span>
      </li>
      <li>
        <span>★</span>
        <span>结课日期:</span>
        <span>
            {{classDetail.endDate}}
          </span>
      </li>
      <li>
        <span>★</span>
        <span>班型:</span>
        <span>
    				{{classDetail.classTypeName}}

    			</span>
      </li>
      <li>
        <span>★</span>
        <span>授课类型:</span>
        <span>
    				{{classDetail.oneByOne==1?'一对多':'一对一'}}
    			</span>
      </li>
      <li>
        <span>★</span>
        <span>课程大类:</span>
        <span>
            {{classDetail.courseName}}
          </span>
      </li>
      <li>
        <span>★</span>
        <span>课程小类:</span>
        <span>
            {{classDetail.courseSubName}}
          </span>
      </li>
      <!--<li>-->
        <!--<span>★</span>-->
        <!--<span>教室:</span>-->
        <!--<span>-->

        <!--</span>-->
      <!--</li>-->
      <!--<li>-->
        <!--<span>★</span>-->
        <!--<span>授课教师:</span>-->
        <!--<span>-->

        <!--</span>-->
      <!--</li>-->
      <!--<li>-->
        <!--<span>★</span>-->
        <!--<span>学管师:</span>-->
        <!--<span></span>-->
      <!--</li>-->
      <li>
        <span>★</span>
        <span>计划课时:</span>
        <span>
            {{classDetail.planHour}}
          </span>
      </li>

      <li>
        <span>★</span>
        <span>预招人数:</span>
        <span>
            {{classDetail.planStudent}}
          </span>
      </li>
      <li>
        <span>★</span>
        <span>招生状态:</span>
        <span>
    				{{classDetail.studentStatus == 1 ? '正在招生' : '结束招生'}}
    			</span>
      </li>
      <li>
        <span>★</span>
        <span>每次课时:</span>
        <span>
    				{{classDetail.lessonHour}}
    			</span>
      </li>
      <li class="per_addperson_li_w ">
        <span></span>
        <span>备注:</span>
        <span class="text_scroll" v-if="classDetail.descr==''">
            {{classDetail.descr}}
          </span>
        <span v-else>
            {{classDetail.descr}}
        </span>
      </li>
    </ul>
    <div class="zxts" style="margin-top: 10px">
      <div class='zxt_nav p_clear_float'>
        <div @click="function(){show='student'}" :class="{'zxt_nav_click':show === 'student'}">学员</div>
        <div @click="function(){show='week'}" :class="{'zxt_nav_click':show === 'week'}">周课程表</div>
        <div @click="function(){show='month'}" :class="{'zxt_nav_click':show === 'month'}">月上课记录</div>
      </div>

      <div class="p_tab_over">
        <info1 :class-id="$route.params.id" v-if="show === 'student'" ></info1>
        <info2 :class-id="$route.params.id" v-else-if="show === 'week'" ></info2>
        <info3 :class-id="$route.params.id" v-else-if="show === 'month'" ></info3>
	    </div>
	 </div>
  </form>
</template>
<script>
  import instance from '../../../api/index.js';
  import { mapState } from 'vuex';
  import timeblock from "./addClassTime.vue";
  import * as util from '../../../assets/util.js';

  export default {
    mounted: function() {
      this.getClassInfo();
    },
    components: {
      timeblock,
      info1:() => import('./studentlist.vue'),
      info2:() => import('././weekTimetable.vue'),
      info3:() => import('./monthRecord.vue')
    },
    computed: {
      // Getting Vuex State from store/index
      ...mapState({
        layerShow: state => state.layerShow
      })
    },
    data() {
      return {
        show: 'student',
        timeShow:false,
        classDetail: {
          schoolId:""
        },
        schoolNames: [],//校区
        classNames: [],//课程大类
        classNameSubs: [],//课程小类
        classTypes: [],//班型
        teachers:[],//授课教师
        roomList:[],//教室
        updateLessons:[],//已选课程
        createLessons:[],//新增课程
        deleteLessons:[],//删除课程
        items: [],
        pcon:0,

      };
    },
    methods: {
      getClassInfo:function(){//获取班级信息
        instance.get('/class/findClass/'+this.$route.params.id).then((res) => {
          this.updateLessons=res.data.data.lessons;
          delete res.data.data.lessons;
          this.classDetail = res.data.data;
        })
      }
    },

  };
</script>
