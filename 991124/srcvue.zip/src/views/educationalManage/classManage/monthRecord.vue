<!-- <title>月上课记录</title> -->
<style>
.p_monthTable1{
	/*width: 100%;*/
	margin:auto;
	/*margin-top: 10px*/
}
.p_monthTable1 tr>td{
	width: 100px;
	border:solid 1px #f0f0f0;
	cursor: pointer;
}
	.p_monthTable1 tr>td>div{
		float: left;
		width: 20px;
		line-height: 100px;
		text-align: center;
		height: 100px;
		border-right: solid 1px #f0f0f0;
		background-color: rgba(254,192,46,0.1);
	}
	.p_monthTable1 tr>td>ul{
		float: left;
		width: 60px;
		/*line-height: 120px;*/
		text-align: center;
		height: 100px;
	}
	.p_monthTable1 tr>td>ul>li{
		height: 20px;
		line-height: 20px;
		list-style-type: none;
		color: #6e6e6e

	}
	.p_monthTable1 tr>td>ul>li>span{
		color: #f3765b
	}
  #tab1{
    width: calc(100% - 10px);
    margin: auto;
  }
</style>
<template>
	<div class="p_con_tab">
		<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
            <span>{{currMonth}}月上课记录</span>
        </h3>
        <div class="p_btn_group p_clear_float">
            <input type="button" value="上月" class="p_btn p_btn_siz_2 p_btn_col_gre p_btn_pos_r" @click="preMonth">
          <!--<input type="button" value="本月" class="p_btn p_btn_siz_2 p_btn_col_gre p_btn_pos_r" @click="preMonth">-->
            <input type="button" value="本月" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r" @click="nowMonth">
        </div>
		<div class="mounthCon">
		</div>
    <div class="addlayer" id='templayer' v-if="show" >
      <header>
        <span class="h5_layerLOGO"></span>
        <span class="h5_layerOFFbtn" @click="setLayerShow">╳</span>
      </header>
      <div class="addlayerBox">
        <h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
          <span>{{date}}上课记录</span>
        </h3>
        <div class="p_table_la_over">
        <table class="p_table_la" cellspacing="0" cellpadding="0" id="tab1">
          <tr>
            <td>序号</td>
            <td>授课教师</td>
            <td>学生</td>
            <td>所属校区</td>
            <td>课程大类</td>
            <td>课程小类</td>
            <td>班级名</td>
            <td>班型</td>
            <td>上课日期</td>
            <td>上课时间段</td>
            <td>上课课时</td>
            <td>请假课时</td>
            <td>旷课课时</td>
            <td>补课课时</td>
            <td>停课课时</td>
            <!--<td>学管师</td>-->
            <td>创建时间</td>
            <td>备注</td>
          </tr>
          <tr v-for="(lis,index) in tableList">
            <td>{{index+1}}</td>
            <td>{{lis.teacherName}}</td>
            <td>{{lis.studentName}}</td>
            <td>{{lis.schoolName}}</td>
            <td>{{lis.courseName}}</td>
            <td>{{lis.courseSubName}}</td>
            <td>{{lis.className}}</td>
            <td>{{lis.oneByOne==1?'一对多':'一对一'}}</td>
            <td>{{lis.lessonDate}}</td>
            <td>{{lis.beginTime}}-{{lis.endTime}}</td>
            <td>{{lis.lessonStatus==1?lis.realHour:''}}</td>
            <td>{{lis.lessonStatus==2?lis.realHour:''}}</td>
            <td>{{lis.lessonStatus==3?lis.realHour:''}}</td>
            <td>{{lis.lessonStatus==4?lis.realHour:''}}</td>
            <td>{{lis.lessonStatus==5?lis.realHour:''}}</td>
            <!--<td></td>-->
            <td>{{lis.createTime}}</td>
            <td>{{lis.descr}}</td>
          </tr>
        </table>
        </div>
      </div>
    </div>
	</div>
</template>
<script>
  import instance from '../../../api/index.js';
  import { mapState } from 'vuex';
  export default {
    props: ['classId'],
    data() {
      return {
        tableList:[],
        mounth:new Date(),
        currMonth:'',//显示月份
        show: false,
        searDetail:{},
        date:'',
        record:[],
        newrecord:[]
      }
    },
    components: {
      page: () => import("../../common/page.vue")
    },
    computed: {
      // Getting Vuex State from store/index
      ...mapState({
        layerShow: state => state.layerShow,
        pageSize: state => state.pageSize,
        pageLarge: state => state.pageLarge
      })
    },
    methods: {
      getData: function() { //
        // this.tableList=[];
        instance.post('/lesson/findStudentLessons',this.searDetail).then((res) => {
          this.tableList = res.data.data;
        })
      },
      // linkStudentInfo:function(id){//学生姓名点击跳转详情
      //   this.$router.push('/xueyuanguanli/studentinfo/'+id+"/baseInfo");
      // },
      setLayerShow: function() {
        this.$store.commit({
          type: 'setLayerShow',
          layerShow: false
        });
        this.show=false
      },
      createTable:function(data){
        var a = data.split('-');
        var p=[];
        p[0]=a[0];
        p[1]=(a[1]<10?('0'+a[1]):a[1]);
        p[2]=(a[2]<10?('0'+a[2]):a[2]);
        a = p.join('-');
        //alert(a);
        this.$store.commit({
          type: 'setLayerShow',
          layerShow:true
        });
        this.show=true;

        this.date=data;
        this.searDetail.qBeginLessonDate=a;
        this.searDetail.qEndLessonDate=a;
        this.searDetail.qClassId=this.classId;
        this.searDetail.qVerify=0;
        this.getData();
        //alert(data);
      },
      startMounth:function(ng){
        $('.mounthCon').empty();
        var createCalendar = function(m,data,fun,con) {
          //alert(fun);
          var currentDate = new Date();
          var activeDate = new Date();
          var ret = ['<table class="p_monthTable1"><tr>'];
          if(m=='p'){//上个月
            activeDate.setMonth(currentDate.getMonth()-1);
          }else if(m=='n'){//下个月
            activeDate.setMonth(currentDate.getMonth()+1);
          };
          activeDate.setDate(1);
          activeDate.setDate(1 - activeDate.getDay());
          var header = "日一二三四五六";
          //日历的头部
          for(var i = 0 ; i < header.length ; i++) {
            ret[ret.length] = '<th>' + header.charAt(i) + '</th>';
          }
          ret[ret.length] = '</tr><tr>';
          var bf = true,af = false;
          for(var i = 0 ; i < 42 ; i++) {
            var date = activeDate.getDate();
            var fdate=activeDate.getYear()+1900+'-'+(activeDate.getMonth()+1)+'-'+activeDate.getDate();
            if(date == 1) {
              if(bf) {
                bf = false;
              } else {
                af = true;
              }
            }
            //日期是否在当前月份内
            if(af || bf) {
              ret[ret.length] = '<td></td>';
            } else {
              // var  str='';
              var str= '<td value="'+fdate+'" class="monthDayClick"><div>'+date+'</div>';
              str+='<ul>';
              try{
                // alert(date-1);
                // alert(data[date-1]['states'][2]['num']+'ok');
                // if()
                str+='<li>上课：<span>'+data[date-1]['states'][0]['num']+'</span></li>';
                str+='<li>请假：<span>'+data[date-1]['states'][1]['num']+'</span></li>';
                str+='<li>旷课：<span>'+data[date-1]['states'][2]['num']+'</span></li>';
                str+='<li>补课：<span>'+data[date-1]['states'][3]['num']+'</span></li>';
                str+='<li>停课：<span>'+data[date-1]['states'][4]['num']+'</span></li>';
              }catch(err){
                str+='<li>暂无记录</li>';
              }
              str+='</ul></td>';
              ret[ret.length]=str;
            }
            //
            if((i + 1) % 7 == 0) {
              ret[ret.length] = '</tr><tr>';
            }
            activeDate.setDate(date + 1);
          }
          //修改最后一个
          ret[ret.length - 1] = '</tr></table>';
          //返回日历表格
          $('body').on('click','.monthDayClick',function(event){
            //alert(1);
            fun($(this).attr('value'))
          });
          $(con).append(ret.join(""));
          //return ret.join("");
        };
        switch (ng){
          case 'c':createCalendar('c',this.newrecord,this.createTable,'.mounthCon');break;
          case 'p':createCalendar('p',this.newrecord,this.createTable,'.mounthCon');break;
          case 'n':createCalendar('n',this.newrecord,this.createTable,'.mounthCon');break;
        }
        //createCalendar('c',this.record,this.createTable,'.mounthCon');
      },
      getmounth:function (ng) {
        this.newrecord=[];
        var date = new Date();
        switch (ng){
          case 'p':{
            var firstDay = new Date(date.getFullYear(), date.getMonth()-1, 1);
            var lastDay = new Date(date.getFullYear(), date.getMonth(), 0);
          };break;
          case 'c':{
            var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
            var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);

          };break;
          case 'n':{
            var firstDay = new Date(date.getFullYear(), date.getMonth()+1, 1);
            var lastDay = new Date(date.getFullYear(), date.getMonth() + 2, 0);
          };break;
        };
        var m=firstDay.getMonth()+1,
            lm=lastDay.getMonth()+1,
            d=firstDay.getDate(),
            ld=lastDay.getDate();
            this.currMonth=m;
        var first=firstDay.getFullYear()+'-'+(m<10?('0'+m):m)+'-'+(d<10?('0'+d):d);
        var last=lastDay.getFullYear()+'-'+(lm<10?('0'+lm):lm)+'-'+(ld<10?('0'+ld):ld);
        for(var i=1;i<=(lastDay.getDate()-firstDay.getDate()+1);i++){
          //alert(firstDay.getFullYear()+'-'+(m<10?('0'+m):m)+'-'+(i<10?('0'+i):i));
          this.newrecord.push({
            'lessonDate':firstDay.getFullYear()+'-'+(m<10?('0'+m):m)+'-'+(i<10?('0'+i):i),
            'states':[
              {'id':'1','num':''},
              {'id':'2','num':''},
              {'id':'3','num':''},
              {'id':'4','num':''},
              {'id':'5','num':''}
            ]
          });
        };
        //console.log(this.newrecord);
        //alert(lastDay.getDate()-firstDay.getDate()+1);
        //alert(first+';'+last);
        instance.get('/lesson/findMonthLessonRecords/'+this.classId+'/'+first+'/'+last).then((res) => {
        // instance.get('/lesson/findMonthLessonRecords/'+this.classId+'/'+'2018-03-01'+'/'+'2018-03-31').then((res) => {
          this.record= res.data.data;
          for(var i in this.record){
            for(var j in this.newrecord){
              // alert(this.record[i].lessonDate+';'+this.newrecord[j].lessonDate);
              if(this.record[i].lessonDate==this.newrecord[j].lessonDate){
                //alert(typeof(this.record[i].lessonStatus));
                switch(this.record[i].lessonStatus){
                  case '1':{this.newrecord[j].states[0].num=this.record[i].total;};break;
                  case '2':{this.newrecord[j].states[1].num=this.record[i].total;};break;
                  case '3':{this.newrecord[j].states[2].num=this.record[i].total;};break;
                  case '4':{this.newrecord[j].states[3].num=this.record[i].total;};break;
                  case '5':{this.newrecord[j].states[4].num=this.record[i].total;};break;
                }
              }
            }
          };
          this.startMounth(ng)
        })
      },
      preMonth:function(){
        this.getmounth('p');

      },
      nowMonth:function(){
        this.getmounth('c');
        // this.startMounth('c')
      },
      nextMonth:function(){
        this.getmounth('n');
        // this.startMounth('n')
      },

    },
    mounted: function() {
      // this.getmounth();
      this.nowMonth();
    }
  };
</script>
