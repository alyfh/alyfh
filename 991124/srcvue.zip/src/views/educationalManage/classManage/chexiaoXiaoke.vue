<!-- <title>撤销消课</title> -->
<style>
	.p_btn_group {
		border-bottom: solid 1px #e7eaec;
		padding-bottom: 10px;
	}

	.p_txt_square {
		width: 50px;
		height: 25px;
		border-radius: 3px;
		border: solid 1px #cdcdcd;
		margin-right: 5px
	}

	.el-input__inner {
		height: 25px;
	}

	.el-date-editor .el-range-separator {
		line-height: 0px;
	}
</style>
<template>
	<div>
		<section class="p_chi_con">
			<div class="p_con_37 p_clear_float">
				<div class="p_con_37_3">
					<h4 class="p_title_strc">基本信息</h4>
					<ul class="p_ul_col">
						<li>
							<span>所属校区:</span>
							<span>
								{{classDetail.schoolName}}
							</span>
						</li>
						<li>
							<span>课程大类:</span>
							<span>
								{{classDetail.courseName}}
							</span>
						</li>
						<li>
							<span>课程小类:</span>
							<span>
								{{classDetail.courseSubName}}
							</span>
						</li>
						<li>
							<span>班级:</span>
							<span>
								{{classDetail.className}}
							</span>
						</li>
						<li>
							<span>授课类型:</span>
							<span>
								{{classDetail.oneByOne==1?'一对多':'一对一'}}
							</span>
						</li>
						<li>
							<span>班型:</span>
							<span>
								{{classDetail.classTypeName}}
							</span>
						</li>
					</ul>
				</div>
				<div class="p_con_37_7">
					<h4 class="p_title_strc">课时信息</h4>
					<ul class="p_ul_col_form">
						<li>
							<span>每次消耗课时</span>
							<span>
                {{classDetail.lessonHour}}
							</span>
						</li>
						<li>
							<span>上课周:</span>
							<span style="width: 25%">
                <el-date-picker type="date"  value-format="yyyy-MM-dd" placeholder="Pick a date" style="width:100%" v-model="kaishi" @change="otherWeek"></el-date-picker>
              </span>
							<span style="width: 25%">
                <el-date-picker type="date"  value-format="yyyy-MM-dd" placeholder="Pick a date" style="width:100%" v-model="jieshu" @change="otherWeek"></el-date-picker>
              </span>
							<!--<span>-->
							<!--<el-date-picker-->
							<!--v-model="shijianduan"-->
							<!--type="daterange"-->
							<!--range-separator="至"-->
							<!--start-placeholder="开始日期"-->
							<!--end-placeholder="结束日期"-->
							<!--value-format="yyyy-MM-dd"-->
							<!--default-value="2018-02-21"-->
							<!--firstDayOfWeek=2-->
							<!--@change="otherWeek">-->
							<!--</el-date-picker>-->
							<!--</span>-->
						</li>
						<li>
							<span>上课日期:</span>
							<span>
                <!--<el-date-picker type="date"  value-format="yyyy-MM-dd" placeholder="Pick a date" style="width:calc(100% - 8px)" v-model="searDetail.lessonDate" @change="updata"></el-date-picker>-->

								<select name="" id="" class="per_addperson_txt" @change="updata(lessonId)" v-model="lessonId">
                   <option value="no">--请选择--</option>
                   <option :value="index" v-for="(item,index) in tableList" :checked="index==lessonId?true:false">{{item.lessonDate}}&nbsp;&nbsp;{{item.beginTime}}-{{item.endTime}}&nbsp;星期{{item.xq}}</option>
                </select>
                <!-- 第三次上课 -->
							</span>
							<!--<span>-->
							<!--<el-date-picker-->
							<!--v-model="shijianduan"-->
							<!--type="daterange"-->
							<!--range-separator="至"-->
							<!--start-placeholder="开始日期"-->
							<!--end-placeholder="结束日期"-->
							<!--value-format="yyyy-MM-dd"-->
							<!--@change="otherWeek">-->
							<!--</el-date-picker>-->
							<!--</span>-->
						</li>

						<li>
							<span>教室:</span>
							<span>
              <!--<select name=""  class='p_con_form_select' v-model="searDetail.classRoomId" @change="updata">-->
                <!--<option value="">&#45;&#45;请选择&#45;&#45;</option>-->
                <!--<option v-for="sName in classRooms" :value="sName.classRoomId" :name="sName.mark">{{ sName.classRoomName}}</option>-->
                <!--</select>-->
                <input type="text" class='per_addperson_txt' :value="classRoomName" readonly>
							</span>
						</li>
						<!--<li>-->
						<!--<span>上课时段:</span>-->
						<!--<span>-->
						<!--&lt;!&ndash;<el-time-picker style="width:calc(100% - 10px)" value-format="HH:mm:ss" v-model="searDetail.beginTime" @change="updata"></el-time-picker> 到&ndash;&gt;-->
						<!--&lt;!&ndash;<el-time-picker style="width:150px" value-format="HH:mm:ss" v-model="searDetail.endTime" @change="updata"></el-time-picker>&ndash;&gt;-->
						<!--<select name="" id="" class="p_con_form_select"></select>-->
						<!--</span>-->
						<!--</li>-->
						<!--<li>-->
						<!--<span></span>-->
						<!--<span>-->
						<!--&lt;!&ndash;<el-time-picker style="width:150px" value-format="HH:mm:ss" v-model="searDetail.beginTime" @change="updata"></el-time-picker> 到&ndash;&gt;-->
						<!--&lt;!&ndash;<el-time-picker style="width:calc(100% - 10px)" value-format="HH:mm:ss" v-model="searDetail.endTime" @change="updata"></el-time-picker>&ndash;&gt;-->
						<!--<select name="" id="" class="p_con_form_select"></select>-->
						<!--</span>-->
						<!--</li>-->
						<li>
							<span>授课教师:</span>
							<span>
                <input type="text" class='per_addperson_txt' :value="teacherName" readonly>
							</span>
						</li>
						<!--<li>-->
						<!--<span>学管师:</span>-->
						<!--<span>-->
						<!--<select name="" id="" class="p_con_form_select"></select>-->
						<!--</span>-->
						<!--</li>-->
					</ul>
				</div>
			</div>
			<table class="p_tab_form_radio_l" cellspacing="0" cellpadding="0">
				<tbody v-for="(item,index) in studentRecordList">
					<tr>
						<td :id="item.id">{{item.studentName}}:</td>
						<td>
							<label v-if="item.lessonStatus==1">上课</label>
							<label v-else-if="item.lessonStatus==2">请假</label>
							<label v-else-if="item.lessonStatus==3">旷课</label>
							<label v-else-if="item.lessonStatus==4">补课</label>
							<label v-else="item.lessonStatus==5">停课</label> :{{item.realHour}}课时
						</td>
						<td>
							<!--扣除：-->
							<!--{{item.realHour}}课时-->
						</td>
						<td>
							当前会员卡剩余{{item.hour}}课时
						</td>
					</tr>
					<tr>
						<td>修改考勤状态</td>
						<td>
							<input type="radio" :id="item.id+1" :name="index+'kaoqin'" v-model="item.lessonStatus" value="1" @change="allchoose(false,'上课')">
							<label :for="item.id+1">上课</label>
						</td>
						<td>
							<input type="radio" :id="item.id+2" :name="index+'kaoqin'" v-model="item.lessonStatus" value="2" @change="allchoose(false,'请假')">
							<label :for="item.id+2">请假</label>
						</td>
						<td>
							<input type="radio" :id="item.id+3" :name="index+'kaoqin'" v-model="item.lessonStatus" value="3" @change="allchoose(false,'旷课')">
							<label :for="item.id+3">旷课</label>
						</td>
						<td>
							<input type="radio" :id="item.id+4" :name="index+'kaoqin'" v-model="item.lessonStatus" value="4" @change="allchoose(false,'补课')">
							<label :for="item.id+4">补课</label>
						</td>
						<td>
							<input type="radio" :id="item.id+5" :name="index+'kaoqin'" v-model="item.lessonStatus" value="5" @change="allchoose(false,'停课')">
							<label :for="item.id+5">停课</label>
						</td>
						<td>
							<label v-if="item.lessonStatus==1">上课</label>
							<label v-else-if="item.lessonStatus==2">请假</label>
							<label v-else-if="item.lessonStatus==3">旷课</label>
							<label v-else-if="item.lessonStatus==4">补课</label>
							<label v-else="item.lessonStatus==5">停课</label> ：
							<input type="text" class="p_txt_square" v-model="item.realHour">课时
						</td>
						<td>
							<input type="button" value="修改考勤" class="p_btn p_btn_siz_2 p_btn_col_k_blu p_btn_pos_r" @click="save(item.id,item.studentId,item.lessonStatus,item.realHour,item.descr)">
						</td>
					</tr>
          <tr>
            <td colspan="8" style="background: rgba(238,238,238,0.5)">
              <ul class='h5_02_info_per_addlist'>
                <li class="per_addperson_li_w per_addperson_li_h2" style="height: 50px">
                  <span style="width: 0px"></span>
                  <span style="width: 50px">备注:</span>
                  <span>
                      <textarea style="height: 50px;width: calc(90% - 70px)" name="" id="" cols="30" rows="4" placeholder="" class='per_addperson_texarea'  v-model="item.descr"></textarea>
                  </span>
                </li>
              </ul>
            </td>
          </tr>
				</tbody>

			</table>

		</section>
	</div>
</template>
<script>
	import instance from '../../../api/index.js';
	import { mapState } from 'vuex';
	import timeblock from "./addClassTime.vue";
	import * as util from '../../../assets/util.js';

	export default {
		data() {
			return {
				searDetail: {},
				classDetail: {
					// schoolId:""
				},
				classRooms: [{
					'classRoomId': '0'
				}], //教室

				teacherNames: [], //教师
				lessons: [],
				studentList: [],
				seaDetail: {
					// qBeginDate: "",
					// qEndDate: ""
				},
				dateDetail: [],
				tableList: [],
				lessonId: '',
				classRoomName: '',
				teacherName: '',
				seaRecord: {},
				recordList: [],
				studentRecordList: [],
				studentLessonList: [],
				cost: [],
				lessonStatus: [],
				allcost: '',
				alllessonStatus: '',
				kaishi: '',
				jieshu: '',
				shijianduan: ''

			};
		},
		methods: {
			getClassInfo: function() { //获取班级信息
				instance.get('/class/findClass/' + this.$route.params.id).then((res) => {
					this.classDetail = res.data.data;
					this.nowWeek();
					instance.get('/student/findClassStudents/' + this.$route.params.id).then((res) => {
						this.studentLessonList = res.data.data;
					})
				})
			},
			nowWeek: function() { //本周时间
				window.util_date.newToday(new Date());
				this.seaDetail.qBeginLessonDate = window.util_date.getMonday().pattern("yyyy-MM-dd");
				this.seaDetail.qEndLessonDate = window.util_date.getSunday().pattern("yyyy-MM-dd");
				this.dateDetail = window.util_date.getDays(window.util_date.getMonday(), 'yyyy-MM-dd');
				// this.getSchedule();
				this.kaishi = this.seaDetail.qBeginLessonDate;
				this.jieshu = this.seaDetail.qEndLessonDate;
				this.getclassStudentRecord();

			},
			// getSchedule: function() { //获取周课程列表信息
			//   this.seaDetail.qClassId=this.$route.params.id;
			//   instance.post('/lesson/findWeekLessonTimeTables2',this.seaDetail).then((res) => {
			//     this.tableList = res.data.data;
			//     var ishave=false;
			//     var myDate = new Date();
			//     var y=myDate.getFullYear();
			//     var m=myDate.getMonth()+1;
			//     var d=myDate.getDate();
			//     if(m<10){
			//       m='0'+m;
			//     };
			//     var now=y+'-'+m+'-'+d;
			//     for(var i=0;i<this.tableList.length;i++){
			//       this.tableList[i].day=this.dateDetail[this.tableList[i]['weekday']-0-1];
			//       if(now==this.tableList[i].day){
			//         ishave=true;
			//         this.lessonId=i;
			//       }
			//       switch(this.tableList[i]['weekday']){
			//         case '1':{this.tableList[i].xq='一'};break;
			//         case '2':{this.tableList[i].xq='二'};break;
			//         case '3':{this.tableList[i].xq='三'};break;
			//         case '4':{this.tableList[i].xq='四'};break;
			//         case '5':{this.tableList[i].xq='五'};break;
			//         case '6':{this.tableList[i].xq='六'};break;
			//         case '7':{this.tableList[i].xq='日'};break;
			//       };
			//     };
			//     if(ishave){
			//       this.seaRecord.qBeginLessonDate=now;
			//       this.seaRecord.qEndLessonDate=now;
			//       this.seaRecord.qBeginBeginTime=this.tableList[this.lessonId].beginTime;
			//       this.seaRecord.qBeginEndTime=this.tableList[this.lessonId].endTime;
			//       this.getclassRecord();
			//     }
			//   })
			// },
			getclassStudentRecord: function() { //获取上课记录
				this.studentRecordList = [];
				this.tableList = [];
				this.seaDetail.qClassId = this.$route.params.id;
				this.seaDetail.qVerify = "0";
				// qVerify
				instance.post('/lesson/findLessonRecords', this.seaDetail).then((res) => {
					this.recordList = res.data.data;
					this.tableList = res.data.data;
					var ishave = false;
					var myDate = new Date();
					var y = myDate.getFullYear();
					var m = myDate.getMonth() + 1;
					var d = myDate.getDate();
					if(m < 10) {
						m = '0' + m;
					};
					if(d < 10) {
						d = '0' + d;
					}
					var now = y + '-' + m + '-' + d;
					for(var i = 0; i < this.tableList.length; i++) {
						this.tableList[i].day = this.dateDetail[this.tableList[i]['weekday'] - 0 - 1];
						if(now == this.tableList[i].day) {
							ishave = true;
							this.lessonId = i;
						}
						switch(this.tableList[i]['weekday']) {
							case '1':
								{
									this.tableList[i].xq = '一'
								};
								break;
							case '2':
								{
									this.tableList[i].xq = '二'
								};
								break;
							case '3':
								{
									this.tableList[i].xq = '三'
								};
								break;
							case '4':
								{
									this.tableList[i].xq = '四'
								};
								break;
							case '5':
								{
									this.tableList[i].xq = '五'
								};
								break;
							case '6':
								{
									this.tableList[i].xq = '六'
								};
								break;
							case '7':
								{
									this.tableList[i].xq = '日'
								};
								break;
						};
					};
					// if(this.recordList.length!=0){
					//   this.buttonRead=true;
					// };
					if(ishave) {
						this.seaRecord.qBeginLessonDate = this.tableList[this.lessonId].day;
						this.seaRecord.qEndLessonDate = this.tableList[this.lessonId].day;
						this.seaRecord.qBeginBeginTime = this.tableList[this.lessonId].beginTime;
						this.seaRecord.qBeginEndTime = this.tableList[this.lessonId].endTime;
						this.classRoomName = this.tableList[this.lessonId].classRoomName;
						this.teacherName = this.tableList[this.lessonId].teacherName;
						// instance.post('/lesson/findStudentLessons',this.seaRecord).then((res) => {
						//   this.studentRecordList = res.data.data;
						//   // alert(this.studentRecordList .length);
						//   for (var i in this.studentRecordList) {
						//     for (var j in this.studentLessonList) {
						//       if (this.studentLessonList[j].id === this.studentRecordList[i].studentId) {
						//         this.studentRecordList[i].hour = this.studentLessonList[j].studentLessonCard.hour;
						//         if (this.studentRecordList[i].lessonStatus === '2' || this.studentRecordList[i].lessonStatus === '5') {
						//           this.studentRecordList[i].read = true;
						//         }
						//       }
						//     }
						//   }
						//
						//
						// })
						this.getStudentLessons();
						// this.buttonRead=true;
					}
					// this.getStudentLessons()
				})

			},
			getStudentLessons: function() { //获取学员课时信息
				var xueyuanjiku = {
					'qVerify': '0',
					'qLessonRecordId': this.recordList[this.lessonId].id
				}
				this.seaRecord.qClassId = this.$route.params.id;
				this.seaRecord.qVerify = "0";
				instance.post('/lesson/findStudentLessons', xueyuanjiku).then((res) => {
					this.studentRecordList = res.data.data;
					// alert(this.studentRecordList.length);
					if(this.studentRecordList.length != 0) {
						this.buttonRead = true;
					};
					// alert(this.studentRecordList .length);
					for(var i in this.studentRecordList) {
						for(var j in this.studentLessonList) {
							if(this.studentLessonList[j].id === this.studentRecordList[i].studentId) {
								this.studentRecordList[i].hour = this.studentLessonList[j].studentLessonCard.hour;
								if(this.studentRecordList[i].lessonStatus === '2' || this.studentRecordList[i].lessonStatus === '5') {
									this.studentRecordList[i].read = true;
								}
							}
						}
					}

				})
			},
			// getclassRecord: function() { //获取上课记录
			//   this.seaRecord.qClassId=this.$route.params.id;
			//   // this.seaRecord.qVerify=0;
			//   instance.post('/lesson/findLessonRecords',this.seaRecord).then((res) => {
			//     this.recordList = res.data.data;
			//     instance.post('/lesson/findStudentLessons',this.seaRecord).then((res) => {
			//       this.studentRecordList = res.data.data;
			//       for (var i in this.studentRecordList){
			//         for(var j in this.studentLessonList){
			//           if(this.studentLessonList[j].id==this.studentRecordList[i].studentId){
			//             this.studentRecordList[i].hour=this.studentLessonList[j].studentLessonCard.hour;
			//           }
			//         }
			//       }
			//     })
			//   })
			// },
			// getStudent:function(){//获取学员信息
			//   instance.get('/student/findClassStudents/'+this.$route.params.id).then((res) =>{
			//     this.studentList=res.data.data;
			//   })
			// },
			updata: function(id) { //选择课时
				// alert(id);
				if(id != 'no') {
					// alert(1);
					this.classRoomName = this.tableList[id - 0].classRoomName;
					this.teacherName = this.tableList[id - 0].teacherName;
					this.seaRecord.qBeginLessonDate = this.tableList[id - 0].day;
					this.seaRecord.qEndLessonDate = this.tableList[id - 0].day;
					this.seaRecord.qBeginBeginTime = this.tableList[this.lessonId].beginTime;
					this.seaRecord.qBeginEndTime = this.tableList[this.lessonId].endTime;
					this.allcost = '';
					this.alllessonStatus = '';
					// this.getclassRecord();
					this.getStudentLessons();
				} else {
					// alert(2);
					this.studentRecordList = [];
				}

			},
			otherWeek: function() {
				// alert(typeof(this.shijianduan));
				// var arr=this.shijianduan.split(',');
				// this.seaDetail.qBeginLessonDate = this.shijianduan[0];
				// this.seaDetail.qEndLessonDate = this.shijianduan[1];
				this.seaDetail.qBeginLessonDate = this.kaishi;
				this.seaDetail.qEndLessonDate = this.jieshu;
				this.getclassStudentRecord();
				// alert(this.shijianduan)
			},
			allchoose: function(index) { //表单修改事件
				if(index) {
					for(var i in this.cost) {
						this.lessonStatus[i] = this.alllessonStatus;
						this.cost[i] = this.allcost;
					}
				} else {
					this.allcost = '';
					this.alllessonStatus = '';
				}
			},
			save: function(sid,pstudentid, states, hour,descr) { //撤销消课
				var re = /^[0-9]+$/;
				//alert(re.test(hour));
				if(re.test(hour)) {

					this.$confirm("确定确认考勤？", "提示", {
							confirmButtonText: "确定",
							cancelButtonText: "取消",
							type: "info"
						}).then(() => {
							/*instance.get('/lesson/revocationStudentLesson/' + sid + '/' + states + '/' + hour).then((res) => {
								if(res.data.errcode == 0) {
									this.$message.success('考勤操作成功!');
								} else {
									this.$message.error('操作失败！' + res.data.errmsg);
								}
							})*/
							instance.post('/lesson/changeStudentLesson',{
								id:sid,
								lessonStatus:states,
								realHour:hour,
								descr:descr
							}).then((res) => {
								if(res.data.errcode == 0) {
									this.$message.success('考勤操作成功!');
								} else {
									this.$message.error('操作失败！' + res.data.errmsg);
								}
							})
						})
						.catch(() => {});
				} else {
					this.$alert('课时必须为正整数', '操作失败', {
						confirmButtonText: '确定',
						type: 'error'
					});
				}

			}

		},
		mounted: function() {
			this.getClassInfo();
			//this.getStudent();

		},
		created: function() {}
	};
</script>
