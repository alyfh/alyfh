<!-- <title>添加班级</title> -->
<style>
  .h5_02_info_per_exportRules_h3{border-bottom: solid 1px #e7e7e7;
    padding:10px 20px 10px 30px;color: #979494}
  /*.ue_time_block_btn{*/
    /*position: absolute;*/
    /*bottom: 5px;*/
    /*right: 10px;*/
    /*width: 20px;*/
    /*height: 20px;*/
    /*border-radius: 10px;*/
    /*background-color: #424242;*/
    /*color: #fff;*/
    /*text-align: center;*/
    /*line-height: 20px;*/
    /*cursor: pointer;*/
  /*}*/
  /*.per_sel_s{*/
    /*width: 90px;*/
    /*height: 25px;*/
    /*border:solid 1px #cdcdcd;*/
    /*border-radius: 5px;*/
    /*margin-right: 3px*/
  /*}*/
  /*.per_sel_b{*/
    /*width: 120px!important*/
  /*}*/
  /*.per_addperson_li_s{*/
    /*width: 20%!important*/
  /*}*/
  .el-input__inner {
    height: 25px;
  }
</style>
<template>
  <form id="" method="post" action="" class="ue_form_add">
    <h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
      <span>编辑班级(</span>
      <span class='h5_mark_xx2'>★</span>
      <span>为必填)</span>
    </h3>
    <ul class='h5_02_info_per_addlist'>
      <li>
        <span>★</span>
        <span>所属校区:</span>
        <span>
            <select name=""  class='per_addperson_txt' v-model="classDetail.schoolId" @change="getRoom(classDetail.schoolId)">
              <option disabled value="">请选择</option>
              <option v-for="sName in schoolNames" :value="sName.id">{{ sName.schoolName }}</option>
            </select>
    			</span>
      </li>
      <li>
        <span>★</span>
        <span>班级名:</span>
        <span><input type="text" class='per_addperson_txt' v-model="classDetail.className"></span>
      </li>
      <li>
        <span>★</span>
        <span>课程大类:</span>
        <span>
    				<select  class='per_addperson_txt' v-model="classDetail.courseId" @change="getClassSub(classDetail.courseId)">
                <option disabled value="">请选择</option>
                <option v-for="className in classNames" :value="className.id">{{className.courseName}}</option>
            </select>
    			</span>
      </li>
      <li>
        <span>★</span>
        <span>课程小类:</span>
        <span>
    				<select name="" id="" class='per_addperson_txt' v-model="classDetail.courseSubId">
              <option v-for="classNameSub in classNameSubs" :value="classNameSub.id">{{classNameSub.courseSubName}}</option>
            </select>

    			</span>
      </li>
      <li>
        <span>★</span>
        <span>授课类型:</span>
        <span>
    				<select name="" id="" class='per_addperson_txt' v-model="classDetail.oneByOne">
              <option value="1">一对多</option>
              <option value="0">一对一</option>
            </select>
    			</span>
      </li>
      <li>
        <span>★</span>
        <span>班型:</span>
        <span>
    				<select name="" id="" class='per_addperson_txt' v-model="classDetail.classTypeId">
              <option v-for="classType in classTypes" :value="classType.id">{{classType.classTypeName}}</option>
            </select>
    			</span>
      </li>

      <li>
        <span>★</span>
        <span>预招人数:</span>
        <span>
    				<input type="text" class='per_addperson_txt' v-model="classDetail.planStudent">
    			</span>
      </li>
      <li>
        <span>★</span>
        <span>开课日期:</span>
        <span>
              <el-date-picker type="date"  value-format="yyyy-MM-dd" placeholder="Pick a date" style="width:100%" v-model="classDetail.beginDate"></el-date-picker>
          </span>
      </li>
      <li>
        <span></span>
        <span>结课日期:</span>
        <span>
              <el-date-picker type="date"  value-format="yyyy-MM-dd" placeholder="Pick a date" style="width:100%" v-model="classDetail.endDate"></el-date-picker>
            </span>
      </li>
      <li>
        <span>★</span>
        <span>招生状态:</span>
        <span>
    				<select name="" id="" class='per_addperson_txt' v-model="classDetail.studentStatus">
                <option value="1">正在招生</option>
                <option value="2">停止招生</option>
            </select>
    			</span>
      </li>
      <li>
        <span>★</span>
        <span>计划课时:</span>
        <span>
    				<input type="text" class='per_addperson_txt' v-model="classDetail.planHour">
    			</span>
      </li>
      <li>
        <span>★</span>
        <span>每次课时:</span>
        <span>
    				<input type="text" class='per_addperson_txt' v-model="classDetail.lessonHour">
    			</span>
      </li>
      <li class="per_addperson_li_w per_addperson_li_h2">
        <span></span>
        <span>备注:</span>
        <span>
             <textarea name="" id="" cols="30" rows="4" placeholder="其他" class='per_addperson_texarea' v-model="classDetail.descr"></textarea>
          </span>
      </li>
    </ul>
    <h3 class='h5_02_info_per_exportRules_h3 p_clear_float' >
      <span>上课时间(</span>
      <span class='h5_mark_xx2'>★</span>
      <span>为必填)</span>
      <input type="button" value="新增上课时间" class="p_btn p_btn_siz_2 p_btn_col_k_gre p_btn_pos_r" id="ue_addclasstime" @click="addTimeBlock()">
    </h3>
    <timeblock :is="item.component" v-for="(item,index) in items" :key="item.id" :counts="index" @delblock="delTimeBlock"  @uplessons="lesson" :room="roomList" :teacher="teachers" :class-list="classDetail" :oldless="updateLessons[index]"></timeblock>
    <div id></div>
    <br class="p_zwf">
    <div class="p_btn_group p_clear_float">
      <input type="button" value="取消" class="p_btn p_btn_siz_2 p_btn_col_red p_btn_pos_r" @click="$router.go(-1)">
      <input type="button" value="保存" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r" @click="saveClass()">
    </div>
  </form>
</template>
<script>
  import instance from '../../../api/index.js';
  import { mapState } from 'vuex';
  import timeblock from "./addClassTime.vue";
  import * as util from '../../../assets/util.js';

  export default {
    data() {
      return {
        classDetail: {
          schoolId:""
        },
        schoolNames: [],//校区
        classNames: [],//课程大类
        classNameSubs: [],//课程小类
        classTypes: [],//班型
        // counselorNames: [], //咨询师
        // consultants: [], //课程顾问
        teachers:[],//授课教师
        roomList:[],//教室
        updateLessons:[],//已选课程
        createLessons:[],//新增课程
        deleteLessons:[],//删除课程
        items: [],
        pcon:0,
        oldschool:""

      };
    },
    methods: {
      saveClass:function(){//保存
        var data =  {
          createLessons:[]
        };
        //alert(this.createLessons.length);
        //console.log(this.createLessons);
        for(var i=0;i<this.createLessons.length;i++){
          // if(this.createLessons[i]==''){
          //   this.createLessons.splice(i,1);
          //   i--;
          // };
         // console.log(this.createLessons[i]);
          //alert(JSON.stringify(this.createLessons[i]) == "{}");
          //alert(this.createLessons[i]==null);
          //alert(this.createLessons[i]=='');
          if(JSON.stringify(this.createLessons[i]) == "{}"||this.createLessons[i]==null||this.createLessons[i]==''){
            //this.createLessons.splice(i,1);
            console.log(this.createLessons[i])
            //i--
          }else{
            data.createLessons.push(this.createLessons[i]);
            //console.log(data.createLessons);
          }
        };
        for(var i=0;i<this.updateLessons.length;i++){
          this.updateLessons[i]['beginDate']=this.classDetail.beginDate;
          this.updateLessons[i]['className']=this.classDetail.className;
          this.updateLessons[i]['schoolId']=this.classDetail.schoolId;
          this.updateLessons[i]['courseId']=this.classDetail.courseId;
          this.updateLessons[i]['courseSubId']=this.classDetail.courseSubId;
          this.updateLessons[i]['beginDate']=this.classDetail.beginDate;
          this.updateLessons[i]['endDate']=this.classDetail.endDate;
          this.updateLessons[i]['lessonHour']=this.classDetail.lessonHour;
        };
        data.clazz=this.classDetail;
        data.updateLessons=this.updateLessons;
        // data.createLessons=this.createLessons;
        data.deleteLessons=this.deleteLessons;
        instance.post('/class/changeClassAndLessons',data).then((res) => {
          if(res.data.errcode == '0') {
            // this.$message.info('保存成功');
            this.$confirm("保存成功！是否跳回列表页面?", "提示", {
              confirmButtonText: "确定",
              cancelButtonText: "取消",
              type: "success"
            }).then(() => {
                this.$router.push('/jiaowuguanli/banjiguanli/banjiliebiao');
              })
              .catch(() => {});

          } else {
            this.$alert(res.data.errmsg, '操作失败', {
              confirmButtonText: '确定',
              type: 'error'
            });
            //this.getClassInfo()
          }
        })
      },
      getClassInfo:function(){//获取班级信息
        instance.get('/class/findClass/'+this.$route.params.id).then((res) => {
          this.updateLessons=res.data.data.lessons;
          //console.log(this.updateLessons);
          delete res.data.data.lessons;
          this.classDetail = res.data.data;
          //console.log(this.updateLessons);
          this.oldschool=res.data.data.schoolId;
          this.getUserSchool();
          // this.getSchool();
          this.getClass();
          this.getClassSub();
          this.getClassType();
          //this.getTeacher(this.oldschool);
          for(var i=0;i<this.updateLessons.length;i++){
            this.items.push({
              component: 'timeblock',
              id:this.pcon
            });
            this.pcon++;
          }
        })
      },
      getUserSchool: function() { //获取当前用户校区字典
        //获取当前登录人
        this.loginInfo = util.session("loginInfo", void(0));
        instance.get('/school/findUserSchools/' + this.loginInfo.login.userId, {}).then((res) => {
          if(res.data.data.length==0){
            this.schoolNames.push({
              'id':this.classDetail.schoolId,
              'schoolName':this.classDetail.schoolName
            })
          }else{
            this.schoolNames = res.data.data;
          }

          this.getRoom(this.classDetail.schoolId);
        })
      },
      getSchool: function() { //获取校区数据
        instance.post('/school/findSimpleSchools', {}).then((res) => {
          this.schoolNames = res.data.data;
        })
      },
      getClass: function() { //获取课程大类数据
        instance.post('/course/findCourses', {
          'qSchoolId':this.classDetail.schoolId
        }).then((res) => {
          this.classNames = res.data.data;
        })
      },
      getClassSub: function(id) { //获取课程小类数据
        instance.post('/course/findSimpleCourseSubs', {
          qCourseId: id
        }).then((res) => {
          this.classNameSubs = res.data.data;
        })
      },
      getClassType: function() { //获取班型
        instance.post('/classtype/findSimpleClassTypes', {}).then((res) => {
          this.classTypes = res.data.data;
        })
      },
      getTeacher: function(schoolId) { //获取授课教师列表
        instance.post('/teacher/findSimpleTeachers', {
          qSchoolId: schoolId,
          qWorking:0,
          qCourseSubId:this.classDetail.courseSubId
        }).then((res) => {
          this.teachers = res.data.data;
        })
      },
      getRoom:function(id) { //获取校区教室数据
        if(this.oldschool!=this.classDetail.schoolId){
          this.$confirm("确定修改校区？修改校区后所选上课时间将被清空！是否继续操作", "提示", {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "info"
          }).then(() => {
            instance.post('/classroom/findSimpleClassRooms',{
              "qSchoolId": id,
            }).then((res) => {
              this.roomList = res.data.data;
              //this.getTeacher(id);
            });
            for(var i=0;i<this.updateLessons.length;i++){
              this.deleteLessons.push({'id':this.updateLessons[i]['id']});
            }
            this.items.splice(0,this.items.length);
            this.updateLessons.splice(0,this.updateLessons.length);
            this.createLessons.splice(0,this.createLessons.length);
          })
            .catch(() => {
              this.classDetail.schoolId=this.oldschool;
            });
        }else{
          instance.post('/classroom/findSimpleClassRooms',{
            "qSchoolId": id,
          }).then((res) => {
            this.roomList = res.data.data;
            //this.getTeacher(id);
          });
        }


        // this.getTeacher(id);
      },
      addTimeBlock:function(){
        this.createLessons.push({});
        this.items.push({
          component: 'timeblock',
          id:this.pcon
        });
        this.pcon++;
      },
      delTimeBlock:function(id,que){
        if(que=='update'){
          this.$confirm("确定删除该课程？", "提示", {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "info"
          }).then(() => {
            this.deleteLessons.push({'id':this.updateLessons[id]['id']});
            this.updateLessons.splice(id,1);
            this.items.splice(id,1);
          })
            .catch(() => {});


        }else{
          // alert(id);
          //alert(this.createLessons.length);
          this.items.splice(id,1,'');
          // alert((this.items.length-id)+'id');
          this.createLessons.splice((id-(this.items.length-this.createLessons.length)),1,'');
          // this.createLessons.splice(id,1,'');
          // alert(this.createLessons.length+';'+this.updateLessons.length);

        }

      },
      lesson:function(data,id,que){
        // alert(que);
        if(que=='update'){
          this.updateLessons[id]=data;
          // this.updateLessons[id]['beginDate']=this.classDetail.beginDate;
          // this.updateLessons[id]['className']=this.classDetail.className;
          // this.updateLessons[id]['schoolId']=this.classDetail.schoolId;
          // this.updateLessons[id]['courseId']=this.classDetail.courseId;
          // this.updateLessons[id]['courseSubId']=this.classDetail.courseSubId;
          // this.updateLessons[id]['beginDate']=this.classDetail.beginDate;
          // this.updateLessons[id]['endDate']=this.classDetail.endDate;
          // this.updateLessons[id]['lessonHour']=this.classDetail.lessonHour;
        }else{
          // this.createLessons[id]=data;
          // this.createLessons[id]['beginDate']=this.classDetail.beginDate;
          // this.createLessons[id]['className']=this.classDetail.className;
          // this.createLessons[id]['schoolId']=this.classDetail.schoolId;
          // this.createLessons[id]['courseId']=this.classDetail.courseId;
          // this.createLessons[id]['courseSubId']=this.classDetail.courseSubId;
          // this.createLessons[id]['beginDate']=this.classDetail.beginDate;
          // this.createLessons[id]['endDate']=this.classDetail.endDate;
          // this.createLessons[id]['lessonHour']=this.classDetail.lessonHour;
          this.createLessons[(id-(this.items.length-this.createLessons.length))]=data;
          //alert((id-(this.items.length-this.createLessons.length)));
          this.createLessons[(id-(this.items.length-this.createLessons.length))]['beginDate']=this.classDetail.beginDate;
          this.createLessons[(id-(this.items.length-this.createLessons.length))]['className']=this.classDetail.className;
          this.createLessons[(id-(this.items.length-this.createLessons.length))]['schoolId']=this.classDetail.schoolId;
          this.createLessons[(id-(this.items.length-this.createLessons.length))]['courseId']=this.classDetail.courseId;
          this.createLessons[(id-(this.items.length-this.createLessons.length))]['courseSubId']=this.classDetail.courseSubId;
          this.createLessons[(id-(this.items.length-this.createLessons.length))]['beginDate']=this.classDetail.beginDate;
          this.createLessons[(id-(this.items.length-this.createLessons.length))]['endDate']=this.classDetail.endDate;
          this.createLessons[(id-(this.items.length-this.createLessons.length))]['lessonHour']=this.classDetail.lessonHour;
          //console.log(this.createLessons);
          // this.createLessons[(this.items.length-id)]=data;
          // alert(this.items.length-id);
          // this.createLessons[(this.items.length-id)]['beginDate']=this.classDetail.beginDate;
          // this.createLessons[(this.items.length-id)]['className']=this.classDetail.className;
          // this.createLessons[(this.items.length-id)]['schoolId']=this.classDetail.schoolId;
          // this.createLessons[(this.items.length-id)]['courseId']=this.classDetail.courseId;
          // this.createLessons[(this.items.length-id)]['courseSubId']=this.classDetail.courseSubId;
          // this.createLessons[(this.items.length-id)]['beginDate']=this.classDetail.beginDate;
          // this.createLessons[(this.items.length-id)]['endDate']=this.classDetail.endDate;
          // this.createLessons[(this.items.length-id)]['lessonHour']=this.classDetail.lessonHour;
          // console.log(this.createLessons);
        }

      },
    },
    components: {
      timeblock
    },
    mounted: function() {
      this.getClassInfo();



    }
  };
</script>
