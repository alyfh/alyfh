<style>
  .ue_time_block{
    border-bottom: solid 1px #e7e7e7;
    margin-bottom: 15px;
    position: relative;
  }
  .el-input__inner{
    height: 25px;
  }
</style>
<template>
  <div class="ue_time_block">
    <form action="">
    <ul class='h5_02_info_per_addlist'>
      <li class="per_addperson_li_w">
        <span>★</span>
        <span>上课时段:</span>
        <span>
            <select name="" id="" class="per_addperson_txt_m" v-model="lessonList.weekday" @change="updata">
                  <option value="1">周一</option>
                  <option value="2">周二</option>
                  <option value="3">周三</option>
                  <option value="4">周四</option>
                  <option value="5">周五</option>
                  <option value="6">周六</option>
                  <option value="7">周日</option>
            </select>&nbsp;
            <el-time-picker style="width:150px" value-format="HH:mm:00" v-model="lessonList.beginTime" @change="updata(true)"></el-time-picker> 到
            <el-time-picker style="width:150px" value-format="HH:mm:00" v-model="lessonList.endTime" @change="updata(true)"></el-time-picker>
         </span>
      </li>
      <li class="per_addperson_li_s">
        <span>★</span>
        <span>教室:</span>
        <span>
          <select name="" id="" class='per_addperson_txt' v-model="lessonList.classRoomId" @change="updata()">
              <option v-for="rooms in room" :value="rooms.id">{{rooms.classRoomName}}</option>
          </select>
        </span>
      </li>
      <li class="per_addperson_li_s">
        <span>★</span>
        <span>授课教师:</span>
        <span>
          <select name="" id="" class='per_addperson_txt' v-model="lessonList.teacherId" @change="updata()">
              <option v-for="tea in teachers" :value="tea.id">{{tea.realName}}</option>
          </select>
        </span>
      </li>

      <!--<div class="ue_time_block_btn" @click="delTime(counts)">╳</div>-->
      <!--<li class="per_addperson_li_s">-->
      <div class="ue_time_block_btn" @click="delTime(counts)">
        <input type="button" value="删除" class="p_btn p_btn_siz_2 p_btn_col_k_oran p_btn_pos_r"  @click="delTime(counts)">

      </div>
      <!--</li>-->
      <!--<li class="per_addperson_li_s">-->
        <!--<span>★</span>-->
        <!--<span>学管师:</span>-->
        <!--<span>-->
          <!--<select name="" id="" class='per_addperson_txt' @change="updata"></select>-->
          <!--</span>-->
      <!--</li>-->
    </ul>
    </form>

  </div>
</template>
<script>
  import instance from '../../../api/index.js';
  import { mapState } from 'vuex';
  import timeblock from "./addClassTime.vue";
  import * as util from '../../../assets/util.js';
  export default {
    props: ['counts','room','teacher','classList','oldless'],
    data() {
      return {
        lessonList:{},
        que:'',
        teacherDetail:[],
        teachers:[]
      };
    },
    methods: {
      delTime:function(key){
        if(this.que=='add'){
          this.$emit('delblock',key);
        } else if(this.que=='update'){
          this.$emit('delblock',key,this.que);
        }
      },
      updata:function(teacheris){
            this.$emit('uplessons',this.lessonList,this.counts,this.que);
            if(teacheris){
              this.getTeacher();
            }
      },
      getTeacher: function() { //获取授课教师列表
        instance.post('/teacher/findSimpleTeachers', {
          qSchoolId: this.classList.schoolId,
          qWorking:0,
          qCourseSubId:this.classList.courseSubId,
          qWeekday:this.lessonList.weekday,
          qBeginTime:this.lessonList.beginTime,
          qEndTime:this.lessonList.endTime
        }).then((res) => {
          this.teachers = res.data.data;
        })
      },


    },
    mounted: function() {
        if(this.oldless != null){
          this.que='update';
          this.lessonList=this.oldless;
          this.getTeacher();
        }else{
          this.que='add';
          this.lessonList={};
        }
    }
  };
</script>
