<!--<title>全部咨询</title>-->
<style scoped>
	.p_table_la tr>td:nth-child(14):hover {
		cursor: pointer;
		color: #0d8ddb;
	}
</style>
<template>
	<section class="p_chi_con">
	<div class="p_con_sea" align='center'>
			
						<font size="6" style="font-weight:bold">会员卡管理</font>
				
		</div>
		<div class="p_con_tab">
			<div class="p_btn_group p_clear_float">
				<input v-if="$_has(actionsList,'addsource')" type="button" value="新增" @click="addSourceSub" class="p_btn p_btn_siz_2 p_btn_col_gre p_btn_pos_r">
			</div>
			<div class="p_table_la_over">
				<table class="p_table_la" cellspacing="0" cellpadding="0">
					<tr>
						<td>会员卡名称</td>
						<td>有效期(天)</td>
						<td>课时数</td>
						<td>赠送课时数</td>
						<td>总课时数</td>
						<td>原价(元)</td>
						<td>现价(元)</td>
						<td v-if="$_has(actionsList,'delsource')||$_has(actionsList,'editsource')||$_has(actionsList,'readsource')">
							操作
						</td>
					</tr>
					<tr v-for="adivce in adviceList">
						
						<td>{{adivce.cardName}}</td>
						<td>{{adivce.validTime}}</td>
						<td>{{adivce.hour}}</td>
						<td>{{adivce.giveHour}}</td>
						<td>{{adivce.sumHour}}</td>
						<td>{{adivce.sourceMoney}}</td>
						<td>{{adivce.currentMoney}}</td>
			<td v-if="$_has(actionsList,'delsource')||$_has(actionsList,'editsource')||$_has(actionsList,'readsource')">
				<input v-if="$_has(actionsList,'delsource')" type="button" value="删除" @click="deleteSourceSub(adivce.id)" class="p_btn p_btn_siz_2 p_btn_col_k_red p_btn_pos_r">
				<input v-if="$_has(actionsList,'editsource')" type="button" value="编辑" @click="editEntry(adivce.id)" class="p_btn p_btn_siz_2 p_btn_col_k_oran p_btn_pos_r">
				<input v-if="$_has(actionsList,'readsource')" type="button" value="详情" @click="loadEntry(adivce.id)" class="p_btn p_btn_siz_2 p_btn_col_k_gre p_btn_pos_r">
			</td>

					</tr>
				</table>
				<!--<router-view></router-view>-->
			</div>
		</div>
		<div class='h5_page_container' id="con">
			<page :record-count="recordCount" v-on:change-page="changePage">
			</page>
		</div>

        <!-- 弹窗 -->
		<modal-dialog :show="layerShow" :action-type="actionType" :sourcesubdetail="sourcesubdetail"  v-on:save-sourceSub="saveSourceSub">
		</modal-dialog>
        <!-- 查看弹窗 -->
		<modal-dialog2 :show="layerShow" :action-type="actionType" :sourcesubdetail="sourcesubdetail">
		</modal-dialog2>

	</section>
</template>
<script>
	import instance from '../../../api/index.js';
	import { mapState } from 'vuex';

	export default {
		computed: {
			// Getting Vuex State from store/index
			...mapState({
				layerShow: state => state.layerShow,
				pageSize: state => state.pageSize,
				pageLarge: state => state.pageLarge,
				adviceStatus: state => state.adviceStatus,
				adviceLevel: state => state.adviceLevel,
			})
		},
		data() {
			return {
				actionsList:[],//获取当前用户对当前模块授权操作
				show: false,
				actionType: "",
				findAdvices: { //查询条件

				},
				adviceList: [], //咨询列表
				recordCount: 0,
				pageNum: 1, //当前页码
				sourcesubdetail:{}

			};
		},
		components: {
			modalDialog: () =>
				import("./addUpdateComponent.vue"),
			modalDialog2: () =>
				import("./readComponent.vue"),
			page: () =>
				import("../../common/page.vue"),

		},
		methods: {
			setLayerShow: function() {
				this.$store.commit({
					type: 'setLayerShow',
					layerShow: false
				})
			},
			getAdviceCount: function(lis) { //获取数量
				instance.post('/lessoncard/findLessonCardsCount', {}).then((res) => {
					this.recordCount = res.data.data.count;
				});
			},
			getAdviceList: function(lis) { //获取列表
				lis.beginRow = (this.pageNum - 1) * this.pageSize;
				lis.pageSize = this.pageSize;
				instance.post('/lessoncard/findLessonCards',lis).then((res) => {
					this.adviceList = res.data.data;
				})

			},
			changePage: function(pageNum) {
				//  console.info("change-page:" + pageNum);
				this.pageNum = pageNum;
				this.getAdviceList(this.findAdvices);
			},
			addSourceSub:function(){
               this.$store.commit({
					type: 'setLayerShow',
					layerShow:true
				})

                this.sourcesubdetail={};
				this.actionType = "add";
			},
			deleteSourceSub: function(key) {

				this.$confirm("您确定删除吗?", "提示", {
						confirmButtonText: "确定",
						cancelButtonText: "取消",
						type: "info"
					})
					.then(() => {
						instance.get('/lessoncard/removeLessonCard/' + key).then((res) => {
							this.$message.info('数据删除成功！');
							this.getAdviceList(this.findAdvices);
			                this.getAdviceCount(this.findAdvices); //数量
						})
					})
					.catch(() => {});

				//this.actionType="read";
			},
			saveSourceSub: function(item) {
				item.id?this.updateSourceSub(item):this.createSourceSub(item)
			},
			createSourceSub: function(item) {
				instance.post('/lessoncard/createLessonCard', item).then((res) => {
					if(res.data.errcode == '0') {
						this.$message.info('信息创建成功！');
			            this.getAdviceList(this.findAdvices);
			            this.getAdviceCount(this.findAdvices); //数量
						this.setLayerShow(); //关闭窗口
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}

				})

			},
			editEntry: function(key) {

				this.$store.commit({
					type: 'setLayerShow',
					layerShow: true
				})
				instance.get('/lessoncard/findLessonCard/' + key).then((res) => {
					this.sourcesubdetail = res.data.data;
				})
				this.actionType = "update";
			},
			updateSourceSub:function(item){
				instance.post('/lessoncard/changeLessonCard', item).then((res) => {
					if(res.data.errcode == '0') {
			            this.getAdviceList(this.findAdvices);
			            this.getAdviceCount(this.findAdvices); //数量
						this.setLayerShow(); //关闭窗口
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}
					
				})
			},
			loadEntry:function(key){
				this.$store.commit({
					type: 'setLayerShow',
					layerShow: true
				})
				instance.get('/lessoncard/findLessonCard/' + key).then((res) => {
					this.sourcesubdetail = res.data.data;
				})
				this.actionType = "read";
			},
			getModuleActions:function(){
				 let  routeCodes=this.$route.path.split("/");
				  let  routeCode=routeCodes[routeCodes.length-1]; 
					instance.get('/navi/findUserActions2/'+routeCode).then((res) => {
						if(res.data.errcode == '0') {
							this.actionsList=res.data.data;					
						} else {
							//this.$message.error('操作失败！' + res.data.info);
						}
						console.info("json:" + res.data);

					})
			}
		},
		mounted: function() {
			this.getAdviceList(this.findAdvices);
			this.getAdviceCount(this.findAdvices); //数量
			this.getModuleActions();

		}
	};
</script>