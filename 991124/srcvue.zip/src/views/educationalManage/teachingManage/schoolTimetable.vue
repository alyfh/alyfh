<!-- <title>校区课表</title> -->
<style>
	.p_monthTable {
		margin: auto;
		margin-bottom: 150px
	}

	.p_monthTable tr>td {
		padding: 5px;
		width: 150px;
		border: solid 1px #f0f0f0;
		cursor: pointer;
	}

	.timeTable_td:hover>.timeTable_hidList {
		display: block;
	}
</style>
<template>
	<div class="p_con_tab">
		<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
      <span>排课表</span>
    </h3>
		<div class="p_con_sea">
			<ul class="p_con_sea_list p_clear_float">
				<li>
					<span>所属校区:</span>
					<span>
            <select name=""  class='per_addperson_txt' v-model="seaDetail.qSchoolId" @change="query()">
              <!--<option value="">--请选择--</option>-->
              <option v-for="sName in schoolNames" :value="sName.id">{{ sName.schoolName }}</option>
            </select>
    			</span>
				</li>
			</ul>
			<!--<div class="p_btn_group p_clear_float">-->
			<!--<input type="button" value="查询" class="p_btn p_btn_siz_2 p_btn_col_k_gre p_btn_pos_r" @click="query">-->
			<!--</div>-->
		</div>
		<div class="p_btn_group p_clear_float" style="width:calc(100% - 60px)">
			<input type="button" value="下周" class="p_btn p_btn_siz_2 p_btn_col_gre p_btn_pos_r" @click="nextWeek()">
			<input type="button" value="本周" class="p_btn p_btn_siz_2 p_btn_col_red p_btn_pos_r" @click="nowWeek()">
			<input type="button" value="上周" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r" @click="previousWeek()">
		</div>
		<div>
			<table class="p_monthTable" cellspacing="0" cellpadding="0">
				<tr>
					<td>周一</td>
					<td>周二</td>
					<td>周三</td>
					<td>周四</td>
					<td>周五</td>
					<td>周六</td>
					<td>周日</td>
				</tr>
				<tr>
					<td v-for="date in dateDetail">{{date}}</td>
				</tr>

				<tr v-for="num in maxNumOfWeek">
					<template v-for=" listen in listenList">
						<td v-if="listen.children.length>=num" :class="listen.children[num-1].courseColor">
							<!--{{listen.children[num-1].courseColor}}-->
							<ul class="timeTable_showList">
								<li><span>时间:</span><span>{{listen.children[num-1].beginTime}}-{{listen.children[num-1].endTime}}</span></li>
								<li><span>课程小类/span><span>{{listen.children[num-1].courseSubName}}</span></li>
								<li><span>教室:</span><span>{{listen.children[num-1].classRoomName}}</span></li>
								<li><span>教师:</span><span>{{listen.children[num-1].teacherName}}</span></li>
							</ul>

							<ul class="timeTable_hidList">
								<li><span>校区:</span><span>{{listen.children[num-1].schoolName}}</span></li>
								<li><span>类型:</span><span>{{classTypeDict[listen.children[num-1].oneByOne]}}</span></li>
								<li><span>课程大类:</span><span>{{listen.children[num-1].courseName}}</span></li>
                <li><span>课程小类:</span><span>{{listen.children[num-1].courseSubName}}</span></li>
								<li><span>教室:</span><span>{{listen.children[num-1].classRoomName}}</span></li>
								<li><span>教师:</span><span>{{listen.children[num-1].teacherName}}</span></li>
								<li><span>时间:</span><span>{{listen.children[num-1].beginTime}}-{{listen.children[num-1].endTime}}</span></li>
								<li><span>课时:</span><span>{{listen.children[num-1].lessonHour}}</span></li>
								<li><span>学员人数:</span><span>{{listen.children[num-1].studentsNum}}</span></li>
								<li><span>学员姓名:</span><span>{{listen.children[num-1].studentNames}}</span></li>
							</ul>
						</td>
						<td v-else class="timeTable_td ">

						</td>
					</template>
				</tr>

			</table>
		</div>
	</div>
</template>
<script>
	import instance from '../../../api/index.js';
	import { mapState } from 'vuex';
	import * as util from '../../../assets/util.js';
	export default {
		data() {
			return {
				seaDetail: {
					qSchoolId: "123",
					qBeginDate: "2018-01-08",
					qEndDate: "2018-01-14"
				},
				dataDetail: [],
				dateDetail: [],
				schoolNames: [],
				loginInfo: {}, //当前登录信息
				listenList: [], //校区排课列表
				maxNumOfWeek: 0,
				courses: [], //课程大类
				coursesColor: [ //课程大类颜色定义
					"timeTable_td timeTable_col_gre",
					"timeTable_td timeTable_col_yel",
					"timeTable_td timeTable_col_blu",
					"timeTable_td timeTable_col_ora",
					"timeTable_td timeTable_col_pur",
				],
				weekDay: {
					"1": "星期一",
					"2": "星期二",
					"3": "星期三",
					"4": "星期四",
					"5": "星期五",
					"6": "星期六",
					"7": "星期日"
				}

			}
		},
		computed: {
			// Getting Vuex State from store/index
			...mapState({
				classTypeDict: state => state.classTypeDict,
			})

		},
		methods: {
			getSchedule: function() { //获取周课程列表信息
				let vm = this;
				instance.post('/lesson/findWeekLessonTimeTables3', this.seaDetail).then((res) => {
					this.dataDetail = res.data.data;

					if(res.data.errcode == "0") {
						vm.listenList = [{
							"weekday": "1",
							"children": []
						}, {
							"weekday": "2",
							"children": []
						}, {
							"weekday": "3",
							"children": []
						}, {
							"weekday": "4",
							"children": []
						}, {
							"weekday": "5",
							"children": []
						}, {
							"weekday": "6",
							"children": []
						}, {
							"weekday": "7",
							"children": []
						}];
						res.data.data.forEach(function(parentNode, i) {

							//处理学员数量 和 学员姓名
							let studentsNum = parentNode.students.length;
							let studentNames = "";
							if(studentsNum != 0) {
								let arr = new Array(studentsNum)
								for(var j in parentNode.students) {
									arr[j] = parentNode.students[j].studentName;
								}
								studentNames = arr.join("，");
							}
							parentNode.studentNames = studentNames;
							parentNode.studentsNum = studentsNum;

							//处理 课程大类分配颜色
							vm.courses.forEach(function(course, i) {
								if(parentNode.courseId == course.id) {
//									parentNode.courseColor = "timeTable_td timeTable_col_blu";
									parentNode.courseColor = course.color;
									//node.children.push(parentNode);
									//flag = true;
								}
							});

							let flag = false; //默认不存在
							vm.listenList.forEach(function(node, i) {
								if(parentNode.weekday == node.weekday) {
									node.children.push(parentNode);
									flag = true;
								}
							});
							if(!flag) {
								let item = {};
								//item.listenDate = parentNode.listenDate;
								item.weekday = parentNode.weekday;
								item.children = [parentNode];
								vm.listenList.push(item);

							}
							for(var i in vm.listenList) {
								if(vm.listenList[i].children.length > vm.maxNumOfWeek)
									vm.maxNumOfWeek = vm.listenList[i].children.length;
							}
							//							console.info("vm.listenList=" + JSON.stringify(vm.listenList));

						})

					}
				})
			},
			getUserSchool: function() { //获取当前用户校区字典
				//获取当前登录人
				this.loginInfo = util.session("loginInfo", void(0));
				instance.post('/school/findUserSchools/' + this.loginInfo.login.userId, {}).then((res) => {
					this.schoolNames = res.data.data;
					this.seaDetail.qSchoolId = res.data.data[0].id;
					this.nowWeek();
				})
			},
			//下周
			nextWeek: function() {
				this.maxNumOfWeek = 0;
				this.seaDetail.qBeginDate = window.util_date.getNextMonday(window.util_date.getMonday()).pattern("yyyy-MM-dd");
				this.seaDetail.qEndDate = window.util_date.getNextSunday(window.util_date.getMonday()).pattern("yyyy-MM-dd");
				this.dateDetail = window.util_date.getDays(window.util_date.getNextMonday(window.util_date.getMonday()), 'yyyy-MM-dd');
				this.getSchedule();

			},
			//上周
			previousWeek: function() {
				this.maxNumOfWeek = 0;
				this.seaDetail.qBeginDate = window.util_date.getPreviousMonday(window.util_date.getMonday()).pattern("yyyy-MM-dd");
				this.seaDetail.qEndDate = window.util_date.getPreviousSunday(window.util_date.getMonday()).pattern("yyyy-MM-dd");
				this.dateDetail = window.util_date.getDays(window.util_date.getPreviousMonday(window.util_date.getMonday()), 'yyyy-MM-dd');
				this.getSchedule();

			},
			//本周
			nowWeek: function() {
				this.maxNumOfWeek = 0;
				window.util_date.newToday(new Date());
				this.seaDetail.qBeginDate = window.util_date.getMonday().pattern("yyyy-MM-dd");
				this.seaDetail.qEndDate = window.util_date.getSunday().pattern("yyyy-MM-dd");
				this.dateDetail = window.util_date.getDays(window.util_date.getMonday(), 'yyyy-MM-dd');

				this.getSchedule();

			},
			//校区值变更 查询
			query: function() {
				this.maxNumOfWeek = 0;
				this.getSchedule();

			},
			//获取课程大类
			getCourses: function() {
				instance.post('/course/findSimpleCourses', {}).then((res) => {
					this.courses = res.data.data;
					let colorMaxNum=this.coursesColor.length;
					let n=0;
					let coursesColor1=this.coursesColor;
					this.courses.forEach(function(course, i) {
						if(n>=colorMaxNum){
							n=0;
						}
						course.color=coursesColor1[n];
							n++;

					});
				})
			},
			getLessonStratTimeStatus: function(time, wDay) {
				let vm = this;
				let flag = false;
				vm.dataDetail.forEach(function(e, i) {
					let beginTime = e.beginTime;
					let weekday = e.weekday;
					if(beginTime.split(":")[0] == time && weekday == wDay) {
						flag = true;

					}
				})

				return flag;
			},
			getRowspan: function(time, wDay) {
				let vm = this;
				let rowspan = 0;
				vm.dataDetail.forEach(function(e, i) {
					let beginTime = e.beginTime;
					let endTime = e.endTime;
					let weekday = e.weekday;
					if(beginTime.split(":")[0] == time && weekday == wDay) {
						rowspan = parseInt(endTime.split(":")[0]) - parseInt(beginTime.split(":")[0]);
						if(parseInt(endTime.split(":")[1]) != 0 && parseInt(beginTime.split(":")[1]) != 0)
							rowspan += 1;

					}
				})

				return rowspan;
			},
			getLessonInfo: function(time, wDay) {
				let vm = this;
				let str = "";
				vm.dataDetail.forEach(function(e, i) {
					let beginTime = e.beginTime;
					let weekday = e.weekday;
					if(beginTime.split(":")[0] == time && weekday == wDay) {
						str += "课程大类：" + e.courseName;
						str += "<br>课程小类：" + e.courseSubName;
						str += "<br>类型：" + vm.classTypeDict[e.oneByOne];
						str += "<br>校区：" + e.schoolName;
						str += "<br>教室：" + e.classRoomName;
						str += "<br>教师：" + e.teacherName;
						str += "<br>时间：" + e.beginTime + "-" + e.endTime;

					}
				})
				return str;
			},
			getNoneLesson: function(time, wDay) {
				let vm = this;
				let flag = true; //默认不在

				vm.dataDetail.forEach(function(e, i) {
					let beginTime = e.beginTime;
					let endTime = e.endTime;
					let weekday = e.weekday;
					let rowspan = 0;
					if(weekday == wDay) {
						let b_hour = parseInt(beginTime.split(":")[0]);
						let e_hour = parseInt(endTime.split(":")[0]);
						rowspan = e_hour - b_hour;
						if(parseInt(endTime.split(":")[1]) != 0 && parseInt(beginTime.split(":")[1]) != 0)
							rowspan += 1;
						if(parseInt(b_hour) <= parseInt(time) && parseInt(time) < parseInt(b_hour + rowspan)) {
							flag = false;

						}

					}
				})
				return flag;
			},
		},
		mounted: function() {
			// this.seaDetail.qStudentId = this.$route.params.id;
			this.getUserSchool();
			//			this.nowWeek();
			this.getCourses();
		}
	}
</script>
