<!--<title>校区管理</title>-->
<style scoped>
	.p_table_la tr>td:nth-child(14):hover {
		cursor: pointer;
		color: #0d8ddb;
	}
</style>
<style>
	.p_btn_pos_r {
		float: right;
		margin-right: 10px;
	}
</style>
<template>
	<section class="p_chi_con">
		<div class="p_con_sea">
			<ul class="p_con_sea_list p_clear_float">
				<li>
					<span>校区:</span>
					<span>
						<select name="" id="" class="p_con_form_select" v-model="findSchools.qSchoolId">
			             	<option value="">--请选择--</option>
			              	<option v-for="school in schoolsDict" :value="school.id">{{school.schoolName}}</option>
			           </select>
					</span>
				</li>
				<li>
					<span>联系电话:</span>
					<span>
						<input type="text" class="p_con_form_input" v-model="findSchools.qTelephone">
					</span>
				</li>
				<li>
					<span>负责人:</span>
					<span>
						<input type="text" class="p_con_form_input" v-model="findSchools.qManagerName">
					</span>
				</li>
			</ul>
			<div class="p_btn_group p_clear_float">
				<input type="button" value="查询" @click="query" class="p_btn p_btn_siz_2 p_btn_col_gre p_btn_pos_r">
			</div>
		</div>

		<div class="p_con_tab">
			<div class="p_btn_group p_clear_float">
				<input type="button" value="新增" class="p_btn p_btn_siz_2 p_btn_col_gre p_btn_pos_r" @click="addSchool">
			</div>
			<div class="p_table_la_over">
				<table class="p_table_la" cellspacing="0" cellpadding="0">
					<tr>
						<td>校区名</td>
						<td>联系电话</td>
						<td>详细地址</td>
						<td>开设课程</td>
						<td>作息时间</td>
						<td>负责人</td>
						<td v-if="$_has(actionsList,'delete')||$_has(actionsList,'update')||$_has(actionsList,'read')">操作</td>
					</tr>
					<tr v-for="school in schoolsList">
						<td>{{school.schoolName}}</td>
						<td>{{school.phone}}</td>
						<td>{{school.address}}</td>
						<td>
							<template v-for="course in school.courseSubs" v-cloak>
								<strong>{{course.course.courseName}}:</strong>
									{{course.courseSubName}}<br />
							</template>
						</td>
						<td>
							<template v-for="schooljt in school.schoolJobTimes" v-cloak>
								<span>
									<template v-if="schooljt.weekday === '1'">
										<strong>周一:</strong>{{schooljt.beginTime}}-{{schooljt.endTime}}
									</template>
									<template v-if="schooljt.weekday === '2'">
										<strong>周二:</strong>{{schooljt.beginTime}}-{{schooljt.endTime}}
									</template>
									<template v-if="schooljt.weekday === '3'">
										<strong>周三:</strong>{{schooljt.beginTime}}-{{schooljt.endTime}}
									</template>
									<template v-if="schooljt.weekday === '4'">
										<strong>周四:</strong>{{schooljt.beginTime}}-{{schooljt.endTime}}
									</template>
									<template v-if="schooljt.weekday === '5'">
										<strong>周五:</strong>{{schooljt.beginTime}}-{{schooljt.endTime}}
									</template>
									<template v-if="schooljt.weekday === '6'">
										<strong>周六:</strong>{{schooljt.beginTime}}-{{schooljt.endTime}}
									</template>
									<template v-if="schooljt.weekday === '7'">
										<strong>周日:</strong>{{schooljt.beginTime}}-{{schooljt.endTime}}
									</template>
								</span>
								<br class="p_zwf">
								</template>
						</td>
						<td>{{school.managerName}}</td>
						<td v-if="$_has(actionsList,'delete')||$_has(actionsList,'update')||$_has(actionsList,'read')">
							<input type="button" v-if="$_has(actionsList,'delete')" value="删除" @click="deleteSchool(school.id)" class="p_btn p_btn_siz_2 p_btn_col_k_red p_btn_pos_r">
							<input type="button" v-if="$_has(actionsList,'update')" value="编辑" @click="updateSchool(school.id)" class="p_btn p_btn_siz_2 p_btn_col_k_oran p_btn_pos_r">
							<input type="button" v-if="$_has(actionsList,'read')" value="查看" @click="readSchool(school.id)" class="p_btn p_btn_siz_2 p_btn_col_k_blu p_btn_pos_r">
						</td>
					</tr>
				</table>
				<!--<router-view></router-view>-->
			</div>
		</div>
		<div class='h5_page_container' id="con">
			<page :record-count="recordCount" v-on:change-page="changePage">
			</page>
		</div>

	</section>
</template>
<script>
	import instance from '../../../api/index.js';
	import { mapState } from 'vuex';
	export default {
		computed: {
			// Getting Vuex State from store/index
			...mapState({
				pageSize: state => state.pageSize,
				pageLarge: state => state.pageLarge,
			})
		},
		data() {
			return {
				actionsList:[],//获取当前用户对当前模块授权操作
				actionType: "",
				findSchools: { //查询条件
					qSchoolId : "", //校区id
					qTelephone : "", //联系电话
					qManagerName : "", //负责人
				},
				schoolsList: [], //校区列表
				schoolsDict:[],//校区字典
				recordCount: 0,
				pageNum: 1 //当前页码
			};
		},
		components: {
			page: () =>
				import("../../common/page.vue"),
		},
		methods: {
			query: function() {
				this.getSchoolsList(this.findSchools);
				this.getSchoolsCount(this.findSchools);
			},
			getSchoolsCount: function(lis) { //校区数量
				instance.post('/school/findSchoolsCount', lis).then((res) => {
					this.recordCount = res.data.data.count;
				});
			},
			getSchoolsList: function(lis) { //校区列表
				lis.beginRow = (this.pageNum - 1) * this.pageSize;
				lis.pageSize = this.pageSize;
				instance.post('/school/findSchools', lis).then((res) => {
					this.schoolsList = res.data.data;
				});

			},
			getSchoolsDict: function() { //校区字典
				instance.post('/school/findSimpleSchools', {}).then((res) => {
					this.schoolsDict = res.data.data;
				});
			},
			changePage: function(pageNum) {
				//  console.info("change-page:" + pageNum);
				this.pageNum = pageNum;
				this.getSchoolsList(this.findSchools);
			},
			addSchool: function() { //新增
				this.$router.push({
					path: `/xiaoquguanli/addSchool`
				});
			},
			updateSchool: function(id) { //编辑
				this.$router.push({
					path: `/xiaoquguanli/updateSchool/${id}`
				});
			},
			readSchool: function(id) { //查看
				this.$router.push({
					path: `/xiaoquguanli/readSchool/${id}`
				});
			},
			deleteSchool: function(id) { //删除
				
				this.$confirm('<strong>是否确认删除此条记录？</strong><br/><span style=color:red;><em>注意：删除此条记录后，和此记录有关联的数据属性将不可使用！</em></span>', '', {
					dangerouslyUseHTMLString: true
				}).then(() => {
					instance.post('/school/removeSchool/' + id, {}).then((res) => {
						if(res.data.errcode == 0) {
							this.$message.success('删除成功!');
						} else {
							this.$message.error('操作失败！' + res.data.errmsg);
						}
						//刷新列表
						this.query();
					});
				}).catch(() => {
					this.$message.info('已取消删除操作!');
				});
			},
			getModuleActions:function(){
				 let  routeCodes=this.$route.path.split("/");
				  let  routeCode=routeCodes[routeCodes.length-1]; 
					instance.get('/navi/findUserActions2/'+routeCode).then((res) => {
						if(res.data.errcode == '0') {
							this.actionsList=res.data.data;					
						} else {
							//this.$message.error('操作失败！' + res.data.info);
						}
						//console.info("json:" + res.data);

					})
			}
		},
		mounted: function() {
			this.getSchoolsCount(this.findSchools); //数量
			this.getSchoolsList(this.findSchools); //列表数据
			this.getModuleActions(); //模块操作权限
			this.getSchoolsDict();//校区字典
		}
	};
</script>