<!--<title>新增校区</title>-->
<style>
	.h5_02_info_per_exportRules_h3 {
		border-bottom: solid 1px #e7e7e7;
		padding: 10px 20px 10px 30px;
		color: #979494
	}
	/*.ue_time_block {
		border-bottom: solid 1px #e7e7e7;
		margin-bottom: 15px;
		position: relative;
	}*/
	/*.ue_time_block_btn {
		position: absolute;
		bottom: 5px;
		right: 10px;
		width: 20px;
		height: 20px;
		border-radius: 10px;
		background-color: #424242;
		color: #fff;
		text-align: center;
		line-height: 20px;
		cursor: pointer;
	}*/

	.p_con_sea_list_li_l>span:nth-child(1) {
		width: 8%!important
	}

	.per_addperson_sel_m {
		width: 10%;
		height: 25px;
		border: solid 1px #cdcdcd;
		border-radius: 5px;
		margin-right: 3px
	}

	.per_sel_s {
		width: 60px;
		height: 25px;
		border: solid 1px #cdcdcd;
		border-radius: 5px;
		margin-right: 3px
	}
  .el-input__inner{
    height: 25px;
    padding-bottom: 1px;
    margin-top: 7px;
  }
  /*.el-input__icon{*/
    /*line-height: clac(100% - 7px)!important;*/
  /*}*/
</style>
<template>
	<form id="" method="post" action="" class="ue_form_add">
		<ul class="h5_02_info_per_addlist">
			<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
	        	<span>新增校区(</span>
	        	<span class='h5_mark_xx2'>★</span>
	        	<span>为必填)</span>
	    	</h3>
			<!--<li>
				<span></span>
				<span>校区编号:</span>
				<span>
					<input type="text" class='per_addperson_txt' readonly="true">
				</span>
			</li>-->
			<li>
				<span>★</span>
				<span>校区名:</span>
				<span>
					<input type="text"  v-model="sources.schoolName" class="per_addperson_txt">
				</span>
			</li>
			<li>
				<span></span>
				<span>负责人:</span>
				<span>
					<select name="" id="" class='per_addperson_txt' v-model="sources.managerId">
    				  	<option  value="">请选择</option>
			            <option v-for="sm in schoolManager" :value="sm.id">{{sm.realName}}</option>
            		</select>
		        </span>
			</li>
			<li>
				<span>★</span>
				<span>联系电话:</span>
				<span>
					<input type="text"  v-model="sources.phone" class="per_addperson_txt">
		        </span>
			</li>
			<br class="p_zwf">
			<li style="width:100%;">
				<span></span>
				<span>详细地址:</span>
				<span style="min-height: 100px;">
					<select name="" id="" class="per_addperson_txt" style="width:130px;" v-model="sources.provinceId" @change="getCity(sources.provinceId)">
						<option v-for="province in provinces" :value="province.adcode">{{province.name}}</option>
					</select>
					<label for="">省</label>

					<select name="" id="" class="per_addperson_txt" style="width:180px;" v-model="sources.cityId" @change="getDistrict(sources.cityId)">
						<option v-for="city in citys" :value="city.adcode">{{city.name}}</option>
					</select>
					<label for="">市</label>

					<select name="" id="" class="per_addperson_txt" style="width:150px;" v-model="sources.areaId" @change="getaddress(sources.areaId)">
						<option v-for="district in districts" :value="district.adcode">{{district.name}}</option>
					</select>
					<label for="">区</label>
          <!--<br/>-->&nbsp;&nbsp;&nbsp;&nbsp;
					<input type="text"  v-model="sources.address" style="width:calc(100% - 640px);" class="per_addperson_txt">
				</span>
			</li>
			<br class="p_zwf">
			<li style="width:100%;">
				<span>★</span>
				<span>开设课程:</span>
				<span class="p_clear_float" style="height: auto">
					<template v-for="course in courseList" v-cloak>
						<strong>{{course.courseName}}</strong>
						<el-checkbox-group v-model="courseSubId">
						    <el-checkbox v-for="courseSub in course.courseSubs" :label="courseSub.id" :key="courseSub.id">{{courseSub.courseSubName}}</el-checkbox>
						 </el-checkbox-group>
					</template>
				</span>
			</li>
			<br class="p_zwf">
			<li style="width:100%;padding-top:10px;min-height: 300px;">
				<span>★</span>
				<span>作息时间:</span>
				<span>
					<span style="margin-bottom: 2px">
						<el-checkbox v-model="day1">周一</el-checkbox>&nbsp;
						<template>
						  <el-time-picker
						    v-model="begin1"
						    placeholder="起始时间">
						  </el-time-picker>&nbsp;至&nbsp;
						  <el-time-picker
						    v-model="end1"
						    placeholder="结束时间">
						  </el-time-picker>
						</template>
					</span>
					<br class="p_zwf">
					<span>
						<el-checkbox v-model="day2">周二</el-checkbox>&nbsp;
						<template>
						  <el-time-picker
						    v-model="begin2"
						    placeholder="起始时间">
						  </el-time-picker>&nbsp;至&nbsp;
						  <el-time-picker
						    v-model="end2"
						    placeholder="结束时间">
						  </el-time-picker>
						</template>
					</span>
					<br class="p_zwf">
					<span>
						<el-checkbox v-model="day3">周三</el-checkbox>&nbsp;
						<template>
						  <el-time-picker
						    v-model="begin3"
						    placeholder="起始时间">
						  </el-time-picker>&nbsp;至&nbsp;
						  <el-time-picker
						    v-model="end3"
						    placeholder="结束时间">
						  </el-time-picker>
						</template>
					</span>
					<br class="p_zwf">
					<span>
						<el-checkbox v-model="day4">周四</el-checkbox>&nbsp;
						<template>
						  <el-time-picker
						    v-model="begin4"
						    placeholder="起始时间">
						  </el-time-picker>&nbsp;至&nbsp;
						  <el-time-picker
						    v-model="end4"
						    placeholder="结束时间">
						  </el-time-picker>
						</template>
					</span>
					<br class="p_zwf">
					<span>
						<el-checkbox v-model="day5">周五</el-checkbox>&nbsp;
						<template>
						  <el-time-picker
						    v-model="begin5"
						    placeholder="起始时间">
						  </el-time-picker>&nbsp;至&nbsp;
						  <el-time-picker
						    v-model="end5"
						    placeholder="结束时间">
						  </el-time-picker>
						</template>
					</span>
					<br class="p_zwf">
					<span>
						<el-checkbox v-model="day6">周六</el-checkbox>&nbsp;
						<template>
						  <el-time-picker
						    v-model="begin6"
						    placeholder="起始时间">
						  </el-time-picker>&nbsp;至&nbsp;
						  <el-time-picker
						    v-model="end6"
						    placeholder="结束时间">
						  </el-time-picker>
						</template>
					</span>
					<br class="p_zwf">
					<span>
						<el-checkbox v-model="day7">周日</el-checkbox>&nbsp;
						<template>
						  <el-time-picker
						    v-model="begin7"
						    placeholder="起始时间">
						  </el-time-picker>&nbsp;至&nbsp;
						  <el-time-picker
						    v-model="end7"
						    placeholder="结束时间">
						  </el-time-picker>
						</template>
					</span>
				</span>
			</li>
			<!--<br class="p_zwf">-->
			<li class="per_addperson_li_w per_addperson_li_h2">
				<span></span>
				<span>备注:</span>
				<span style="min-height: 100px;">
					<textarea name="" id="" cols="30" rows="4"  class='per_addperson_texarea' v-model="sources.descr"></textarea>
		        </span>
			</li>
		</ul>
		<br class="p_zwf">
		<div class="p_btn_group p_clear_float">
			<input type="button" value="取消" class="p_btn p_btn_siz_2 p_btn_col_red p_btn_pos_r" @click="cancel">
			<input type="button" value="保存" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r" @click="save">
		</div>
	</form>
</template>
<script>
	import instance from '../../../api/index.js';
	import utils from '../../../assets/util.js';
	import axios from 'axios';
	import { mapState } from 'vuex';
	export default {
		data() {
			return {
				sources: {
					id: "",
					orgId: "",
					schoolName: "",
					schoolStatus: "0",
					phone: "",
					provinceId: "",
					cityId: "",
					areaId: "",
					provinceName: "",
					cityName: "",
					areaName: "",
					address: "",
					managerId: "",
					managerName: "",
					descr: "",
					creatorId: "",
					creatorName: "",
					createTime: "",
					vers: "",
					timestamp: "",
					courseSubs: [],
					schoolJobTimes: []
				},
				courseList: [], //课程大类字典
				courseSubId: [], //课程小类选中id
				day1: "",
				day2: "",
				day3: "",
				day4: "",
				day5: "",
				day6: "",
				day7: "",
				begin1: this.getNow(),
				begin2: this.getNow(),
				begin3: this.getNow(),
				begin4: this.getNow(),
				begin5: this.getNow(),
				begin6: this.getNow(),
				begin7: this.getNow(),
				end1: this.getNow(),
				end2: this.getNow(),
				end3: this.getNow(),
				end4: this.getNow(),
				end5: this.getNow(),
				end6: this.getNow(),
				end7: this.getNow(),
				provinces: [], //全国省份
				citys: [], //当前选中省份下的所有城市
				districts: [], //当前选 中城市下的所有区县,
				schoolManager: [] //店长
			};
		},
		computed: {
			// Getting Vuex State from store/index
			...mapState({
				cityJson: state => state.cityJson,
				adviceStatus: state => state.adviceStatus,
				adviceLevel: state => state.adviceLevel,
			})
		},
		methods: {
			cancel : function(){ //取消
				this.$router.push({
					path: `/jiaowuguanli/xiaoquguanli`
				});
			},
			save: function() { //保存校区信息
          var index=true;
				//清空课程
				this.sources.courseSubs = [];
				//整理课程小类
				if(this.courseSubId != null && this.courseSubId != "") {
					this.courseSubId.forEach(function(r) {
						let courseSub = {};
						courseSub['id'] = r;
						this.sources.courseSubs.push(courseSub);
					}, this);
				}
				//清空校区作息时间
				this.sources.schoolJobTimes = [];
				//整理校区作息时间
				if(this.day1) { //周一作息时间
					let schoolJobTime = {};
					if(this.begin1==null||this.end1==null){
            this.$message.error('操作失败！时间不能为空');
            index=false;
          }else{
					schoolJobTime['beginTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.begin1).replace("Z", " UTC")));
					schoolJobTime['endTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.end1).replace("Z", " UTC")));
					schoolJobTime['weekday'] = "1";
					this.sources.schoolJobTimes.push(schoolJobTime);
          }
				}
				if(this.day2) { //周二作息时间
					let schoolJobTime = {};
          if(this.begin2==null||this.end2==null){
            this.$message.error('操作失败！时间不能为空');
            index=false;
          }else {
            schoolJobTime['beginTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.begin2).replace("Z", " UTC")));
            schoolJobTime['endTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.end2).replace("Z", " UTC")));
            schoolJobTime['weekday'] = "2";
            this.sources.schoolJobTimes.push(schoolJobTime);
          }
				}
				if(this.day3) { //周三作息时间
					let schoolJobTime = {};
          if(this.begin3==null||this.end3==null){
            this.$message.error('操作失败！时间不能为空');
            index=false;
          }else {
            schoolJobTime['beginTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.begin3).replace("Z", " UTC")));
            schoolJobTime['endTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.end3).replace("Z", " UTC")));
            schoolJobTime['weekday'] = "3";
            this.sources.schoolJobTimes.push(schoolJobTime);
          }
				}
				if(this.day4) { //周四作息时间
					let schoolJobTime = {};
          if(this.begin4==null||this.end4==null){
            this.$message.error('操作失败！时间不能为空');
            index=false;
          }else {
            schoolJobTime['beginTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.begin4).replace("Z", " UTC")));
            schoolJobTime['endTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.end4).replace("Z", " UTC")));
            schoolJobTime['weekday'] = "4";
            this.sources.schoolJobTimes.push(schoolJobTime);
          }
				}
				if(this.day5) { //周五作息时间
					let schoolJobTime = {};
          if(this.begin5==null||this.end5==null){
            this.$message.error('操作失败！时间不能为空');
            index=false;
          }else {
            schoolJobTime['beginTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.begin5).replace("Z", " UTC")));
            schoolJobTime['endTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.end5).replace("Z", " UTC")));
            schoolJobTime['weekday'] = "5";
            this.sources.schoolJobTimes.push(schoolJobTime);
          }
				}
				if(this.day6) { //周六作息时间
					let schoolJobTime = {};
          if(this.begin6==null||this.end6==null){
            this.$message.error('操作失败！时间不能为空');
            index=false;
          }else {
            schoolJobTime['beginTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.begin6).replace("Z", " UTC")));
            schoolJobTime['endTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.end6).replace("Z", " UTC")));
            schoolJobTime['weekday'] = "6";
            this.sources.schoolJobTimes.push(schoolJobTime);
          }
				}
				if(this.day7) { //周日作息时间
					let schoolJobTime = {};
          if(this.begin7==null||this.end7==null){
            this.$message.error('操作失败！时间不能为空');
            index=false;
          }else {
            schoolJobTime['beginTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.begin7).replace("Z", " UTC")));
            schoolJobTime['endTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.end7).replace("Z", " UTC")));
            schoolJobTime['weekday'] = "7";
            this.sources.schoolJobTimes.push(schoolJobTime);
          }
				}
        if(index){
          instance.post('/school/createSchool', this.sources).then((res) => {
            if(res.data.errcode == '0') {
              this.$message.success('信息创建成功！');
              //this.$router.go(-1);
              this.$router.push({
                path: `/jiaowuguanli/xiaoquguanli`
              });
            } else {

              this.$message.error('操作失败！' + res.data.errmsg);
            }
          })
        }
			},
			getProvince: function() {

				if(typeof(this.cityJson.status) == "undefined") { //首次加载 调接口高德地图

					axios.get('/restapi/v3/config/district?subdistrict=3&key=84b4e40f86d5c8087078673175324d9b').then((res) => {
						//this.consultants = res.data.status;
						if(res.data.status == '1') {
							this.$store.commit({
								type: 'setCityJson',
								cityJson: res.data
							})
							this.provinces = res.data.districts[0].districts;
						} else {
							this.$message.error('操作失败！' + res.data.info);
						}

						console.info("json:" + res.data);

					})
				} else {
					this.provinces = this.cityJson.districts[0].districts;
				}

			},
			getCity: function(provinceId) { //根据省份获取城市
				let vm = this;
				var name='';
				this.provinces.forEach(function(e, i) {
					if(e.adcode == provinceId) {
						vm.citys = e.districts;
            name=e.name

					}
				});
        vm.sources.provinceName=name;

			},
			getDistrict: function(cityId) { //根据城市获取区县
				let vm = this;
        var name='';
				this.citys.forEach(function(e, i) {
					if(e.adcode == cityId) {
						vm.districts = e.districts;
            name=e.name
					}

				});
        vm.sources.cityName=name;
			},
      getaddress: function(areaId) { //根据城市获取区县
        console.log(this.districts);
        let vm = this;
        var name='';
        this.districts.forEach(function(e, i) {
          if(e.adcode == areaId) {
            name=e.name
          }

        });
        vm.sources.areaName=name;
      },
			getCourse: function() { //课程大类列表
				instance.post('/course/findCourses', {}).then((res) => {
					this.courseList = res.data.data;

					//this.courseList.forEach(function(r) {
					//this.courseCheckGroup.push("checkGruop"+r.id);
					//}, this);
				});
			},
			getSchoolManager: function() { //查询店长
				instance.post('/user/findSystemRoleSimpleUser', {
					qRoleCode: "schoolmanager"
				}).then((res) => {
					this.schoolManager = res.data.data;
				});
			},
			getNow: function() { //当前系统时间
				var date = new Date();
				let year = date.getFullYear();
				let month = date.getMonth();
				let day = date.getDate();
				let hours = date.getHours();
				let minutes = date.getMinutes();

				return new Date(year, month, day, hours, minutes);
			},
			dateFtt: function(fmt, date) { //简单格式化，时间，满足作息时间使用
				var o = {
					"M+": date.getMonth() + 1, //月份
					"d+": date.getDate(), //日
					"h+": date.getHours(), //小时
					"m+": date.getMinutes(), //分
					"s+": date.getSeconds(), //秒
					"q+": Math.floor((date.getMonth() + 3) / 3), //季度
					"S": date.getMilliseconds() //毫秒
				};
				if(/(y+)/.test(fmt))
					fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
				for(var k in o)
					if(new RegExp("(" + k + ")").test(fmt))
						fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
				return fmt;
			}
		},
		mounted: function() {
			this.getProvince();
			this.getCourse();
			this.getSchoolManager();
		}
	};
</script>
