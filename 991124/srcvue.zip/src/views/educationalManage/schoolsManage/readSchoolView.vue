<!--<title>查看校区</title>-->
<style>
	.h5_02_info_per_exportRules_h3 {
		border-bottom: solid 1px #e7e7e7;
		padding: 10px 20px 10px 30px;
		color: #979494
	}
	/*.ue_time_block {
		border-bottom: solid 1px #e7e7e7;
		margin-bottom: 15px;
		position: relative;
	}*/
	/*.ue_time_block_btn {
		position: absolute;
		bottom: 5px;
		right: 10px;
		width: 20px;
		height: 20px;
		border-radius: 10px;
		background-color: #424242;
		color: #fff;
		text-align: center;
		line-height: 20px;
		cursor: pointer;
	}*/
	
	.p_con_sea_list_li_l>span:nth-child(1) {
		width: 8%!important
	}
	
	.per_addperson_sel_m {
		width: 10%;
		height: 25px;
		border: solid 1px #cdcdcd;
		border-radius: 5px;
		margin-right: 3px
	}
	
	.per_sel_s {
		width: 60px;
		height: 25px;
		border: solid 1px #cdcdcd;
		border-radius: 5px;
		margin-right: 3px
	}
</style>
<template>
	<form id="" method="post" action="" class="ue_form_add">
		<ul class="h5_02_info_per_addlist">
			<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
	        	<span>查看校区</span>
	    	</h3>
			<li>
				<span></span>
				<span>校区名:</span>
				<span>
					{{sources.schoolName}}
				</span>
			</li>
			<li>
				<span></span>
				<span>负责人:</span>
				<span>
					{{sources.managerName}}
		        </span>
			</li>
			<li>
				<span></span>
				<span>联系电话:</span>
				<span>
					{{sources.phone}}
		        </span>
			</li>
			<br class="p_zwf">
			<li style="width:100%;">
				<span></span>
				<span>详细地址:</span>
				<span>
					{{sources.provinceName}}&nbsp;(省)&nbsp;{{sources.cityName}}&nbsp;(市)&nbsp;{{sources.areaName}}&nbsp;(区)&nbsp;{{sources.address}}
				</span>
			</li>
			<br class="p_zwf">
			<li style="width:100%;">
				<span></span>
				<span>开设课程:</span>
				<span class="p_clear_float" style="height: auto">
					<template v-for="course in sources.courseSubs" v-cloak>
						<strong>{{course.course.courseName}}:</strong>
							{{course.courseSubName}}<br />
					</template>
				</span>
			</li>
			<br class="p_zwf">
			<li style="width:100%;padding-top:10px;min-height: 240px;">
				<span></span>
				<span>作息时间:</span>
				<span>
					<template v-for="schooljt in sources.schoolJobTimes" v-cloak>
					<span>
						<template v-if="schooljt.weekday === '1'">
							<strong>周一:</strong>{{schooljt.beginTime}}-{{schooljt.endTime}}
						</template>
						<template v-if="schooljt.weekday === '2'">
							<strong>周二:</strong>{{schooljt.beginTime}}-{{schooljt.endTime}}
						</template>
						<template v-if="schooljt.weekday === '3'">
							<strong>周三:</strong>{{schooljt.beginTime}}-{{schooljt.endTime}}
						</template>
						<template v-if="schooljt.weekday === '4'">
							<strong>周四:</strong>{{schooljt.beginTime}}-{{schooljt.endTime}}
						</template>
						<template v-if="schooljt.weekday === '5'">
							<strong>周五:</strong>{{schooljt.beginTime}}-{{schooljt.endTime}}
						</template>
						<template v-if="schooljt.weekday === '6'">
							<strong>周六:</strong>{{schooljt.beginTime}}-{{schooljt.endTime}}
						</template>
						<template v-if="schooljt.weekday === '7'">
							<strong>周日:</strong>{{schooljt.beginTime}}-{{schooljt.endTime}}
						</template>
					</span>
					<br class="p_zwf">
					</template>
				</span>
			</li>
			<br class="p_zwf">
			<li>
				<span></span>
				<span>备注:</span>
				<span>
					{{sources.descr}}
		        </span>
			</li>
		</ul>
		<br class="p_zwf">
		<div class="p_btn_group p_clear_float">
			<input type="button" value="取消" class="p_btn p_btn_siz_2 p_btn_col_red p_btn_pos_r" @click="cancel">
		</div>
	</form>
</template>
<script>
	import instance from '../../../api/index.js';
	import utils from '../../../assets/util.js';
	import axios from 'axios';
	import { mapState } from 'vuex';
	export default {
		props: ['id'], //传入的流水号
		data() {
			return {
				sources: {
					id: "",
					orgId: "",
					schoolName: "",
					schoolStatus: "0",
					phone: "",
					provinceId: "",
					cityId: "",
					areaId: "",
					provinceName: "",
					cityName: "",
					areaName: "",
					address: "",
					managerId: "",
					managerName: "",
					descr: "",
					creatorId: "",
					creatorName: "",
					createTime: "",
					vers: "",
					timestamp: "",
					courseSubs: [],
					schoolJobTimes: []
				}
			};
		},
		created() {
			// 组件创建完后获取数据，
			instance.get('/school/findSchool/' + this.id).then((res) => {
				this.sources = res.data.data;
			})
		},
		computed: {
			// Getting Vuex State from store/index
			...mapState({
				cityJson: state => state.cityJson
			})
		},
		methods: {
			cancel : function(){ //取消
				this.$router.push({
					path: `/jiaowuguanli/xiaoquguanli`
				});
			},
			getProvince: function() {  //加载省市区字典
				let vm = this;
				if(typeof(this.cityJson.status) == "undefined") { //首次加载 调接口高德地图				 	

					axios.get('/restapi/v3/config/district?subdistrict=3&key=84b4e40f86d5c8087078673175324d9b').then((res) => {
						//this.consultants = res.data.status;
						if(res.data.status == '1') {
							this.$store.commit({
								type: 'setCityJson',
								cityJson: res.data
							})

							res.data.districts[0].districts.forEach(function(e, i) {
								if(e.adcode == vm.sources.provinceId) {
									vm.sources.provinceName = e.name;
									e.districts.forEach(function(e, i) {
										if(e.adcode == vm.sources.cityId) {
											vm.sources.cityName = e.name;
											e.districts.forEach(function(e, i) {
												if(e.adcode == vm.sources.areaId) {
													vm.sources.areaName = e.name;

												}

											})
										}

									})
								}

							});

						} else {
							this.$message.error('操作失败！' + res.data.info);
						}

						console.info("json:" + res.data);

					})
				} else {
					this.cityJson.districts[0].districts.forEach(function(e, i) {
						if(e.adcode == vm.sources.provinceId) {
							vm.sources.provinceName = e.name;
							e.districts.forEach(function(e, i) {
								if(e.adcode == vm.sources.cityId) {
									vm.sources.cityName = e.name;
									e.districts.forEach(function(e, i) {
										if(e.adcode == vm.sources.areaId) {
											vm.sources.areaName = e.name;

										}

									})
								}

							})
						}

					});
				}
			}
		},
		mounted: function() {
			this.getProvince();
		}
	};
</script>