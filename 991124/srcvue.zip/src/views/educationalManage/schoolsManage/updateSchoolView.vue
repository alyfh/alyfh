<!--<title>编辑校区</title>-->
<style>
	.h5_02_info_per_exportRules_h3 {
		border-bottom: solid 1px #e7e7e7;
		padding: 10px 20px 10px 30px;
		color: #979494
	}
	/*.ue_time_block {
		border-bottom: solid 1px #e7e7e7;
		margin-bottom: 15px;
		position: relative;
	}*/
	/*.ue_time_block_btn {
		position: absolute;
		bottom: 5px;
		right: 10px;
		width: 20px;
		height: 20px;
		border-radius: 10px;
		background-color: #424242;
		color: #fff;
		text-align: center;
		line-height: 20px;
		cursor: pointer;
	}*/

	.p_con_sea_list_li_l>span:nth-child(1) {
		width: 8%!important
	}

	.per_addperson_sel_m {
		width: 10%;
		height: 25px;
		border: solid 1px #cdcdcd;
		border-radius: 5px;
		margin-right: 3px
	}

	.per_sel_s {
		width: 60px;
		height: 25px;
		border: solid 1px #cdcdcd;
		border-radius: 5px;
		margin-right: 3px
	}
</style>
<template>
	<form id="" method="post" action="" class="ue_form_add">
		<ul class="h5_02_info_per_addlist">
			<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
	        	<span>编辑校区(</span>
	        	<span class='h5_mark_xx2'>★</span>
	        	<span>为必填)</span>
	    	</h3>
			<!--<li>
				<span></span>
				<span>校区编号:</span>
				<span>
					<input type="text" class='per_addperson_txt' readonly="true">
				</span>
			</li>-->
			<li>
				<span>★</span>
				<span>校区名:</span>
				<span>
					<input type="text"  v-model="sources.school.schoolName" class="per_addperson_txt">
				</span>
			</li>
			<li>
				<span></span>
				<span>负责人:</span>
				<span>
					<select name="" id="" class='per_addperson_txt' v-model="sources.school.managerId">
    				  	<option  value="">请选择</option>
			            <option v-for="sm in schoolManager" :value="sm.id">{{sm.realName}}</option>
            		</select>
		        </span>
			</li>
			<li>
				<span>★</span>
				<span>联系电话:</span>
				<span>
					<input type="text"  v-model="sources.school.phone" class="per_addperson_txt">
		        </span>
			</li>
			<br class="p_zwf">
			<li style="width:100%;">
				<span></span>
				<span>详细地址:</span>
				<span style="min-height: 100px;">
					<select name="" id="" class="per_addperson_txt" style="width:130px;" v-model="sources.school.provinceId" @change="getCity(sources.school.provinceId)">
						<option v-for="province in provinces" :value="province.adcode">{{province.name}}</option>
					</select>
					<label for="">省</label>

					<select name="" id="" class="per_addperson_txt" style="width:180px;" v-model="sources.school.cityId" @change="getDistrict(sources.school.cityId)">
						<option v-for="city in citys" :value="city.adcode">{{city.name}}</option>
					</select>
					<label for="">市</label>

					<select name="" id="" class="per_addperson_txt" style="width:150px;" v-model="sources.school.areaId" @change="getaddress(sources.school.areaId)">
						<option v-for="district in districts" :value="district.adcode">{{district.name}}</option>
					</select>
					<label for="">区</label><br/>
					<input type="text"  v-model="sources.school.address" style="width:718px;" class="per_addperson_txt">
				</span>
			</li>
			<br class="p_zwf">
			<li style="width:100%;">
				<span>★</span>
				<span>开设课程:</span>
				<span class="p_clear_float" style="height: auto">
					<template v-for="course in courseList" v-cloak>
						<strong>{{course.courseName}}</strong>
						<el-checkbox-group v-model="courseSubId">
						    <el-checkbox v-for="courseSub in course.courseSubs" :label="courseSub.id" :key="courseSub.id">{{courseSub.courseSubName}}</el-checkbox>
						 </el-checkbox-group>
					</template>
				</span>
			</li>
			<br class="p_zwf">
			<li style="width:100%;padding-top:10px;min-height: 300px;">
				<span>★</span>
				<span>作息时间:</span>
				<span>
					<span>
						<el-checkbox v-model="day1">周一</el-checkbox>&nbsp;
						<input type="hidden" v-model="timeid1" />
						<template>
						  <el-time-picker
						    v-model="begin1"
						    placeholder="起始时间">
						  </el-time-picker>&nbsp;至&nbsp;
						  <el-time-picker
						    v-model="end1"
						    placeholder="结束时间">
						  </el-time-picker>
						</template>
					</span>
					<br class="p_zwf">
					<span>
						<el-checkbox v-model="day2">周二</el-checkbox>&nbsp;
						<input type="hidden" v-model="timeid2" />
						<template>
						  <el-time-picker
						    v-model="begin2"
						    placeholder="起始时间">
						  </el-time-picker>&nbsp;至&nbsp;
						  <el-time-picker
						    v-model="end2"
						    placeholder="结束时间">
						  </el-time-picker>
						</template>
					</span>
					<br class="p_zwf">
					<span>
						<el-checkbox v-model="day3">周三</el-checkbox>&nbsp;
						<input type="hidden" v-model="timeid3" />
						<template>
						  <el-time-picker
						    v-model="begin3"
						    placeholder="起始时间">
						  </el-time-picker>&nbsp;至&nbsp;
						  <el-time-picker
						    v-model="end3"
						    placeholder="结束时间">
						  </el-time-picker>
						</template>
					</span>
					<br class="p_zwf">
					<span>
						<el-checkbox v-model="day4">周四</el-checkbox>&nbsp;
						<input type="hidden" v-model="timeid4" />
						<template>
						  <el-time-picker
						    v-model="begin4"
						    placeholder="起始时间">
						  </el-time-picker>&nbsp;至&nbsp;
						  <el-time-picker
						    v-model="end4"
						    placeholder="结束时间">
						  </el-time-picker>
						</template>
					</span>
					<br class="p_zwf">
					<span>
						<el-checkbox v-model="day5">周五</el-checkbox>&nbsp;
						<input type="hidden" v-model="timeid5" />
						<template>
						  <el-time-picker
						    v-model="begin5"
						    placeholder="起始时间">
						  </el-time-picker>&nbsp;至&nbsp;
						  <el-time-picker
						    v-model="end5"
						    placeholder="结束时间">
						  </el-time-picker>
						</template>
					</span>
					<br class="p_zwf">
					<span>
						<el-checkbox v-model="day6">周六</el-checkbox>&nbsp;
						<input type="hidden" v-model="timeid6" />
						<template>
						  <el-time-picker
						    v-model="begin6"
						    placeholder="起始时间">
						  </el-time-picker>&nbsp;至&nbsp;
						  <el-time-picker
						    v-model="end6"
						    placeholder="结束时间">
						  </el-time-picker>
						</template>
					</span>
					<br class="p_zwf">
					<span>
						<el-checkbox v-model="day7">周日</el-checkbox>&nbsp;
						<input type="hidden" v-model="timeid7" />
						<template>
						  <el-time-picker
						    v-model="begin7"
						    placeholder="起始时间">
						  </el-time-picker>&nbsp;至&nbsp;
						  <el-time-picker
						    v-model="end7"
						    placeholder="结束时间">
						  </el-time-picker>
						</template>
					</span>
				</span>
			</li>
			<br class="p_zwf">
			<li class="per_addperson_li_w per_addperson_li_h2">
				<span></span>
				<span>备注:</span>
				<span style="min-height: 100px;">
					<textarea name="" id="" cols="30" rows="4"  class='per_addperson_texarea' v-model="sources.school.descr"></textarea>
		        </span>
			</li>
		</ul>
		<br class="p_zwf">
		<div class="p_btn_group p_clear_float">
			<input type="button" value="取消" class="p_btn p_btn_siz_2 p_btn_col_red p_btn_pos_r" @click="cancel">
			<input type="button" value="保存" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r" @click="save">
		</div>
	</form>
</template>
<script>
	import instance from '../../../api/index.js';
	import utils from '../../../assets/util.js';
	import axios from 'axios';
	import { mapState } from 'vuex';
	export default {
		props: ['id'], //传入的流水号
		data() {
			return {
				sources: {
					school:{
						id: "",
						orgId: "",
						schoolName: "",
						schoolStatus: "0",
						phone: "",
						provinceId: "",
						cityId: "",
						areaId: "",
						provinceName: "",
						cityName: "",
						areaName: "",
						address: "",
						managerId: "",
						managerName: "",
						descr: "",
						creatorId: "",
						creatorName: "",
						createTime: "",
						vers: "",
						timestamp: "",
						courseSubs: [],
						schoolJobTimes: []
					},
					createSchoolJobTimes:[],
					updateSchoolJobTimes:[],
					deleteSchoolJobTimes:[]
				},
				courseList: [], //课程大类字典
				courseSubId: [], //课程小类选中id
				day1: "",
				day2: "",
				day3: "",
				day4: "",
				day5: "",
				day6: "",
				day7: "",
				begin1: "",
				begin2: "",
				begin3: "",
				begin4: "",
				begin5: "",
				begin6: "",
				begin7: "",
				end1: "",
				end2: "",
				end3: "",
				end4: "",
				end5: "",
				end6: "",
				end7: "",
				timeid1:"",
				timeid2:"",
				timeid3:"",
				timeid4:"",
				timeid5:"",
				timeid6:"",
				timeid7:"",
				provinces: [], //全国省份
				citys: [], //当前选中省份下的所有城市
				districts: [], //当前选 中城市下的所有区县,
				schoolManager: [] //店长
			};
		},
		created() {
			// 组件创建完后获取数据，
			instance.get('/school/findSchool/' + this.id).then((res) => {
				this.sources.school = res.data.data;

				//根据省份id初始化城市
				this.getCity(this.sources.school.provinceId);

				//根据城市id，初始化区县
				this.getDistrict(this.sources.school.cityId);

				//处理开设课程
				this.sources.school.courseSubs.forEach(function(s){
					//设置上次选中值
					this.courseSubId.push(s.id);
				},this);

				//处理作息时间
				this.sources.school.schoolJobTimes.forEach(function(s){
					if(s.weekday==='1'){
						this.begin1 = this.getDate() + " "+s.beginTime;
						this.end1 = this.getDate() + " "+s.endTime;
						this.day1 = true;
						this.timeid1=s.id;
					}
					if(s.weekday==='2'){
						this.begin2 = this.getDate() + " "+s.beginTime;
						this.end2 = this.getDate() + " "+s.endTime;
						this.day2 = true;
						this.timeid2=s.id;
					}
					if(s.weekday==='3'){
						this.begin3 = this.getDate() + " "+s.beginTime;
						this.end3 = this.getDate() + " "+s.endTime;
						this.day3 = true;
						this.timeid3=s.id;
					}
					if(s.weekday==='4'){
						this.begin4 = this.getDate() + " "+s.beginTime;
						this.end4 = this.getDate() + " "+s.endTime;
						this.day4 = true;
						this.timeid4=s.id;
					}
					if(s.weekday==='5'){
						this.begin5 = this.getDate() + " "+s.beginTime;
						this.end5 = this.getDate() + " "+s.endTime;
						this.day5 = true;
						this.timeid5=s.id;
					}
					if(s.weekday==='6'){
						this.begin6 = this.getDate() + " "+s.beginTime;
						this.end6 = this.getDate() + " "+s.endTime;
						this.day6 = true;
						this.timeid6=s.id;
					}
					if(s.weekday==='7'){
						this.begin7 = this.getDate() + " "+s.beginTime;
						this.end7 = this.getDate() + " "+s.endTime;
						this.day7 = true;
						this.timeid7=s.id;
					}
				},this);
			});
		},
		computed: {
			// Getting Vuex State from store/index
			...mapState({
				cityJson: state => state.cityJson,
				adviceStatus: state => state.adviceStatus,
				adviceLevel: state => state.adviceLevel,
			})
		},
		methods: {
			cancel : function(){ //取消
				this.$router.push({
					path: `/jiaowuguanli/xiaoquguanli`
				});
			},
			save: function() { //保存校区信息
        var index=true;
				//清空课程
				this.sources.school.courseSubs = [];
				//整理课程小类
				if(this.courseSubId != null && this.courseSubId != "") {
					this.courseSubId.forEach(function(r) {
						let courseSub = {};
						courseSub['id'] = r;
						this.sources.school.courseSubs.push(courseSub);
					}, this);
				}

				//清空校区作息时间
				this.sources.school.schoolJobTimes = [];
				this.sources.createSchoolJobTimes = [];
				this.sources.updateSchoolJobTimes = [];
				this.sources.deleteSchoolJobTimes = [];

				//整理校区作息时间
				if(this.day1) { //周一作息时间

					if(this.timeid1!="" && this.timeid1!=null){ //id存在，已选择，放到修改

						let schoolJobTime = {};
            if(this.begin1==null||this.end1==null){
              this.$message.error('操作失败！时间不能为空');
              index=false;
            }else {
              schoolJobTime['beginTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.begin1).replace("Z", " UTC")));
              schoolJobTime['endTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.end1).replace("Z", " UTC")));
              schoolJobTime['weekday'] = "1";
              schoolJobTime['id'] = this.timeid1;
              this.sources.updateSchoolJobTimes.push(schoolJobTime);
            }
					}else{ //id不存在，已选择，放到创建

						let schoolJobTime = {};
            if(this.begin1==null||this.end1==null){
              this.$message.error('操作失败！时间不能为空');
              index=false;
            }else {
              schoolJobTime['beginTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.begin1).replace("Z", " UTC")));
              schoolJobTime['endTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.end1).replace("Z", " UTC")));
              schoolJobTime['weekday'] = "1";
              this.sources.createSchoolJobTimes.push(schoolJobTime);
            }
					}
				}else{
					if(this.timeid1!="" && this.timeid1!=null){ //id存在，但未选择，放到删除

						let timeid = {};
						timeid['id'] = this.timeid1;
						//删除对应时间设置
						this.sources.deleteSchoolJobTimes.push(timeid);
					}
				}

				if(this.day2) { //周二作息时间

					if(this.timeid2!="" && this.timeid2!=null){ //id存在，已选择，放到修改

						let schoolJobTime = {};
            if(this.begin2==null||this.end2==null){
              this.$message.error('操作失败！时间不能为空');
              index=false;
            }else {
              schoolJobTime['beginTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.begin2).replace("Z", " UTC")));
              schoolJobTime['endTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.end2).replace("Z", " UTC")));
              schoolJobTime['weekday'] = "2";
              schoolJobTime['id'] = this.timeid2;
              this.sources.updateSchoolJobTimes.push(schoolJobTime);
            }
					}else{ //id不存在，已选择，放到创建

						let schoolJobTime = {};
            if(this.begin2==null||this.end2==null){
              this.$message.error('操作失败！时间不能为空');
              index=false;
            }else {
              schoolJobTime['beginTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.begin2).replace("Z", " UTC")));
              schoolJobTime['endTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.end2).replace("Z", " UTC")));
              schoolJobTime['weekday'] = "2";
              this.sources.createSchoolJobTimes.push(schoolJobTime);
            }
					}
				}else{
					if(this.timeid2!="" && this.timeid2!=null){ //id存在，但未选择，放到删除

						let timeid = {};
						timeid['id'] = this.timeid2;
						//删除对应时间设置
						this.sources.deleteSchoolJobTimes.push(timeid);
					}
				}

				if(this.day3) { //周三作息时间

					if(this.timeid3!="" && this.timeid3!=null){ //id存在，已选择，放到修改

						let schoolJobTime = {};
            if(this.begin3==null||this.end3==null){
              this.$message.error('操作失败！时间不能为空');
              index=false;
            }else {
              schoolJobTime['beginTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.begin3).replace("Z", " UTC")));
              schoolJobTime['endTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.end3).replace("Z", " UTC")));
              schoolJobTime['weekday'] = "3";
              schoolJobTime['id'] = this.timeid3;
              this.sources.updateSchoolJobTimes.push(schoolJobTime);
            }
					}else{ //id不存在，已选择，放到创建

						let schoolJobTime = {};
            if(this.begin3==null||this.end3==null){
              this.$message.error('操作失败！时间不能为空');
              index=false;
            }else {
              schoolJobTime['beginTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.begin3).replace("Z", " UTC")));
              schoolJobTime['endTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.end3).replace("Z", " UTC")));
              schoolJobTime['weekday'] = "3";
              this.sources.createSchoolJobTimes.push(schoolJobTime);
            }
					}
				}else{
					if(this.timeid3!="" && this.timeid3!=null){ //id存在，但未选择，放到删除

						let timeid = {};
						timeid['id'] = this.timeid3;
						//删除对应时间设置
						this.sources.deleteSchoolJobTimes.push(timeid);
					}
				}

				if(this.day4) { //周四作息时间

					if(this.timeid4!="" && this.timeid4!=null){ //id存在，已选择，放到修改

						let schoolJobTime = {};
            if(this.begin4==null||this.end4==null){
              this.$message.error('操作失败！时间不能为空');
              index=false;
            }else {
              schoolJobTime['beginTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.begin4).replace("Z", " UTC")));
              schoolJobTime['endTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.end4).replace("Z", " UTC")));
              schoolJobTime['weekday'] = "4";
              schoolJobTime['id'] = this.timeid4;
              this.sources.updateSchoolJobTimes.push(schoolJobTime);
            }
					}else{ //id不存在，已选择，放到创建

						let schoolJobTime = {};
            if(this.begin4==null||this.end4==null){
              this.$message.error('操作失败！时间不能为空');
              index=false;
            }else {
              schoolJobTime['beginTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.begin4).replace("Z", " UTC")));
              schoolJobTime['endTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.end4).replace("Z", " UTC")));
              schoolJobTime['weekday'] = "4";
              this.sources.createSchoolJobTimes.push(schoolJobTime);
            }
					}
				}else{
					if(this.timeid4!="" && this.timeid4!=null){ //id存在，但未选择，放到删除

						let timeid = {};
						timeid['id'] = this.timeid4;
						//删除对应时间设置
						this.sources.deleteSchoolJobTimes.push(timeid);
					}
				}

				if(this.day5) { //周五作息时间

					if(this.timeid5!="" && this.timeid5!=null){ //id存在，已选择，放到修改

						let schoolJobTime = {};
            if(this.begin5==null||this.end5==null){
              this.$message.error('操作失败！时间不能为空');
              index=false;
            }else {
              schoolJobTime['beginTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.begin5).replace("Z", " UTC")));
              schoolJobTime['endTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.end5).replace("Z", " UTC")));
              schoolJobTime['weekday'] = "5";
              schoolJobTime['id'] = this.timeid5;
              this.sources.updateSchoolJobTimes.push(schoolJobTime);
            }
					}else{ //id不存在，已选择，放到创建

						let schoolJobTime = {};
            if(this.begin5==null||this.end5==null){
              this.$message.error('操作失败！时间不能为空');
              index=false;
            }else {
              schoolJobTime['beginTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.begin5).replace("Z", " UTC")));
              schoolJobTime['endTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.end5).replace("Z", " UTC")));
              schoolJobTime['weekday'] = "5";
              this.sources.createSchoolJobTimes.push(schoolJobTime);
            }
					}
				}else{
					if(this.timeid5!="" && this.timeid5!=null){ //id存在，但未选择，放到删除

						let timeid = {};
						timeid['id'] = this.timeid5;
						//删除对应时间设置
						this.sources.deleteSchoolJobTimes.push(timeid);
					}
				}

				if(this.day6) { //周六作息时间

					if(this.timeid6!="" && this.timeid6!=null){ //id存在，已选择，放到修改

						let schoolJobTime = {};
            if(this.begin6==null||this.end6==null){
              this.$message.error('操作失败！时间不能为空');
              index=false;
            }else {
              schoolJobTime['beginTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.begin6).replace("Z", " UTC")));
              schoolJobTime['endTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.end6).replace("Z", " UTC")));
              schoolJobTime['weekday'] = "6";
              schoolJobTime['id'] = this.timeid6;
              this.sources.updateSchoolJobTimes.push(schoolJobTime);
            }
					}else{ //id不存在，已选择，放到创建

						let schoolJobTime = {};
            if(this.begin6==null||this.end6==null){
              this.$message.error('操作失败！时间不能为空');
              index=false;
            }else {
              schoolJobTime['beginTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.begin6).replace("Z", " UTC")));
              schoolJobTime['endTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.end6).replace("Z", " UTC")));
              schoolJobTime['weekday'] = "6";
              this.sources.createSchoolJobTimes.push(schoolJobTime);
            }
					}
				}else{
					if(this.timeid6!="" && this.timeid6!=null){ //id存在，但未选择，放到删除

						let timeid = {};
						timeid['id'] = this.timeid6;
						//删除对应时间设置
						this.sources.deleteSchoolJobTimes.push(timeid);
					}
				}

				if(this.day7) { //周日作息时间

					if(this.timeid7!="" && this.timeid7!=null){ //id存在，已选择，放到修改

						let schoolJobTime = {};
            if(this.begin7==null||this.end7==null){
              this.$message.error('操作失败！时间不能为空');
              index=false;
            }else {
              schoolJobTime['beginTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.begin7).replace("Z", " UTC")));
              schoolJobTime['endTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.end7).replace("Z", " UTC")));
              schoolJobTime['weekday'] = "7";
              schoolJobTime['id'] = this.timeid7;
              this.sources.updateSchoolJobTimes.push(schoolJobTime);
            }
					}else{ //id不存在，已选择，放到创建

						let schoolJobTime = {};
            if(this.begin7==null||this.end7==null){
              this.$message.error('操作失败！时间不能为空');
              index=false;
            }else {
              schoolJobTime['beginTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.begin7).replace("Z", " UTC")));
              schoolJobTime['endTime'] = this.dateFtt('hh:mm:ss', new Date(new String(this.end7).replace("Z", " UTC")));
              schoolJobTime['weekday'] = "7";
              this.sources.createSchoolJobTimes.push(schoolJobTime);
            }
					}
				}else{
					if(this.timeid7!="" && this.timeid7!=null){ //id存在，但未选择，放到删除

						let timeid = {};
						timeid['id'] = this.timeid7;
						//删除对应时间设置
						this.sources.deleteSchoolJobTimes.push(timeid);
					}
				}



        if(index) {

          instance.post('/school/changeSchoolAndJobTimes', this.sources).then((res) => {
            if (res.data.errcode == '0') {
              this.$message.success('信息创建成功！');
              //this.$router.go(-1);
              this.$router.push({
                path: `/jiaowuguanli/xiaoquguanli`
              });
            } else {

              this.$message.error('操作失败！' + res.data.errmsg);
            }
          })
        }
			},
			getProvince: function() {

				if(typeof(this.cityJson.status) == "undefined") { //首次加载 调接口高德地图

					axios.get('/restapi/v3/config/district?subdistrict=3&key=84b4e40f86d5c8087078673175324d9b').then((res) => {
						//this.consultants = res.data.status;
						if(res.data.status == '1') {
							this.$store.commit({
								type: 'setCityJson',
								cityJson: res.data
							})
							this.provinces = res.data.districts[0].districts;
						} else {
							this.$message.error('操作失败！' + res.data.info);
						}

						console.info("json:" + res.data);

					})
				} else {
					this.provinces = this.cityJson.districts[0].districts;
				}

			},
			// getCity: function(provinceId) { //根据省份获取城市
        // // alert(provinceId);
			// 	let vm = this;
			// 	this.provinces.forEach(function(e, i) {
			// 		if(e.adcode == provinceId) {
			// 			vm.citys = e.districts;
			// 		}
        //
			// 	});
			// 	this.districts=[];
        // this.getDistrict(this.sources.school.cityId);
        //
			// },
			// getDistrict: function(cityId) { //根据城市获取区县
			// 	let vm = this;
			// 	this.citys.forEach(function(e, i) {
			// 		if(e.adcode == cityId) {
			// 			vm.districts = e.districts;
			// 		}
            //
			// 	});
			// },
      ////////////////////////////
      getCity: function(provinceId) { //根据省份获取城市
        let vm = this;
        var name='';
        this.provinces.forEach(function(e, i) {
          if(e.adcode == provinceId) {
            vm.citys = e.districts;
            name=e.name

          }
        });
        this.districts=[];
        this.getDistrict(this.sources.school.cityId);
        vm.sources.school.provinceName=name;

      },
      getDistrict: function(cityId) { //根据城市获取区县
        let vm = this;
        var name='';
        this.citys.forEach(function(e, i) {
          if(e.adcode == cityId) {
            vm.districts = e.districts;
            name=e.name
          }

        });
        this.getaddress(this.sources.school.areaId);
        vm.sources.school.cityName=name;
      },
      getaddress: function(areaId) { //根据城市获取区县
        //console.log(this.districts);
        let vm = this;
        var name='';
        this.districts.forEach(function(e, i) {
          if(e.adcode == areaId) {
            name=e.name
          }

        });
        vm.sources.school.areaName=name;
      },
      /////////////////////////////
			getCourse: function() { //课程大类列表
				instance.post('/course/findCourses', {}).then((res) => {
					this.courseList = res.data.data;

					//this.courseList.forEach(function(r) {
					//this.courseCheckGroup.push("checkGruop"+r.id);
					//}, this);
				});
			},
			getSchoolManager: function() { //查询店长
				instance.post('/user/findSystemRoleSimpleUser', {
					qRoleCode: "schoolmanager"
				}).then((res) => {
					this.schoolManager = res.data.data;
				});
			},
			getNow: function() { //当前系统时间
				var date = new Date();
				let year = date.getFullYear();
				let month = date.getMonth();
				let day = date.getDate();
				let hours = date.getHours();
				let minutes = date.getMinutes();

				return new Date(year, month, day, hours, minutes);
			},
			dateFtt: function(fmt, date) { //简单格式化，时间，满足作息时间使用
				var o = {
					"M+": date.getMonth() + 1, //月份
					"d+": date.getDate(), //日
					"h+": date.getHours(), //小时
					"m+": date.getMinutes(), //分
					"s+": date.getSeconds(), //秒
					"q+": Math.floor((date.getMonth() + 3) / 3), //季度
					"S": date.getMilliseconds() //毫秒
				};
				if(/(y+)/.test(fmt))
					fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
				for(var k in o)
					if(new RegExp("(" + k + ")").test(fmt))
						fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
				return fmt;
			},
			getDate: function() { //当前系统日期
				var date = new Date();
				let nowDay = date.getFullYear() + "-" + ((date.getMonth() + 1) < 10 ? "0" + (date.getMonth() + 1) : (date.getMonth() + 1)) + "-" + (date.getDate() < 10 ? "0" + (date.getDate()) : date.getDate()); //date.getDate();
				return nowDay;
			},
		},
		mounted: function() {
			this.getProvince();
			this.getCourse();
			this.getSchoolManager();
		}
	};
</script>
