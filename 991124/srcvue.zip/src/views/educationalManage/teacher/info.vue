<!--<title>新增学员</title>-->
<style>
	.el-input__inner {
		height: 25px;
	}
</style>
<template>
	<form id="addstu" method="post" action="" class="ue_form_add" >
		<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
        	<span>基本信息</span>
        </h3>
		<ul class='h5_02_info_per_addlist'>
			<li>
				<span></span>
				<span>姓名:</span>
				<span>{{adviceDetail.realName}}</span>
			</li>
			<li>
				<span></span>
				<span>性别:</span>
				<span v-if="adviceDetail.sex==0">男</span>
				<span v-else-if="adviceDetail.sex==1">女</span>
				<span v-else="adviceDetail.sex==2">其它</span>
			</li>
			<li>
				<span></span>
				<span>出生日期:</span>
				<span>{{adviceDetail.birthday}}</span>
			</li>
			<li>
				<span></span>
				<span>手机:</span>
				<span>
    				{{adviceDetail.telephone}}

    			</span>
			</li>
			<li>
				<span></span>
				<span>民族:</span>
				<span>{{adviceDetail.nation}}</span>
			</li>
			<li>
				<span></span>
				<span>结婚状况:</span>
    			<span v-if="adviceDetail.marriage=='0'">未婚</span>
				<span v-else-if="adviceDetail.marriage=='1'">已婚</span>
				<span v-else-if="adviceDetail.marriage=='2'">离异</span>
				<span v-else="adviceDetail.marriage=='3'">丧偶</span>
			</li>

			<li>
				<span></span>
				<span>学历:</span>
				<span>
    				{{adviceDetail.education}}
    			</span>
			</li>
			<li>
				<span></span>
				<span>身份证号:</span>
				<span>{{adviceDetail.idNumber}}</span>
			</li>

			<li>
				<span></span>
				<span>毕业院校:</span>
				<span>
    				{{adviceDetail.graduate}}
        
    			</span>
			</li>
			<li>
				<span></span>
				<span>现住址:</span>
				<span>
    				{{adviceDetail.address}}
    			</span>
			</li>

			<li>
				<span></span>
				<span>户籍所在地:</span>
				<span>
    				{{adviceDetail.domicilePlace}}
    			</span>
			</li>
			<li>
				<span></span>
				<span>简历:</span>
				<span>
    				<!--{{adviceDetail.resume}}-->
    				<a :href="adviceDetail.AttachPath">{{adviceDetail.AttachName}}</a>
    			</span>
			</li>
			<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
        	<span>入职信息</span>
            </h3>
			<li>
				<span></span>
				<span>账号:</span>
				<span>
    				{{adviceDetail.username}}
    			</span>
			</li>
			<li>
				<span></span>
				<span>密码:</span>
				<span>
    				
    				</span>
			</li>
			<li>
				<span></span>
				<span>在职状态:</span>
    			<span v-if="adviceDetail.working=='0'">在职</span>
				<span v-else="adviceDetail.working=='1'">离职</span>
			</li>
			<li style="width:100%;">
				<span></span>
				<span>入职校区:</span>
				<!-- <span v-for="adivce in adviceDetail.schools">
					{{adivce.schoolName}}
    				
    			</span> -->
    			<span>
    			<template v-for="adivce in adviceDetail.schools">
						{{adivce.schoolName}}
				</template>
				</span>
			</li>

			<li>
				<span></span>
				<span>入职部门:</span>
				<span>{{adviceDetail.departmentName}}</span>
			</li>
			<li>
				<span></span>
				<span>入职职务:</span>
				<span>
					{{adviceDetail.dutyName}}
    				
    			</span>
			</li>
			<li>
				<span></span>
				<span>入职日期:</span>
				<span>
					{{adviceDetail.entryDate}}   				
    			</span>
			</li>
			<li>
				<span></span>
				<span>是否授课:</span>
				<span v-if="adviceDetail.teach=='0'">是</span>
				<span v-else="adviceDetail.teach=='1'">否</span>
			</li>

			<li>
				<span></span>
				<span>转正日期:</span>
				<span>
    				{{adviceDetail.officialDate}}
    			</span>
			</li>
			<li>
				<span></span>
				<span>离职日期:</span>
				<span>
    				{{adviceDetail.leaveDate}}
    			</span>
			</li>
			<li style="width:100%;">
				<span></span>
				<span>角色:</span>
				<!-- <span v-for="adivce in adviceDetail.roles">
    				{{adivce.roleName}}
    			</span> -->
    			<span>
    			<template v-for="adivce in adviceDetail.roles">
						{{adivce.roleName}}
				</template>
				</span>
			</li>
			
		</ul>

	</form>
</template>
<script>
	import instance from '../../../api/index.js';
	import axios from 'axios';
	import { mapState } from 'vuex';
	let Base64 = require('js-base64').Base64; //引入base64算法
	export default {
		data() {
			return {
				adviceDetail: {},
				provinceName: "",
				cityName: "",
				districtName: "",
			};
		},
		computed: {
			// Getting Vuex State from store/index
			...mapState({
				cityJson: state => state.cityJson,
				adviceStatus: state => state.adviceStatus,
				adviceLevel: state => state.adviceLevel,
				shifouByDigit: state => state.shifouByDigit,
				classTypeDict: state => state.classTypeDict
			})
		},
		methods: {
			getAdivceInfo: function(id) { //获取信息
				instance.get('/user/findUser/' + id).then((res) => {
				this.adviceDetail = res.data.data;

					//附件名称
				this.adviceDetail.AttachName = Base64.decode(this.adviceDetail.resume.split("_")[1]);
				//附件下载地址
				this.adviceDetail.AttachPath = '/api/attach/' + this.adviceDetail.resume;
				})
			}
		},
		mounted: function() {
			this.getAdivceInfo(this.$route.params.id);
			
		}
	};
</script>