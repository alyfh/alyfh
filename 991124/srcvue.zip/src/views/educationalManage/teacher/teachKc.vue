<!--<title>选班</title>-->
<template>
	<div>
		<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
    <span>教授课程</span>
  </h3>

		<div class="h5_iframe1_table_page" id='tree'></div>
		<!--tree容器-->
		<div class="p_btn_group p_clear_float">

			<input type="button" value="保存" @click="submit()" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r">
		</div>
	</div>
	</div>
</template>

<script>
	import instance from '../../../api/index.js';
	import axios from 'axios';
	import { mapState } from 'vuex';

	export default {

		data() {
			return {
				tempdatas: [], //默认选中
				data2: []

			};
		},
		methods: {

			finddxlb: function(key) { //列表数据
				$('#page1').jstree("destroy");
				var datas = this.data2;
				instance.post('/course/findCourses', {}).then((res) => {
					if(res.data.errcode == '0') {

						var temp = res.data.data;
						temp.forEach(function(val, index) {
							var childrens = [];

							val.courseSubs.forEach(function(val1, index) {

								var childrentmp = {};
								childrentmp.id = val1.id;
								childrentmp.text = val1.courseSubName;

								childrens.push(childrentmp);
							});
							var parentmp = {};
							parentmp.id = val.id + ",";
							parentmp.text = val.courseName;
							parentmp.children = childrens;
							//alert(JSON.stringify(parentmp));
							datas.push(parentmp);
						});

					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}

					//制作树
					$('#tree').jstree({
						'core': {
							'themes': {
								'theme': 'default',
								'icons': false
							},
							'data': this.data2
						},
						'plugins': ['types', 'checkbox']
					});

					//展开节点
					$("#tree").on("loaded.jstree", function(event, data) {
						// 展开所有节点
						$('#tree').jstree('open_all');

						instance.get('/teacher/findTeacherCourses/' + key).then((res) => { //获取选中的节点数值

							var _tempdatas = [];
							var datatemp = res.data.data;

							datatemp.forEach(function(item, index) {

								var ids = item.id;
								_tempdatas.push(ids);

							});

							_tempdatas.forEach(function(node) {

								$('#tree').jstree('select_node', node, true);

							});
						})

					});

				})

			},
			findteacherkc: function(id) { //选中数据

			},
			submit: function() {

				var items = $('#tree').jstree().get_checked(); //获取所有选中的节点ID

				var param = {
					id: this.$route.params.id,
					courseSubs: []
				};
				items.forEach(function(item, index) {
					var ids = {
						id: ""
					};
					if(item.indexOf(",") == -1) {
						ids.id = item;
					}
					param.courseSubs.push(ids);

				});

				instance.post('/teacher/changeTeacherCourseSub', param).then((res) => {

					if(res.data.errcode == '0') {
						this.$message.info('信息修改成功！');
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}

				});
			}
		},
		mounted: function() {

			this.finddxlb(this.$route.params.id);
			//this.findteacherkc(this.$route.params.id);

		}
	};
</script>