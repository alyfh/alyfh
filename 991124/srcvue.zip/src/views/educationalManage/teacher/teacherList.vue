<!--<title>全部咨询</title>-->
<style scoped>
	.p_table_la tr>td:nth-child(14):hover {
		cursor: pointer;
		color: #0d8ddb;
	}
</style>
<template>
	<section class="p_chi_con">
	<div class="p_con_sea">
			<ul class="p_con_sea_list p_clear_float">
					<li>
					<span>账号:</span>
					<span>
						<input type="text" class="p_con_form_input" v-model="findAdvices.qUsername" >
					</span>
				</li>
				<li>
					<span>姓名:</span>
					<span>
						<input type="text" class="p_con_form_input"  v-model="findAdvices.qRealName" >
					</span>
				</li>
				<li>
					<span>身份证号:</span>
					<span>
						<input type="text" class="p_con_form_input" v-model="findAdvices.qIdNumber" >
					</span>
				</li>
				<li>
					<span>手机:</span>
					<span>
						<input type="text" class="p_con_form_input" v-model="findAdvices.qTelephone"  >
					</span>
				</li>
				<li>
              <span>在职状态:</span>
              <span>
              <select name="" id="" class="p_con_form_select" v-model="findAdvices.qWorking"  >
              <option value="">--请选择--</option>
              <option value="0">在职</option>
              <option value="1">离职</option>
              </select>
			  </span>
        </li>	
        <li>
		  <span>转正状态:</span>
          <span>
            <select name="" id="" class="p_con_form_select" v-model="findAdvices.qOfficial">
              <option value="">--请选择--</option>
              <option value="0">已转正</option>
              <option value="1">未转正</option>
            </select>
		  </span>
		 </li>
		 <li>
		  <span>校区:</span>
          <span>
            <select name="" id="" class="p_con_form_select" v-model="findAdvices.qSchoolId">
              <!--<option value="">-</option>-->
              <option value="">--请选择--</option>
              <option v-for="xq in queryxqData" :value="xq.id">{{xq.schoolName}}</option>
            </select>
		   </span>
		</li>
		<li>
		   <span>部门:</span>
			<span>
			<select name="" id="" class="p_con_form_select" v-model="findAdvices.qDepartmentId">
			  <option value="">--请选择--</option>
              <option v-for="consultant in querybmData" :value="consultant.id">{{consultant.departmentName}}</option>
            </select>
			</span>
		</li>
	  </ul>	
	  <div class="p_btn_group p_clear_float">
				<input type="button" value="查询" @click="query" class="p_btn p_btn_siz_2 p_btn_col_gre p_btn_pos_r">
			</div>
		</div>
		<div class="p_con_tab">
			
			<div class="p_table_la_over">
				<table class="p_table_la" cellspacing="0" cellpadding="0">
					<tr>
						<td>账号</td>
						<td>姓名</td>
						<td>性别</td>
						<td>身份证号</td>
						<td>手机</td>
						<td>在职状态</td>
						<td>转正状态</td>
						<td>入职校区</td>
						<td>部门</td>
						<td v-if="$_has(actionsList,'jiaoshoukecheng')">
							操作
						</td>
					</tr>
					<tr v-for="adivce in adviceList">
						
						<td>{{adivce.username}}</td>
						<td>{{adivce.realName}}</td>

						<td v-if="adivce.sex==0">男</td>
						<td v-else-if="adivce.sex==1">女</td>
						<td v-else="adivce.sex==2">其它</td>
						<td>{{adivce.idNumber}}</td>
						<td>{{adivce.telephone}}</td>
                        <td v-if="adivce.working==0">在职</td>
						<td v-else-if="adivce.working==1">离职</td>
						 <td v-if="adivce.official==0">已转正</td>
						<td v-else-if="adivce.official==1">未转正</td>
						<td v-if="adivce.schools.length>0">
                       <span v-for="(item,key) in adivce.schools">{{item.schoolName}}<br/></span>
						</td>
						<td v-else="adivce.schools.length==0"></td>
						<td>{{adivce.departmentName}}</td>
			<td v-if="$_has(actionsList,'jiaoshoukecheng')">
				<input v-if="$_has(actionsList,'jiaoshoukecheng')" type="button" value="教授课程设置" @click="linkAdviceInfo(adivce.id)" class="p_btn p_btn_siz_2 p_btn_col_k_red p_btn_pos_r">
			</td>

					</tr>
				</table>
				<!--<router-view></router-view>-->
			</div>
		</div>
		<div class='h5_page_container' id="con">
			<page :record-count="recordCount" v-on:change-page="changePage">
			</page>
		</div>

        <!-- 弹窗 -->
		<modal-dialog :show="layerShow" :action-type="actionType" :sourcesubdetail="sourcesubdetail"  v-on:save-sourceSub="saveSourceSub">
		</modal-dialog>
        <!-- 查看弹窗 -->
		<modal-dialog2 :show="layerShow" :action-type="actionType" :sourcesubdetail="sourcesubdetail">
		</modal-dialog2>

	</section>
</template>
<script>
	import instance from '../../../api/index.js';
	import { mapState } from 'vuex';
	import * as util from '../../../assets/util.js';
	export default {
		computed: {
			// Getting Vuex State from store/index
			...mapState({
				layerShow: state => state.layerShow,
				pageSize: state => state.pageSize,
				pageLarge: state => state.pageLarge,
				adviceStatus: state => state.adviceStatus,
				adviceLevel: state => state.adviceLevel,
			})
		},
		data() {
			return {
				actionsList:[],//获取当前用户对当前模块授权操作
				show: false,
				actionType: "",
				findAdvices: { //查询条件
                qUsername:"",
				qRealName:"",
				qIdNumber:"",
				qTelephone:"",
				qWorking:"",
				qOfficial:"",
				qSchoolId:"",
				qDepartmentId:""
				},
				adviceList: [], //
				recordCount: 0,
				pageNum: 1, //当前页码
				sourcesubdetail:{},
				queryxqData:[],
				querybmData:[],
				daqianxq:""
                
			};
		},
		components: {
			modalDialog: () =>
				import("./addUpdateComponent.vue"),
			modalDialog2: () =>
				import("./readComponent.vue"),
			page: () =>
				import("../../common/page.vue"),

		},
		methods: {
			setLayerShow: function() {
				this.$store.commit({
					type: 'setLayerShow',
					layerShow: false
				})
			},
			query:function(){
			this.getAdviceList(this.findAdvices);
			this.getAdviceCount(this.findAdvices); //数量
			},
			findxqSources:function(){//校区
				this.loginInfo = util.session("loginInfo", void(0));
				instance.post('/school/findUserSchools/'+this.loginInfo.login.userId, {}).then((res) => {
					if(res.data.errcode == '0') {
                          if(res.data.data.length==1){
                        this.queryxqData=res.data.data;
						this.findAdvices.qSchoolId=res.data.data[0].id;
                        this.getAdviceList(this.findAdvices);
			            this.getAdviceCount(this.findAdvices); //数量
                          }else{
                        this.queryxqData=res.data.data;
						//this.findAdvices.qSchoolId=res.data.data[0].id;
                        this.getAdviceList(this.findAdvices);
			            this.getAdviceCount(this.findAdvices); //数量
                          }



						
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}
					
				})
				
			},
			getAdviceCount: function(lis) { //获取数量
				instance.post('/teacher/findTeachersCount',lis).then((res) => {
					this.recordCount = res.data.data.count;
				});
			},
			getAdviceList: function(lis) { //获取列表
				lis.beginRow = (this.pageNum - 1) * this.pageSize;
				lis.pageSize = this.pageSize;
				instance.post('/teacher/findTeachers',lis).then((res) => {
					this.adviceList = res.data.data;
				})

			},
			changePage: function(pageNum) {
				//  console.info("change-page:" + pageNum);
				this.pageNum = pageNum;
				this.getAdviceList(this.findAdvices);
			},
			addSourceSub:function(){
               this.$store.commit({
					type: 'setLayerShow',
					layerShow:true
				})
				this.actionType = "add";
			},
			deleteSourceSub: function(key) {

				this.$confirm("您确定删除吗?", "提示", {
						confirmButtonText: "确定",
						cancelButtonText: "取消",
						type: "info"
					})
					.then(() => {
						instance.get('/lessoncard/removeLessonCard/' + key).then((res) => {
							this.$message.info('数据删除成功！');
							this.getAdviceList(this.findAdvices);
			                this.getAdviceCount(this.findAdvices); //数量
						})
					})
					.catch(() => {});

				//this.actionType="read";
			},
			saveSourceSub: function(item) {
				item.id?this.updateSourceSub(item):this.createSourceSub(item)
			},
			createSourceSub: function(item) {
				instance.post('/lessoncard/createLessonCard', item).then((res) => {
					if(res.data.errcode == '0') {
						this.$message.info('信息创建成功！');
			            this.getAdviceList(this.findAdvices);
			            this.getAdviceCount(this.findAdvices); //数量
						this.setLayerShow(); //关闭窗口
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}

				})

			},
			editEntry: function(key) {

				this.$store.commit({
					type: 'setLayerShow',
					layerShow: true
				})
				instance.get('/lessoncard/findLessonCard/' + key).then((res) => {
					this.sourcesubdetail = res.data.data;
				})
				this.actionType = "update";
			},
			updateSourceSub:function(item){
				instance.post('/lessoncard/changeLessonCard', item).then((res) => {
					if(res.data.errcode == '0') {
			            this.getAdviceList(this.findAdvices);
			            this.getAdviceCount(this.findAdvices); //数量
						this.setLayerShow(); //关闭窗口
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}
					
				})
			},
			loadEntry:function(key){
				this.$store.commit({
					type: 'setLayerShow',
					layerShow: true
				})
				instance.get('/lessoncard/findLessonCard/' + key).then((res) => {
					this.sourcesubdetail = res.data.data;
				})
				this.actionType = "read";
			},
			findbmSources:function(){//部门
				instance.post('/dept/findSimpleDepartments', {}).then((res) => {
					if(res.data.errcode == '0') {
						this.querybmData=res.data.data;
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}
					
				})
				
			},
			linkAdviceInfo: function(id) { //姓名点击跳转详情
				this.$router.push('/jiaowuguanli/adviceinfo/' + id+"/baseInfo");
			},
			getModuleActions:function(){
				 let  routeCodes=this.$route.path.split("/");
				  let  routeCode=routeCodes[routeCodes.length-1]; 
					instance.get('/navi/findUserActions2/'+routeCode).then((res) => {
						if(res.data.errcode == '0') {
							this.actionsList=res.data.data;					
						} else {
							//this.$message.error('操作失败！' + res.data.info);
						}
						console.info("json:" + res.data);

					})
			}

		},
		mounted: function() {
			this.findxqSources();
			this.findbmSources();
			this.getModuleActions();

		}
	};
</script>