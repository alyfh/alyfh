<!--<title>购课信息</title>-->
<style scoped>
	.p_table_la tr:nth-child(1)>td {
		word-break: keep-all;
		word-break: keep-all;
		white-space: nowrap;
	}
</style>
<template>
	<div class="p_con_tab">
		<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
      <span>工作时间{{message}}</span>
    </h3>
		<div class="p_btn_group p_clear_float">
			<input type="button" value="新增" class="p_btn p_btn_siz_2 p_btn_col_gre p_btn_pos_r" @click="addVisit">

		</div>
		<div class="p_table_la_over">
			<table class="p_table_la" cellspacing="0" cellpadding="0">
				<tr>
					<td>姓名</td>
					<td>校区</td>
					<td>工作时间(星期)</td>
					<td>上班时间</td>
					<td>下班时间</td>
					<td>操作</td>
				</tr>
				<tr v-for="visit in visitList">
					<td>{{visit.realName}}</td>
					<td>{{visit.schoolName}}</td>
					<td v-if="visit.weekday==1">星期一</td>
					<td v-if="visit.weekday==2">星期二</td>
					<td v-if="visit.weekday==3">星期三</td>
					<td v-if="visit.weekday==4">星期四</td>
					<td v-if="visit.weekday==5">星期五</td>
					<td v-if="visit.weekday==6">星期六</td>
					<td v-if="visit.weekday==7">星期日</td>
					<td>{{visit.beginTime}} </td>
					<td>{{visit.endTime}}</td>
					<td>
						<input type="button" value="编辑" @click="editVisit(visit.id)" class="p_btn p_btn_siz_2 p_btn_col_k_oran p_btn_pos_r">
						<input type="button" value="删除" @click="delVisit(visit.id)" class="p_btn p_btn_siz_2 p_btn_col_k_oran p_btn_pos_r">
					</td>
					</td>
				</tr>
			</table>
		</div>
		<!-- 分页 -->
		<!-- <div class='h5_page_container' id="con">
			<page :record-count="recordCount" v-on:change-page="changePage">
			</page>
		</div>-->
	</div>
</template>
<script>
	import instance from '../../../../api/index.js';
	import { mapState } from 'vuex';
	export default {
		components: {
			page: () =>
				import("../../../common/page.vue")
		},
		data() {
			return {
				visitList: [],
				message: "",
				recordCount: 0,
				pageNum: 1 //当前页码
			};
		},

		computed: {
			// Getting Vuex State from store/index
			...mapState({
				adviceStatus: state => state.adviceStatus,
				adviceLevel: state => state.adviceLevel,
				pageSize: state => state.pageSize,
			})
		},
		methods: {
			getVisitList: function(id) { 
				instance.get('/teacher/findTeacherJobTimes/'+id).then((res) => {
					if(res.data.data == null) {
						this.message = '(' + res.data.errmsg + ')';
					} else {
						this.message = "";
						this.visitList = res.data.data;
					}
				})
			},
			getVisitCount: function(id) {

                /*instance.post('/teacher/findTeacherJobTimesCount/' + id).then((res) => {
					this.recordCount = res.data.data.count;
				})*/

			},
			delVisit: function(id) {

              this.$confirm("您确定删除吗?", "提示", {
						confirmButtonText: "确定",
						cancelButtonText: "取消",
						type: "info"
					})
					.then(() => {
						instance.get('/teacher/removeTeacherJobTime/' + id).then((res) => {
							this.$message.info('数据删除成功！');
						    this.getVisitList(this.$route.params.id);
						})
					})
					.catch(() => {});

				//this.actionType="read";

			},
			addVisit: function() {
				this.$router.push('/jiaowuguanli/adviceinfo/' + this.$route.params.id + "/addVisit");
			},
			editVisit: function(key) {
				this.$router.push('/jiaowuguanli/adviceinfo/' + key + "/editVisit");
			},
			changePage: function(pageNum) {
				console.info("change-page:" + pageNum);
				this.pageNum = pageNum;
				this.getVisitList(this.$route.params.id);
			}
		},
		mounted: function() {
			this.getVisitList(this.$route.params.id);
			this.getVisitCount(this.$route.params.id);
		}
	};
</script>