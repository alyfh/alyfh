<style>
  .el-input__inner {
    height: 25px !important
  }
</style>
<template>
	<form id="addstu" method="post" action="" class="ue_form_add">
		<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
        	<span>新增工作时间(</span>
        	<span class='h5_mark_xx2'>★</span>
        	<span>为必填)</span>
    	</h3>
		<ul class='h5_02_info_per_addlist'>
			<li>
				<span>★</span>
				<span>姓名:</span>
				<span>
				<input type="text" class="p_con_form_input"  v-model="names">
				</span>
			</li>
      <li>
				<span>★</span>
				<span>校区:</span>
        <span>
                  <select name="" id="" class="p_con_form_select" v-model="xschools">
              <!--<option value="">-</option>-->
              <option value="">--请选择--</option>
              <option v-for="xq in queryxqData" :value="xq.id">{{xq.schoolName}}</option>
                 </select>
		      </span>
			</li>

		</ul>
<table class="p_table_font" cellspacing="0" cellpadding="0">
					<tr>
						<td style="width:110px;text-align:center">作息时间：</td>
						<td>
							<table  cellspacing="0" cellpadding="0" style="width: 100%">


                <!--<div v-for="(visit,key) in adviceDetail.jobTimes">-->
								<tr v-for="(visit,key) in adviceDetail.jobTimes">
									<td>




                    <ul class='h5_02_info_per_addlist'>
                      <li class="per_addperson_li_w">
                        <span>
                          <input type="checkbox" :id="key" @click="resets(key)" v-model="visit.checked" >
                        </span>
                        <span style="width: 30px;">
                          <label v-if="visit.weekday=='1'" >周一</label>
										      <label v-else-if="visit.weekday=='2'">周二</label>
										      <label v-else-if="visit.weekday=='3'">周三</label>
										      <label v-else-if="visit.weekday=='4'">周四</label>
										      <label v-else-if="visit.weekday=='5'">周五</label>
										      <label v-else-if="visit.weekday=='6'">周六</label>
										      <label v-else-if="visit.weekday=='7'">周日</label>
                        </span>
                        <span>

            <el-time-picker   value-format="HH:mm:ss" format="HH:mm:ss" v-model="visit.beginTime" style="width:170px"></el-time-picker> 到
            <el-time-picker value-format="HH:mm:ss" format="HH:mm:ss" v-model="visit.endTime" style="width:170px"></el-time-picker>
         </span>
                      </li></ul>




										<!--<input type="checkbox" :id="key" @click="resets(key)" v-model="visit.checked" >-->
										<!--<label v-if="visit.weekday=='1'" >周一</label>-->
										<!--<label v-else-if="visit.weekday=='2'">周二</label>-->
										<!--<label v-else-if="visit.weekday=='3'">周三</label>-->
										<!--<label v-else-if="visit.weekday=='4'">周四</label>-->
										<!--<label v-else-if="visit.weekday=='5'">周五</label>-->
										<!--<label v-else-if="visit.weekday=='6'">周六</label>-->
										<!--<label v-else-if="visit.weekday=='7'">周日</label>-->

										<!--<span> <el-time-picker   value-format="HH:mm:ss" format="HH:mm:ss" v-model="visit.beginTime" ></el-time-picker>-->
    				                   <!--</span>-->

									<!--到-->

										<!--<span> <el-time-picker value-format="HH:mm:ss" format="HH:mm:ss" v-model="visit.endTime"></el-time-picker>-->
    				        <!--</span>-->
                    <!---->


									</td>
								</tr>

                               <!--</div>-->
							</table>
						</td>
					</tr>
				</table>
		<br class="p_zwf">
		<div class="p_btn_group p_clear_float">
			<input type="button" value="返回" @click="$router.go(-1)" class="p_btn p_btn_siz_2 p_btn_col_ora p_btn_pos_r">

			<input type="button" value="保存" @click="saveVisit(adviceDetail)" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r">
		</div>
	</form>
</template>
<script>
	import instance from '../../../../api/index.js';
	import axios from 'axios';
	import { mapState } from 'vuex';
  import * as util from '../../../../assets/util.js';
	export default {
		data() {
			return {

				counselorNames:{},
				consultants: [],
				queryxqData:[],
        adviceDetail:{id:this.$route.params.id,
                               jobTimes:[
                                {
                                	id:"",
                                	schoolId:"",
                                	schoolName:"",
                                	realName:"",
                                	userId:this.$route.params.id,
                                	weekday:"1",
                                	beginTime:"",
                                	endTime:"",
                                    createTime:this.getNow(),
                                    checked:false
                                },
                                {
                                	id:"",
                                	schoolId:"",
                                	schoolName:"",
                                	realName:"",
                                	userId:this.$route.params.id,
                                	weekday:"2",
                                	beginTime:"",
                                	endTime:"",
                                    createTime:this.getNow(),
                                    checked:false
                                },
                                {
                                	id:"",
                                	schoolId:"",
                                	schoolName:"",
                                	realName:"",
                                	userId:this.$route.params.id,
                                	weekday:"3",
                                	beginTime:"",
                                	endTime:"",
                                    createTime:this.getNow(),
                                    checked:false
                                },
                                {
                                	id:"",
                                	schoolId:"",
                                	schoolName:"",
                                	realName:"",
                                	userId:this.$route.params.id,
                                	weekday:"4",
                                	beginTime:"",
                                	endTime:"",
                                    createTime:this.getNow(),
                                    checked:false
                                },
                                {
                                	id:"",
                                	schoolId:"",
                                	schoolName:"",
                                	realName:"",
                                	userId:this.$route.params.id,
                                	weekday:"5",
                                	beginTime:"",
                                	endTime:"",
                                    createTime:this.getNow(),
                                    checked:false
                                },
                                {
                                	id:"",
                                	schoolId:"",
                                	schoolName:"",
                                	realName:"",
                                	userId:this.$route.params.id,
                                	weekday:"6",
                                	beginTime:"",
                                	endTime:"",
                                    createTime:this.getNow(),
                                    checked:false
                                },
                                {
                                	id:"",
                                	schoolId:"",
                                	schoolName:"",
                                	realName:"",
                                	userId:this.$route.params.id,
                                	weekday:"7",
                                	beginTime:"",
                                	endTime:"",
                                    createTime:this.getNow(),
                                    checked:false
                                }
                               ]
                },
                names:"",
                xschools:""

			};
		},
		computed: {
			// Getting Vuex State from store/index
			...mapState({
				adviceStatus: state => state.adviceStatus,
				adviceLevel: state => state.adviceLevel,
			}),
      xschoolsq() {　　　　
        return this.xschools;
      }
		},
    watch: {


       xschoolsq(curVal, oldVal) {
        　if(curVal != "")　
          this.adviceDetail={id:this.$route.params.id,
                               jobTimes:[
                                {
                                  id:"",
                                  schoolId:"",
                                  schoolName:"",
                                  realName:"",
                                  userId:this.$route.params.id,
                                  weekday:"1",
                                  beginTime:"",
                                  endTime:"",
                                    createTime:this.getNow(),
                                    checked:false
                                },
                                {
                                  id:"",
                                  schoolId:"",
                                  schoolName:"",
                                  realName:"",
                                  userId:this.$route.params.id,
                                  weekday:"2",
                                  beginTime:"",
                                  endTime:"",
                                    createTime:this.getNow(),
                                    checked:false
                                },
                                {
                                  id:"",
                                  schoolId:"",
                                  schoolName:"",
                                  realName:"",
                                  userId:this.$route.params.id,
                                  weekday:"3",
                                  beginTime:"",
                                  endTime:"",
                                    createTime:this.getNow(),
                                    checked:false
                                },
                                {
                                  id:"",
                                  schoolId:"",
                                  schoolName:"",
                                  realName:"",
                                  userId:this.$route.params.id,
                                  weekday:"4",
                                  beginTime:"",
                                  endTime:"",
                                    createTime:this.getNow(),
                                    checked:false
                                },
                                {
                                  id:"",
                                  schoolId:"",
                                  schoolName:"",
                                  realName:"",
                                  userId:this.$route.params.id,
                                  weekday:"5",
                                  beginTime:"",
                                  endTime:"",
                                    createTime:this.getNow(),
                                    checked:false
                                },
                                {
                                  id:"",
                                  schoolId:"",
                                  schoolName:"",
                                  realName:"",
                                  userId:this.$route.params.id,
                                  weekday:"6",
                                  beginTime:"",
                                  endTime:"",
                                    createTime:this.getNow(),
                                    checked:false
                                },
                                {
                                  id:"",
                                  schoolId:"",
                                  schoolName:"",
                                  realName:"",
                                  userId:this.$route.params.id,
                                  weekday:"7",
                                  beginTime:"",
                                  endTime:"",
                                    createTime:this.getNow(),
                                    checked:false
                                }
                               ]
                }

      }
    },
		methods: {
			getNow: function() {
				var date = new Date();
				let nowDay = date.getFullYear() + "-" + ((date.getMonth() + 1) < 10 ? "0" + (date.getMonth() + 1) : (date.getMonth() + 1)) + "-" + date.getDate();

				return nowDay;
			},
			getAdivceInfo: function(id) {
				instance.get('/user/findUser/' + id).then((res) => {
					this.names=res.data.data.realName;
          //this.queryxqData=res.data.data.schools;

          this.loginInfo = util.session("loginInfo", void(0));
        instance.post('/school/findUserSchools/'+this.loginInfo.login.userId, {}).then((res) => {
          if(res.data.errcode == '0') {
               if(res.data.data.length==1){
                this.queryxqData=res.data.data;
                this.xschools=res.data.data[0].id;
               }else{
                this.queryxqData=res.data.data;
               }


          } else {
            this.$message.error('操作失败！' + res.data.errmsg);
          }

        })


				})

				// instance.post('/school/findSchools', {}).then((res) => {
				// 	if(res.data.errcode == '0') {
				// 		this.queryxqData=res.data.data;
				// 	} else {
				// 		this.$message.error('操作失败！' + res.data.errmsg);
				// 	}

				// })
			},
			saveVisit: function(item) {

				//item.id ? this.updateVisit(item) : this.createVisit(item)
				this.createVisit(item)
			},
			createVisit: function(item) {
        this.arrydel(item);

				instance.post('/teacher/createTeacherJobTimes', item).then((res) => {
					if(res.data.errcode == '0') {

						//this.$router.push('/zhaoshengguanli/adviceinfo/' + this.$route.params.id + "/visitList");
            //this.savegx(item);
            this.$message.info('信息创建成功！');
            this.$router.push('/jiaowuguanli/adviceinfo/' + this.$route.params.id + "/visitList");
					} else {
            this.exceptiontemp();
						this.$message.error('操作失败！' + res.data.errmsg);
					}

				})
			},
			resets:function(key){
				var keys=$("#"+key).prop('checked');
				if(!keys){
                this.adviceDetail.jobTimes[key].beginTime="";
                this.adviceDetail.jobTimes[key].endTime="";
				}
				},
			arrydel:function(item){//保存前对未勾选项处理
				   var shool=this.xschools;
				   var name=this.names;
           var arry=[];
           var arrys=[];
           var a=item.jobTimes;
                a.forEach(function(val,index) {
                	    var das={};
                      var flag=val.checked;
                       if(flag){
                          das.id="";
                          das.schoolId=shool;
                          das.realName=name;
                          das.userId=val.userId;
                          das.weekday=val.weekday;
                          das.beginTime=val.beginTime;
                          das.endTime=val.endTime;
                          das.createTime=val.createTime;
                          arry.push(das);
                       }

                  });
                if(arry.length!=0){
                   this.adviceDetail.jobTimes=arry;
                }else{

                    this.exceptiontemp();
                }






			},
      savegx:function(item){//保存后勾选处理
               var shool=this.xschools;
               var name=this.names;
               var arry=[];

                var a=item.jobTimes;
                a.forEach(function(val,index) {

                         var das={};
                          das.id="";
                          das.schoolId=shool;
                          das.realName=name;
                          das.userId=val.userId;
                          das.weekday=val.weekday;
                          das.beginTime=val.beginTime;
                          das.endTime=val.endTime;
                          das.createTime=val.createTime;
                          das.checked=true;
                          arry.push(das);


                  });

                this.adviceDetail.jobTimes=arry;




      },
      exceptiontemp:function(){//全部没有勾选的时候处理函数
           var shool=this.xschools;
           var name=this.names;
           var arrys=[];
        for(var i=0;i<7;i++){
                      var dasy={};
                          dasy.id="";
                          dasy.schoolId=shool;
                          dasy.realName=name;
                          dasy.userId=this.$route.params.id;
                          dasy.weekday=""+(i+1)+"";
                          dasy.beginTime="";
                          dasy.endTime="";
                          dasy.createTime="";
                        arrys.push(dasy);
                    }
       this.adviceDetail.jobTimes=arrys;
      }
		},

		mounted: function() {
			this.getAdivceInfo(this.$route.params.id);

		}
	};
</script>
