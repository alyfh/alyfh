
<style>
	.el-input__inner {
		height: 32px !important
	}
</style>
<template>
	<form id="addstu" method="post" action="" class="ue_form_add">
		<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
        	<span>修改工作时间(</span>
        	<span class='h5_mark_xx2'>★</span>
        	<span>为必填)</span>
    	</h3>
		<ul class='h5_02_info_per_addlist'>
			<li>
				<span>★</span>
				<span>姓名:</span>
				<span> 
				<input type="text" class="p_con_form_input"  v-model="adviceDetail.realName">
				</span>
			</li>
            <li>
				<span>★</span>
				<span>校区:</span>
			  <span>
              <select name="" id="" class="p_con_form_select" v-model="adviceDetail.schoolId">
              <!--<option value="">-</option>-->
              <option value="">--请选择--</option>
              <option v-for="xq in queryxqData" :value="xq.id">{{xq.schoolName}}</option>
              </select>
		      </span>
			</li>
			
		</ul>
<table class="p_table_font" cellspacing="0" cellpadding="0">
					<tr>
						<td style="width:110px;text-align:center">作息时间：</td>
						<td>
							<table  cellspacing="0" cellpadding="0"> 
								

                                
								<tr>
									<td>
										<!--<input type="checkbox" :id="0" @click="resets(0)" checked="true">-->
										<label v-if="adviceDetail.weekday=='1'" >周一</label>
										<label v-else-if="adviceDetail.weekday=='2'">周二</label>
										<label v-else-if="adviceDetail.weekday=='3'">周三</label>
										<label v-else-if="adviceDetail.weekday=='4'">周四</label>
										<label v-else-if="adviceDetail.weekday=='5'">周五</label>
										<label v-else-if="adviceDetail.weekday=='6'">周六</label>
										<label v-else-if="adviceDetail.weekday=='7'">周日</label>
									
										<span> <el-time-picker  value-format="HH:mm:ss"   style="width:100%"   v-model="adviceDetail.beginTime" ></el-time-picker>
    				                   </span>
									
									到
									
										<span> <el-time-picker value-format="HH:mm:ss"  style="width:100%" v-model="adviceDetail.endTime"></el-time-picker>
    				                   </span>
									</td>
								</tr>

                              
							</table>
						</td>
					</tr>
				</table>
		<br class="p_zwf">
		<div class="p_btn_group p_clear_float">
			<input type="button" value="返回" @click="$router.go(-1)" class="p_btn p_btn_siz_2 p_btn_col_ora p_btn_pos_r">

			<input type="button" value="保存" @click="saveVisit(adviceDetail)" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r">
		</div>
	</form>
</template>
<script>
	import instance from '../../../../api/index.js';
	import axios from 'axios';
	import { mapState } from 'vuex';
	import * as util from '../../../../assets/util.js';
	export default {
		data() {
			return {
				
				counselorNames:{}, 
				consultants: [], 
				queryxqData:[],
                adviceDetail:{},
                teachertiemlb:[]


			};
		},
		computed: {
			// Getting Vuex State from store/index
			...mapState({
				adviceStatus: state => state.adviceStatus,
				adviceLevel: state => state.adviceLevel,
			})
		},
		methods: {
			getNow: function() {
				var date = new Date();
				let nowDay = date.getFullYear() + "-" + ((date.getMonth() + 1) < 10 ? "0" + (date.getMonth() + 1) : (date.getMonth() + 1)) + "-" + date.getDate();

				return nowDay;
			},
			// getAdivceInfo: function() {//查询校区
				

			// 	instance.post('/school/findSchools', {}).then((res) => {
			// 		if(res.data.errcode == '0') {
			// 			//this.queryxqData=res.data.data;
			// 		} else {
			// 			this.$message.error('操作失败！' + res.data.errmsg);
			// 		}
					
			// 	})
			// },
			saveVisit: function(item) {
				
				//item.id ? this.updateVisit(item) : this.createVisit(item)
				this.updateVisit(item)
			},
			updateVisit: function(item) {
				instance.post('/teacher/changeTeacherJobTime', item).then((res) => {
					if(res.data.errcode == '0') {
						this.$message.info('信息修改成功！');
						this.$router.push('/jiaowuguanli/adviceinfo/' + item.userId + "/visitList");
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}
				})
			},
			resets:function(key){
				var keys=$("#"+key).prop('checked');
				if(!keys){
                this.adviceDetail.beginTime="";
                this.adviceDetail.endTime="";
				}
				},
			findeditdata:function(id){//查询数据列表值
                    instance.get('/teacher/findTeacherJobTime/'+ id ).then((res) => {
					if(res.data.errcode == '0') {
					this.adviceDetail=res.data.data;

    //                 instance.get('/user/findUser/' + res.data.data.userId).then((res) => {
					
    //                 this.queryxqData=res.data.data.schools;
                    

				// })
                this.loginInfo = util.session("loginInfo", void(0));
				instance.post('/school/findUserSchools/'+this.loginInfo.login.userId, {}).then((res) => {
					if(res.data.errcode == '0') {
						this.queryxqData=res.data.data;
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}
					
				})
                   
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}


					
				})

			}	
		},

		mounted: function() {
			this.findeditdata(this.$route.params.id);
			//this.getAdivceInfo();
		}
	};
</script>