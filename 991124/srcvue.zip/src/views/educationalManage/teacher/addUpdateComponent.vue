<style scoped>
.h5_02_info_per_exportRules_h3 {
			border-bottom: solid 1px #e7e7e7;
			padding: 10px 20px 10px 30px;
			color: #979494
		}
	/*.ue_time_block {
		border-bottom: solid 1px #e7e7e7;
		margin-bottom: 15px;
		position: relative;
	}*/
	
	/*.ue_time_block_btn {
		position: absolute;
		bottom: 5px;	
		right: 10px;
		width: 20px;
		height: 20px;
		border-radius: 10px;
		background-color: #424242;
		color: #fff;
		text-align: center;
		line-height: 20px;
		cursor: pointer;
	}*/
	.p_con_sea_list_li_l>span:nth-child(1){width: 8%!important}
	.per_addperson_sel_m{
	    width: 10%;
	    height: 25px;
	    border:solid 1px #cdcdcd;
	    border-radius: 5px;
	    margin-right: 3px
	}
	.per_sel_s{
		width: 60px;
	    height: 25px;
	    border:solid 1px #cdcdcd;
	    border-radius: 5px;
	    margin-right: 3px
	}
</style>

<template>
	<div class="addlayer" id='templayer' v-show="show&&(actionType==='add'||actionType==='update')">
		<header>
			<span class="h5_layerLOGO">新增会员卡</span>
			<span class="h5_layerOFFbtn" @click="setLayerShow">╳</span>
		</header>
		<div class="addlayerBox">
			<form id="" method="post" action="" class="ue_form_add">
				<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
        	    <span>新增会员卡(</span>
        	    <span class='h5_mark_xx2'>★</span>
        	    <span>为必填)</span>
    	        </h3>
    			<input type="hidden"  v-model="sourcesubdetail.id">
				<ul class="p_con_sea_list p_clear_float">
					
					
					<li>
						
						<span>★会员卡名称:</span>
						<span> 
							<input type="text" class="p_con_form_input" v-model="sourcesubdetail.cardName">
				        </span>
					</li>
					<li>
						
						<span>★有效期(天):</span>
						<span> 
							<input type="text" class="p_con_form_input" v-model="sourcesubdetail.validTime">
				        </span>
					</li>
					<li>
						
						<span>★课时数:</span>
						<span> 
							<input type="text" class="p_con_form_input" v-model="sourcesubdetail.hour">
				        </span>
					</li>
					<li>
						<span></span>
						<span>赠送课时数:</span>
						<span> 
							<input type="text" class="p_con_form_input" v-model="sourcesubdetail.giveHour">
				        </span>
					</li>
					<li>
						
						<span>总课时数:</span>
						<span> 
							<input type="text" readonly="true" class="p_con_form_input" v-model="sourcesubdetail.sumHour" >
				        </span>
					</li>
					<li>
						
						<span>★原价(元):</span>
						<span> 
							<input type="text" class="p_con_form_input" v-model="sourcesubdetail.sourceMoney">
				        </span>
					</li>
					<li>
						<span>★现价(元):</span>
						<span> 
							<input type="text" class="p_con_form_input" v-model="sourcesubdetail.currentMoney">
				        </span>
					</li>
				</ul>
				<ul class="p_con_sea_list p_clear_float">
				 	<li class="p_con_sea_list_li_l">
                		<span>备注:</span>
                		<span>
                   			<textarea name="" id="" cols="30" rows="4"  class='per_addperson_texarea' v-model="sourcesubdetail.descr" ></textarea>
                		</span>
            		</li>
            	</ul>
				<br class="p_zwf">
				<div class="p_btn_group p_clear_float">
					<input type="button" value="取消" class="p_btn p_btn_siz_2 p_btn_col_red p_btn_pos_r" @click="setLayerShow">
					<input type="button" value="确定" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r" @click="saveSourceSub">
				</div>
			</form>
		</div>
	</div>

</template>

<script>
	import instance from '../../../api/index.js';
    import axios from 'axios';
	import { mapState } from 'vuex';
	export default {
		props: ['show', 'actionType', 'sourcesubdetail'],
		
		data() {
			return {
				gridColumns: [{
					code: 'id',
					name: 'id',
					isKey: true
				}],
				gridData: []
				

			};
		},
		computed: {
			// Getting Vuex State from store/index
			...mapState({
				cityJson: state => state.cityJson,
				adviceStatus: state => state.adviceStatus,
				adviceLevel: state => state.adviceLevel,
			}),
			hour() {　　　　
				return this.sourcesubdetail.hour
			},
			giveHour() {　　　　
				return this.sourcesubdetail.giveHour
			}
		},
		watch: {

			 /*'sourcesubdetail.hour':{
			 	handler:(val,oldVal)=>{
			 		alert(this.sourcesubdetail.giveHour);
              //this.sourcesubdetail.sumHour=parseFloat(val)+parseFloat(this.sourcesubdetail.giveHour);
			 	},
			 	deep:true
			 }*/

			 hour(curVal, oldVal) {
			 	　if(this.sourcesubdetail.giveHour != undefined && curVal != "")　
					this.sourcesubdetail.sumHour = parseFloat(this.sourcesubdetail.giveHour) + parseFloat(curVal);　
					else
					this.sourcesubdetail.sumHour="";
			},
			giveHour(curVal, oldVal) {
			 	　  if(this.sourcesubdetail.hour != undefined && curVal != "")　
					this.sourcesubdetail.sumHour = parseFloat(this.sourcesubdetail.hour) + parseFloat(curVal);　
					else
					this.sourcesubdetail.sumHour="";
			}
            
		},
		methods: {
			setLayerShow: function() {
				this.$store.commit({ //将弹层隐藏
					type: 'setLayerShow',
					layerShow: false
				})
			},
			saveSourceSub: function() {
				this.$emit('save-sourceSub', this.sourcesubdetail);

			}
		},
		created: function() {
		},
		mounted: function() {
			
		}

	};
</script>