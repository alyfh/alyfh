<!--<title>全部咨询</title>-->
<style scoped>
	.p_table_la tr>td:nth-child(14):hover {
		cursor: pointer;
		color: #0d8ddb;
	}
</style>
<template>
	<section class="p_chi_con">
	<div class="p_con_sea">
			<ul class="p_con_sea_list p_clear_float">
		<!--  <li>
		  <span>校区:</span>
          <span>
            <select name="" id="" class="p_con_form_select" v-model="findAdvices.qSchoolId">
              <option value="">-</option>
              <option value="">--请选择--</option>
              <option v-for="xq in queryxqData" :value="xq.id">{{xq.schoolName}}</option>
            </select>
		   </span>
		</li> -->
		<li>
		   <span>课程大类:</span>
			<span>
			<select name="" id="" class="p_con_form_select" v-model="findAdvices.qCourseId">
			  <option value="">--请选择--</option>
              <option v-for="consultant in querydlData" :value="consultant.id">{{consultant.courseName}}</option>
            </select>
			</span>
		</li>
	  </ul>	
	  <div class="p_btn_group p_clear_float">
				<input type="button" value="查询" @click="query" class="p_btn p_btn_siz_2 p_btn_col_gre p_btn_pos_r">
			</div>
		</div>
		<div class="p_con_tab">
			<div class="p_btn_group p_clear_float">
				<input v-if="$_has(actionsList,'addsource')" type="button" value="新增" @click="addSourceSub" class="p_btn p_btn_siz_2 p_btn_col_gre p_btn_pos_r">
			</div>
			<div class="p_table_la_over">
				<table class="p_table_la" cellspacing="0" cellpadding="0">
					<tr>
						<td>课程大类</td>
						<td>备注</td>
						<!-- <td>操作</td> -->
						<td v-if="$_has(actionsList,'delsource')||$_has(actionsList,'editsource')||$_has(actionsList,'readsource')">
							操作
						</td>
					</tr>
					<tr v-for="adivce in adviceList">
						
						<td>{{adivce.courseName}}</td>
						<td>{{adivce.descr}}</td>
			<!-- <td>
				<input type="button" value="删除" @click="deleteSourceSub(adivce.id)" class="p_btn p_btn_siz_2 p_btn_col_k_red p_btn_pos_r">
				<input type="button" value="编辑" @click="editEntry(adivce.id)" class="p_btn p_btn_siz_2 p_btn_col_k_oran p_btn_pos_r">
				<input type="button" value="详情" @click="loadEntry(adivce.id)" class="p_btn p_btn_siz_2 p_btn_col_k_gre p_btn_pos_r">
			</td> -->
                        <td v-if="$_has(actionsList,'delsource')||$_has(actionsList,'editsource')||$_has(actionsList,'readsource')">
							<input v-if="$_has(actionsList,'delsource') && loginInfo.login.userId==adivce.creatorId" type="button" value="删除" @click="deleteSourceSub(adivce.id)" class="p_btn p_btn_siz_2 p_btn_col_k_red p_btn_pos_r">
							<input v-if="$_has(actionsList,'editsource') && loginInfo.login.userId==adivce.creatorId" type="button" value="编辑" @click="editEntry(adivce.id)" class="p_btn p_btn_siz_2 p_btn_col_k_oran p_btn_pos_r">
							<input v-if="$_has(actionsList,'readsource')" type="button" value="详情" @click="loadEntry(adivce.id)" class="p_btn p_btn_siz_2 p_btn_col_k_blu p_btn_pos_r">

						</td>




					</tr>
				</table>
				<!--<router-view></router-view>-->
			</div>
		</div>
		<div class='h5_page_container' id="con">
			<page :record-count="recordCount" v-on:change-page="changePage">
			</page>
		</div>

        <!-- 弹窗 -->
		<modal-dialog :show="layerShow" :action-type="actionType" :sourcesubdetail="sourcesubdetail"  v-on:save-sourceSub="saveSourceSub">
		</modal-dialog>
        <!-- 查看弹窗 -->
		<modal-dialog2 :show="layerShow" :action-type="actionType" :sourcesubdetail="sourcesubdetail">
		</modal-dialog2>

	</section>
</template>
<script>
	import instance from '../../../api/index.js';
	import { mapState } from 'vuex';
	import * as util from '../../../assets/util.js';

	export default {
		computed: {
			// Getting Vuex State from store/index
			...mapState({
				layerShow: state => state.layerShow,
				pageSize: state => state.pageSize,
				pageLarge: state => state.pageLarge,
				adviceStatus: state => state.adviceStatus,
				adviceLevel: state => state.adviceLevel,
			})
		},
		data() {
			return {
				actionsList:[],//获取当前用户对当前模块授权操作
				show: false,
				actionType: "",
				findAdvices: { //查询条件
				qSchoolId:"",
				qCourseId:""
				},
				adviceList: [], //
				recordCount: 0,
				pageNum: 1, //当前页码
				sourcesubdetail:{},
				queryxqData:[],
				querydlData:[],
				loginInfo: {} //当前登录信息

			};
		},
		components: {
			modalDialog: () =>
				import("./addUpdateComponent.vue"),
			modalDialog2: () =>
				import("./readComponent.vue"),
			page: () =>
				import("../../common/page.vue"),

		},
		methods: {
			setLayerShow: function() {
				this.$store.commit({
					type: 'setLayerShow',
					layerShow: false
				})
			},
			query:function(){
			this.getAdviceList(this.findAdvices);
			this.getAdviceCount(this.findAdvices); //数量
			},
			getAdviceCount: function(lis) { //获取数量
				instance.post('/course/findCoursesCount',lis).then((res) => {
					this.recordCount = res.data.data.count;
				});
			},
			getAdviceList: function(lis) { //获取列表
				lis.beginRow = (this.pageNum - 1) * this.pageSize;
				lis.pageSize = this.pageSize;
				//获取当前登录人
				this.loginInfo = util.session("loginInfo", void(0));
				instance.post('/course/findCourses',lis).then((res) => {
					this.adviceList = res.data.data;
				})

			},
			changePage: function(pageNum) {
				//  console.info("change-page:" + pageNum);
				this.pageNum = pageNum;
				this.getAdviceList(this.findAdvices);
			},
			addSourceSub:function(){
               this.$store.commit({
					type: 'setLayerShow',
					layerShow:true
				})
                this.sourcesubdetail={};
				this.actionType = "add";
			},
			deleteSourceSub: function(key) {

				this.$confirm("您确定删除吗?", "提示", {
						confirmButtonText: "确定",
						cancelButtonText: "取消",
						type: "info"
					})
					.then(() => {
						instance.get('/course/removeCourse/' + key).then((res) => {
							this.$message.info('数据删除成功！');
							this.getAdviceList(this.findAdvices);
			                this.getAdviceCount(this.findAdvices); //数量
						})
					})
					.catch(() => {});

				//this.actionType="read";
			},
			saveSourceSub: function(item) {
				item.id?this.updateSourceSub(item):this.createSourceSub(item)
			},
			createSourceSub: function(item) {
				instance.post('/course/createCourse', item).then((res) => {
					if(res.data.errcode == '0') {
						this.$message.info('信息创建成功！');
			            this.getAdviceList(this.findAdvices);
			            this.getAdviceCount(this.findAdvices); //数量
						this.setLayerShow(); //关闭窗口
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}

				})

			},
			editEntry: function(key) {

				this.$store.commit({
					type: 'setLayerShow',
					layerShow: true
				})
				instance.get('/course/findCourse/' + key).then((res) => {
					this.sourcesubdetail = res.data.data;
				})
				this.actionType = "update";
			},
			updateSourceSub:function(item){
				instance.post('/course/changeCourse', item).then((res) => {
					if(res.data.errcode == '0') {
			            this.getAdviceList(this.findAdvices);
			            this.getAdviceCount(this.findAdvices); //数量
						this.setLayerShow(); //关闭窗口
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}
					
				})
			},
			loadEntry:function(key){
				this.$store.commit({
					type: 'setLayerShow',
					layerShow: true
				})
				instance.get('/course/findCourse/' + key).then((res) => {
					this.sourcesubdetail = res.data.data;
				})
				this.actionType = "read";
			},
			findxqSources:function(){//校区
				instance.post('/school/findSchools', {}).then((res) => {
					if(res.data.errcode == '0') {
						this.queryxqData=res.data.data;
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}
					
				})
				
			},
			finddlSources:function(){//课程大类
				instance.post('/course/findCourses', {}).then((res) => {
					if(res.data.errcode == '0') {
						this.querydlData=res.data.data;
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}
					
				})
				
			},
			getModuleActions:function(){
				 let  routeCodes=this.$route.path.split("/");
				  let  routeCode=routeCodes[routeCodes.length-1]; 
					instance.get('/navi/findUserActions2/'+routeCode).then((res) => {
						if(res.data.errcode == '0') {
							this.actionsList=res.data.data;					
						} else {
							//this.$message.error('操作失败！' + res.data.info);
						}
						//console.info("json:" + res.data);

					})
			}

		},
		mounted: function() {
			this.findxqSources();
			this.finddlSources();
			this.getAdviceList(this.findAdvices);
			this.getAdviceCount(this.findAdvices); //数量
			this.getModuleActions();

		}
	};
</script>