<style scoped>
	.h5_02_info_per_exportRules_h3 {
		border-bottom: solid 1px #e7e7e7;
		padding: 10px 20px 10px 30px;
		color: #979494
	}
	
	.ue_time_block {
		border-bottom: solid 1px #e7e7e7;
		margin-bottom: 15px;
		position: relative;
	}
	
	.ue_time_block_btn {
		position: absolute;
		bottom: 5px;
		right: 10px;
		width: 20px;
		height: 20px;
		border-radius: 10px;
		background-color: #424242;
		color: #fff;
		text-align: center;
		line-height: 20px;
		cursor: pointer;
	}
	   .h5_01_info_per_addlist>li{
  display: inline-block;
  width: calc(48% - 30px);
  padding: 0px 10px;
  margin: 10px;
  /*color: #fcb95b;*/
  color: #676a6c
}
</style>

<template>
	<div class="addlayer" id='templayer' v-show="show&&(actionType==='read')">
		<header>
			<span class="h5_layerLOGO">详细信息</span>
			<span class="h5_layerOFFbtn" @click="setLayerShow">╳</span>
		</header>
		<div class="addlayerBox">
			<form id="" method="post" action="" class="ue_form_add">
				<h3 class='h5_02_info_per_exportRules_h3'>
        	<span>课程大类(</span>
        	<span class='h5_mark_xx2'>★</span>
        	<span>为必填)</span>
    	</h3>
				<ul class='h5_01_info_per_addlist'>
					<li>
						<span>★</span>
						<span>课程大类:</span>
						<span> 
							{{sourcesubdetail.courseName}}
				        </span>
					</li>
				
				
				 	<li class="per_addperson_li_w per_addperson_li_h2">
				 		<span></span>
                		<span>备注:</span>
                		<span>
                   			{{sourcesubdetail.descr}}
                		</span>
            		</li>
            	</ul>
				<br class="p_zwf">
			</form>
		</div>
	</div>

</template>

<script>
	import instance from '../../../api/index.js';

	export default {
		props: ['show', 'actionType', 'sourcesubdetail'],
		
		data() {
			return {
				
			};
		},
		watch: {
			$route: function(to, from) {
				// this.activeMenuName = this.$route.name;
				//this.breadcrumbs = (this.$route && this.$route.matched) || [];
			}
		},
		methods: {
			setLayerShow: function() {
				this.$store.commit({ //将弹层隐藏
					type: 'setLayerShow',
					layerShow: false
				})
			}
		

		},
		created: function() {
			// console.info("bbbbbbbbbbbb:"+this.organizeDetail);
		},
		mounted: function() {

		}

	};
</script>