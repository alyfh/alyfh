<style scoped>
	.p_btn_group {
		border-bottom: solid 1px #e7eaec;
		padding-bottom: 10px;
	}
</style>

<template>
	<section class="p_chi_con">
		<div class="p_con_sea">
			<ul class="p_con_sea_list p_clear_float">
				<li>
					<span>校区:</span>
					<span>
						<select name="" v-model="querySourceId" class="p_con_form_select">
							<option value="">--请选择--</option>
							<option v-for="entry in simplesourceslist" v-bind:value="entry.id">{{entry.schoolName}}</option>
							
						</select>
					</span>
				</li>
				<li>
					<span>教室名:</span>
					<span><input type="text" class='per_addperson_txt' v-model="queryclassRoomName"></span>
				</li>
				
				
			</ul>
			<div class="p_btn_group p_clear_float">
				<input type="button" value="查询" @click="query" class="p_btn p_btn_siz_2 p_btn_col_k_gre p_btn_pos_r">
			</div>
		</div>
		<div class="p_con_tab">
			<div class="p_btn_group p_clear_float">
				<!--input type="button" value="删除" class="p_btn p_btn_siz_2 p_btn_col_red p_btn_pos_r"-->
				<input v-if="$_has(actionsList,'addsource')" type="button" value="新增" class="p_btn p_btn_siz_2 p_btn_col_gre p_btn_pos_r" @click="addSourceSub">

			</div>
			<div class="p_table_la_over">
				<!--数据列表-->
				<simple-grid :data-list="gridData" :actions-list="actionsList" :columns="gridColumns" v-on:load-entry="loadSourceSub" v-on:delete-entry="deleteSourceSub" v-on:edit-entry="editSourceSub">
				</simple-grid>

			</div>
			<!-- 分页 -->
			<div class='h5_page_container' id="con">
				<page :record-count="recordCount" v-on:change-page="changePage">
				</page>
			</div>
		</div>

		<!-- 弹窗 -->
		<modal-dialog :show="layerShow" :action-type="actionType" :sourcesubdetail="sourcesubdetail" :simplesourceslist="simplesourceslist" v-on:save-sourceSub="saveSourceSub">
		</modal-dialog>

		<!-- 查看弹窗 -->
		<modal-dialog2 :show="layerShow" :action-type="actionType" :sourcesubdetail="sourcesubdetail">
		</modal-dialog2>

	</section>

</template>

<script>
	import instance from '../../../api/index.js';
	import { mapState } from 'vuex';
	import * as util from '../../../assets/util.js';
	export default {
		components: {
			simpleGrid: () =>
				import("./listComponent.vue"),
			modalDialog: () =>
				import("./addUpdateComponent.vue"),
			modalDialog2: () =>
				import("./readComponent.vue"),
			page: () =>
				import("../../common/page.vue")
		},
		data() {
			return {
				actionsList:[],//获取当前用户对当前模块授权操作
				show: false,
				actionType: "query",
				gridColumns: [{
					code: 'id',
					name: 'id',
					isKey: true
				}],
				gridData: [],
				recordCount: 0,
				pageNum: 1, //当前页码
				simplesourceslist:[],
				querySourceId:"",
				queryclassRoomName:"",
				sourcesubdetail:{}
			};
		},
		computed: {
			// Getting Vuex State from store/index
			...mapState({
				layerShow: state => state.layerShow,
				pageSize: state => state.pageSize,
				pageLarge: state => state.pageLarge
			})
		},
		watch: {
			$route: function(to, from) {
				// this.activeMenuName = this.$route.name;
				// this.breadcrumbs = (this.$route && this.$route.matched) || [];
			}
		},
		methods: {
			setLayerShow: function() {
				this.$store.commit({
					type: 'setLayerShow',
					layerShow: false
				})
			},
			query:function(){
			this.getSourceSubs();
			this.getSourceSubCount();
			},
			getSourceSubCount: function() {
				var params={};
				if(this.querySourceId!=""||this.queryclassRoomName!="")
				params.qSchoolId=this.querySourceId;
			    params.qClassRoomName=this.queryclassRoomName;
				instance.post('/classroom/findClassRoomsCount', params).then((res) => {
					this.recordCount = res.data.data.count;
				})

			},
			getSourceSubs: function() {//查询列表
				var params={
					"beginRow": (this.pageNum - 1) * this.pageSize,
					"pageSize": this.pageSize
				};
				if(this.querySourceId!=""||this.queryclassRoomName!="")
				params.qSchoolId=this.querySourceId;
			    params.qClassRoomName=this.queryclassRoomName;
				instance.post('/classroom/findClassRooms',params ).then((res) => {
					this.gridData = res.data.data;
				})
				this.actionType = "query";
			},
			editSourceSub: function(key) {

				this.$store.commit({
					type: 'setLayerShow',
					layerShow: true
				})
				instance.get('/classroom/findClassRoom/' + key).then((res) => {
					this.sourcesubdetail = res.data.data;
					// this.$set('organizeDetail',res.data.data);
					//console.info( "aaaaaaaaaaaa:"+this.sourcesubdetail);
				})
				this.actionType = "update";
			},
			loadSourceSub: function(key) {
				this.$store.commit({
					type: 'setLayerShow',
					layerShow: true
				})
				instance.get('/classroom/findClassRoom/' + key).then((res) => {
					this.sourcesubdetail = res.data.data;
				})
				this.actionType = "read";
			},
			addSourceSub: function() {
				
				this.$store.commit({
					type: 'setLayerShow',
					layerShow: true
				})
				this.sourcesubdetail.classRoomName=""
                this.sourcesubdetail.descr=""
				this.loginInfo = util.session("loginInfo", void(0));
				instance.get('/school/findUserSchools/' + this.loginInfo.login.userId).then((res) => {
					if(res.data.errcode == '0') {
						if(res.data.data.length==1){
                        this.sourcesubdetail.schoolId=res.data.data[0].id;
						}else{
					    this.sourcesubdetail.schoolId="";
					    this.sourcesubdetail.id="";
						}
						
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}
					
				})
				//this.sourcesubdetail={};
				this.actionType = "add";
			},
			deleteSourceSub: function(key) {

				this.$confirm("您确定删除吗?", "提示", {
						confirmButtonText: "确定",
						cancelButtonText: "取消",
						type: "info"
					})
					.then(() => {
						instance.get('/classroom/removeClassRoom/' + key).then((res) => {
							this.$message.info('数据删除成功！');
							this.getSourceSubs();
						    this.getSourceSubCount();
						})
					})
					.catch(() => {});

				//this.actionType="read";
			},
			saveSourceSub: function(item) {
				item.id ? this.updateSourceSub(item) : this.createSourceSub(item)
			},
			createSourceSub: function(item) {
				instance.post('/classroom/createClassRoom', item).then((res) => {
					if(res.data.errcode == '0') {
						this.$message.info('信息创建成功！');
						this.getSourceSubs();
						this.getSourceSubCount();
						this.setLayerShow(); //关闭窗口
					    this.sourcesubdetail.schoolId="";
					    this.sourcesubdetail.id="";
					    this.sourcesubdetail.classRoomName=""
                        this.sourcesubdetail.descr=""
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}

				})

			},
			updateSourceSub: function(item) {
				//console.info("item:"+JSON.stringify(item));
				instance.post('/classroom/changeClassRoom', item).then((res) => {
					if(res.data.errcode == '0') {
						this.$message.info('信息修改成功！');
						this.getSourceSubs();
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}
					this.setLayerShow(); //关闭窗口
				})
			},
			changePage: function(pageNum) {
				console.info("change-page:" + pageNum);
				this.pageNum = pageNum;
				this.getSourceSubs();
				this.getSourceSubCount();
			},
			findSimpleSources:function(){//
				this.loginInfo = util.session("loginInfo", void(0));
				instance.get('/school/findUserSchools/' + this.loginInfo.login.userId).then((res) => {
					if(res.data.errcode == '0') {
						this.simplesourceslist=res.data.data;
						if(res.data.data.length==1){
                        this.querySourceId=res.data.data[0].id;
                        this.sourcesubdetail.schoolId=res.data.data[0].id;
						}else{
						this.sourcesubdetail.schoolId="";
						}
						
						
						this.query();
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}
					
				})
				
			},
			getModuleActions:function(){
				 let  routeCodes=this.$route.path.split("/");
				  let  routeCode=routeCodes[routeCodes.length-1]; 
					instance.get('/navi/findUserActions2/'+routeCode).then((res) => {
						if(res.data.errcode == '0') {
							this.actionsList=res.data.data;					
						} else {
							//this.$message.error('操作失败！' + res.data.info);
						}
						console.info("json:" + res.data);

					})
			}
			
		},
		created: function() {

		},
		mounted: function() {
			this.getSourceSubs();
			this.getSourceSubCount();
			this.findSimpleSources();
			this.getModuleActions();
			// newAppend('#con',10,1,5,5,loadpages);
			//弹窗显示调用页面
			$('#ue_addclass').click(function(event) {
				$('#templayer').show();
				$(".big_hiddenBakground").show();
				$('.addlayerBox').load('add.html');
			});
			//弹窗关闭按钮
			$('.h5_layerOFFbtn').click(function(event) {
				$('.addlayer').css('display', 'none');
				$(".big_hiddenBakground").css({
					"display": "none"
				});
			});
		}

	};
</script>