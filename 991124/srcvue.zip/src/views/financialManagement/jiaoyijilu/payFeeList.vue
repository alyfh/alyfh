<!--<title>交费记录</title>-->
<style>
	.p_table_la tr>td:nth-child(1):hover {
		cursor: pointer;
		color: #0d8ddb;
	}
</style>
<template>
	<section class="p_chi_con">
		<div class="p_con_sea">
			<ul class="p_con_sea_list p_clear_float">
				<li>
					<span>学员姓名:</span>
					<span>
						<input type="text" class="p_con_form_input" v-model="findBuyCards.qStudentName">
					</span>
				</li>
				<li>
					<span>会员卡号:</span>
					<span>
						<input type="text" class="p_con_form_input" v-model="findBuyCards.qStudentLessonCardCode">
					</span>
				</li>
			</ul>
			<div class="p_btn_group p_clear_float">
				<input type="button" value="查询" @click="query" class="p_btn p_btn_siz_2 p_btn_col_gre p_btn_pos_r">
			</div>
		</div>

		<div class="p_con_tab">
			<!--<div class="p_btn_group p_clear_float">
				<input type="button" value="转班" class="p_btn p_btn_siz_2 p_btn_col_oran p_btn_pos_r" @click="transferClass()">
				<input type="button" value="分班" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r" @click="divideClass()">
			</div>-->
			<div class="p_table_la_over">
				<table class="p_table_la" cellspacing="0" cellpadding="0">
					<tr>
						<!--<td>选择</td>-->
						<td>订单号</td>
						<td>订单时间</td>
						<td>学员姓名</td>
						<td>所属校区</td>
						<td>支付日期</td>
						<td>实收金额</td>
						<td>审核状态</td>
						<td>支付方式</td>
						<td>支付状态</td>
						<td>收款状态</td>
						<td>经办人</td>
						<td v-if="$_has(actionsList,'confirm')">操作</td>
					</tr>
					<tr v-for="(buycard,index) in buycardList">
						<!--<td>
							<input type="checkbox" :value="index" v-model="selectArr">
						</td>-->
						<td @click="linkBuyCardInfo(buycard.id)">{{buycard.orderCode}}</td>
						<!--<td>{{buycard.orderCode}}</td>-->
						<td>{{buycard.orderTime}}</td>
						<td>{{buycard.studentName}}</td>
						<td>{{buycard.schoolName}}</td>
						<td>{{buycard.payDate}}</td>
						<td>{{buycard.money}}</td>
						<td>{{approveStatuses[buycard.approveStatus]}}</td>
						<td>{{payTypes[buycard.payType]}}</td>
						<td>{{payStatuses[buycard.payStatus]}}</td>
						<td>{{receiveStatuses[buycard.receiveStatus]}}</td>
						<td>{{buycard.responsibleRealName}}</td>
						<td v-if="$_has(actionsList,'confirm') && buycard.receiveStatus!='0' && buycard.approveStatus!='3'">
							<input type="button" value="确认收款" v-if="buycard.receiveStatus!='0' && buycard.approveStatus!='3'" @click="confirmAllGathering(buycard.id)" class="p_btn p_btn_siz_3 p_btn_col_k_blu p_btn_pos_r">
						</td>
						<td v-else-if="$_has(actionsList,'confirm')">
							--
						</td>
					</tr>
				</table>
			</div>
		</div>
		<div class='h5_page_container' id="con">
			<page :record-count="recordCount" v-on:change-page="changePage">
			</page>
		</div>
	</section>
</template>
<script>
	import instance from '../../../api/index.js';
	import { mapState } from 'vuex';
	import * as util from '../../../assets/util.js';
	export default {
		computed: {
			// Getting Vuex State from store/index
			...mapState({
				// layerShow: state => state.layerShow,
				pageSize: state => state.pageSize,
				pageLarge: state => state.pageLarge,
				payStatuses: state => state.payStateDict, //支付状态
				payTypes: state => state.paymentDict, //支付方式
				approveStatuses: state => state.approveStatusDict, //审核状态
				receiveStatuses: state => state.receiveStatusDict //收款状态
			})
		},
		data() {
			return {
				actionType: "query",
				selectArr: [],
				actionsList: [], //获取当前用户对当前模块授权操作
				findBuyCards: {}, //查询条件
				buycardList: [], //购课列表
				schoolNames: [], //校区,
				userSchoolId: "", //当前用户所在校区,
				cardNames: [], //会员卡类型
				recordCount: 0,
				pageNum: 1, //当前页码
				linkId: "",
				dialogFormCancelVisible:false,//取消功能 隐藏
				loginInfo: {}, //当前登录信息
				cancelCardDetail: {//取消购课订单数据对象
					id:"",
					cancelReason:""
				}
			};
		},
		components: {
			page: () =>
				import("../../common/page.vue")
		},
		methods: {
			getBuyCardCount: function() { //获取购课数量
				var params = {};
				if(!(JSON.stringify(this.findBuyCards) == "{}")) {
					var result = $.extend(true, params, this.findBuyCards);
				} else {
					var result = params;
				};

				instance.post('/buycard/findBuyCardsCount', result).then((res) => {
					this.recordCount = res.data.data.count;
				});
			},
			getBuyCard: function() { //获取购课列表
				var params = {
					"beginRow": (this.pageNum - 1) * this.pageSize,
					"pageSize": this.pageSize
				};
				if(!(JSON.stringify(this.findBuyCards) == "{}")) {
					var result = $.extend(true, params, this.findBuyCards);
				} else {
					var result = params;
				};
				instance.post('/buycard/findBuyCards', result).then((res) => {
					this.buycardList = res.data.data;
				})
				this.actionType = "query";

			},
			query: function() {
				this.getBuyCard();
				this.getBuyCardCount();
			},
			changePage: function(pageNum) {
				this.pageNum = pageNum;
				this.getBuyCard();
			},
			linkBuyCardInfo: function(id) { //点击跳转详情-订单号
				this.$router.push('/caiwuguanli/jiaoyijilu/findbuycard/' + id);
			},
			
			confirmAllGathering: function(id) { //确认全部收款
				this.$confirm("是否已确认收到全部款项?", "提示", {
						confirmButtonText: "确定",
						cancelButtonText: "取消",
						type: "info"
					})
					.then(() => {
						instance.get('/buycard/receivePayment/' + id).then((res) => {
							if(res.data.errcode == '0') {
								//执行查询方法，重载数据
								this.query();
							} else {
								this.$message.error('操作失败！' + res.data.errmsg);
							}
						})
						
					})
					.catch(() => {});
			},
			getModuleActions: function() {
				let routeCodes = this.$route.path.split("/");
				let routeCode = routeCodes[routeCodes.length - 1];
				instance.get('/navi/findUserActions2/' + routeCode).then((res) => {
					if(res.data.errcode == '0') {
						this.actionsList = res.data.data;
					} else {
						//this.$message.error('操作失败！' + res.data.info);
					}
					console.info("json:" + res.data);

				})
			}
			

		},
		mounted: function() {
			this.getBuyCard();
			this.getBuyCardCount();
			this.getModuleActions();
		}
	};
</script>