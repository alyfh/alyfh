<!--<title>退费记录</title>-->
<style>
	.p_table_la tr>td:nth-child(1):hover {
		cursor: pointer;
		color: #0d8ddb;
	}
</style>
<template>
	<section class="p_chi_con">
		<div class="p_con_sea">
			<ul class="p_con_sea_list p_clear_float">
				<li>
					<span>订单号:</span>
					<span>
            <input type="text" class="p_con_form_input" v-model="findRefunds.qOrderCode">
          </span>
				</li>
				<li>
					<span>学员姓名:</span>
					<span>
            <input type="text" class="p_con_form_input" v-model="findRefunds.qStudentName">
          </span>
				</li>

				<!--<li>
					<span>会员卡号:</span>
					<span>
            <input type="text" class="p_con_form_input" v-model="findRefunds.qCardCode">
          </span>
				</li>-->
				<li>
					<span>所属校区:</span>
					<span>

                <select name=""  class="p_con_form_select" v-model="findRefunds.qSchoolId">
                 <option value="">-请选择-</option>
                  <option v-for="sName in schoolNames" :value="sName.id">{{ sName.schoolName }}</option>
                </select>
          </span>
				</li>
				<li>
					<span>支付方式:</span>
					<span>
            <select name="" id="" class="p_con_form_select" v-model="findRefunds.qPayType">
                    <!--<option value="">-</option>-->
                    <option value="">-请选择-</option>
                    <option v-for = "(item,key) in reTypes" :value="key">{{item}}</option>
                  </select>
          </span>
				</li>
				<li>
					<span>支付状态:</span>
					<span>
			            <select name="" id="" class="p_con_form_select" v-model="findRefunds.qPayStatus">
			              <!--<option value="">-</option>-->
			             <option value="">-请选择-</option>
			              <option v-for = "(item,key) in reStatuses" :value="key">{{item}}</option>
			            </select>
			        </span>
				</li>
				<li>
					<span>审核状态:</span>
					<span>
			            <select name="" id="" class="p_con_form_select" v-model="findRefunds.qApproveStatus">
			              <!--<option value="">-</option>-->
			             <option value="">-请选择-</option>
			              <option v-for = "(item,key) in approveStatusDict" :value="key">{{item}}</option>
			            </select>
			        </span>
				</li>
				<li>
					<span>订单时间:</span>
					<span>
            <el-date-picker type="date"  value-format="yyyy-MM-dd" placeholder="Pick a date" style="width:100%" v-model="findRefunds.qBeginOrderTime"></el-date-picker>
          </span>
				</li>
				<li>
					<span>至:</span>
					<span>
            <el-date-picker type="date"  value-format="yyyy-MM-dd" placeholder="Pick a date" style="width:100%" v-model="findRefunds.qEndOrderTime"></el-date-picker>
          </span>
				</li>
				<li>
					<span>退费日期:</span>
					<span>
            <el-date-picker type="date"  value-format="yyyy-MM-dd" placeholder="Pick a date" style="width:100%" v-model="findRefunds.qBeginRefundDate"></el-date-picker>
          </span>
				</li>
				<li>
					<span>至:</span>
					<span>
            <el-date-picker type="date"  value-format="yyyy-MM-dd" placeholder="Pick a date" style="width:100%" v-model="findRefunds.qEndRefundDate"></el-date-picker>
          </span>
				</li>
			</ul>
			<div class="p_btn_group p_clear_float">
				<input type="button" value="查询" @click="query" class="p_btn p_btn_siz_2 p_btn_col_gre p_btn_pos_r">
			</div>
		</div>

		<div class="p_con_tab">
			<!--<div class="p_btn_group p_clear_float">
        <input type="button" value="转班" class="p_btn p_btn_siz_2 p_btn_col_oran p_btn_pos_r" @click="transferClass()">
        <input type="button" value="分班" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r" @click="divideClass()">
      </div>-->
			<div class="p_table_la_over">
				<table class="p_table_la" cellspacing="0" cellpadding="0">
					<tr>
						<td>订单号</td>
						<td>订单时间</td>
						<td>学员姓名</td>
						<td>所属校区</td>
						<td>退费日期</td>
						<td>退费金额</td>
						<td>支付方式</td>
						<td>支付状态</td>
						<td>审核状态</td>
						<td>经办人</td>
					</tr>
					<tr v-for="(refund,index) in refundList">
						<!--<router-link to="/buycard" tag="td">{{studentdata.studentLessonCard.studentName}}</router-link>-->
						<!--<td @click="linkStudentInfo(buycard.studentLessonCard.studentId)">{{studentdata.studentLessonCard.studentName}}</td>-->
						<td>{{refund.orderCode}}</td>
						<td>{{refund.orderTime}}</td>
						<td>{{refund.studentName}}</td>
						<td>{{refund.schoolName}}</td>
						<td>{{refund.refundDate}}</td>
						<td>{{refund.refundMoney}}</td>
						<td>{{reTypes[refund.payType]}}</td>
						<td>{{reStatuses[refund.payStatus]}}</td>
						<td>{{approveStatusDict[refund.approveStatus]}}</td>
						<td>{{refund.actorRealName}}</td>
					</tr>
				</table>
			</div>
		</div>
		<div class='h5_page_container' id="con">
			<page :record-count="recordCount" v-on:change-page="changePage">
			</page>
		</div>
	</section>
</template>
<script>
	import instance from '../../../api/index.js';
	import { mapState } from 'vuex';
	import * as util from '../../../assets/util.js';
	export default {
		computed: {
			// Getting Vuex State from store/index
			...mapState({
				// layerShow: state => state.layerShow,
				pageSize: state => state.pageSize,
				pageLarge: state => state.pageLarge,
				reTypes: state => state.paymentDict, //支付状态
				reStatuses: state => state.payStateDict, //支付方式
				approveStatusDict: state => state.approveStatusDict, //审核状态
			})
		},
		data() {
			return {
				actionType: "query",
				selectArr: [],
				findRefunds: {}, //查询条件
				refundList: [], //购课列表
				schoolNames: [], //校区,
				userSchoolId: "", //当前用户所在校区,
				recordCount: 0,
				pageNum: 1, //当前页码
				linkId: "",
				dialogFormCancelVisible: false, //取消功能 隐藏
				dialogFormFenLei: {
					name: ''
				},
				loginInfo: {} //当前登录信息

			};
		},
		components: {
			page: () =>
				import("../../common/page.vue")
		},
		methods: {
			getUserSchool: function() { //获取当前用户校区字典
				//获取当前登录人
				this.loginInfo = util.session("loginInfo", void(0));
				instance.post('/school/findUserSchools/' + this.loginInfo.login.userId, {}).then((res) => {
					if(res.data.data != null && res.data.data != "") {
						this.schoolNames = res.data.data;
						this.userSchoolId = res.data.data[0].id;
						if(res.data.data!=null && res.data.data.length==1){
							this.findRefunds.qSchoolId = this.userSchoolId;
						}
						this.getRefund();
						this.getRefundCount();
					}

				})

			},
			getCard: function() { //获取会员卡数据
				instance.post('/lessoncard/findSimpleList', {}).then((res) => {
					this.cardNames = res.data.data;
				})
			},
			getRefundCount: function() { //获取购课数量
				var params = {};
				if(!(JSON.stringify(this.findRefunds) == "{}")) {
					var result = $.extend(true, params, this.findRefunds);
				} else {
					var result = params;
				};

				instance.post('/refund/findRefundsCount', result).then((res) => {
					this.recordCount = res.data.data.count;
				});
			},
			getRefund: function() { //获取退费列表
				var params = {
					"beginRow": (this.pageNum - 1) * this.pageSize,
					"pageSize": this.pageSize
				};
				if(!(JSON.stringify(this.findRefunds) == "{}")) {
					var result = $.extend(true, params, this.findRefunds);
				} else {
					var result = params;
				};
				instance.post('/refund/findRefunds', result).then((res) => {
					this.refundList = res.data.data;
				})
				this.actionType = "query";

			},
			query: function() {
				this.getRefund();
				this.getRefundCount();

			},
			changePage: function(pageNum) {
				//        console.info("change-page:" + pageNum);
				this.pageNum = pageNum;
				this.getRefund();
			},
			linkStudentInfo: function(id) { //学生姓名点击跳转详情
				this.$router.push('/xueyuanguanli/studentinfo/' + id);
			},
			editCard: function(id) { //修改

				// this.$router.push('/xueyuanguanli/buyCard/'+id);
				this.$router.push('/caiwuguanli/dingdanshenhe/editrefund/' + id);

			},
			cancelCard: function(id) { //取消

				// this.$router.push('/xueyuanguanli/buyCard/'+id);
				this.$router.push({
					path: `/zhaoshengguanli/readAdvice/${id}`
				});

			},

		},
		mounted: function() {
			this.getUserSchool(); //当前人所在校区
			this.getCard(); //会员卡类型

			// this.getSourceSub();//来源小类
			//弹窗显示调用页面
			$('#ue_addclass').click(function(event) {
				$('#templayer').show();
				$(".big_hiddenBakground").show();
				$('.addlayerBox').load('add.html');
			});
			//弹窗关闭按钮
			$('.h5_layerOFFbtn').click(function(event) {
				$('.addlayer').css('display', 'none');
				$(".big_hiddenBakground").css({
					"display": "none"
				});
			});
		}
	};
</script>