<!--<title>业务办理</title>-->
<style scoped>
	.p_table_la tr>td:nth-child(1):hover {
		cursor: pointer;
		color: #0d8ddb;
	}
</style>
<template>
	<section class="p_chi_con">
		<div class="p_con_sea">
			<ul class="p_con_sea_list p_clear_float">
				<li>
					<span>学员姓名:</span>
					<span>
						<input type="text" class="p_con_form_input" v-model="findStudents.qStudentName">
					</span>
				</li>
				<li>
					<span>会员卡号:</span>
					<span>
						<input type="text" class="p_con_form_input" v-model="findStudents.qCardCode">
					</span>
				</li>
				<li>
					<span>所属校区:</span>
					<span>
			            <select name=""  class="p_con_form_select" v-model="findStudents.qSchoolId" @change="getQueryInfo(findStudents.qSchoolId)">
			            	<option value="">-请选择-</option>
			            	<option v-for="sName in schoolNames" :value="sName.id">{{ sName.schoolName }}</option>
			            </select>
					</span>
				</li>
				<li>
					<span>班级:</span>
					<span>
			            <select name=""  class="p_con_form_select" v-model="findStudents.qClassId">
			            	<option value="">-请选择-</option>
			            	<option v-for="sName in classs" :value="sName.id">{{ sName.className }}</option>
			            </select>
					</span>
				</li>
				<li>
					<span>课程大类:</span>
					<span>
			            <select name="" id="" class="p_con_form_select" v-model="findStudents.qCourseId" @change="getClassSub(findStudents.qCourseId)">
			            	<option>-请选择-</option>
			            	<option v-for="className in classNames" :value="className.id">{{className.courseName}}</option> 
			            </select>
					</span>
				</li>
				<li>
					<span>课程小类:</span>
					<span>
			            <select name="" id="" class="p_con_form_select" v-model="findStudents.qCourseSubId">
			            	<option value="">-请选择-</option>
			            	<option v-for="classNameSub in classNameSubs" :value="classNameSub.id">{{classNameSub.courseSubName}}</option>
			            </select>
					</span>
				</li>

			</ul>
			<div class="p_btn_group p_clear_float">
				<input type="button" value="查询" @click="query" class="p_btn p_btn_siz_2 p_btn_col_gre p_btn_pos_r">
			</div>
		</div>

		<div class="p_con_tab">
			<div class="p_btn_group p_clear_float">
			</div>
			<div class="p_table_la_over">
				<table class="p_table_la" cellspacing="0" cellpadding="0">
					<tr>
						<td>学员姓名</td>
						<td>会员卡号</td>
						<td>所属校区</td>
						<td>班级</td>
						<td>课程大类</td>
						<td>课程小类</td>
						<td>已消耗课时</td>
						<td v-if="$_has(actionsList,'detail')">操作</td>
					</tr>
					<!--所有学员-->
					<template v-for="(studentdata,i) in studentList">
						<tr>
							<td :rowspan="studentdata.studentName_span" v-if="studentdata.studentName_dis==false" @click="linkStudentInfo(studentdata.studentId)">{{studentdata.studentName}}</td>
							<td :rowspan="studentdata.cardCode_span" v-if="studentdata.cardCode_dis==false">{{studentdata.cardCode}}</td>
							<td :rowspan="studentdata.schoolName_span" v-if="studentdata.schoolName_dis==false">{{studentdata.schoolName}}</td>
							<td :rowspan="studentdata.className_span" v-if="studentdata.className_dis==false">{{studentdata.className}}</td>
							<td :rowspan="studentdata.courseName_span" v-if="studentdata.courseName_dis==false">{{studentdata.courseName}}</td>
							<td :rowspan="studentdata.courseSubName_span" v-if="studentdata.courseSubName_dis==false">{{studentdata.courseSubName}}</td>
							<td>{{studentdata.expendHour}}</td>
							<td v-if="$_has(actionsList,'detail')">
								<input type="button" v-if="$_has(actionsList,'detail')" value="详情" class="p_btn p_btn_siz_3 p_btn_col_k_blu p_btn_pos_r" @click="linkStudentInfo(studentdata.studentId)">
							</td>
						</tr>
					</template>

				</table>
			</div>
		</div>
		<div class='h5_page_container' id="con">
			<page :record-count="recordCount" v-on:change-page="changePage">
			</page>
		</div>
	</section>
</template>
<script>
	import instance from '../../../api/index.js';
	import { mapState } from 'vuex';
	import * as util from '../../../assets/util.js';
	export default {
		computed: {
			// Getting Vuex State from store/index
			...mapState({
				// layerShow: state => state.layerShow,
				pageSize: state => state.pageSize,
				pageLarge: state => state.pageLarge
			})
		},
		data() {
			return {
				actionType: "query",
				selectArr: [],
				actionsList: [], //获取当前用户对当前模块授权操作
				findStudents: { //查询条件
				},
				studentList: [], //学员列表
				schoolNames: [], //校区,
				userSchoolId: "", //当前用户所在校区,
				classs: [], //班级
				classNames: [], //课程大类
				classNameSubs: [], //课程小类
				counselorNames: [], //咨询师
				consultants: [], //课程顾问
				teachers: [], //授课教师
				recordCount: 0,
				pageNum: 1, //当前页码
				linkId: ""

			};
		},
		components: {
			page: () =>
				import("../../common/page.vue")
		},
		methods: {

			query: function() {
				this.getStudent();
				this.getStudentCount();

			},
			getUserSchool: function() { //获取当前用户校区字典
				//获取当前登录人
				this.loginInfo = util.session("loginInfo", void(0));
				instance.post('/school/findUserSchools/' + this.loginInfo.login.userId, {}).then((res) => {
					if(res.data.data != null && res.data.data != "") {
						this.schoolNames = res.data.data;
						this.userSchoolId = res.data.data[0].id;
						if(res.data.data!=null && res.data.data.length==1){
							this.findStudents.qSchoolId = this.userSchoolId;
						}
						this.getStudent();
						this.getStudentCount();
					}
				})

			},
			getSchool: function() { //获取校区数据
				instance.post('/school/findSimpleSchools', {}).then((res) => {
					this.schoolNames = res.data.data;
				})
			},
			getQueryInfo: function(schoolId) { //联动查询咨询师，课程顾问，班级，授课教师
				this.getConsult(schoolId);
				this.getconsultant(schoolId);
				//this.getTeacher(schoolId);
				//this.getClasss(schoolId);

			},
			getClasss: function() { //获取班级列表
				instance.post('/class/findSimpleClasses', {

				}).then((res) => {
					this.classs = res.data.data;
				})
			},
			getConsult: function(schoolId) { //获取咨询师列表
				instance.post('/user/findSimpleCounselors', {
					qSchoolId: schoolId
				}).then((res) => {
					this.counselorNames = res.data.data;
				})
			},
			getconsultant: function(schoolId) { //获取课程顾问列表
				instance.post('/user/findSimpleCourseCounselors', {
					qSchoolId: schoolId
				}).then((res) => {
					this.consultants = res.data.data;
				})
			},
			getTeacher: function(schoolId) { //获取授课教师列表
				instance.post('/teacher/findSimpleTeachers', {
					qSchoolId: schoolId
				}).then((res) => {
					this.teachers = res.data.data;
				})
			},
			getClass: function() { //获取课程大类数据
				// course/findCourses
				// /course/findSimpleCourse
				instance.post('/course/findCourses', {}).then((res) => {
					this.classNames = res.data.data;
				})
			},
			getClassSub: function(id) { //获取课程小类数据
				// /course/findSimpleCourseSubs
				instance.post('/course/findSimpleCourseSubs', {
					qCourseId: id
				}).then((res) => {
					this.classNameSubs = res.data.data;
					// console.info(res.data);
				})
			},
			getStudent: function() { //获取学生列表
				var params = {
					"beginRow": (this.pageNum - 1) * this.pageSize,
					"pageSize": this.pageSize
				};
				// console.log(this.findStudents.qSchoolId);
				// console.log(JSON.stringify(this.findStudents)=="{}");
				if(!(JSON.stringify(this.findStudents) == "{}")) {
					//alert(true);
					var result = $.extend(true, params, this.findStudents);
				} else {
					//alert(false)
					var result = params;
				};
				instance.post('/lesson/findStudentLessonRecords', result).then((res) => {
					this.studentList = res.data.data;
					this.combineCell();
				})
				this.actionType = "query";

			},
			getStudentCount: function() { //获取学生数量
				var params = {};
				if(!(JSON.stringify(this.findStudents) == "{}")) {
					var result = $.extend(true, params, this.findStudents);
				} else {
					var result = params;
				};
				instance.post('/lesson/findStudentLessonRecordsCount', result).then((res) => {
					this.recordCount = res.data.data.count;
				});
			},
			changePage: function(pageNum) {
				console.info("change-page:" + pageNum);
				this.pageNum = pageNum;
				this.getStudent();
			},
			linkStudentInfo: function(id) { //学生姓名点击跳转详情
				this.$router.push('/caiwuguanli/studentinfo/' + id + "/keshixiaohao");
				//				this.$router.push('/xueyuanguanli/studentinfo/' + id + "/keshixiaohao");
			},
			editInfo: function(id) { //编辑
				this.$router.push('/xueyuanguanli/editStudent/' + id);
			},
			combineCell: function() { //行单元格合并
				let arr_field = ["studentName", "cardCode", "schoolName", "className", "courseName", "courseSubName"];
				if(this.studentList != null) {
					for(let field in arr_field) {
						var k = 0;
						while(k < this.studentList.length) {
							this.studentList[k][arr_field[field] + '_span'] = 1;
							this.studentList[k][arr_field[field] + '_dis'] = false;
							for(var i = k + 1; i <= this.studentList.length - 1; i++) {
								if(this.studentList[k]['studentId'] == this.studentList[i]['studentId'] && this.studentList[k][arr_field[field]] == this.studentList[i][arr_field[field]] && this.studentList[k][arr_field[field]] != '') {
									this.studentList[k][arr_field[field] + '_span']++;
									this.studentList[k][arr_field[field] + '_dis'] = false;
									this.studentList[i][arr_field[field] + '_span'] = 1;
									this.studentList[i][arr_field[field] + '_dis'] = true;
								} else {
									break;
								}
							}
							k = i;
						}
					}
				}

				return this.studentList;
			},
			getModuleActions: function() {
				let routeCodes = this.$route.path.split("/");
				let routeCode = routeCodes[routeCodes.length - 1];
				instance.get('/navi/findUserActions2/' + routeCode).then((res) => {
					if(res.data.errcode == '0') {
						this.actionsList = res.data.data;
					} else {
						//this.$message.error('操作失败！' + res.data.info);
					}
					console.info("json:" + res.data);

				})
			}
		},
		mounted: function() {
			//this.getSchool(); //校区
			this.getUserSchool();
			this.getClass(); //课程大类
			this.getClasss(); //班级
			//this.getConsult();//咨询师
			// this.getTeacher();//授课教师
			// this.getconsultant();//课程顾问

			//this.getStudent();
			//this.getStudentCount(); //数量
			this.getModuleActions();
		}
	};
</script>