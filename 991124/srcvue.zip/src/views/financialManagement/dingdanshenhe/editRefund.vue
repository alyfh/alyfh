<!--<title>审核会员卡</title>-->

<template>
	<form id="" method="post" action="" class="ue_form_add">
		<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
        	<span>退费订单详情</span>
    	</h3>
		<ul class='h5_02_info_per_addlist'>
			<li>
				<span></span>
				<span>订单号:</span>
				<span>
    				<!--<input type="text" class='per_addperson_txt' readonly v-model="cardDetail.orderCode">-->
    				{{refundDetail.orderCode}}
				</span>
			</li>
			<li>
				<span></span>
				<span>订单时间:</span>
				<span>
    				<!--<input type="text" class='per_addperson_txt' readonly v-model="cardDetail.orderTime">-->
    				{{refundDetail.orderTime}}
				</span>
			</li>
			<li>
				<span></span>
				<span>所属校区:</span>
				<span>
    				<!--<input type="text" class='per_addperson_txt' readonly v-model="cardDetail.schoolName">-->
    				{{refundDetail.schoolName}}
				</span>
			</li>
			<li>
				<span></span>
				<span>学生姓名:</span>
				<span>
    				<!--<input type="text" class='per_addperson_txt' readonly v-model="cardDetail.studentName">-->
    				{{refundDetail.studentName}}
				</span>
			</li>
			<!--<li>
				<span></span>
				<span>会员卡类型:</span>
				<span>
					<input type="text" class='per_addperson_txt' readonly v-model="cardDetail.cardName">
					{{refundDetail.cardName}}
		             <select  class='per_addperson_txt' v-bind:readonly="isReadOnly"  v-model="cardDetail.cardId" >
		               <option  v-for="card in cardInfo" :value="card.id">{{card.cardName}}</option>
		             </select>
          		</span>
			</li>-->
			<li>
				<span></span>
				<span>会员卡号:</span>
				<span>
    				<!--<input type="text" class='per_addperson_txt' readonly v-model="cardDetail.studentLessonCardCode">-->
    				{{refundDetail.cardCode}}
				</span>
			</li>
			<li>
				<span></span>
				<span>实收金额:</span>
				<span>
    				<!--<input type="text" class='per_addperson_txt' readonly v-model="cardDetail.studentName">-->
    				{{refundDetail.sumMoney}}
				</span>
			</li>
			<li>
				<span></span>
				<span>总课时:</span>
				<span>
    				<!--<input type="text" class='per_addperson_txt' readonly v-model="cardDetail.studentName">-->
    				{{refundDetail.sumHour}}
				</span>
			</li>
			<li>
				<span></span>
				<span>已消耗课时:</span>
				<span>
    				<!--<input type="text" class='per_addperson_txt' readonly v-model="cardDetail.studentName">-->
    				{{refundDetail.expendedHour}}
				</span>
			</li>
			<li>
				<span></span>
				<span>剩余课时:</span>
				<span>
    				<!--<input type="text" class='per_addperson_txt' readonly v-model="cardDetail.studentName">-->
    				{{refundDetail.hour}}
				</span>
			</li>
			<li>
				<span></span>
				<span>退费课时:</span>
				<span>
					<input type="text" class='per_addperson_txt' v-model="refundDetail.refundHour" v-validate="'numeric'" name="已消耗课时">
				</span>
			</li>
			<li>
				<span></span>
				<span>退费金额:</span>
				<span>
					<input type="text" class='per_addperson_txt' v-model="refundDetail.refundMoney" v-validate="'numeric'" name="已消耗课时">
				</span>
			</li>

			<li>
				<span></span>
				<span>支付方式:</span>
				<span>
					<!--<input type="text" class='per_addperson_txt' readonly v-model="paymentDict[cardDetail.payType]">-->
					<!--{{paymentDict[refundDetail.payType]}}-->
                    <select name="" id="" class='per_addperson_txt'  v-model="refundDetail.payType">
                    	 <option v-for = "(item,key) in paymentDict" :value="key">{{item}}</option>
                    </select>
                </span>
			</li>
			<li>
				<span></span>
				<span>支付状态:</span>
				<span>
					<!--<input type="text" class='per_addperson_txt' readonly v-model="payStateDict[cardDetail.payStatus]">-->
					<!--{{payStateDict[refundDetail.payStatus]}}-->
    				<select name="" id="" class='per_addperson_txt'  v-model="refundDetail.payStatus">
    					<option v-for = "(item,key) in payStateDict" :value="key">{{item}}</option>
    				</select>
    			</span>
			</li>
			<li>
				<span></span>
				<span>退费日期:</span>
				<span>
					 <el-date-picker type="date"  value-format="yyyy-MM-dd" placeholder="Pick a date" style="width:100%" v-model="refundDetail.refundDate"></el-date-picker>
    				<!--{{cardDetail.orderTime}}-->
				</span>
			</li>
			<li>
				<span></span>
				<span>经办人:</span>
				<span>
					<!--<input type="text" class='per_addperson_txt' readonly  v-model="cardDetail.responsibleRealName">-->
					{{refundDetail.actorRealName}}
				</span>
			</li>
			<li>
				<span></span>
				<span>开户行:</span>
				<span>
					<input type="text" class='per_addperson_txt'  v-model="refundDetail.bankName">
					<!--{{refundDetail.bankName}}-->
				</span>
			</li>
			<li>
				<span></span>
				<span>银行账户:</span>
				<span>
					<input type="text" class='per_addperson_txt'  v-model="refundDetail.bankAccount">
					<!--{{refundDetail.bankAccount}}-->
				</span>
			</li>
			<li>
				<span></span>
				<span>户名:</span>
				<span>
					<input type="text" class='per_addperson_txt'  v-model="refundDetail.bankUsername">
					<!--{{refundDetail.bankUsername}}-->
				</span>
			</li>
			<li class="per_addperson_li_w per_addperson_li_h2">
				<span></span>
				<span>备注:</span>
				<span>
                   <textarea name="" id="" cols="30" rows="4" placeholder="" class='per_addperson_texarea'  v-model="refundDetail.descr"></textarea>
                </span>
			</li>
		</ul <br class="p_zwf">
		<div class="p_btn_group p_clear_float">
			<!--<input type="button" value="返回" class="p_btn p_btn_siz_2 p_btn_col_red p_btn_pos_r">-->
			<input type="button" value="返回" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r" @click="returnCard(refundDetail)">
			<input type="button" value="确定" class="p_btn p_btn_siz_2 p_btn_col_ora p_btn_pos_r" @click="saveInfo(refundDetail)">
		</div>
	</form>
</template>
<script>
	import instance from '../../../api/index.js';
	import { mapState } from 'vuex';
	export default {
		data() {
			return {
				refundDetail: {
					orderCode: "",
					sumMoney: "",
					expendedHour: "",
					discountMoney: "",
					cardCode: "",
					payStatus: ""
				},
				cardInfo: [], //会员卡
				errcode: "",
			}
		},
		created: function() {
			this.getOrderBuyCard(this.$route.params.id);
		},
		computed: {　
			// Getting Vuex State from store/index
			...mapState({
				payStateDict: state => state.payStateDict,
				paymentDict: state => state.refundDict,
				approveStatuses: state => state.approveStatusDict //审核状态
			}),
			expendedHour() { //已消耗课时
				return this.refundDetail.expendedHour
			}
		},
		watch: {
			expendedHour(curVal, oldVal) {　
				if(this.refundDetail.hour != "" && curVal != "")　
					this.refundDetail.sumHour = parseFloat(this.refundDetail.hour) + parseFloat(curVal);　
				else　　　
					this.refundDetail.sumHour = "";　　　　　　　　　
			}

		},
		methods: {
			getCard: function() { //会员卡类型
				instance.post('/lessoncard/findSimpleList', {}).then((res) => {
					this.cardInfo = res.data.data;
				})
			},
			saveInfo: function(data) { //保存
				data.approveStatus='2';
				instance.post('/refund/changeRefund', data).then((res) => {
					if(res.data.errcode == '0') {
						//this.cardDetail.id = res.data.data.id;
						this.$message.info('信息修改成功！');
						this.$router.push('/caiwuguanli/dingdanshenhe/tuifeidingdan');
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}

				})
			},
			returnCard: function(data) { //返回
				this.$router.push('/caiwuguanli/dingdanshenhe/tuifeidingdan');
			},
			getOrderBuyCard(id) { //获取退费订单信息
				instance.get('/refund/findRefund/' + id).then((res) => {
					if(res.data.errcode == '0') {
						this.refundDetail = res.data.data;
						/*
						this.cardDetail.orderCode = res.data.data.orderCode;
						this.cardDetail.orderTime = res.data.data.orderTime;
						this.cardDetail.schoolName = res.data.data.schoolName;
						this.cardDetail.schoolId = res.data.data.schoolId;
						this.cardDetail.responsibleRealName = res.data.data.responsibleRealName;
						this.cardDetail.responsibleUserId = res.data.data.responsibleUserId;
						//this.cardDetail.id = res.data.data.id;
						this.cardDetail.studentName = res.data.data.studentName;
						*/
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}
				})
			}

		},
		mounted: function() {
			this.getCard();
		}
	};
</script>