<!--<title>购课订单</title>-->

<template>
	<section class="p_chi_con">
		<div class="p_con_sea">
			<ul class="p_con_sea_list p_clear_float">
				<li>
					<span>学员姓名:</span>
					<span>
						<input type="text" class="p_con_form_input" v-model="findBuyCards.qStudentName">
					</span>
				</li>
				<li>
					<span>会员卡号:</span>
					<span>
						<input type="text" class="p_con_form_input" v-model="findBuyCards.qStudentLessonCardCode">
					</span>
				</li>
				<li>
					<span>所属校区:</span>
					<span>
						<!--<select class="p_con_form_select" name="" v-model="findBuyCards.qSchoolId">
							<template v-for="sName in schoolNames">
								<option :value="sName.id" v-if="userSchoolId == sName.id" selected>
									{{ sName.schoolName}}
								</option>
								<option :value="sName.id" v-else>
									{{ sName.schoolName }}
								</option>
							</template>
						</select>-->


		            <select name=""  class="p_con_form_select" v-model="findBuyCards.qSchoolId">
		              <option value="">-请选择-</option>
		              <option v-for="sName in schoolNames" :value="sName.id">{{ sName.schoolName }}</option>
		            </select>
					</span>
				</li>
				<li>
					<span>会员卡类型:</span>
					<span>
			            <select name="" id="" class="p_con_form_select" v-model="findBuyCards.qCardId">
			                <option value="">-请选择-</option>
			                <option v-for="card in cardNames" :value="card.id">{{card.cardName}}</option>
			            </select>
					</span>
				</li>
				<li>
					<span>审核状态:</span>
					<span>
			            <select name="" id="" class="p_con_form_select" v-model="findBuyCards.qApproveStatus">
			              <option value="">-请选择-</option>
			              <option v-for = "(item,key) in approveStatuses" :value="key">{{item}}</option>
			            </select>
					</span>
				</li>
				<li>
					<span>支付方式:</span>
					<span>
						<select name="" id="" class="p_con_form_select" v-model="findBuyCards.qPayType">
			              <option value="">-请选择-</option>
			              <option v-for = "(item,key) in payTypes" :value="key">{{item}}</option>
            			</select>
					</span>
				</li>
				<li>
					<span>支付状态:</span>
					<span>
						<select name="" id="" class="p_con_form_select" v-model="findBuyCards.qPayStatus">
              <option value="">-请选择-</option>
              <option v-for = "(item,key) in payStatuses" :value="key">{{item}}</option>
            </select>
					</span>
				</li>
				<li>
					<span>订单号:</span>
					<span>
						<input type="text" class="p_con_form_input" v-model="findBuyCards.qOrderCode">
					</span>
				</li>
				<li>
					<span>订单时间:</span>
					<span>
						<el-date-picker type="date"  value-format="yyyy-MM-dd" placeholder="Pick a date" style="width:100%" v-model="findBuyCards.qBeginOrderTime"></el-date-picker>
					</span>
				</li>
				<li>
					<span>至:</span>
					<span>
						<el-date-picker type="date"  value-format="yyyy-MM-dd" placeholder="Pick a date" style="width:100%" v-model="findBuyCards.qEndOrderTime"></el-date-picker>
					</span>
				</li>
				<li>
					<span>支付日期:</span>
					<span>
						<el-date-picker type="date"  value-format="yyyy-MM-dd" placeholder="Pick a date" style="width:100%" v-model="findBuyCards.qBeginPayDate"></el-date-picker>
					</span>
				</li>
				<li>
					<span>至:</span>
					<span>
						<el-date-picker type="date"  value-format="yyyy-MM-dd" placeholder="Pick a date" style="width:100%" v-model="findBuyCards.qEndPayDate"></el-date-picker>
					</span>
				</li>
			</ul>
			<div class="p_btn_group p_clear_float">
				<input type="button" value="查询" @click="query" class="p_btn p_btn_siz_2 p_btn_col_gre p_btn_pos_r">
			</div>
		</div>

		<div class="p_con_tab">
			<!--<div class="p_btn_group p_clear_float">
				<input type="button" value="转班" class="p_btn p_btn_siz_2 p_btn_col_oran p_btn_pos_r" @click="transferClass()">
				<input type="button" value="分班" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r" @click="divideClass()">
			</div>-->
			<div class="p_table_la_over">
				<table class="p_table_la" cellspacing="0" cellpadding="0">
					<tr>
						<!--<td>选择</td>-->
						<td>订单号</td>
						<td>订单时间</td>
						<td>学员姓名</td>
						<td>所属校区</td>
						<td>会员卡类型</td>
						<td>有效期</td>
						<td>会员卡号</td>
						<td>原价</td>
						<td>现价</td>
						<td>优惠金额</td>
						<td>实收金额</td>
						<td>课时</td>
						<td>赠送课时</td>
						<td>总课时</td>
						<td>审核状态</td>
						<td>支付方式</td>
						<td>支付状态</td>
						<td>经办人</td>
						<td v-if="($_has(actionsList,'approve') || $_has(actionsList,'cancel'))">操作</td>
					</tr>
					<tr v-for="(buycard,index) in buycardList">
						<!--<td>
							<input type="checkbox" :value="index" v-model="selectArr">
						</td>-->
						<!--<router-link to="/buycard" tag="td">{{studentdata.studentLessonCard.studentName}}</router-link>-->
						<!--<td @click="linkStudentInfo(buycard.studentLessonCard.studentId)">{{studentdata.studentLessonCard.studentName}}</td>-->
						<td>{{buycard.orderCode}}</td>
						<td>{{buycard.orderTime}}</td>
						<td>{{buycard.studentName}}</td>
						<td>{{buycard.schoolName}}</td>
						<td>{{buycard.cardName}}</td>
						<td>{{buycard.validDate}}</td>
						<td>{{buycard.studentLessonCardCode}}</td>
						<td>{{buycard.sourceMoney}}</td>
						<td>{{buycard.currentMoney}}</td>
						<td>{{buycard.discountMoney}}</td>
						<td>{{buycard.money}}</td>
						<td>{{buycard.hour}}</td>
						<td>{{buycard.giveHour}}</td>
						<td>{{buycard.sumHour}}</td>
						<td>{{approveStatuses[buycard.approveStatus]}}</td>
						<td>{{payTypes[buycard.payType]}}</td>
						<td>{{payStatuses[buycard.payStatus]}}</td>
						<td>{{buycard.responsibleRealName}}</td>
						<td v-if="($_has(actionsList,'approve') || $_has(actionsList,'cancel')) && buycard.approveStatus!='2' && buycard.approveStatus!='3'">
							<input  type="button" value="详情" @click="linkdetails(buycard.id)" class="p_btn p_btn_siz_2 p_btn_col_k_blu p_btn_pos_r">
							<input type="button" value="订单审核" v-if="$_has(actionsList,'approve')" @click="approveCard(buycard.id)" class="p_btn p_btn_siz_3 p_btn_col_k_blu p_btn_pos_r">
							<!--<input type="button" value="修改" v-if="buycard.approveStatus!='2' && buycard.approveStatus!='3'" @click="editCard(buycard.id)" class="p_btn p_btn_siz_3 p_btn_col_k_oran p_btn_pos_r">-->
							<input type="button" value="订单取消" v-if="$_has(actionsList,'cancel')" @click="cancelCard(buycard.id)" class="p_btn p_btn_siz_3 p_btn_col_k_red p_btn_pos_r">
						</td>
						<td v-else-if="$_has(actionsList,'approve') || $_has(actionsList,'cancel')">
							<input  type="button" value="详情" @click="linkdetails(buycard.id)" class="p_btn p_btn_siz_2 p_btn_col_k_blu p_btn_pos_r">
						</td>
					</tr>
				</table>
			</div>
		</div>
		<div class='h5_page_container' id="con">
			<page :record-count="recordCount" v-on:change-page="changePage">
			</page>
		</div>
		<!-- 取消弹框 -->
		<el-dialog title="" :visible.sync="dialogFormCancelVisible">
			取消原因：
			<el-input type="textarea" v-model="cancelCardDetail.cancelReason"></el-input>
			<span slot="footer" class="dialog-footer">
				<el-button type="primary"  @click="saveCancelInfo(cancelCardDetail)">确定</el-button>
		        <el-button @click.native="dialogFormCancelVisible = false">取 消</el-button>
	        </span>
		</el-dialog>
	</section>
</template>
<script>
	import instance from '../../../api/index.js';
	import { mapState } from 'vuex';
	import * as util from '../../../assets/util.js';
	export default {
		computed: {
			// Getting Vuex State from store/index
			...mapState({
				// layerShow: state => state.layerShow,
				pageSize: state => state.pageSize,
				pageLarge: state => state.pageLarge,
				payStatuses: state => state.payStateDict, //支付状态
				payTypes: state => state.paymentDict, //支付方式
				approveStatuses: state => state.approveStatusDict //审核状态
			})
		},
		data() {
			return {
				actionType: "query",
				selectArr: [],
				actionsList: [], //获取当前用户对当前模块授权操作
				findBuyCards: {}, //查询条件
				buycardList: [], //购课列表
				schoolNames: [], //校区,
				userSchoolId: "", //当前用户所在校区,
				cardNames: [], //会员卡类型
				recordCount: 0,
				pageNum: 1, //当前页码
				linkId: "",
				dialogFormCancelVisible: false, //取消功能 隐藏
				loginInfo: {}, //当前登录信息
				cancelCardDetail: { //取消购课订单数据对象
					id: "",
					cancelReason: ""
				}
			};
		},
		components: {
			page: () =>
				import("../../common/page.vue")
		},
		methods: {
			getUserSchool: function() { //获取当前用户校区字典
				//获取当前登录人
				this.loginInfo = util.session("loginInfo", void(0));
				instance.post('/school/findUserSchools/' + this.loginInfo.login.userId, {}).then((res) => {
					if(res.data.data != null && res.data.data != "") {
						this.schoolNames = res.data.data;
						this.userSchoolId = res.data.data[0].id;
						if(res.data.data!=null && res.data.data.length==1){
							this.findBuyCards.qSchoolId=this.userSchoolId;
						}

						this.getBuyCard();
						this.getBuyCardCount();
					}
				})

			},
			getCard: function() { //获取会员卡数据
				instance.post('/lessoncard/findSimpleList', {}).then((res) => {
					this.cardNames = res.data.data;
				})
			},
			getBuyCardCount: function() { //获取购课数量
				var params = {};
				if(!(JSON.stringify(this.findBuyCards) == "{}")) {
					var result = $.extend(true, params, this.findBuyCards);
				} else {
					var result = params;
				};

				instance.post('/buycard/findBuyCardsCount', result).then((res) => {
					this.recordCount = res.data.data.count;
				});
			},
			getBuyCard: function() { //获取购课列表
				var params = {
					"beginRow": (this.pageNum - 1) * this.pageSize,
					"pageSize": this.pageSize
				};
				if(!(JSON.stringify(this.findBuyCards) == "{}")) {
					var result = $.extend(true, params, this.findBuyCards);
				} else {
					var result = params;
				};
				instance.post('/buycard/findBuyCards', result).then((res) => {
					this.buycardList = res.data.data;
				})
				this.actionType = "query";

			},
			query: function() {
				this.getBuyCard();
				this.getBuyCardCount();

			},
			changePage: function(pageNum) {
				//				console.info("change-page:" + pageNum);
				this.pageNum = pageNum;
				this.getBuyCard();
			},
			linkStudentInfo: function(id) { //学生姓名点击跳转详情
				this.$router.push('/xueyuanguanli/studentinfo/' + id);
			},
			linkdetails: function(id) { //详情

				// this.$router.push('/xueyuanguanli/buyCard/'+id);
				this.$router.push('/caiwuguanli/dingdanshenhe/linkdetails/' + id);
			},
			approveCard: function(id) { //审核

				// this.$router.push('/xueyuanguanli/buyCard/'+id);
				this.$router.push('/caiwuguanli/dingdanshenhe/approvebuycard/' + id);
			},
			editCard: function(id) { //修改

				// this.$router.push('/xueyuanguanli/buyCard/'+id);
				this.$router.push('/caiwuguanli/dingdanshenhe/editbuycard/' + id);

			},
			cancelCard: function(id) { //取消
				instance.get('/buycard/findBuyCard/' + id).then((res) => {
					if(res.data.errcode == '0') {
						//this.cancelCardDetail = res.data.data;
						this.cancelCardDetail.id = res.data.data.id;
						this.cancelCardDetail.cancelReason = res.data.data.cancelReason;
						//显示取消原因弹框
						this.dialogFormCancelVisible = true;
						//执行查询方法，重载数据
						this.query();
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}
				})

			},
			saveCancelInfo: function(data) { //确定-保存取消原因
				instance.post('/buycard/cancelBuyCard', data).then((res) => {
					if(res.data.errcode == '0') {
						//this.cardDetail.id = res.data.data.id;
						this.$message.info('信息保存成功！');
						//隐藏取消原因弹框
						this.dialogFormCancelVisible = false;
						//执行查询方法，重载数据
						this.query();
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}

				})
			},
			getModuleActions: function() {
				let routeCodes = this.$route.path.split("/");
				let routeCode = routeCodes[routeCodes.length - 1];
				instance.get('/navi/findUserActions2/' + routeCode).then((res) => {
					if(res.data.errcode == '0') {
						this.actionsList = res.data.data;
					} else {
						//this.$message.error('操作失败！' + res.data.info);
					}
					console.info("json:" + res.data);

				})
			}
		},
		mounted: function() {
			this.getUserSchool(); //当前人所在校区
			this.getCard(); //会员卡类型
			this.getModuleActions();
		}
	};
</script>
