<!--<title>订单审核</title>-->
<style>
	.zxt {
		width: 100%;
		position: relative;
		margin: auto;
		margin-top: 15px;
	}
	
	.zxt_nav {
		left: 20px;
		top: 0px
	}
	
	.h5_iframe1_table_page {
		width: calc(100% - 30px);
		margin-bottom: 15px;
		background-color: #f0f0f0;
		margin-left: 10px;
		padding: 1px
	}
</style>
<template>
	<div class="zxt">
		<div class="h5_iframe1_table_page">
			<router-view></router-view>
		</div>
	</div>
</template>
<script>
	
</script>