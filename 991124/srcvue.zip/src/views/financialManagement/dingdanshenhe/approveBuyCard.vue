<!--<title>审核会员卡</title>-->

<template>
	<form id="" method="post" action="" class="ue_form_add">
		<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
        	<span>购课订单详情</span>
    	</h3>
		<ul class='h5_02_info_per_addlist'>
			<li>
				<span></span>
				<span>订单号:</span>
				<span>
    				<!--<input type="text" class='per_addperson_txt' readonly v-model="cardDetail.orderCode">-->
    				{{cardDetail.orderCode}}
				</span>
			</li>
			<li>
				<span></span>
				<span>订单时间:</span>
				<span>
    				<!--<input type="text" class='per_addperson_txt' readonly v-model="cardDetail.orderTime">-->
    				{{cardDetail.orderTime}}
				</span>
			</li>
			<li>
				<span></span>
				<span>购课校区:</span>
				<span>
    				<!--<input type="text" class='per_addperson_txt' readonly v-model="cardDetail.schoolName">-->
    				{{cardDetail.schoolName}}
				</span>
			</li>
			<li>
				<span></span>
				<span>学生姓名:</span>
				<span>
    				<!--<input type="text" class='per_addperson_txt' readonly v-model="cardDetail.studentName">-->
    				{{cardDetail.studentName}}
				</span>
			</li>
			<li>
				<span></span>
				<span>会员卡类型:</span>
				<span>
					<!--<input type="text" class='per_addperson_txt' readonly v-model="cardDetail.cardName">-->
					{{cardDetail.cardName}}
		             <!--<select  class='per_addperson_txt' v-bind:readonly="isReadOnly"  v-model="cardDetail.cardId" >
		               <option  v-for="card in cardInfo" :value="card.id">{{card.cardName}}</option>
		             </select>-->
          		</span>
			</li>
			<li>
				<span></span>
				<span>会员卡号:</span>
				<span>
    				<!--<input type="text" class='per_addperson_txt' readonly v-model="cardDetail.studentLessonCardCode">-->
    				{{cardDetail.studentLessonCardCode}}
				</span>
			</li>
			<li>
				<span></span>
				<span>有效期:</span>
				<span>
    				<!--<input type="text" class='per_addperson_txt' readonly v-model="cardDetail.validDate">-->
    				{{cardDetail.validDate}}
				</span>
			</li>
			<li>
				<span></span>
				<span>原价:</span>
				<span>
					<!--<input type="text" class='per_addperson_txt' readonly v-model="cardDetail.sourceMoney">-->
					{{cardDetail.sourceMoney}}
				</span>
				
			</li>
			<li>
				<span></span>
				<span>现价:</span>
				<span>
					<!--<input type="text" class='per_addperson_txt' readonly v-model="cardDetail.currentMoney">-->
					{{cardDetail.currentMoney}}
				</span>
			</li>
			<li>
				<span></span>
				<span>优惠金额:</span>
				<span>
					<input type="text" class='per_addperson_txt' v-model="cardDetail.discountMoney" v-validate="'numeric'" name="优惠金额">
					<!--{{cardDetail.discountMoney}}-->
				</span>
			</li>
			<li>
				<span></span>
				<span>实收金额:</span>
				<span>
					<!--<input type="text" class='per_addperson_txt' readonly v-model="cardDetail.money">-->
					{{cardDetail.money}}
				</span>
			</li>
			<li>
				<span></span>
				<span>课时:</span>
				<span>
					<!--<input type="text" class='per_addperson_txt' readonly v-model="cardDetail.hour">-->
					{{cardDetail.hour}}
				</span>
			</li>
			<li>
				<span></span>
				<span>赠送课时:</span>
				<span>
					<input type="text" class='per_addperson_txt' v-model="cardDetail.giveHour">
					<!--{{cardDetail.giveHour}}-->
				</span>
			</li>
			<li>
				<span></span>
				<span>总课时:</span>
				<span>
					<!--<input type="text" class='per_addperson_txt' readonly v-model="cardDetail.sumHour">-->
					{{cardDetail.sumHour}}
				</span>
			</li>
			<li>
				<span></span>
				<span>购课时间:</span>
				<span>
					<!--<input type="text" class='per_addperson_txt' readonly v-model="cardDetail.buyCardTime">-->
					{{cardDetail.buyCardTime}}
				</span>
			</li>
			<!--<li>
				<span></span>
				<span>审核状态:</span>
				<span>
					<select name="" id="" class='per_addperson_txt'  v-model="cardDetail.approveStatus">
                    	<option v-for = "(item,key) in approveStatuses" :value="key">{{item}}</option>
                    </select>
    			</span>
			</li>-->
			<li>
				<span></span>
				<span>支付方式:</span>
				<span>
					<!--<input type="text" class='per_addperson_txt' v-model="paymentDict[cardDetail.payType]">-->
					<!--{{paymentDict[cardDetail.payType]}}-->
                    <select name="" id="" class='per_addperson_txt'  v-model="cardDetail.payType">
                    	 <option v-for = "(item,key) in paymentDict" :value="key">{{item}}</option>
                    </select>
                </span>
			</li>
			<li>
				<span></span>
				<span>支付状态:</span>
				<span>
    				<select name="" id="" class='per_addperson_txt'  v-model="cardDetail.payStatus">
    					<option v-for = "(item,key) in payStateDict" :value="key">{{item}}</option>
    				</select>
    			</span>
			</li>
			<li>
				<span></span>
				<span>支付日期:</span>
				<span>
					<el-date-picker type="date"  value-format="yyyy-MM-dd" placeholder="Pick a date" style="width:100%" v-model="cardDetail.payDate"></el-date-picker>
					<!--<input type="text" class='per_addperson_txt'   v-model="cardDetail.payDate">-->
				</span>
			</li>
			<li>
				<span></span>
				<span>经办人:</span>
				<span>
					<!--<input type="text" class='per_addperson_txt' readonly  v-model="cardDetail.responsibleRealName">-->
					{{cardDetail.responsibleRealName}}
				</span>
			</li>
			<li class="per_addperson_li_w per_addperson_li_h2">
				<span></span>
				<span>审核意见:</span>
				<span>
                   <textarea name="" id="" cols="30" rows="4" placeholder="" class='per_addperson_texarea'  v-model="cardDetail.descr"></textarea>
                </span>
			</li>
			
		</ul <br class="p_zwf">
		<div class="p_btn_group p_clear_float">
			<!--<input type="button" value="返回" class="p_btn p_btn_siz_2 p_btn_col_red p_btn_pos_r">-->
			<input type="button" value="返回" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r" @click="returnCard(cardDetail)">
			<input type="button" value="审核通过" class="p_btn p_btn_siz_2 p_btn_col_ora p_btn_pos_r" @click="saveInfo(cardDetail)">
		</div>
	</form>
</template>
<script>
	import instance from '../../../api/index.js';
	import { mapState } from 'vuex';
	export default {
		data() {
			return {
				cardDetail: {
					orderCode: "",
					sourceMoney: "",
					giveHour: "",
					discountMoney: "",
					cardId: "",
					approveStatus: "1",
					payStatus: "",
					approveStatus: ""
				},
				cardInfo: [], //会员卡
				errcode: "",
			}
		},
		created: function() {
			this.getOrderBuyCard(this.$route.params.id);
		},
		computed: {　
			// Getting Vuex State from store/index
			...mapState({
				payStateDict: state => state.payStateDict,
				paymentDict: state => state.paymentDict,
				approveStatuses: state => state.approveStatusDict //审核状态
			}),
			discountMoney() { //优惠金额
				return this.cardDetail.discountMoney　　
			},
			giveHour() { //赠送课时
				return this.cardDetail.giveHour　　
			}
		},
		watch: {
			discountMoney(curVal, oldVal) {
				if(this.cardDetail.currentMoney != "" && curVal != "")　
					this.cardDetail.money = parseFloat(this.cardDetail.currentMoney) - parseFloat(curVal);　
				else　　 this.cardDetail.money = "";　　　　　　　　　　
			},
			giveHour(curVal, oldVal) {　
				if(this.cardDetail.hour != "" && curVal != "")　
					this.cardDetail.sumHour = parseFloat(this.cardDetail.hour) + parseFloat(curVal);　
				else　　　
					this.cardDetail.sumHour = "";　　　　　　　　　
			}

		},
		methods: {
			getCard: function() { //会员卡类型
				instance.post('/lessoncard/findSimpleList', {}).then((res) => {
					this.cardInfo = res.data.data;
				})
			},
			saveInfo: function(data) { //审核通过
				instance.post('/buycard/passBuyCard', data).then((res) => {
					if(res.data.errcode == '0') {
						//this.cardDetail.id = res.data.data.id;
						this.$message.info('信息保存成功！');
						this.$router.push('/caiwuguanli/dingdanshenhe/goukedingdan');
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}

				})
			},
			returnCard: function(data) { //返回
				this.$router.push('/caiwuguanli/dingdanshenhe/goukedingdan');
			},
			getOrderBuyCard(id) { //获取购课订单信息
				instance.get('/buycard/findBuyCard/' + id).then((res) => {
					if(res.data.errcode == '0') {
						this.cardDetail = res.data.data;
						/*
						this.cardDetail.orderCode = res.data.data.orderCode;
						this.cardDetail.orderTime = res.data.data.orderTime;
						this.cardDetail.schoolName = res.data.data.schoolName;
						this.cardDetail.schoolId = res.data.data.schoolId;
						this.cardDetail.responsibleRealName = res.data.data.responsibleRealName;
						this.cardDetail.responsibleUserId = res.data.data.responsibleUserId;
						//this.cardDetail.id = res.data.data.id;
						this.cardDetail.studentName = res.data.data.studentName;
						*/
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}
				})
			}

		},
		mounted: function() {
			this.getCard();
		}
	};
</script>