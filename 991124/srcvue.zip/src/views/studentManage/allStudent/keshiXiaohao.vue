<!--<title>学员课时消耗记录</title>-->
<template>

	<div class="p_con_tab">
		<!--div class="p_table_la_over">
			<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
            	<span>课程信息</span>
        	</h3>
			<table class="p_table_la" cellspacing="0" cellpadding="0">
				<tr>
					<td>学员姓名</td>
					<td>会员卡号</td>
					<td>所属校区</td>
					<td>课程大类</td>
					<td>课程小类</td>
					<td>班级名称</td>
					<td>班级类别</td>
					<td>总课时</td>
					<td>消耗课时</td>
					<td>剩余课时</td>
				</tr>
				<tr>
					<td>王小明</td>
					<td>553453</td>
					<td>海淀校区</td>
					<td>舞蹈</td>
					<td>启蒙舞</td>
					<td>舞蹈-启蒙舞周日下午班</td>
					<td>一对多</td>
					<td>55</td>
					<td>3</td>
					<td>52</td>
				</tr>
			</table>
		</div-->
		<div class="p_table_la_over">
			<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
            	<span>上课记录</span>
        	</h3>
			<table class="p_table_la" cellspacing="0" cellpadding="0">
				<tr>
					<td>上课日期</td>
					<td>上课时间</td>
					<!--<td>上课状态</td>-->
					<!--<td>消耗课时</td>-->
          <td>考勤状态</td>
					<td>授课教师</td>
					<td>创建时间</td>
					<td>备注</td>
				</tr>
				<tr v-for=" lesson in lessonList">
					<td>{{lesson.lessonDate}}</td>
					<td>{{lesson.beginTime}}—{{lesson.endTime}}</td>
					<td>{{lessonStatusDict[lesson.lessonStatus]}} ：{{lesson.realHour}}课时</td>
					<!--<td>{{lesson.realHour}}</td>-->
					<td>{{lesson.teacherName}}</td>
					<td>{{lesson.createTime}}</td>
					<td>{{lesson.descr}}</td>
				</tr>

			</table>
		</div>
		<!-- 分页 -->
		<div class='h5_page_container' id="con">
			<page :record-count="recordCount" v-on:change-page="changePage">
			</page>
		</div>
	</div>
</template>

<script>
	import instance from '../../../api/index.js';
	import { mapState } from 'vuex';
	export default {
		components: {
			page: () =>
				import("../../common/page.vue")
		},
		data() {
			return {
				lessonList: [],
				message: "",
				recordCount: 0,
				pageNum: 1 //当前页码
			};
		},

		computed: {
			// Getting Vuex State from store/index
			...mapState({
				lessonStatusDict: state => state.lessonStatusDict,
			})
		},
		methods: {
			getLessonList: function(id) { //列表信息
				instance.post('/lesson/findStudentLessons', {
					qStudentId: id,
					qVerify: 0,
					"beginRow": (this.pageNum - 1) * this.pageSize,
					"pageSize": this.pageSize
				}).then((res) => {
					if(res.data.data == null) {
						this.message = '(' + res.data.errmsg + ')';
					} else {
						this.message = "";
						this.lessonList = res.data.data;
					}
				})
			},
			getLessonCount: function(id) {
				instance.post('/lesson/findStudentLessonsCount', {
					qStudentId: id,
					qVerify: 0,
				}).then((res) => {
					this.recordCount = res.data.data.count;
				})

			},
			changePage: function(pageNum) {
				console.info("change-page:" + pageNum);
				this.pageNum = pageNum;
				this.getLessonList(this.$route.params.id);
			}
		},
		mounted: function() {
			this.getLessonList(this.$route.params.id);
			this.getLessonCount(this.$route.params.id);
		}
	};
</script>
