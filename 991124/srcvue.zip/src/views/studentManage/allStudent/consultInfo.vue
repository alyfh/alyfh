<!--<title>咨询信息</title>-->
<template>
	<form id="" method="post" action="" class="ue_form_add">
		<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
            <span>咨询信息{{ifconsult}}</span>
            <!--<span class='h5_mark_xx2'>★</span>-->
            <!--<span>为必填)</span>-->
        </h3>
		<ul class='h5_02_info_per_addlist'>
			<li>
				<span>★</span>
				<span>姓名:</span>
				<span>{{consultDetail.studentName}}</span>
			</li>
			<li>
				<span>★</span>
				<span>性别:</span>
				<span>{{consultDetail.sex}}</span>
			</li>
			<li>
				<span>★</span>
				<span>年龄:</span>
				<span>{{consultDetail.age}}</span>
			</li>
			<li>
				<span>★</span>
				<span>联系人手机:</span>
				<span>
    				{{consultDetail.telephone}}

    			</span>
			</li>
			<li>
				<span>★</span>
				<span>与之关系:</span>
				<span>{{consultDetail.relationShip}}</span>
			</li>
			<li>
				<span></span>
				<span>邮箱:</span>
				<span>
    				{{consultDetail.email}}

    			</span>
			</li>

			<li>
				<span></span>
				<span>QQ:</span>
				<span>
    				{{consultDetail.qq}}
    			</span>
			</li>
			<li>
				<span></span>
				<span>微信:</span>
				<span>{{consultDetail.wechat}}</span>
			</li>

			<li>
				<span>★</span>
				<span>来源大类:</span>
				<span>
    				{{consultDetail.sourceName}}

    			</span>
			</li>
			<li>
				<span>★</span>
				<span>来源小类:</span>
				<span>
    				{{consultDetail.sourceSubName}}
    			</span>
			</li>

			<li>
				<span>★</span>
				<span>课程大类:</span>
				<span>
    				{{consultDetail.courseName}}
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>课程小类:</span>
				<span>
    				{{consultDetail.courseSubName}}
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>所属校区:</span>
				<span>
    				{{consultDetail.schoolName}}
    			</span>
			</li>
			<li>
				<span></span>
				<span>咨询师:</span>
				<span>
    				{{consultDetail.counselorName}}
    				</span>
			</li>
			<li>
				<span></span>
				<span>课程顾问:</span>
				<span>
    				{{consultDetail.courseCounselorName}}
    			</span>
			</li>
			<li>
				<span></span>
				<span>主动联系:</span>
				<span>
					{{shifouByDigit[consultDetail.initiative]}}

    			</span>
			</li>

			<li>
				<span></span>
				<span>推荐人:</span>
				<span>{{consultDetail.referrerName}}</span>
			</li>
			<li>
				<span>★</span>
				<span>线索状态:</span>
				<span>
					{{adviceStatus[consultDetail.status]}}

    			</span>
			</li>
			<li>
				<span>★</span>
				<span>客户等级:</span>
				<span>
					{{adviceLevel[consultDetail.studentLevel]}}
    			</span>
			</li>
			<li>
				<span></span>
				<span>所属活动:</span>
				<span>{{consultDetail.fromEvent}}</span>
			</li>

			<li>
				<span></span>
				<span>家庭住址(省):</span>
				<span>
    				{{provinceName}}
    			</span>
			</li>
			<li>
				<span></span>
				<span>市:</span>
				<span>
    				{{cityName}}
    			</span>
			</li>
			<li>
				<span></span>
				<span>区县:</span>
				<span>
    				{{districtName}}
    			</span>
			</li>
			<li>
				<span></span>
				<span>小区:</span>
				<span>{{consultDetail.biotope}}</span>
			</li>
			<li>
				<span></span>
				<span>详细地址:</span>
				<span>{{consultDetail.address}}</span>
			</li>
			<li>
				<span></span>
				<span>就读学校:</span>
				<span>{{consultDetail.school}}</span>
			</li>
			<li>
				<span>★</span>
				<span>班级类别:</span>
				<span>
					{{classTypeDict[consultDetail.classType]}}

    			</span>
			</li>
			<li class="per_addperson_li_w">
				<span></span>
				<span>备注:</span>
				<span class="text_scroll">{{consultDetail.descr}}</span>
			</li>
		</ul>

		<!--<br class="p_zwf">-->
		<!--<div class="p_btn_group p_clear_float">-->
		<!--<input type="button" value="返回" class="p_btn p_btn_siz_2 p_btn_col_red p_btn_pos_r">-->
		<!--<input type="button" value="保存" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r">-->
		<!--</div>-->
	</form>
</template>
<script>
	import instance from '../../../api/index.js';
	import { mapState } from 'vuex';
	export default {
		data() {
			return {
				consultDetail: {},
				ifconsult: "",
			    provinceName: "",
				cityName: "",
				districtName: "",
			};
		},
		computed: {
			// Getting Vuex State from store/index
			...mapState({
				cityJson: state => state.cityJson,
				adviceStatus: state => state.adviceStatus,
				adviceLevel: state => state.adviceLevel,
				shifouByDigit: state => state.shifouByDigit,
				classTypeDict: state => state.classTypeDict
			})
		},
		methods: {
			getStudentInfo: function(id) { //获取学员信息
				instance.get('/student/findStudent/' + id, {}).then((res) => {
					if(res.data.errcode == '0') {
						if(res.data.data.informationId!=null)
						this.getconsultInfo(res.data.data.informationId);
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}
				})
			},
			getconsultInfo: function(id) { //获取咨询信息
				instance.get('/infor/findInformation/' + id, {}).then((res) => {
					if(res.data.data == null) {
						this.ifconsult = '(' + res.data.errmsg + ')';
					} else {
						this.ifconsult = "";
						this.consultDetail = res.data.data;
						this.getProvince();
					}
				})
			},
			getProvince: function() {
				let vm = this;
				if(typeof(this.cityJson.status) == "undefined") { //首次加载 调接口高德地图

					axios.get('/restapi/v3/config/district?subdistrict=3&key=84b4e40f86d5c8087078673175324d9b').then((res) => {
						//this.consultants = res.data.status;
						if(res.data.status == '1') {
							this.$store.commit({
								type: 'setCityJson',
								cityJson: res.data
							})
							//this.provinces = res.data.districts[0].districts;

							res.data.districts[0].districts.forEach(function(e, i) {
								if(e.adcode == vm.consultDetail.provinceId) {
									vm.provinceName = e.name;
									e.districts.forEach(function(e, i) {
										if(e.adcode == vm.consultDetail.cityId) {
											vm.cityName = e.name;
											e.districts.forEach(function(e, i) {
												if(e.adcode == vm.consultDetail.areaId) {
													vm.districtName = e.name;

												}

											})
										}

									})
								}

							});

						} else {
							this.$message.error('操作失败！' + res.data.info);
						}

						console.info("json:" + res.data);

					})
				} else {
					//this.provinces = this.cityJson.districts[0].districts;
					this.cityJson.districts[0].districts.forEach(function(e, i) {
						if(e.adcode == vm.consultDetail.provinceId) {
							vm.provinceName = e.name;
							e.districts.forEach(function(e, i) {
								if(e.adcode == vm.consultDetail.cityId) {
									vm.cityName = e.name;
									e.districts.forEach(function(e, i) {
										if(e.adcode == vm.consultDetail.areaId) {
											vm.districtName = e.name;

										}

									})
								}

							})
						}

					});
				}

				//console.info("provinces:" + this.cityJson.districts[0].districts);
			}
		},
		mounted: function() {
			this.getStudentInfo(this.$route.params.id);
			// this.getconsultInfo();
		}
	};
</script>
