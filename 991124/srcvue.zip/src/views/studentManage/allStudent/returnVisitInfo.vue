
	<!--<title>回访信息</title>-->
  <style>
    .td_fixed{
      width: 270px;
    }
  </style>
  <template>
	<div class="p_con_tab">
		<div class="p_table_la_over">
			<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
            	<span>回访信息{{ifreturn}}</span>
        	</h3>
			<table class="p_table_la" cellspacing="0" cellpadding="0">
				<tr>
					<td>回访日期</td>
					<td>咨询师</td>
					<td>课程顾问</td>
					<td>下次回访日期</td>
					<td>客户等级</td>
					<td>线索状态</td>
					<td>回访内容</td>
				</tr>
				<tr v-for="info in returnDetail">
					<td>{{info.visitTime}}</td>
					<td>{{info.counselorName}}</td>
					<td>{{info.courseCounselorName}}</td>
					<td>{{info.nextVisitTime}}</td>
					<td>{{adviceLevel[info.studentLevel]}} </td>
					<td>{{adviceStatus[info.status]}}</td>
					<td class="td_fixed">
            {{info.visitContent}}
					</td>
				</tr>
			</table>
		</div>
	</div>
  </template>
  <script>
    import instance from '../../../api/index.js';
    import { mapState } from 'vuex';
    export default {
      data() {
        return {
          returnDetail:[],
          ifreturn:"",
          informationId:""//咨询ID
        };
      },
      computed: {
			// Getting Vuex State from store/index
			...mapState({
				adviceStatus: state => state.adviceStatus,
				adviceLevel: state => state.adviceLevel,
			})
		},
      methods:{
        getreturnInfo:function(){//获取回访列表信息
          instance.post('/visit/findVisits',{
            informationId:this.informationId
          }).then((res) => {
            if(res.data.data==null){
              this.ifreturn='('+res.data.errmsg+')';
            }else{
              this.ifreturn="";
              this.returnDetail=res.data.data;
            }
          })
        },
        getStudentinformationId:function(id){
          instance.get('/student/findStudent/'+id).then((res) => {
            if(res.data.data.informationId==null){
              this.ifreturn="(回访信息不存在)";
            }else{
              this.informationId=res.data.data.informationId;
              this.getreturnInfo();
            }
          })
        }
      },
      mounted: function() {
        this.getStudentinformationId(this.$route.params.id);
      }
    };
  </script>
