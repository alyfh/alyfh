<!--<title>全部学员</title>-->
<style scoped>
	.p_table_la tr>td:nth-child(1):hover {
		cursor: pointer;
		color: #0d8ddb;
	}
</style>
<template>
	<section class="p_chi_con">
		<div class="p_con_sea">
			<ul class="p_con_sea_list p_clear_float">
				<li>
					<span>学员姓名:</span>
					<span>
						<input type="text" class="p_con_form_input" v-model="findStudents.qStudentName">
					</span>
				</li>
				<li>
					<span>会员卡号:</span>
					<span>
						<input type="text" class="p_con_form_input" v-model="findStudents.qLessonCardCode">
					</span>
				</li>
				<li>
					<span>所属校区:</span>
					<span>
            <select name=""  class="p_con_form_select" v-model="findStudents.qSchoolId" @change="getQueryInfo(findStudents.schoolId)">
              <!--option>-请选择-</option-->
              <option v-for="sName in schoolNames" :value="sName.id">{{ sName.schoolName }}</option>
            </select>
					</span>
				</li>
				<li>
					<span>来源大类:</span>
					<span>
            <select name="" id="" class="p_con_form_select" v-model="findStudents.qSourceId" @change="getSourceSub(findStudents.qSourceId)">
                <option value="">-请选择-</option>
                <option v-for="sourceName in sourceNames" :value="sourceName.id">{{sourceName.sourceName}}</option>
            </select>
					</span>
				</li>
				<li>
					<span>来源小类:</span>
					<span>
            <select name="" id="" class="p_con_form_select" v-model="findStudents.qSourceSubId">
              <option value="">-请选择-</option>
              <option v-for="sourceSubName in sourceNameSubs" :value="sourceSubName.id">{{sourceSubName.sourceSubName}}</option>
            </select>
					</span>
				</li>
				<li>
					<span>联系人手机:</span>
					<span>
						<input type="text" class="p_con_form_input" v-model="findStudents.qTelephone">
					</span>
				</li>
				<li>
					<span>咨询师:</span>
					<span>
						<select name="" id="" class="p_con_form_select" v-model="findStudents.qCounselorId">
              <option value="">-请选择-</option>
              <option v-for="counselorName in counselorNames" :value="counselorName.id">{{counselorName.realName}}</option>
            </select>
					</span>
				</li>
				<li>
					<span>课程顾问:</span>
					<span>
						<select name="" id="" class="p_con_form_select" v-model="findStudents.qCourseCounselorId">
              <option value="">-请选择-</option>
              <option v-for="consultant in consultants" :value="consultant.id">{{consultant.realName}}</option>
            </select>
					</span>
				</li>
				<li>
					<span>授课教师:</span>
					<span>
						<select name="" id="" class="p_con_form_select" v-model="findStudents.qTeacherId">
               				<option value="">-请选择-</option>
               				<option v-for="teacher in teachers" :value="teacher.id">{{teacher.realName}}</option>
            			</select>
					</span>
				</li>
				<li>
					<span>生日开始:</span>
					<span>
						<!--<input type="text" class="p_con_form_input" v-model="findStudents.qMonthBegin">-->
						<select name="" id="" class="p_con_form_select" v-model="findStudents.qMonthBegin">
               				<option value="">-请选择-</option>
               				<option v-for="month in monthList" :value="month.id">{{month.name}}</option>
            			</select>
					</span>

				</li>
				<li>
					<span>生日结束:</span>
					<span>
						<!--<input type="text" class="p_con_form_input" v-model="findStudents.qMonthEnd	">-->
						<!--<select name="" id="" class="p_con_form_select" v-model="findStudents.qMonthEnd">
							<option value="">-请选择-</option>
			              	<option v-for = "(item,key) in monthDict" :value="key">{{item}}</option>
            			</select>-->
            			<select name="" id="" class="p_con_form_select" v-model="findStudents.qMonthEnd">
               				<option value="">-请选择-</option>
               				<option v-for="month in monthList" :value="month.id">{{month.name}}</option>
            			</select>
            			
					</span>
				</li>
				<li>
					<span>出生日期开始:</span>
					<span>
						<!--<input type="text" class="p_con_form_input" v-model="findStudents.qBirthdayBegin">-->
						<el-date-picker type="date"  value-format="yyyy-MM-dd" placeholder="Pick a date" style="width:100%" v-model="findStudents.qBirthdayBegin"></el-date-picker>
					</span>

				</li>
				<li>
					<span>出生日期结束:</span>
					<span>
						<!--<input type="text" class="p_con_form_input" v-model="findStudents.qBirthdayEnd	">-->
						<el-date-picker type="date"  value-format="yyyy-MM-dd" placeholder="Pick a date" style="width:100%" v-model="findStudents.qBirthdayEnd"></el-date-picker>
					</span>
				</li>
				<!--<li>-->
				<!--<span>学管师:</span>-->
				<!--<span>-->
				<!--<select name="" id="" class="p_con_form_select" v-model="findStudents.qManagerId"></select>-->
				<!--</span>-->
				<!--</li>-->
			</ul>
			<div class="p_btn_group p_clear_float">
				<input type="button" value="查询" @click="query" class="p_btn p_btn_siz_2 p_btn_col_gre p_btn_pos_r">
			</div>
		</div>

		<div class="p_con_tab">
			<div class="p_btn_group p_clear_float">
				<!--input type="button" value="转班" class="p_btn p_btn_siz_2 p_btn_col_oran p_btn_pos_r" @click="transferClass()">
				<input type="button" value="分班" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r" @click="divideClass()"-->
			</div>
			<div class="p_table_la_over">
				<table class="p_table_la" cellspacing="0" cellpadding="0">
					<tr>
						<td>学员姓名</td>
						<td>性别</td>
						<td>年龄</td>
						<td>会员卡号</td>
						<td>联系方式</td>
						<td>创建时间</td>
						<td v-if="$_has(actionsList,'visitList')||$_has(actionsList,'addVisit')">
							操作
						</td>
					</tr>
					<tr v-for="(studentdata,index) in studentList">

						<!--<router-link to="/buycard" tag="td">{{studentdata.studentLessonCard.studentName}}</router-link>-->
						<template v-if="$_has(actionsList,'read')">
							<td @click="linkStudentInfo(studentdata.studentLessonCard.studentId)">{{studentdata.studentLessonCard.studentName}}</td>
						</template>
						<template v-else>
							<td>{{studentdata.studentLessonCard.studentName}}</td>
						</template>
						<td>{{studentdata.sex}}</td>
						<td>{{dateDiff(studentdata.birthday,new Date().pattern("yyyy-MM-dd"),"相差Y年M月D天")}}</td>
						<td>{{studentdata.studentLessonCard.cardCode}}</td>
						<td>{{studentdata.telephone}}</td>
						<td>{{studentdata.createTime}}</td>
						<td v-if="$_has(actionsList,'visitList')||$_has(actionsList,'addVisit')">
							<input v-if="$_has(actionsList,'visitList')" type="button" value="回访记录" class="p_btn p_btn_siz_3 p_btn_col_k_blu p_btn_pos_r" @click="getvisitList(studentdata.informationId)">
							<input v-if="$_has(actionsList,'addVisit')" type="button" value="新增回访" class="p_btn p_btn_siz_3 p_btn_col_k_oran p_btn_pos_r" @click="addvisit(studentdata.informationId)">

						</td>
					</tr>
				</table>
			</div>
		</div>
		<div class='h5_page_container' id="con">
			<page :record-count="recordCount" v-on:change-page="changePage">
			</page>
		</div>
	</section>
</template>
<script>
	import instance from '../../../api/index.js';
	import * as util from '../../../assets/util.js';
	import { mapState } from 'vuex';
	export default {
		computed: {
			// Getting Vuex State from store/index
			...mapState({
				// layerShow: state => state.layerShow,
				pageSize: state => state.pageSize,
				pageLarge: state => state.pageLarge,
				monthDict: state => state.monthDict
			})
		},
		data() {
			return {
				actionType: "query",
				actionsList: [], //获取当前用户对当前模块授权操作
				selectArr: [],
				findStudents: { //查询条件
				},
				studentList: [], //学员列表
				schoolNames: [], //校区,
				sourceNames: [], //来源大类
				sourceNameSubs: [], //来源小类
				counselorNames: [], //咨询师
				consultants: [], //课程顾问
				teachers: [], //授课教师
				recordCount: 0,
				pageNum: 1, //当前页码
				linkId: "",
				monthList: [{
						id: "01",
						name: "1月"
					},
					{
						id: "02",
						name: "2月"
					},
					{
						id: "03",
						name: "3月"
					},
					{
						id: "04",
						name: "4月"
					},
					{
						id: "05",
						name: "5月"
					},
					{
						id: "06",
						name: "6月"
					},
					{
						id: "07",
						name: "7月"
					},
					{
						id: "08",
						name: "8月"
					},
					{
						id: "09",
						name: "9月"
					},
					{
						id: "10",
						name: "10月"
					},
					{
						id: "11",
						name: "11月"
					},
					{
						id: "12",
						name: "12月"
					}
				]

			};
		},
		components: {
			page: () =>
				import("../../common/page.vue")
		},
		methods: {
			getStudentCount: function() { //获取学生数量
				var params = {};
				if(!(JSON.stringify(this.findStudents) == "{}")) {
					var result = $.extend(true, params, this.findStudents);
				} else {
					var result = params;
				};
				instance.post('/student/findStudentsCount', result).then((res) => {
					this.recordCount = res.data.data.count;
				});
			},
			query: function() {
				this.getStudent();
				this.getStudentCount();
			},
			getSchool: function() { //获取校区数据
				//获取当前登录人
				let loginInfo = util.session("loginInfo");
				instance.get('/school/findUserSchools/' + loginInfo.login.userId).then((res) => {

					if(res.data.data != null && res.data.data != "") {
						this.schoolNames = res.data.data;
						if(res.data.data != null && res.data.data.length == 1) {
							this.findStudents.qSchoolId = res.data.data[0].id;
							this.getQueryInfo(this.findStudents.qSchoolId);
						}
						this.query();

					}
				})
			},
			getQueryInfo: function(schoolId) { //联动查询咨询师，课程顾问
				this.getConsult(schoolId);
				this.getconsultant(schoolId);
				this.getTeacher(schoolId);

			},
			getConsult: function(schoolId) { //获取咨询师列表
				instance.post('/user/findSystemRoleSimpleUser', {
					qSchoolId: schoolId,
					qRoleCode: "counselor",
				}).then((res) => {
					this.counselorNames = res.data.data;
				})
			},
			getconsultant: function(schoolId) { //获取课程顾问列表
				instance.post('/user/findSystemRoleSimpleUser', {
					qSchoolId: schoolId,
					qRoleCode: "coursecounselor",
				}).then((res) => {
					this.consultants = res.data.data;
				})
			},
			getTeacher: function(schoolId) { //获取授课教师列表  
				instance.post('/user/findSystemRoleSimpleUser', {
					qSchoolId: schoolId,
					qRoleCode: "teacher",
				}).then((res) => {
					this.teachers = res.data.data;
				})
			},
			getSource: function() { //获取来源大类数据
				instance.post('/source/findSimpleSources', {}).then((res) => {
					this.sourceNames = res.data.data;
				})
			},
			getSourceSub: function(id) { //获取来源小类数据
				if(id != "") {
					instance.get('/source/findSourceSubs4Source/' + id).then((res) => {
						this.sourceNameSubs = res.data.data;
					})
				}else{
					this.sourceNameSubs=[];
				}

			},
			getStudent: function() { //获取学生列表
				var params = {
					"beginRow": (this.pageNum - 1) * this.pageSize,
					"pageSize": this.pageSize
				};
				// console.log(this.findStudents.qSchoolId);
				// console.log(JSON.stringify(this.findStudents)=="{}");
				if(!(JSON.stringify(this.findStudents) == "{}")) {
					//alert(true);
					var result = $.extend(true, params, this.findStudents);
				} else {
					//alert(false)
					var result = params;
				};
				instance.post('/student/findStudents', result).then((res) => {
					this.studentList = res.data.data;
				})
				this.actionType = "query";

			},
			changePage: function(pageNum) {
				console.info("change-page:" + pageNum);
				this.pageNum = pageNum;
				this.getStudent();
			},
			linkStudentInfo: function(id) { //学生姓名点击跳转详情
				this.$router.push('/xueyuanguanli/studentinfo/' + id + "/baseInfo");
			},
			editInfo: function(id) { //编辑
				this.$router.push('/xueyuanguanli/editStudent/' + id);
			},
			transferClass: function() { //转班
				this.$confirm("确定对选中的学生进行转班?", "提示", {
						confirmButtonText: "确定",
						cancelButtonText: "取消",
						type: "info"
					})
					.then(() => {
						let arr = [];
						var len = this.studentList.length;
						for(var i = 0; i < len; i++) {
							if(this.selectArr.indexOf(i) >= 0) {
								arr.push(this.studentList[i]['studentLessonCard']['studentId']);
							} else {
								console.log(this.selectArr.indexOf(i));
							}
						};
						// alert(arr);
						this.$router.push('/xueyuanguanli/zhuanban/' + arr);

					})
					.catch(() => {});
			},
			divideClass: function() { //分班
				this.$confirm("确定对选中的学生进行分班?", "提示", {
						confirmButtonText: "确定",
						cancelButtonText: "取消",
						type: "info"
					})
					.then(() => {
						let arr = [];
						var len = this.studentList.length;
						for(var i = 0; i < len; i++) {
							if(this.selectArr.indexOf(i) >= 0) {
								arr.push(this.studentList[i]['studentLessonCard']['studentId']);
							} else {
								console.log(this.selectArr.indexOf(i));
							}
						};
						// alert(arr);
						this.$router.push('/xueyuanguanli/fenban/' + arr);

					})
					.catch(() => {});
			},
			deletestu: function(item) { //删除
				this.$confirm("确定删除该的学生?", "警告", {
						confirmButtonText: "确定",
						cancelButtonText: "取消",
						type: "info"
					})
					.then(() => {

					})
					.catch(() => {});
			},
			stopClass: function(item) { //停课
				this.$confirm("确定对所选择的学生进行停课操作吗?", "警告", {
						confirmButtonText: "确定",
						cancelButtonText: "取消",
						type: "info"
					})
					.then(() => {

					})
					.catch(() => {});
			},
			resumeClass: function(item) { //复课
				this.$confirm("确定对所选择的学生进行复课操作吗?", "警告", {
						confirmButtonText: "确定",
						cancelButtonText: "取消",
						type: "info"
					})
					.then(() => {

					})
					.catch(() => {});
			},
			returnClass: function(item) { //退班
				this.$confirm("是否对学生进行退班操作?", "警告", {
						confirmButtonText: "确定",
						cancelButtonText: "取消",
						type: "info"
					})
					.then(() => {

					})
					.catch(() => {});
			},
			bxks: function(item) { //补消课时
				this.$router.push('/xueyuanguanli/buxiaokeshi/' + item);
			},
			returnCost: function(item) { //退费
				this.$confirm("确定对所选择的学生进行退费操作吗?", "警告", {
						confirmButtonText: "确定",
						cancelButtonText: "取消",
						type: "info"
					})
					.then(() => {
						this.$router.push('/xueyuanguanli/tuifei/' + item);
					})
					.catch(() => {});
			},
			buyCard: function(item) { //购卡
				this.$router.push('/xueyuanguanli/buyCard/' + item);
			},

			chooseClass: function(item) { //选班
				this.$router.push('/xueyuanguanli/chooseclass/' + item);
			},
			addvisit: function(informationId) {
				this.$router.push('/zhaoshengguanli/adviceinfo/' + informationId + '/addVisit');
			},
			getvisitList: function(informationId) {
				this.$router.push('/zhaoshengguanli/adviceinfo/' + informationId + '/visitList');
			},
			getModuleActions: function() {
				let routeCodes = this.$route.path.split("/");
				let routeCode = routeCodes[routeCodes.length - 1];
				instance.get('/navi/findUserActions2/' + routeCode).then((res) => {
					if(res.data.errcode == '0') {
						this.actionsList = res.data.data;
					} else {
						//this.$message.error('操作失败！' + res.data.info);
					}
					console.info("json:" + res.data);

				})
			},
			dateDiff: function(d1, d2, str) {
				//console.info(d1+"-----"+d2);
				if(d1 == null || d2 == null) return;
				d1 = new Date(d1.replace(/-/g, '/'));
				d2 = new Date(d2.replace(/-/g, '/'));
				var obj = {},
					M1 = d1.getMonth(),
					D1 = d1.getDate(),
					M2 = d2.getMonth(),
					D2 = d2.getDate();
				obj.Y = d2.getFullYear() - d1.getFullYear() + (M1 * 100 + D1 > M2 * 100 + D2 ? -1 : 0);
				obj.M = obj.Y * 12 + M2 - M1 + (D1 > D2 ? -1 : 0);
				obj.s = Math.floor((d2 - d1) / 1000); //差几秒
				obj.m = Math.floor(obj.s / 60); //差几分钟
				obj.h = Math.floor(obj.m / 60); //差几小时
				obj.D = Math.floor(obj.h / 24); //差几天 
				return obj.Y;
				//      return str.replace(/\w/g,function(a){
				//          return obj[a] ? obj[a]:a;
				//      });
				// dateDiff("2016-9-30","2016-10-1","相差Y年M月D天");
			}
		},
		mounted: function() {
			this.getSchool(); //校区
			//this.getConsult(); //咨询师
			//this.getTeacher(); //授课教师
			//this.getconsultant(); //课程顾问
			this.getSource(); //来源大类
			//this.getStudent();
			//this.getStudentCount(); //数量
			this.getModuleActions();

		}
	};
</script>