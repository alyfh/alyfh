
	<!--<title>购课信息</title>-->
	<style scoped>
        .p_table_la tr:nth-child(1)>td{
        	word-break: keep-all;
        	word-break: keep-all;
        	white-space:nowrap;
        }
	</style>
  <template>
	<div class="p_con_tab">
		<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
      <span>购课信息{{ifBuyClass}}</span>
    </h3>
		<div class="p_table_la_over">
			<table class="p_table_la" cellspacing="0" cellpadding="0">
				<tr>
					<td>订单号</td>
					<td>订单时间</td>
					<td>学员姓名</td>
					<td>购课校区</td>
					<td>会员卡类型</td>
					<!--<td>有效期截止日期</td>-->
					<td>会员卡号</td>
					<td>原价</td>
					<td>现价</td>
					<td>优惠金额</td>
					<td>实收金额</td>
					<td>课时</td>
					<td>赠送课时</td>
					<td>总课时</td>
					<td>审核状态</td>
					<td>支付方式</td>
					<td>支付状态</td>
					<td>经办人</td>
				</tr>
        <tr v-for="info in buyClassDetail">
          <td>{{info.orderCode}}</td>
          <td>{{info.orderTime}}</td>
          <td>{{info.studentName}}</td>
          <td>{{info.schoolName}}</td>
          <td>{{info.cardName}}</td>
          <td>{{info.studentLessonCardCode}}</td>
          <td>{{info.sourceMoney}}</td>
          <td>{{info.currentMoney}}</td>
          <td>{{info.discountMoney}}</td>
          <td>{{info.money}}</td>
          <!--<td>{{info.orderTime}}</td>-->
          <td>{{info.hour}}</td>
          <td>{{info.giveHour}}</td>
          <td>{{info.sumHour}}</td>
          <td>{{approveStatusDict[info.approveStatus]}}</td>
          <td>{{paymentDict[info.payType]}}</td>
          <td>{{payStateDict[info.payStatus]}}</td>
          <td>{{info.creatorName}}</td>
        </tr>
			</table>
		</div>
	</div>
  </template>
  <script>
    import instance from '../../../api/index.js';
    import { mapState } from 'vuex';
    export default {
      data() {
        return {
          buyClassDetail:[],
          ifBuyClass:""
        };
      },
      computed: {　
			// Getting Vuex State from store/index
			...mapState({
				payStateDict: state => state.payStateDict,
				paymentDict: state => state.paymentDict,
				approveStatusDict: state => state.approveStatusDict,
			})
				
		},
      methods:{
        getBuyClassInfo:function(id){//获取购课列表信息
          instance.get('/buycard/findStudentBuyCards/'+id,{
          // instance.post('/buycard/findBuyCards',{
          }).then((res) => {
            if(res.data.data==null){
              this.ifBuyClass='('+res.data.errmsg+')';
            }else{
              this.ifBuyClass="";
              this.buyClassDetail=res.data.data;
            }
          })
        }
        // getReturnCount:function(){
        //
        // }
      },
      mounted: function() {
        this.getBuyClassInfo(this.$route.params.id);
        // this.getconsultInfo();
      }
    };
  </script>
