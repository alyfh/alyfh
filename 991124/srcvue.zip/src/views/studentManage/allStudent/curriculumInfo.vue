<!--<title>课程明细</title>-->
<style scoped>
	.p_table_la tr:nth-child(1)>td {
		word-break: keep-all;
		word-break: keep-all;
		white-space: nowrap;
	}
</style>
<template>
	<div class="p_con_tab">
		<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
            	<span>课程明细</span>
        	</h3>
		<div class="p_table_la_over">

			<table class="p_table_la" cellspacing="0" cellpadding="0">
				<tr>
					<td>购课校区</td>
					<td>班级名</td>
					<td>授课类型</td>
					<td>班型</td>
					<td>总课时</td>
					<td>课程大类</td>
					<td>课程小类</td>
					<td>开始上课日期</td>
					<td>星期</td>
					<td>上课时间段</td>
					<td>每次课时</td>
					<td>授课教师</td>
					<td v-if="$_has(actionsList,'returnClass')">操作</td>
				</tr>
				<template v-for="(info,i) in classDetail">
					<template v-for="(lesson,j) in info.lessons">
						<tr v-if="j==0">
							<td :rowspan='info.lessons.length'>{{info.schoolName}}</td>
							<td :rowspan='info.lessons.length'>{{info.className}}</td>
							<td :rowspan='info.lessons.length'>{{classTypeDict[info.oneByOne]}}</td>
							<td :rowspan='info.lessons.length'>{{info.classTypeName}}</td>
							<td :rowspan='info.lessons.length'>{{info.planHour}}</td>
							<td>{{lesson.courseName}}</td>
							<td>{{lesson.courseSubName}}</td>
							<td>{{lesson.beginDate}}</td>
							<td>{{weekDay[lesson.weekday]}}</td>
							<td>{{lesson.beginTime}}-{{lesson.endTime}}</td>
							<td>{{lesson.lessonHour}}</td>
							<td>{{lesson.teacherName}}</td>
							<td :rowspan='info.lessons.length' v-if="$_has(actionsList,'returnClass')">
								<input type="button" value="退班" class="p_btn p_btn_siz_3 p_btn_col_k_red p_btn_pos_r" @click="returnClass(info.id)">

							</td>
						</tr>
						<tr v-else>
							<td>{{lesson.courseName}}</td>
							<td>{{lesson.courseSubName}}</td>
							<td>{{lesson.beginDate}}</td>
							<td>{{weekDay[lesson.weekday]}}</td>
							<td>{{lesson.beginTime}}-{{lesson.endTime}}</td>
							<td>{{lesson.lessonHour}}</td>
							<td>{{lesson.teacherName}}</td>

						</tr>

					</template>
				</template>

			</table>
		</div>
	</div>
</template>
<script>
	import instance from '../../../api/index.js';
	import { mapState } from 'vuex';
	export default {
		data() {
			return {
				classDetail: [],
				actionsList: [], //获取当前用户对当前模块授权操作
				ifBuyClass: "",
				weekDay: {
					"1": "星期一",
					"2": "星期二",
					"3": "星期三",
					"4": "星期四",
					"5": "星期五",
					"6": "星期六",
					"7": "星期日"
				}
			};
		},
		computed: {　
			// Getting Vuex State from store/index
			...mapState({
				classTypeDict: state => state.classTypeDict,
			})

		},
		methods: {
			getBuyClassInfo: function(id) { //获取学员班级列表信息
				instance.get('/class/findStudentClasses/' + id).then((res) => {
					if(res.data.data == null) {
						this.ifBuyClass = '(' + res.data.errmsg + ')';
					} else {
						this.ifBuyClass = "";
						this.classDetail = res.data.data;
					}
				})
			},
			returnClass: function(classId) { //退班
				this.$confirm("是否对学生进行退班操作?", "警告", {
						confirmButtonText: "确定",
						cancelButtonText: "取消",
						type: "info"
					})
					.then(() => {
						instance.get('/student/quitClass/' + classId + "/" + this.$route.params.id).then((res) => {
							if(res.data.errcode == '0') {
								this.$message.info('学员退班成功！');
								this.getBuyClassInfo(this.$route.params.id);
							} else {
								this.$message.error('操作失败！' + res.data.errmsg);
							}
						})
					})
					.catch(() => {});
			},
			getModuleActions: function() {
				//let routeCodes = this.$route.path.split("/");
				let routeCode = "xueyuanguanli_yewubanlis";
				instance.get('/navi/findUserActions2/' + routeCode).then((res) => {
					if(res.data.errcode == '0') {
						this.actionsList = res.data.data;
					} else {
						//this.$message.error('操作失败！' + res.data.info);
					}
					console.info("json:" + res.data);

				})
			}

		},
		mounted: function() {
			this.getBuyClassInfo(this.$route.params.id);
			this.getModuleActions();
		}
	};
</script>