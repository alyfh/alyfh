<!--<title>新增学员</title>-->
<style>
	.el-input__inner {
		height: 25px;
	}
	
	.edit_inp {
		width: 25%;
		margin-top: -5px;
		height: 25px;
	}
	
	.edit_inp_no {
		background-color: #f0f0f0;
		border: none;
	}
</style>
<template>
	<form id="addstu" method="post" action="" class="ue_form_add">
		<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
        	<span>新增学员</span>
        	<!--<span class='h5_mark_xx2'>★</span>-->
        	<!--<span>为必填)</span>-->
    </h3>
		<ul class='h5_02_info_per_addlist'>
			<li>
				<span>★</span>
				<span>学员姓名:</span>
				<span>{{studentDetail.studentName}}</span>
			</li>
			<li>
				<span>★</span>
				<span>相关意向学员:</span>
				<span>{{studentDetail.informationStudentName}}</span>

			</li>
			<li>
				<span>★</span>
				<span>出生日期:</span>
				<span>
            {{studentDetail.birthday}}
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>性别:</span>
				<span>
            {{studentDetail.sex}}
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>家长姓名:</span>
				<span>
            {{studentDetail.parentName}}
          </span>
			</li>
			<li>
				<span>★</span>
				<span>与学员关系:</span>
				<span>
            {{studentDetail.relationShip}}
    			</span>
			</li>

			<li>
				<span>★</span>
				<span>联系人手机:</span>
				<span>
            {{studentDetail.telephone}}
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>QQ:</span>
				<span>
            {{studentDetail.qq}}
          </span>
			</li>
			<li>
				<span>★</span>
				<span>邮箱:</span>
				<span>
              {{studentDetail.email}}
            </span>
			</li>
			<li>
				<span>★</span>
				<span>微信:</span>
				<span>
            {{studentDetail.wechat}}
          </span>
			</li>
			<li>
				<span>★</span>
				<span>来源大类:</span>
				<span>
            {{studentDetail.sourceName}}
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>来源小类:</span>
				<span>
            {{studentDetail.sourceSubName}}
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>所属校区:</span>
				<span>
            {{studentDetail.schoolName}}
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>课程大类:</span>
				<span>
            {{studentDetail.courseName}}
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>课程小类:</span>
				<span>
            {{studentDetail.courseSubName}}
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>咨询师:</span>
				<span>
            {{studentDetail.counselorName}}
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>课程顾问:</span>
				<span>
            {{studentDetail.courseCounselorName}}
    			</span>
			</li>

		</ul>
		<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
      <span>购卡信息{{ifCard}}</span>
      <!--<span class='h5_mark_xx2'>★</span>-->
      <!--<span>为必填)</span>-->
    </h3>
		<ul class='h5_02_info_per_addlist'>

			<li>
				<span>★</span>
				<span>会员卡号:</span>
				<span>
          {{cardDetail.cardCode}}
        </span>

			</li>
			<li>
				<span>★</span>
				<span>总课时:</span>
				<span>
            {{cardDetail.sumHour}}
        </span>
			</li>

			<li>
				<span>★</span>
				<span>课堂消耗课时:</span>
				<span>
            {{usedHour}}
        </span>
			</li>
			<li>
				<span>★</span>
				<span>期初消耗课时:</span>
				<span>
          <input type="text" class='per_addperson_txt edit_inp ' :class="{edit_inp_no:isShow_editInitHour}" v-model="cardDetail.initHour" style="width: 25%;margin-top: -5px;" name="期初消耗课时" :disabled="isShow_editInitHour">
            <!--{{cardDetail.initHour}}-->

            <!--<input type="text" class='per_addperson_txt' v-show="isShow_saveInitHour" v-model="cardDetail.initHour" v-validate="'numeric'" name="期初消耗课时">-->
            <input type="button" value="编辑" v-show="isShow_editInitHour" class="p_btn p_btn_siz_2 p_btn_col_k_oran p_btn_pos_r" style="z-index: 100;padding: 1px 2px;font-size: 0.8rem;margin-right: calc(100% - 90px);margin-top: 9px;margin-left: 2px" @click="editInitHour()">
            <input type="button" value="保存" v-show="isShow_saveInitHour" class="p_btn p_btn_siz_2 p_btn_col_k_oran p_btn_pos_r" style="z-index: 100;padding: 1px 2px;font-size: 0.8rem;margin-right: calc(100% - 90px);margin-top: 9px;margin-left: 2px" @click="saveInitHour()">
        </span>
			</li>

			<li>
				<span>★</span>
				<span>剩余课时:</span>
				<span>
            {{cardDetail.hour}}
        </span>
			</li>

		</ul>
	</form>
</template>
<script>
	import instance from '../../../api/index.js';
	import { mapState } from 'vuex';
	export default {
		data() {
			return {
				studentDetail: {},
				cardDetail: {},
				ifCard: "",
				usedHour: '',
				isShow_editInitHour: true, //控制 期初消耗课时 编辑控制显示
				isShow_saveInitHour: false, //控制 期初消耗课时 保存控制显示
			};
		},
		computed: {　
			// Getting Vuex State from store/index
			...mapState({
				payStateDict: state => state.payStateDict,
				paymentDict: state => state.paymentDict,
			}),
			　
			//		usedHour() {　　　　
			//			return parseFloat(this.cardDetail.sumHour)　 - 　parseFloat(this.cardDetail.hour);
			//		}

		},
		methods: {
			getStudentInfo: function(id) { //获取学员信息
				instance.get('/student/findStudent/' + id, {}).then((res) => {
					this.studentDetail = res.data.data;
				})
			},
			getCardInfo: function(id) { //获取课时卡信息
				instance.get('/student/findStudentLessonCard/' + id, {}).then((res) => {
					if(res.data.data == null) {
						this.ifCard = '(' + res.data.errmsg + ')';
					} else {
						this.ifCard = "";
						this.cardDetail = res.data.data;
						this.usedHour = parseFloat(this.cardDetail.sumHour)　 - 　parseFloat(this.cardDetail.hour) - parseFloat(this.cardDetail.initHour);
					}

				})

			},
			//保存 期初消耗课时 校验
			changeInitHour: function() {
				if(parseFloat(this.cardDetail.initHour) > parseFloat(this.cardDetail.sumHour)) {
					this.$message.info('期初消耗课时不得大于总课时！');
					this.cardDetail.initHour = 0;
				} else {
					this.cardDetail.hour = parseFloat(this.cardDetail.sumHour) - parseFloat(this.usedHour) - parseFloat(this.cardDetail.initHour);
				}
			},
			//编辑期初消耗课时
			editInitHour: function() {
				this.isShow_editInitHour = false;
				this.isShow_saveInitHour = true;
			},
			//保存期初消耗课时
			saveInitHour: function() {
				if(parseFloat(this.cardDetail.initHour) > parseFloat(this.cardDetail.sumHour)) {
					this.$message.info('期初消耗课时不得大于总课时！');
					this.cardDetail.initHour = 0;
				} else {
					instance.get('/student/changeInitLessonHours/' + this.cardDetail.id + '/' + this.cardDetail.initHour, {}).then((res) => {
						if(res.data.errcode == '0') {
							this.$message.info('信息保存成功！');
							this.isShow_editInitHour = true;
							this.isShow_saveInitHour = false;
							this.cardDetail.hour = parseFloat(this.cardDetail.sumHour) - parseFloat(this.usedHour) - parseFloat(this.cardDetail.initHour);
						} else {
							this.$message.error('操作失败！' + res.data.errmsg);
						}
					})
					
				}

			}
		},
		mounted: function() {
			this.getStudentInfo(this.$route.params.id);
			this.getCardInfo(this.$route.params.id);
		}
	};
</script>