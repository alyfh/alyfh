
    <!--<title>学员档案</title>-->
    <style>
        .zxt{
            width:95%;
            position:relative;
            margin:auto;
            margin-top: 15px;
        }
        .zxt_nav {
            left: 20px;
            top: 0px
        }
        .h5_iframe1_table_page{
            width:calc(100% - 30px);
            margin-bottom: 15px;
            background-color: #f0f0f0;
            margin-left: 10px;
            padding: 1px
        }
    </style>
    <template>
<div class="zxt">
  <div class="p_btn_group1 p_clear_float">
    <input type="button" value="返回" class="p_btn p_btn_siz_2 p_btn_col_pink p_btn_pos_r" style="z-index: 100" @click="$router.go(-1)">
  </div>
  <div class='zxt_nav p_clear_float'>
      <div v-for="(lists, index) in list" :class="{'zxt_nav_click':ind === index}"
        @click="changeBgc(index)">{{lists.name}}
      </div>

    </div>
    <div class="h5_iframe1_table_page">
      <router-view></router-view>
    </div>
</div>
    </template>
    <script>
      import instance from '../../../api/index.js';
      import { mapState } from 'vuex';
      export default {
        data() {
          return {
            list: [
              {
                'name':'基本信息',
                'url':'/baseInfo'
              },
              {
                'name':'咨询信息',
                'url':'/consultInfo'
              },
              {
                'name':'回访信息',
                'url':'/returnVisitInfo'
              },
              {
                'name':'购课信息',
                'url':'/buyClassInfo'
              },
              {
                'name':'课程明细',
                'url':'/kechengmingxi'
              },
              {
                'name':'课程表',
                'url':'/Schedule'
              },
              {
                'name':'课时消耗记录',
                'url':'/keshixiaohao'
              }],
          ind: 0
          };
        },
        methods:{
          changeBgc: function (index) {
            this.ind = index;
            var str=this.list[index]['url'];
            this.linkStudentInfo(str);

          },
          linkStudentInfo:function(url){
            this.$router.push('/xueyuanguanli/studentinfo/'+this.$route.params.id+url);
          }
        },
        mounted: function() {
         // this.linkStudentInfo('/baseInfo');

        }
      };
    </script>

