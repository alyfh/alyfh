<!--<title>新增学员</title>-->
<style>
	.el-input__inner {
		height: 25px;
	}
</style>
<template>
	<form id="addstu" method="post" action="" class="ue_form_add">
		<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
        	<span>学员信息(</span>
        	<span class='h5_mark_xx2'>★</span>
        	<span>为必填)</span>
    	</h3>
		<ul class='h5_02_info_per_addlist'>
			<li>
				<span>★</span>
				<span>学员姓名:</span>
				<span><input type="text" class='per_addperson_txt' v-model="studentDetail.studentName"></span>
			</li>
			<li>
				<span></span>
				<span>相关意向学员:</span>
				<span><input type="text" readonly class='per_addperson_txt' v-model="studentDetail.informationStudentName"></span>
			</li>
			<li>
				<span>★</span>
				<span>出生日期:</span>
				<span>
            <el-date-picker type="date"  value-format="yyyy-MM-dd" placeholder="Pick a date" style="width:100%" v-model="studentDetail.birthday"></el-date-picker>
    				<!--<input type="text" class='per_addperson_txt' v-model="studentDetail.birthday">-->

    			</span>
			</li>
			<li>
				<span>★</span>
				<span>性别:</span>
				<span>
                    <select name=""  class='per_addperson_txt' v-model="studentDetail.sex">
                       <option value="男">男</option>
                       <option value="女">女</option>
                   </select>
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>家长姓名:</span>
				<span><input type="text" class='per_addperson_txt' v-model="studentDetail.parentName"></span>
			</li>
			<li>
				<span>★</span>
				<span>与学员关系:</span>
				<span>
    				<!--<input type="text" class='per_addperson_txt' v-model="studentDetail.relationShip">-->
          <select name="" id="" class='per_addperson_txt' v-model="studentDetail.relationShip">
    				  <option  value="" >请选择</option>
              <option value="爸爸">爸爸</option>
              <option value="妈妈">妈妈</option>
              <option value="祖父母">祖父母</option>
              <option value="其他">其他</option>
            </select>

    			</span>
			</li>

			<li>
				<span>★</span>
				<span>联系人手机:</span>
				<span>
    				<input type="text" class='per_addperson_txt' v-model="studentDetail.telephone">
    			</span>
			</li>
			<li>
				<span></span>
				<span>QQ:</span>
				<span><input type="text" class='per_addperson_txt' v-model="studentDetail.qq"></span>
			</li>
			<li>
				<span></span>
				<span>邮箱:</span>
				<span><input type="text" class='per_addperson_txt' v-model="studentDetail.email"></span>
			</li>
			<li>
				<span></span>
				<span>微信:</span>
				<span><input type="text" class='per_addperson_txt' v-model="studentDetail.wechat"></span>
			</li>
			<li>
				<span>★</span>
				<span>来源大类:</span>
				<span>
    				<select name="" id="" class='per_addperson_txt' v-model="studentDetail.sourceId" @change="getSourceSub(studentDetail.sourceId)">
                <option disabled value="">请选择</option>
                <option v-for="sourceName in sourceNames" :value="sourceName.id">{{sourceName.sourceName}}</option>
            </select>
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>来源小类:</span>
				<span>
    				<select name="" id="" class='per_addperson_txt' v-model="studentDetail.sourceSubId">
              <option v-for="sourceSubName in sourceNameSubs" :value="sourceSubName.id">{{sourceSubName.sourceSubName}}</option>
            </select>
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>所属校区:</span>
				<span>
    				<select name=""  class='per_addperson_txt' v-model="studentDetail.schoolId" @change="getClass">
              <option v-for="sName in schoolNames" :value="sName.id">{{ sName.schoolName }}</option>
            </select>
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>课程大类:</span>
				<span>
    				<select  class='per_addperson_txt' v-model="studentDetail.courseId" @change="getClassSub(studentDetail.courseId)">
                <option disabled value="">请选择</option>
                <option v-for="className in classNames" :value="className.id">{{className.courseName}}</option>
            </select>
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>课程小类:</span>
				<span>
    				<select name="" id="" class='per_addperson_txt' v-model="studentDetail.courseSubId">
              <option disabled value="">请选择</option>
              <option v-for="classNameSub in classNameSubs" :value="classNameSub.id">{{classNameSub.courseSubName}}</option>
            </select>
    			</span>
			</li>
			<li>
				<span></span>
				<span>咨询师:</span>
				<span>
    				<select name="" id="" class='per_addperson_txt' v-model="studentDetail.counselorId">
              <option v-for="counselorName in counselorNames" :value="counselorName.id">{{counselorName.realName}}</option>
            </select>
    			</span>
			</li>
			<li>
				<span></span>
				<span>课程顾问:</span>
				<span>
    				<select name="" id="" class='per_addperson_txt' v-model="studentDetail.courseCounselorId">
              <option v-for="consultant in consultants" :value="consultant.id">{{consultant.realName}}</option>
            </select>
    			</span>
			</li>

		</ul>

		<br class="p_zwf">
		<div class="p_btn_group p_clear_float">
			<input type="button" value="返回" @click="$router.go(-1)" class="p_btn p_btn_siz_2 p_btn_col_red p_btn_pos_r">
			<input type="button" value="购卡" v-if="!studentDetail.id" @click="buyCard(studentDetail)" class="p_btn p_btn_siz_2 p_btn_col_ora p_btn_pos_r">
			<input type="button" value="保存" @click="saveStudent(studentDetail)" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r">
		</div>
	</form>
</template>
<script>
	import instance from '../../../api/index.js';
	import { mapState } from 'vuex';
  import * as util from '../../../assets/util.js';
	export default {
		data() {
			return {
				studentDetail: {
					courseId: "",
					sourceId: ""
				},
				adviceDetail: {},
				schoolNames: [],
				classNames: [],
				classNameSubs: [],
				sourceNames: [],
				sourceNameSubs: [],
        loginInfo: {},
				counselorNames: [], //咨询师
				consultants: [] //课程顾问
			};
		},
		methods: {
			saveStudent: function(item) {
				item.id ? this.updateStudent(item) : this.CreateStudent(item)
			},
			updateStudent: function(item) {
				instance.post('/student/changeStudent', item).then((res) => {
					if(res.data.errcode == '0') {
						this.$message.info('信息修改成功！');
						this.$router.go(-1);
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}
				})
			},
			CreateStudent: function(item) { //保存新增学员
				instance.post('/student/createStudent', item).then((res) => {
					if(res.data.errcode == '0') {
						this.studentDetail.id = res.data.data.id;
						this.$message.info('信息创建成功！');
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}

				})
			},
			buyCard: function(item) { //购卡
				if(item.id) {
					this.$router.push('/xueyuanguanli/buyCard/' + item.id);

				} else {
					instance.post('/student/createStudent', item).then((res) => {
						if(res.data.errcode == '0') {
							this.$router.push('/xueyuanguanli/buyCard/' + res.data.data.id);
						} else {
							this.$message.error('操作失败！' + res.data.errmsg);
						}

					})
				}

			},
			getSchool: function() { //获取校区数据
        this.loginInfo = util.session("loginInfo", void(0));
        // /school/findUserSchools/:userId
				instance.get('/school/findUserSchools/'+this.loginInfo.login.userId).then((res) => {
					this.schoolNames = res.data.data;
          // this.getClass();

             this.getSource();
				})
			},
			getClass: function() { //获取课程大类数据
				instance.post('/course/findCourses', {
          qSchoolId: this.studentDetail.schoolId
        }).then((res) => {
					this.classNames = res.data.data;
					var index=false;
					for(var i=0;i<this.classNames.length;i++){
					  if(this.studentDetail.courseId==this.classNames[i].id){
					    index=true;
            }
          }
          if(!index){
            this.classNameSubs=[];
          }

				});

        this.getConsult();
				this.getconsultant();
			},
			getClassSub: function(id) { //获取课程小类数据
          instance.post('/course/findSimpleCourseSubs', {
            qSchoolId: this.studentDetail.schoolId,
            qCourseId: id
          }).then((res) => {
            this.classNameSubs = res.data.data;
          })
        // }

			},
			getSource: function() { //获取来源大类数据
				instance.post('/source/findSimpleSources', {}).then((res) => {
					this.sourceNames = res.data.data;
				})
			},
			getSourceSub: function(id) { //获取来源小类数据
				// alert(id);
				instance.get('/source/findSourceSubs4Source/' + id).then((res) => {
					this.sourceNameSubs = res.data.data;
				})
			},
      getConsult: function() { //获取咨询师列表
        instance.post('/user/findSystemRoleSimpleUser', {
          qSchoolId: this.studentDetail.schoolId,
          qRoleCode: "counselor",
        }).then((res) => {
          this.counselorNames = res.data.data;
        })
      },
      getconsultant: function() { //获取课程顾问列表
        instance.post('/user/findSystemRoleSimpleUser', {
          qSchoolId: this.studentDetail.schoolId,
          qRoleCode: "coursecounselor",
        }).then((res) => {
          this.consultants = res.data.data;
        })
      },
			getAdivceInfo: function(id) { //获取咨询信息信息
				instance.get('/infor/findInformation/' + id).then((res) => {
					this.adviceDetail = res.data.data;
					this.studentDetail.informationId = this.adviceDetail.id;
					this.studentDetail.informationStudentName = this.adviceDetail.studentName;
					this.studentDetail.sex = this.adviceDetail.sex;
					this.studentDetail.telephone = this.adviceDetail.telephone;
					this.studentDetail.relationShip = this.adviceDetail.relationShip;
					this.studentDetail.qq = this.adviceDetail.iceD;
					this.studentDetail.email = this.adviceDetail.email;
					this.studentDetail.qq = this.adviceDetail.qq;
					this.studentDetail.wechat = this.adviceDetail.wechat;
					this.studentDetail.sourceId = this.adviceDetail.sourceId;
					this.studentDetail.sourceSubId = this.adviceDetail.sourceSubId;
					this.studentDetail.schoolId = this.adviceDetail.schoolId;
					this.studentDetail.courseId = this.adviceDetail.courseId;
					this.studentDetail.courseSubId = this.adviceDetail.courseSubId;
					this.studentDetail.counselorId = this.adviceDetail.counselorId;
					this.studentDetail.courseCounselorId = this.adviceDetail.courseCounselorId;
          this.getClass();
					if(this.studentDetail.courseId != "")
						this.getClassSub(this.studentDetail.courseId);

					if(this.studentDetail.sourceId != "")
						this.getSourceSub(this.studentDetail.sourceId);

				})
			},
			getStudentInfo: function(id) { //获取学员信息
				instance.get('/student/findStudent/' + id).then((res) => {
					this.studentDetail = res.data.data;

					if(this.studentDetail.courseId != "")
						this.getClassSub(this.studentDetail.courseId);

					if(this.studentDetail.sourceId != "")
						this.getSourceSub(this.studentDetail.sourceId);

				})
			},
		},
		mounted: function() {
			if(this.$route.params.adviceId) { //新增学员传递咨询ID
				this.getAdivceInfo(this.$route.params.adviceId);
			} else if(this.$route.params.studentId) { //修改
				this.getStudentInfo(this.$route.params.studentId);
			}
			this.getSchool();
			// this.getClass();
            //
			// this.getSource();
			// this.getConsult();
			// this.getconsultant();
		}
	};
</script>
