<!--<title>选班</title>-->
<style>
	.el-input__inner {
		height: 23px;
	}
</style>
<template>
	<div>
		<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
    <span>学员选班</span>
  </h3>
		<div class="p_con_sea">
			<ul class="p_con_sea_list p_clear_float">
				<li>
					<span>所属校区:</span>
					<span>
            <select name=""  class="p_con_form_select" v-model="findClass.qSchoolId" @change="getTeacher(findClass.qSchoolId)">
              <!--option value="">-请选择-</option-->
              <option v-for="sName in schoolNames" :value="sName.id">{{ sName.schoolName }}</option>
            </select>
					</span>
				</li>
				</li>
				<li>
					<span>课程大类:</span>
					<span>
            <select name="" id="" class="p_con_form_select" v-model="findClass.qCourseId" @change="getClassSub(findClass.qCourseId)">
                <option value="">-请选择-</option>
               <option v-for="className in classNames" :value="className.id">{{className.courseName}}</option>
            </select>
					</span>
				</li>
				<li>
					<span>课程小类:</span>
					<span>
            <select name="" id="" class="p_con_form_select" v-model="findClass.qCourseSubId">
              <!--<option value="">-</option>-->
                         <option v-for="classNameSub in classNameSubs" :value="classNameSub.id">{{classNameSub.courseSubName}}</option>
            </select>
					</span>
				</li>
				<li>
					<span>班级类别:</span>
					<span>
					<select name="" id="" class="p_con_form_select" v-model="findClass.qOneByOne">
						 <option v-for = "(item,key) in classTypeDict" :value="key">{{item}}</option>

					</select>
				</span>
				</li>
				<li>
					<span>授课教师:</span>
					<span>
					<select name="" id="" class="p_con_form_select" v-model="findClass.qTeacherId">
               <!--<option value="">-</option>-->
               <option v-for="teacher in teachers" :value="teacher.id">{{teacher.realName}}</option>
            </select>
				</span>
				</li>
				<li>
					<span>上课日期:</span>
					<span>
					<select name="" id="" class="p_con_form_select" v-model="findClass.qWeekday">
						<option value="">-请选择-</option>
						<option value="1">星期一</option>
						<option value="2">星期二</option>
						<option value="3">星期三</option>
						<option value="4">星期四</option>
						<option value="5">星期五</option>
						<option value="6">星期六</option>
						<option value="7">星期日</option>
					</select>
				</span>
				</li>
				<li>
					<span>开课日期起:</span>
					<span>
					<el-date-picker type="date"   value-format="yyyy-MM-dd" placeholder="Pick a date" style="width:100%" v-model="findClass.qBeginBeginDate"></el-date-picker>

				</span>
				</li>
				<li>
					<span>开课日期止:</span>
					<span>
					<el-date-picker type="date"   value-format="yyyy-MM-dd" placeholder="Pick a date" style="width:100%;height:23px" v-model="findClass.qEndBeginDate"></el-date-picker>

				</span>
				</li>

			</ul>
			<div class="p_btn_group p_clear_float">
				<!--<input type="button" value="返回" class="p_btn p_btn_siz_2 p_btn_col_red p_btn_pos_r">-->
				<input type="button" value="查询" @click="query" class="p_btn p_btn_siz_2 p_btn_col_gre p_btn_pos_r">

			</div>
			<table class="p_table_font" cellspacing="0" cellpadding="0">
				<!--tr>
					<td>上课日期：</td>
					<td>
						<span>
						<input type="checkbox">
						<label for="">全部</label>
					</span>
						<span>
						<input type="checkbox">
						<label for="">周一</label>
					</span>
						<span>
						<input type="checkbox">
						<label for="">周二</label>
					</span>
						<span>
						<input type="checkbox">
						<label for="">周三</label>
					</span>
						<span>
						<input type="checkbox">
						<label for="">周四</label>
					</span>
						<span>
						<input type="checkbox">
						<label for="">周五</label>
					</span>
						<span>
						<input type="checkbox">
						<label for="">周六</label>
					</span>
						<span>
						<input type="checkbox">
						<label for="">周日</label>
					</span>
					</td>
				</tr-->
				<tr>
					<td width="100px">班级名称：</td>
					<td>
						<template v-for=" (c,index) in classList">
							<span style="margin-bottom: 3px;display:block;width:20%;float: left;padding: 3px 0px">
						    <input type="radio" :value="c" v-model="classInfo" :id="c.id">
						    <label :for="c.id" style="cursor: pointer">{{c.className}}</label>
					    </span>
							<!--<br v-show="parseInt(index%3)==0&&index!=0?true:false"/>-->
						</template>

					</td>
				</tr>

				<tr>
					<td>上课教室：</td>
					<td>
						<table>
							<tr v-for="lesson in classInfo.lessons">
								<td>{{weekdays[lesson.weekday]}}{{lesson.beginTime}}-{{lesson.endTime}}</td>
								<td>{{lesson.teacherName}}</td>
								<td>{{lesson.classRoomName}}</td>
							</tr>

						</table>
					</td>
				</tr>
			</table>
			<div class="p_btn_group p_clear_float">
				<input type="button" value="返回" @click="$router.go(-1)" class="p_btn p_btn_siz_2 p_btn_col_oran p_btn_pos_r">
				<input type="button" value="保存" @click="saveInfo" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r">
			</div>
		</div>
	</div>
</template>
<script>
	import instance from '../../../api/index.js';
	import { mapState } from 'vuex';
	import * as util from '../../../assets/util.js';
	export default {
		data() {
			return {
				findClass: {
          'qClassStatus':0
        },
				classList: [], //班级列表
				classNames: [], //课程大类
				classNameSubs: [], //课程小类
				schoolNames: [], //校区,
				teachers: [], //授课教师
				classInfo: [], //班级详情
				studentId: this.$route.params.id,
				weekdays: {
					1: "星期一",
					2: "星期二",
					3: "星期三",
					4: "星期四",
					5: "星期五",
					6: "星期六",
					7: "星期日",
				}
			}
		},
		created: function() {
			//			this.getDoRefund(this.$route.params.id);
			//			if(util.session('loginInfo')) {
			//				let loginInfo = util.session('loginInfo').login;
			//				this.cardDetail.actorRealName = loginInfo.realName;
			//				this.cardDetail.actorUserId = loginInfo.userId;
			//			}

		},
		computed: {　
			// Getting Vuex State from store/index
			...mapState({
				classTypeDict: state => state.classTypeDict,

			}),
			　

		},
		　　watch: {　　　　　　　　

		},
		methods: {
			saveInfo: function() { //保存
				instance.get('/student/selectClass/' + this.classInfo.id + "/" + this.studentId).then((res) => {
					if(res.data.errcode == '0') {
						this.$message.info('选班成功！');
						this.$router.go(-1);
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}

				})
			},
			query: function() {
				instance.post('/class/findClasses', this.findClass).then((res) => {
					if(res.data.errcode == '0') {
						this.classList = res.data.data;
						this.classInfo = [];
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}

				})

			},
			getClass: function() { //获取课程大类数据
				// course/findCourses
				// /course/findSimpleCourse
				instance.post('/course/findCourses', {}).then((res) => {
					this.classNames = res.data.data;
				})
			},
			getClassSub: function(id) { //获取课程小类数据
				// /course/findSimpleCourseSubs
				instance.post('/course/findSimpleCourseSubs', {
					qCourseId: id
				}).then((res) => {
					this.classNameSubs = res.data.data;
					// console.info(res.data);
				})
			},
			getSchool: function() { //获取校区数据
				//获取当前登录人
				let loginInfo = util.session("loginInfo");
				instance.get('/school/findUserSchools/' + loginInfo.login.userId).then((res) => {
					this.schoolNames = res.data.data;
				})
			},
			getTeacher: function(schoolId) { //获取授课教师列表
				instance.post('/teacher/findSimpleTeachers', {
					qSchoolId: schoolId
				}).then((res) => {
					this.teachers = res.data.data;
				})
			},

		},
		mounted: function() {
			this.getClass();
			this.getSchool();
			//this.getCard();

		}
	};
</script>
