<!--<title>购卡</title>-->

<template>
	<form id="" method="post" action="" class="ue_form_add">
		<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
        	<span>购卡信息(</span>
        	<span class='h5_mark_xx2'>★</span>
        	<span>为必填)</span><span v-if="errors.any()" style="color:red">{{ errors.all() }}</span>
    	</h3>
		<ul class='h5_02_info_per_addlist'>
			<li>
				<span>★</span>
				<span>订单号:</span>
				<span>
    				<input type="text" class='per_addperson_txt' readonly v-model="cardDetail.orderCode"></span>
			</li>
			<li>
				<span>★</span>
				<span>订单时间:</span>
				<span>
    				<input type="text" class='per_addperson_txt' readonly v-model="cardDetail.orderTime"></span>
			</li>
			<li>
				<span>★</span>
				<span>购课校区:</span>
				<span>
    				<input type="text" class='per_addperson_txt' readonly v-model="cardDetail.schoolName"></span>
			</li>
			<li>
				<span>★</span>
				<span>学生姓名:</span>
				<span>
    				<input type="text" class='per_addperson_txt' readonly v-model="cardDetail.studentName"></span>
			</li>
			<li>
				<span>★</span>
				<span>会员卡类型:</span>
				<span>
             <select  class='per_addperson_txt'  v-model="cardDetail.cardId" @change="getCardInfo(cardDetail.cardId)">
               <option  v-for="card in cardInfo" :value="card.id">{{card.cardName}}</option>
             </select>
          </span>
			</li>
			<li>
				<span></span>
				<span>有效期:</span>
				<span>
    				<input type="text" class='per_addperson_txt' readonly v-model="cardDetail.validDate"></span>
			</li>

			<li>
				<span>★</span>
				<span>会员卡号:</span>
				<span>
    				<input type="text" class='per_addperson_txt' readonly  v-model="cardDetail.studentLessonCardCode">
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>原价:</span>
				<span><input type="text" class='per_addperson_txt' readonly v-model="cardDetail.sourceMoney"></span>
			</li>
			<li>
				<span></span>
				<span>现价:</span>
				<span><input type="text" class='per_addperson_txt' readonly v-model="cardDetail.currentMoney"></span>
			</li>
			<li>
				<span>★</span>
				<span>优惠金额:</span>
				<span><input type="text" class='per_addperson_txt'  v-model="cardDetail.discountMoney"  name="优惠金额"></span>
			</li>
			<li>
				<span>★</span>
				<span>实收金额:</span>
				<span><input type="text" class='per_addperson_txt' readonly v-model="cardDetail.money"></span>
			</li>
			<li>
				<span>★</span>
				<span>课时:</span>
				<span><input type="text" class='per_addperson_txt' readonly v-model="cardDetail.hour"></span>
			</li>
			<li>
				<span>★</span>
				<span>赠送课时:</span>
				<span><input v-validate="'numeric'" name="赠送课时" type="text" class='per_addperson_txt' v-model="cardDetail.giveHour">

				 </span>

			</li>
			<li>
				<span>★</span>
				<span>总课时:</span>
				<span><input type="text" class='per_addperson_txt' readonly v-model="cardDetail.sumHour"></span>
			</li>
			<li>
				<span>★</span>
				<span>购课时间:</span>
				<span> <el-date-picker type="date"   value-format="yyyy-MM-dd" placeholder="Pick a date" style="width:100%" v-model="cardDetail.buyCardTime"></el-date-picker>
    				</span>

			</li>
			<li>
				<span>★</span>
				<span>支付状态:</span>
				<span>

    				<select name="" id="" class='per_addperson_txt'  v-model="cardDetail.payStatus">
    					 <option v-for = "(item,key) in payStateDict" :value="key">{{item}}</option>

    				</select>
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>支付方式:</span>
				<span>
                    <select name="" id="" class='per_addperson_txt'  v-model="cardDetail.payType">
                    	 <option v-for = "(item,key) in paymentDict" :value="key">{{item}}</option>
                    </select>
                </span>
			</li>
			<li>
				<span></span>
				<span>支付日期:</span>
				<span> <el-date-picker type="date"   value-format="yyyy-MM-dd" placeholder="Pick a date" style="width:100%" v-model="cardDetail.payDate"></el-date-picker>
    				</span>

			</li>
			<li>
				<span>★</span>
				<span>经办人:</span>
				<span><input type="text" class='per_addperson_txt' readonly  v-model="cardDetail.responsibleRealName"></span>
			</li>
			<li class="per_addperson_li_w per_addperson_li_h2">
				<span></span>
				<span>备注:</span>
				<span>
                   <textarea name="" id="" cols="30" rows="4" placeholder="" class='per_addperson_texarea'  v-model="cardDetail.descr"></textarea>
                </span>
			</li>
		</ul <br class="p_zwf">
		<div class="p_btn_group p_clear_float">
			<input type="button" value="返回" @click="$router.go(-1)" class="p_btn p_btn_siz_2 p_btn_col_red p_btn_pos_r">
			<input type="button" value="选班" class="p_btn p_btn_siz_2 p_btn_col_ora p_btn_pos_r" @click="chooseClass(cardDetail)">
			<input type="button" value="保存" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r" @click="saveInfo(cardDetail)">
		</div>
	</form>
</template>
<script>
	import instance from '../../../api/index.js';
	import { mapState } from 'vuex';
	export default {
		data() {
			return {
				cardDetail: {
					buyCardTime: this.getNow(),
					orderCode: "",
					sourceMoney: "",
					giveHour: "",
					discountMoney: 0,
					cardId: "",
					approveStatus: "1",
					currentMoney: ""
				},
				cardInfo: [], //会员卡
				errcode: "",
				isSaved:false//是否保存
			}
		},
		created: function() {
			this.getOrderBuyCard(this.$route.params.id);
		},
		computed: {　
			// Getting Vuex State from store/index
			...mapState({
				payStateDict: state => state.payStateDict,
				paymentDict: state => state.paymentDict,
			}),
			　
			giveHour() {　　　　
				return this.cardDetail.giveHour　　
			},
			discountMoney() {　
        return this.cardDetail.discountMoney　　
			},
			cardId() {　　　　
				return this.cardDetail.cardId　　
			}
		},
		　　watch: {　　　　　　　　
			giveHour(curVal, oldVal) {　
				if(this.cardDetail.hour != "" && curVal != "")　
					this.cardDetail.sumHour = parseFloat(this.cardDetail.hour) + parseFloat(curVal);　
				else　　　
					this.cardDetail.sumHour = "";　　　　　　　　　
			},
			discountMoney(curVal, oldVal) {
        function accSub(arg1, arg2) {
          var r1, r2, m, n;
          try { r1 = arg1.toString().split(".")[1].length } catch (e) { r1 = 0 }
          try { r2 = arg2.toString().split(".")[1].length } catch (e) { r2 = 0 }
          m = Math.pow(10, Math.max(r1, r2));
          n = (r1 >= r2) ? r1 : r2;
          return ((arg1 * m - arg2 * m) / m).toFixed(n);
        }
        if(this.cardDetail.currentMoney != "" && curVal != ""){　
          this.cardDetail.money =accSub(this.cardDetail.currentMoney-0, curVal-0)}
          // this.cardDetail.money = (this.cardDetail.currentMoney-0) - (curVal-0)}
        else　　 this.cardDetail.money = "";　　　　　　　　　　
			},
			cardId(curVal, oldVal) {
				if(curVal != "") {
					if(this.cardDetail.hour != "" && this.cardDetail.giveHour)　
						this.cardDetail.sumHour = parseFloat(this.cardDetail.hour) + parseFloat(this.cardDetail.giveHour);　
					else　　　
						this.cardDetail.sumHour = "";　

					if(this.cardDetail.currentMoney != "" && this.cardDetail.discountMoney)　
						this.cardDetail.sumHour = parseFloat(this.cardDetail.currentMoney) - parseFloat(this.cardDetail.discountMoney);　
					else　　　
						this.cardDetail.sumHour = "";　

				}　　　　　　　　　　　
			},

		},
		methods: {
		//   youhui:function(){
      //   var now=this.cardDetail.discountMoney;
      //   if(now.indexOf('.')>0){
      //     var arrnow=now.split('.');
      //     arrnow[1]=arrnow[1].substring(0,2);
      //     var ppp=arrnow.join('.');
      //     this.cardDetail.discountMoney=ppp;
      //   }
      //
      // },
			getStudentInfo: function() { //获取基本信息
				//alert(this.$route.params.id);
				var id = this.$route.params.id
				instance.get('/student/findStudent/' + id).then((res) => {
					this.cardDetail = res.data.data;
				})
			},
			getNow: function() {
				var date = new Date();
				let nowDay = date.getFullYear() +
					"-" + ((date.getMonth() + 1) < 10 ? "0" + (date.getMonth() + 1) : (date.getMonth() + 1)) +
					"-" + (date.getDate() < 10 ? "0" + date.getDate() : date.getDate());
				return nowDay;
			},
			getCard: function() { //会员卡类型
				instance.post('/lessoncard/findSimpleList', {}).then((res) => {
					this.cardInfo = res.data.data;
				})
				// this.acti
			},
			getCardInfo: function(id) {
				instance.get('/lessoncard/findLessonCard/' + id).then((res) => {
					if(res.data.errcode == '0') {
						this.cardDetail.sourceMoney = res.data.data.sourceMoney;
						this.cardDetail.hour = res.data.data.hour;
						this.cardDetail.giveHour = res.data.data.giveHour;
						this.cardDetail.sumHour = res.data.data.sumHour;
						this.cardDetail.currentMoney = res.data.data.currentMoney;
						this.cardDetail.validDate = res.data.data.validTime;
						if(this.cardDetail.discountMoney != "") {
							this.cardDetail.money = parseFloat(res.data.data.currentMoney) - parseFloat(this.cardDetail.discountMoney);
						} else {
							this.cardDetail.discountMoney = 0;
							this.cardDetail.money = res.data.data.currentMoney;
						}

					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}
				})
			},
			saveInfo: function(data) { //保存购卡
				instance.post('/buycard/createBuyCard', data).then((res) => {
					if(res.data.errcode == '0') {
						//this.cardDetail.studentId = res.data.data.studentId;
						this.isSaved=true;
						this.$message.info('信息创建成功！');
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}

				})
			},
			chooseClass: function(data) { //保存并选班
				if(this.isSaved) {
					this.$router.push('/xueyuanguanli/chooseclass/' + data.studentId);

				} else {
					instance.post('/buycard/createBuyCard', data).then((res) => {
						if(res.data.errcode == '0') {
							this.$router.push('/xueyuanguanli/chooseclass/' + data.studentId);
						} else {
							this.$message.error('操作失败！' + res.data.errmsg);
						}

					})
				}
			},
			getOrderBuyCard(studentId) {
				instance.get('/buycard/orderBuyCard/' + studentId).then((res) => {
					if(res.data.errcode == '0') {
						this.cardDetail.studentLessonCardCode = res.data.data.studentLessonCardCode;
						this.cardDetail.orderCode = res.data.data.orderCode;
						this.cardDetail.orderTime = res.data.data.orderTime;
						this.cardDetail.schoolName = res.data.data.schoolName;
						this.cardDetail.schoolId = res.data.data.schoolId;
						this.cardDetail.responsibleRealName = res.data.data.responsibleRealName;
						this.cardDetail.responsibleUserId = res.data.data.responsibleUserId;
						this.cardDetail.studentId = res.data.data.studentId;
						this.cardDetail.studentName = res.data.data.studentName;

					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}
				})
			}

		},
		mounted: function() {
			//this.getStudentInfo();

			this.getCard();

		}
	};
</script>
