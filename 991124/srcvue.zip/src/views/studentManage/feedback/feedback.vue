<!-- <title>反馈及意见</title> -->
<style scoped>
.feedback {
  width: calc(100% - 40px);
  height: auto;
  padding: 20px;
  background: white;
}
.feedback:after {
  display: block;
  clear: both;
  content: "";
  visibility: hidden;
  height: 0;
}
.fedbak_screen ul li {
  float: left;
  margin-right: 15px;
  margin-bottom: 10px;
}
.fedbak_screen ul:after {
  display: block;
  clear: both;
  content: "";
  visibility: hidden;
  height: 0;
}
.fedbak_screen input {
  outline: none;
  width: 150px;
  border: none;
  border-bottom: 1px solid #ccc;
}
.fedbak_screen select {
  outline: none;
  width: 100px;
  padding: 3px;
  text-align: center;
  border-radius: 5px;
  border: 1px solid #ccc;
}
.fedbak_screen button {
  outline: none;
  border: none;
  width: 60px;
  padding: 3px;
  background: #3fa599;
  border-radius: 5px;
  color: white;
}
.fedbak_screen option {
  background: white;
}
</style>
<template>
    <div class="feedback">
        <div class="fedbak_screen">
          <ul>
            <li>
              <span>反馈单号</span>
              <input type="text">
            </li>
            <li>
              <span>反馈日期</span>
              <input type="text">
            </li>
            <li>
              <span>会员卡号</span>
              <input type="text">
            </li>
            <li>
              <span>学生姓名</span>
              <input type="text">
            </li>
            <li>
              <span>联系方式</span>
              <input type="text">
            </li>
            <li>
              <span>所属校区</span>
              <select name="" id="">
                <option value="">所属校区</option>
              </select>
            </li>
            <li>
              <span>处理人</span>
              <input type="text">
            </li>
            <li>
              <span>处理状态</span>
              <select name="" id="">
                <option value>未处理</option>
                <option value="1">111111</option>
                <option value="2">111111</option>
              </select>
            </li>
            <li style="float:right;"><button>查询</button></li>
          </ul>
        </div>
        <div class="fedbak_list">
          <el-table :data="tableData" border style="width: 100%;">
            <el-table-column prop="a" label="反馈单号" align="center">
            </el-table-column>
            <el-table-column prop="" label="反馈日期" align="center">
            </el-table-column>
            <el-table-column prop="" label="会员卡号" align="center">
            </el-table-column>
            <el-table-column prop="" label="性别" align="center">
            </el-table-column>
            <el-table-column prop="" label="联系方式" align="center">
            </el-table-column>
            <el-table-column prop="" label="所属校区" align="center">
            </el-table-column>
            <el-table-column prop="" label="反馈内容" align="center">
            </el-table-column>
            <el-table-column prop="" label="处理状态" align="center">
            </el-table-column>
            <el-table-column prop="" label="处理结果" align="center">
            </el-table-column>
            <el-table-column prop="" label="处理人" align="center">
            </el-table-column>
            <el-table-column
              fixed="right"
              label="操作"
              width="100" align="center">
              <template slot-scope="scope">
                <el-button @click="handleClick(scope.$index,scope.row)" type="text" size="small">详情</el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>
    </div>
</template>
<script>
export default {
  data() {
    return {
      tableData: [{"a":"5"}, {"a":"5"}, {"a":"5"}]
    };
  },
  methods: {
    handleClick(row) {
      this.$router.push("/xueyuanguanli/feedbackDetails/" + row)
    }
  }
};
</script>