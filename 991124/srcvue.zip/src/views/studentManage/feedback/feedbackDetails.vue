<!-- <title>反馈及意见详情</title> -->
<style scoped>
.feedbackDetails {
  width: calc(100% - 40px);
  height: auto;
  padding: 20px;
  background: white;
}
.details_head {
  font-size: 25px;
  font-weight: bold;
  text-align: center;
  line-height: 50px;
}
.details_mian {
  width: 96%;
  height: auto;
  padding: 30px 2%;
  border: 1px solid #cccccc;
}
.details_mian_one ul:after {
  display: block;
  clear: both;
  content: "";
  visibility: hidden;
  height: 0;
}
.details_mian_one li {
  float: left;
  margin: 10px;
  margin-left: 0;
}
.details_mian_one li span {
  display: inline-block;
  width: 70px;
}
.details_mian_one li input {
  border: 1px solid #cccccc;
  height: 25px;
  border-radius: 5px;
  text-indent: 12px;
}
.txtdomain {
  width: 87%;
  height: 70px;
  text-indent: 14px;
  padding: 10px 0;
}
.details_mian_three{
    margin: 10px 0;
}
.handle_people input {
  border: 1px solid #cccccc;
  height: 25px;
  border-radius: 5px;
  text-indent: 12px;
  margin-left: 5px;
}
</style>
<template>
    <div class="feedbackDetails">
        <div class="details_head">
            <h3>反馈及意见详情</h3>
        </div>
        <div class="details_mian">
            <div class="details_mian_one">
                <ul>
                    <li><span>反馈单号:</span><input type="text"></li>
                    <li><span>反馈日期:</span><input type="text"></li>
                    <li><span>所属校区:</span><input type="text"></li>
                    <li><span>会员卡号:</span><input type="text"></li>
                    <li><span>学员姓名:</span><input type="text"></li>
                    <li><span>性别:</span><input type="text"></li>
                    <li><span>联系方式:</span><input type="text"></li>
                </ul>
            </div>
            <div class="details_mian_two">
                <h3 style="font-weight: normal;">反馈内容</h3>
                <div class="domain">
                    <textarea name="txtdomain" id="txtdomain_one" class="txtdomain"></textarea>
                </div>
            </div>
            <div class="details_mian_three">
                <div class="handle_state">
                    <span>处理状态:</span>
                    <el-checkbox-group v-model="checkList" style="display: inline-block;">
                        <el-checkbox label="未处理"></el-checkbox>
                        <el-checkbox label="处理中"></el-checkbox>
                        <el-checkbox label="已处理"></el-checkbox>
                    </el-checkbox-group>
                    <div class="handle_people" style="display: inline-block;margin-left: 5px;">
                        <span>处理人:</span><input type="text" />
                    </div>
                </div>
            </div>
            <div class="details_mian_two">
                <h3 style="font-weight: normal;">反馈内容</h3>
                <div class="domain">
                    <textarea name="txtdomain" id="txtdomain_two" class="txtdomain"></textarea>
                </div>
                <div class="" style="text-align: center;padding: 10px 0 0;">
                    <el-button style="background: #3fa599;color:white;width: 120px;margin-right: 100px;" @click="cancel()">确认</el-button>
                    <el-button style="width: 120px;" @click="cancel()">取消</el-button>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
export default {
  data() {
    return {
      checkList: []
    };
  },
  methods: {
    cancel() {
      this.$router.push("/xueyuanguanli/xueyuanguanli_fankuijiyijian");
    }
  }
};
</script>