<!--<title>课程表</title>-->
<style scoped>
	.p_table_la tr:nth-child(1)>td {
		word-break: keep-all;
		word-break: keep-all;
		white-space: nowrap;
	}
	/*.p_table_la{*/
	/*font-size: 0.5rem*/
	/*}*/
</style>
<template>
	<div class="p_con_tab">
		<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
            <span>排课表</span>
        </h3>
		<div class="p_btn_group p_clear_float">
			<input type="button" value="下周" class="p_btn p_btn_siz_2 p_btn_col_gre p_btn_pos_r" @click="nextWeek()">
			<input type="button" value="本周" class="p_btn p_btn_siz_2 p_btn_col_ora p_btn_pos_r" @click="nowWeek()">
			<input type="button" value="上周" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r" @click="previousWeek()">
		</div>
		<div class="p_table_la_over">
			<table class="p_table_la" cellspacing="0" cellpadding="0" style="font-size: 0.5rem">
				<tr>
					<td colspan=2 rowspan=2>时间</td>
					<td v-for="date in dateDetail">{{date}}</td>
				</tr>
				<tr>
					<td>周一</td>
					<td>周二</td>
					<td>周三</td>
					<td>周四</td>
					<td>周五</td>
					<td>周六</td>
					<td>周日</td>
				</tr>
				<template v-for="i in 14">
					<tr>
						<template v-for="j in 9">
							<td v-if="i==1&&j==1" rowspan="5">上午</td>
							<!--上午-->
							<td v-else-if="i==6&&j==1" rowspan="6">下午</td>
							<!--下午-->
							<td v-else-if="i==12&&j==1" rowspan="3">晚上</td>
							<!--晚上-->
							<td v-else-if="j==2">{{7+i}}点</td>
							<!--时间点-->
							<td v-html="getLessonInfo(7+i,j-2)" v-else-if="j>2&&getLessonStratTimeStatus(7+i,j-2)" :rowspan="getRowspan(7+i,j-2)" style="background-color:#1ab394"></td>
							<!--输出课程信息-->
							<td v-else-if="j>2&&getNoneLesson(7+i,j-2)"></td>
							<!--没有课程时间段占空位-->

							<!--课程时间段不显示TD-->
						</template>
					</tr>
				</template>
				<!--tr>
					<td rowspan=5>上午</td>
					<td>8点</td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td>9点</td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>

				</tr>
				<tr>
					<td>10点</td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>

				</tr>
				<tr>
					<td>11点</td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>

				</tr>
				<tr>
					<td>12点</td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>

				</tr>
				<tr>
					<td rowspan=6>下午</td>
					<td>13点</td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td>14点</td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td>15点</td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>

				</tr>
				<tr>
					<td>16点</td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>

				</tr>
				<tr>
					<td>17点</td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>

				</tr>
				<tr>
					<td>18点</td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td rowspan=5>晚上</td>
					<td>19点</td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td>20点</td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td>21点</td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr-->

			</table>
		</div>
	</div>
</template>
<script>
	import instance from '../../../api/index.js';
	import { mapState } from 'vuex';
	export default {
				props: ['classId'],
		data() {
			return {
				seaDetail: {
					qBeginDate: "",
					qEndDate: ""
				},
				dataDetail: [],
				dateDetail: []

			}
		},
		computed: {　
			// Getting Vuex State from store/index
			...mapState({
				classTypeDict: state => state.classTypeDict,
			})

		},
		watch:{
			
			classId(curVal,oldVal){
　　　　　　　　　　//console.log(curVal,oldVal);
                    this.nowWeek();
　　　　　　　　},
		},
		methods: {
			getSchedule: function() { //获取周课程列表信息
					if(this.classId == "") {
					this.$message.error('操作失败！请选择班级！');
					return;
				}
				this.seaDetail.qClassId=this.classId;
				instance.post('/lesson/findWeekLessonTimeTables2', this.seaDetail).then((res) => {
					this.dataDetail = res.data.data;
				})
			},
			nextWeek: function() {
				this.seaDetail.qBeginDate = window.util_date.getNextMonday(window.util_date.getMonday()).pattern("yyyy-MM-dd");
				this.seaDetail.qEndDate = window.util_date.getNextSunday(window.util_date.getMonday()).pattern("yyyy-MM-dd");
				this.dateDetail = window.util_date.getDays(window.util_date.getNextMonday(window.util_date.getMonday()), 'yyyy-MM-dd');
				this.getSchedule();

			},
			previousWeek: function() {
				this.seaDetail.qBeginDate = window.util_date.getPreviousMonday(window.util_date.getMonday()).pattern("yyyy-MM-dd");
				this.seaDetail.qEndDate = window.util_date.getPreviousSunday(window.util_date.getMonday()).pattern("yyyy-MM-dd");
				this.dateDetail = window.util_date.getDays(window.util_date.getPreviousMonday(window.util_date.getMonday()), 'yyyy-MM-dd');
				this.getSchedule();

			},
			nowWeek: function() {
				window.util_date.newToday(new Date());
				this.seaDetail.qBeginDate = window.util_date.getMonday().pattern("yyyy-MM-dd");
				this.seaDetail.qEndDate = window.util_date.getSunday().pattern("yyyy-MM-dd");
				this.dateDetail = window.util_date.getDays(window.util_date.getMonday(), 'yyyy-MM-dd');
				this.getSchedule();

			},
			getLessonStratTimeStatus: function(time, wDay) {
				let vm = this;
				let flag = false;
				vm.dataDetail.forEach(function(e, i) {
					let beginTime = e.beginTime;
					let weekday = e.weekday;
					if(beginTime.split(":")[0] == time && weekday == wDay) {
						flag = true;

					}
				})

				return flag;
			},
			getRowspan: function(time, wDay) {
				let vm = this;
				let rowspan = 0;
				vm.dataDetail.forEach(function(e, i) {
					let beginTime = e.beginTime;
					let endTime = e.endTime;
					let weekday = e.weekday;
					if(beginTime.split(":")[0] == time && weekday == wDay) {
						rowspan = parseInt(endTime.split(":")[0]) - parseInt(beginTime.split(":")[0]);
						if(parseInt(endTime.split(":")[1]) != 0 && parseInt(beginTime.split(":")[1]) != 0)
							rowspan += 1;

					}
				})

				return rowspan;
			},
			getLessonInfo: function(time, wDay) {
				let vm = this;
				let str = "";
				vm.dataDetail.forEach(function(e, i) {
					let beginTime = e.beginTime;
					let weekday = e.weekday;
					if(beginTime.split(":")[0] == time && weekday == wDay) {
						str += "课程大类：" + e.courseName;
						str += "<br>课程小类：" + e.courseSubName;
						str += "<br>类型：" + vm.classTypeDict[e.oneByOne];
						str += "<br>校区：" + e.schoolName;
						str += "<br>教室：" + e.classRoomName;
						str += "<br>教师：" + e.teacherName;
						str += "<br>时间：" + e.beginTime + "-" + e.endTime;

					}
				})
				return str;
			},
			getNoneLesson: function(time, wDay) {
				let vm = this;
				let flag = true; //默认不在

				vm.dataDetail.forEach(function(e, i) {
					let beginTime = e.beginTime;
					let endTime = e.endTime;
					let weekday = e.weekday;
					let rowspan = 0;
					if(weekday == wDay) {
						let b_hour = parseInt(beginTime.split(":")[0]);
						let e_hour = parseInt(endTime.split(":")[0]);
						rowspan = e_hour - b_hour;
						if(parseInt(endTime.split(":")[1]) != 0 && parseInt(beginTime.split(":")[1]) != 0)
							rowspan += 1;
						if(parseInt(b_hour) <= parseInt(time) && parseInt(time) < parseInt(b_hour + rowspan)) {
							flag = false;

						}

					}
				})
				return flag;
			},
		},
		mounted: function() {
			//this.seaDetail.qStudentId = this.$route.params.id;
			//this.nowWeek();
		}
	}
</script>