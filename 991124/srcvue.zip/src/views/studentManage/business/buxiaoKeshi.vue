<!--<title>补消课时</title>-->
<template>
  <div>
	<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
        <span>补消课时</span>
  </h3>
	<div class="p_con_sea">
		<ul class="p_con_sea_list p_clear_float">
			<li>
				<span>学员姓名:</span>
				<span>
					<input type="text" class="p_con_form_input">
				</span>
			</li>
			<li>
				<span>所属校区:</span>
				<span>
					<select name="" id="" class="p_con_form_select"></select>
				</span>
			</li>
			<li>
				<span>课程大类:</span>
				<span>
					<select name="" id="" class="p_con_form_select"></select>
				</span>
			</li>
			<li>
				<span>课程小类:</span>
				<span>
					<select name="" id="" class="p_con_form_select"></select>
				</span>
			</li>
			<li>
				<span>班级类别:</span>
				<span>
					<select name="" id="" class="p_con_form_select"></select>
				</span>
			</li>
			<li>
				<span>授课类型:</span>
				<span>
					<select name="" id="" class="p_con_form_select"></select>
				</span>
			</li>
			<li>
				<span>班级:</span>
				<span>
					<select name="" id="" class="p_con_form_select"></select>
				</span>
			</li>
			<li>
				<span>授课教师:</span>
				<span>
					<select name="" id="" class="p_con_form_select"></select>
				</span>
			</li>
			<li>
				<span>学管师:</span>
				<span>
					<input type="text" class="p_con_form_input">
				</span>
			</li>
			<li>
				<span>日期:</span>
				<span>
					<input type="text" class="p_con_form_input">
				</span>
			</li>
			<li>
				<span>补消课时:</span>
				<span>
					<input type="text" class="p_con_form_input">
				</span>
			</li>
			<li>
                <span>备注:</span>
                <span>
                   <textarea name="" id="" cols="30" rows="4" placeholder="其他" class='per_addperson_texarea_s'></textarea>
                </span>
            </li>
		</ul>
		<div class="p_btn_group p_clear_float">
        	<input type="button" value="取消" class="p_btn p_btn_siz_2 p_btn_col_red p_btn_pos_r">
        	<input type="button" value="确定" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r">
    	</div>
	</div>
  </div>
</template>
