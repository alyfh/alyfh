<!--<title>退费</title>-->
<template>
	<form id="" method="post" action="" class="ue_form_add">
		<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
        	<span>退费订单详情信息(</span>
        	<span class='h5_mark_xx2'>★</span>
        	<span>为必填)</span>
    	</h3>
		<ul class='h5_02_info_per_addlist'>
			<li>
				<span>★</span>
				<span>订单号:</span>
				<span>{{cardDetail.orderCode}}</span>
			</li>
			<li>
				<span></span>
				<span>订单时间:</span>
				<span>{{cardDetail.orderTime}}</span>
			</li>
			<li>
				<span>★</span>
				<span>购课校区:</span>
				<span>
    				{{cardDetail.schoolName}}
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>学生姓名:</span>
				<span>
    				{{cardDetail.studentName}}
    			</span>
			</li>

			<li>
				<span>★</span>
				<span>会员卡号:</span>
				<span>
    				{{cardDetail.cardCode}}
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>实收金额:</span>
				<span>{{cardDetail.sumMoney}}</span>
			</li>
			<li>
				<span>★</span>
				<span>总课时:</span>
				<span>{{cardDetail.sumHour}}</span>
			</li>
			<li>
				<span>★</span>
				<span>已消耗课时:</span>
				<span>{{cardDetail.expendedHour}}</span>
			</li>
			<li>
				<span>★</span>
				<span>剩余课时:</span>
				<span>{{cardDetail.hour}}</span>
			</li>
			<li>
				<span>★</span>
				<span>退费课时:</span>
				<span><input type="text" v-model="cardDetail.refundHour" class='per_addperson_txt'></span>
			</li>
			<li>
				<span>★</span>
				<span>退费金额:</span>
				<span><input type="text" v-model="cardDetail.refundMoney" class='per_addperson_txt'></span>
			</li>
			<li>
				<span>★</span>
				<span>支付状态:</span>
				<span>
    				<select name="" id="" v-model="cardDetail.payStatus" class='per_addperson_txt'>
    					 <option v-for = "(item,key) in payStateDict" :value="key">{{item}}</option>
    				</select>
    			</span>
			</li>
			<li>
				<span>★</span>
				<span>支付方式:</span>
				<span>
                    <select name="" id="" v-model="cardDetail.payType" class='per_addperson_txt'>
                    	 <option v-for = "(item,key) in refundDict" :value="key">{{item}}</option>
                    </select>
                </span>
			</li>
			<li>
				<span>★</span>
				<span>退费日期:</span>
				<span>
					<el-date-picker type="date"   value-format="yyyy-MM-dd" placeholder="Pick a date" style="width:100%" v-model="cardDetail.refundDate"></el-date-picker>
    		</span>
			</li>
			<li>
				<span>★</span>
				<span>经办人:</span>
				<span>{{cardDetail.actorRealName}}</span>
			</li>
			<li>
				<span>★</span>
				<span>开户行:</span>
				<span><input type="text" v-model="cardDetail.bankName" class='per_addperson_txt'></span>
			</li>
			<li>
				<span>★</span>
				<span>银行账号:</span>
				<span><input type="text" v-model="cardDetail.bankAccount" class='per_addperson_txt'></span>
			</li>
			<li>
				<span>★</span>
				<span>户名:</span>
				<span><input type="text" v-model="cardDetail.bankUsername" class='per_addperson_txt'></span>
			</li>
			<li class="per_addperson_li_w per_addperson_li_h2">
				<span>★</span>
				<span>备注:</span>
				<span>
                   <textarea name="" id="" v-model="cardDetail.descr" cols="30" rows="4" placeholder="其他" class='per_addperson_texarea'></textarea>
                </span>
			</li>
		</ul>

		<br class="p_zwf">
		<div class="p_btn_group p_clear_float">
			<input type="button" value="取消" @click="$router.go(-1)" class="p_btn p_btn_siz_2 p_btn_col_red p_btn_pos_r">
			<input type="button" value="确定" @click="saveInfo(cardDetail)" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r">
		</div>
	</form>
</template>
<script>
	import instance from '../../../api/index.js';
	import { mapState } from 'vuex';
	import * as util from '../../../assets/util.js';
	export default {
		data() {
			return {
				cardDetail: {
					orderCode: "",
					refundDate: this.getNow(),
					approveStatus: "1"
				},
				cardInfo: [], //会员卡
			}
		},
		created: function() {
			this.getDoRefund(this.$route.params.id);
			if(util.session('loginInfo')) {
				let loginInfo = util.session('loginInfo').login;
				this.cardDetail.actorRealName = loginInfo.realName;
				this.cardDetail.actorUserId = loginInfo.userId;
			}

		},
		computed: {　
			// Getting Vuex State from store/index
			...mapState({
				payStateDict: state => state.payStateDict,
				refundDict: state => state.refundDict,
			}),
			　

		},
		　　watch: {　　　　　　　　

		},
		methods: {
			saveInfo: function(data) { //保存
				instance.post('/refund/createRefund', data).then((res) => {
					if(res.data.errcode == '0') {
						//this.cardDetail.id = res.data.data.id;
						this.$message.info('信息创建成功！');
						this.$router.go(-1);
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}

				})
			},

			getDoRefund(studentId) { //生成退费订单
				instance.get('/refund/doRefund/' + studentId).then((res) => {
					if(res.data.errcode == '0') {
						this.cardDetail.cardCode = res.data.data.cardCode;
						this.cardDetail.orderCode = res.data.data.orderCode;
						this.cardDetail.orderTime = res.data.data.orderTime;
						this.cardDetail.schoolName = res.data.data.schoolName;
						this.cardDetail.schoolId = res.data.data.schoolId;
						this.cardDetail.studentId = res.data.data.studentId;
						this.cardDetail.studentName = res.data.data.studentName;
						this.cardDetail.sumMoney = res.data.data.sumMoney;
						this.cardDetail.sumHour = res.data.data.sumHour;
						this.cardDetail.expendedHour = res.data.data.expendedHour;
						this.cardDetail.hour = res.data.data.hour;

					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}
				})
			},
			getNow: function() {
				var date = new Date();
				let nowDay = date.getFullYear() + 
				"-" + ((date.getMonth() + 1) < 10 ? "0" + (date.getMonth() + 1) : (date.getMonth() + 1)) + 
				"-" + (date.getDate()< 10 ? "0" + date.getDate(): date.getDate());
				return nowDay;
			},

		},
		mounted: function() {

			//this.getCard();

		}
	};
</script>