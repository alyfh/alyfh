<!--<title>业务办理</title>-->
<style scoped>
	.p_table_la tr>td:nth-child(1):hover {
		cursor: pointer;
		color: #0d8ddb;
	}
</style>
<template>
	<section class="p_chi_con">
		<div class="p_con_sea">
			<ul class="p_con_sea_list p_clear_float">
				<li>
					<span>学员姓名:</span>
					<span>
						<input type="text" class="p_con_form_input" v-model="findStudents.qStudentName">
					</span>
				</li>
				<li>
					<span>会员卡号:</span>
					<span>
						<input type="text" class="p_con_form_input" v-model="findStudents.qLessonCardCode">
					</span>
				</li>
				<li>
					<span>所属校区:</span>
					<span>
            <select name=""  class="p_con_form_select" v-model="findStudents.qSchoolId" @change="getQueryInfo(findStudents.qSchoolId)">
              <!--option value="">-请选择-</option-->
              <option v-for="sName in schoolNames" :value="sName.id">{{ sName.schoolName }}</option>
            </select>
					</span>
				</li>
				<li>
					<span>班级:</span>
					<span>
            <select name=""  class="p_con_form_select" v-model="findStudents.qClassId">
              <option value="">-请选择-</option>
              <option v-for="sName in classs" :value="sName.id">{{ sName.className }}</option>
            </select>
					</span>
				</li>
				<li>
					<span>课程大类:</span>
					<span>
            <select name="" id="" class="p_con_form_select" v-model="findStudents.qCourseId" @change="getClassSub(findStudents.qCourseId)">
                <option value="">-请选择-</option>
               <option v-for="className in classNames" :value="className.id">{{className.courseName}}</option>
            </select>
					</span>
				</li>
				<li>
					<span>课程小类:</span>
					<span>
            <select name="" id="" class="p_con_form_select" v-model="findStudents.qCourseSubId">
              <!--<option value="">-</option>-->
                         <option v-for="classNameSub in classNameSubs" :value="classNameSub.id">{{classNameSub.courseSubName}}</option>
            </select>
					</span>
				</li>

				<li>
					<span>咨询师:</span>
					<span>
						<select name="" id="" class="p_con_form_select" v-model="findStudents.qCounselorId">
              <option value="">-请选择-</option>
              <option v-for="counselorName in counselorNames" :value="counselorName.id">{{counselorName.realName}}</option>
            </select>
					</span>
				</li>
				<li>
					<span>课程顾问:</span>
					<span>
						<select name="" id="" class="p_con_form_select" v-model="findStudents.qCourseCounselorId">
              <option value="">-请选择-</option>
              <option v-for="consultant in consultants" :value="consultant.id">{{consultant.realName}}</option>
            </select>
					</span>
				</li>
				<li>
					<span>授课教师:</span>
					<span>
						<select name="" id="" class="p_con_form_select" v-model="findStudents.qTeacherId">
               <option value="">-请选择-</option>
               <option v-for="teacher in teachers" :value="teacher.id">{{teacher.realName}}</option>
            </select>
					</span>
				</li>
				<li>
					<span>停课状态:</span>
					<span>
						<select name="" id="" class="p_con_form_select" v-model="findStudents.qStatus">
               <option value="">-请选择-</option>
                <option value="0">上课</option>
                <option value="1">停课</option>
            </select>
					</span>
				</li>
			</ul>
			<div class="p_btn_group p_clear_float">
				<input type="button" value="查询" @click="query" class="p_btn p_btn_siz_2 p_btn_col_gre p_btn_pos_r">
			</div>
		</div>

		<div class="p_con_tab">
			<div class="p_btn_group p_clear_float">
				<input v-if="$_has(actionsList,'transferClass')" type="button" value="转班" class="p_btn p_btn_siz_2 p_btn_col_oran p_btn_pos_r" @click="transferClass()">
				<input v-if="$_has(actionsList,'divideClass')" type="button" value="分班" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r" @click="divideClass()">
			</div>
			<div class="p_table_la_over">
				<table class="p_table_la" cellspacing="0" cellpadding="0">
					<tr>
						<!--td v-if="$_has(actionsList,'divideClass')">选择</td-->
						<td>学员姓名</td>
						<td>性别</td>
						<td>年龄</td>
						<td>会员卡号</td>
						<td>所属校区</td>
						<td>班级</td>
						<td>总课时</td>
						<td>已消耗课时</td>
						<td>剩余课时</td>
						<td>授课教师</td>
						<td>咨询师</td>
						<td>课程顾问</td>
						<td>创建时间</td>
						<td v-if="$_has(actionsList,'edit')||$_has(actionsList,'chooseClass')||$_has(actionsList,'buyCard')||$_has(actionsList,'returnCost')||$_has(actionsList,'deletestu')||($_has(actionsList,'resumeClass')&&studentdata.status=='1')||($_has(actionsList,'stopClass')&&studentdata.status=='0')">
							操作
						</td>
					</tr>
					<tr v-for="(studentdata,index) in studentList">
						<!--td v-if="$_has(actionsList,'divideClass')">
							<input type="checkbox" :value="index" v-model="selectArr">
						</td-->
						<!--<router-link to="/buycard" tag="td">{{studentdata.studentLessonCard.studentName}}</router-link>-->
						<template v-if="$_has(actionsList,'read')">
							<td @click="linkStudentInfo(studentdata.id)">{{studentdata.studentName}}</td>
						</template>
						<template v-else>
							<td>{{studentdata.studentName}}</td>
						</template>

						<td>{{studentdata.sex}}</td>
						<td>{{dateDiff(studentdata.birthday,new Date().pattern("yyyy-MM-dd"),"相差Y年M月D天")}}</td>
						<td>{{studentdata.studentLessonCard.cardCode}}</td>
						<td>{{studentdata.schoolName}}</td>
						<td>
							<template v-for="classRoom in studentdata.classes">
								<span>
								{{classRoom.className}}<br>
								<!--input type="button" value="退班" class="td_line_span" @click="returnClass(classRoom.id,studentdata.id)"-->
							</span>
							</template>
						</td>
						<td>{{studentdata.studentLessonCard.sumHour}}</td>
						<td>{{studentdata.studentLessonCard.sumHour-studentdata.studentLessonCard.hour}}</td>
						<td>{{studentdata.studentLessonCard.hour}}</td>
						<td>
							<template v-for="classRoom in studentdata.classes">
								<template v-for="lesson in classRoom.lessons">
									{{lesson.teacherName}}<br>
								</template>
							</template>
						</td>

						<td>{{studentdata.counselorName}}</td>
						<td>{{studentdata.courseCounselorName}}</td>
						<td>{{studentdata.createTime}}</td>
						<!--
                         offical 为 1  已退费 （操作只能为：删除 编辑  续费）

                         -->
						<td style="text-align: left" v-if="$_has(actionsList,'edit')||$_has(actionsList,'chooseClass')||$_has(actionsList,'buyCard')||($_has(actionsList,'returnCost')&&studentdata.official=='0'&&studentdata.studentLessonCard.sumMoney>0&&studentdata.classes.length==0)||$_has(actionsList,'returnClass')&&studentdata.classes.length>0||$_has(actionsList,'deletestu')||($_has(actionsList,'resumeClass')&&studentdata.status=='1')||($_has(actionsList,'stopClass')&&studentdata.status=='0')">
							<input v-if="$_has(actionsList,'edit')" type="button" value="编辑" class="p_btn p_btn_siz_3 p_btn_col_k_blu p_btn_pos_l" @click="editInfo(studentdata.id)">
							<input v-if="$_has(actionsList,'chooseClass')&&studentdata.official=='0'" type="button" value="选班" class="p_btn p_btn_siz_3 p_btn_col_k_oran p_btn_pos_l" @click="chooseClass(studentdata.id)">

							<!--已退费或者有购卡记录 显示为续费-->
							<template v-if="studentdata.offical==1||studentdata.studentLessonCard.sumHour>0">
								<input v-if="$_has(actionsList,'buyCard')" type="button" value="续费" class="p_btn p_btn_siz_3 p_btn_col_k_blu p_btn_pos_l" @click="buyCard(studentdata.id)">
							</template>
							<template v-else>
								<input v-if="$_has(actionsList,'buyCard')" type="button" value="购卡" class="p_btn p_btn_siz_3 p_btn_col_k_blu p_btn_pos_l" @click="buyCard(studentdata.id)">
							</template>
							<!--未退费，总金额大于0，没有班级-->
							<input v-if="$_has(actionsList,'returnCost')&&studentdata.official=='0'&&studentdata.studentLessonCard.sumMoney>0&&studentdata.classes.length==0" type="button" value="退费" class="p_btn p_btn_siz_3 p_btn_col_k_pur p_btn_pos_l" @click="returnCost(studentdata.id)">
							<input v-if="$_has(actionsList,'returnClass')&&studentdata.classes.length>0" type="button" value="退班" class="p_btn p_btn_siz_3 p_btn_col_k_red p_btn_pos_l" @click="returnClass(studentdata.id)">

							<!--input type="button" value="补消课时" class="p_btn p_btn_siz_3 p_btn_col_k_blu p_btn_pos_r" @click="bxks()"-->
							<!--<input v-if="$_has(actionsList,'deletestu')" type="button" value="删除" class="p_btn p_btn_siz_3 p_btn_col_k_red p_btn_pos_l" @click="deletestu(studentdata.id)">-->
							<input v-if="$_has(actionsList,'resumeClass')&&studentdata.status=='1'&&studentdata.official=='0'" type="button" value="复课" class="p_btn p_btn_siz_3 p_btn_col_k_gre p_btn_pos_l" @click="resumeClass(studentdata.id)">
							<input v-if="$_has(actionsList,'stopClass')&&studentdata.status=='0'&&studentdata.official=='0'" type="button" value="停课" class="p_btn p_btn_siz_3 p_btn_col_k_red p_btn_pos_l" @click="stopClass(studentdata.id)">
						</td>
					</tr>
				</table>
			</div>
		</div>
		<div class='h5_page_container' id="con">
			<page :record-count="recordCount" v-on:change-page="changePage">
			</page>
		</div>
	</section>
</template>
<script>
	import instance from '../../../api/index.js';
	import * as util from '../../../assets/util.js';
	import { mapState } from 'vuex';
	export default {
		computed: {
			// Getting Vuex State from store/index
			...mapState({
				// layerShow: state => state.layerShow,
				pageSize: state => state.pageSize,
				pageLarge: state => state.pageLarge
			})
		},
		data() {
			return {
				actionType: "query",
				actionsList: [], //获取当前用户对当前模块授权操作
				selectArr: [],
				findStudents: { //查询条件
				},
				studentList: [], //学员列表
				schoolNames: [], //校区,
				classs: [], //班级
				classNames: [], //课程大类
				classNameSubs: [], //课程小类
				counselorNames: [], //咨询师
				consultants: [], //课程顾问
				teachers: [], //授课教师
				recordCount: 0,
				pageNum: 1, //当前页码
				linkId: ""

			};
		},
		components: {
			page: () =>
				import("../../common/page.vue")
		},
		methods: {
			getStudentCount: function() { //获取学生数量
				var params = {};
				if(!(JSON.stringify(this.findStudents) == "{}")) {
					var result = $.extend(true, params, this.findStudents);
				} else {
					var result = params;
				};
				instance.post('/student/findBusinessStudentsCount', result).then((res) => {
					this.recordCount = res.data.data.count;
				});
			},
			query: function() {
				this.getStudent();
				this.getStudentCount();
			},
			getSchool: function() { //获取校区数据
				//获取当前登录人
				let loginInfo = util.session("loginInfo");
				instance.get('/school/findUserSchools/' + loginInfo.login.userId).then((res) => {

					if(res.data.data != null && res.data.data != "") {
						this.schoolNames = res.data.data;
						if(res.data.data != null && res.data.data.length == 1) {
							this.findStudents.qSchoolId = res.data.data[0].id;
							this.getQueryInfo(this.findStudents.qSchoolId);
						}
						this.query();

					}
				})
			},
			getQueryInfo: function(schoolId) { //联动查询咨询师，课程顾问，班级，授课教师
				this.getConsult(schoolId);
				this.getconsultant(schoolId);
				this.getTeacher(schoolId);
				this.getClasss(schoolId);

			},
			getClasss: function(schoolId) { //获取班级列表
				instance.post('/class/findSimpleClasses', {
					qSchoolId: schoolId
				}).then((res) => {
					this.classs = res.data.data;
				})
			},
			getConsult: function(schoolId) { //获取咨询师列表
				instance.post('/user/findSimpleCounselors', {
					qSchoolId: schoolId
				}).then((res) => {
					this.counselorNames = res.data.data;
				})
			},
			getconsultant: function(schoolId) { //获取课程顾问列表
				instance.post('/user/findSimpleCourseCounselors', {
					qSchoolId: schoolId
				}).then((res) => {
					this.consultants = res.data.data;
				})
			},
			getTeacher: function(schoolId) { //获取授课教师列表
				instance.post('/teacher/findSimpleTeachers', {
					qSchoolId: schoolId
				}).then((res) => {
					this.teachers = res.data.data;
				})
			},
			getClass: function() { //获取课程大类数据
				// course/findCourses
				// /course/findSimpleCourse
				instance.post('/course/findCourses', {}).then((res) => {
					this.classNames = res.data.data;
				})
			},
			getClassSub: function(id) { //获取课程小类数据
				// /course/findSimpleCourseSubs
				instance.post('/course/findSimpleCourseSubs', {
					qCourseId: id
				}).then((res) => {
					this.classNameSubs = res.data.data;
					// console.info(res.data);
				})
			},
			getStudent: function() { //获取学生列表
				var params = {
					"beginRow": (this.pageNum - 1) * this.pageSize,
					"pageSize": this.pageSize
				};
				// console.log(this.findStudents.qSchoolId);
				// console.log(JSON.stringify(this.findStudents)=="{}");
				if(!(JSON.stringify(this.findStudents) == "{}")) {
					//alert(true);
					var result = $.extend(true, params, this.findStudents);
				} else {
					//alert(false)
					var result = params;
				};
				instance.post('/student/findBusinessStudents', result).then((res) => {
					this.studentList = res.data.data;
				})
				this.actionType = "query";

			},
			changePage: function(pageNum) {
				console.info("change-page:" + pageNum);
				this.pageNum = pageNum;
				this.getStudent();
			},
			linkStudentInfo: function(id) { //学生姓名点击跳转详情
				this.$router.push('/xueyuanguanli/studentinfo/' + id + "/baseInfo");
			},
			editInfo: function(id) { //编辑
				this.$router.push('/xueyuanguanli/editStudent/' + id);
			},
			transferClass: function() { //转班

				this.$router.push('/xueyuanguanli/zhuanban');

			},
			divideClass: function() { //分班
				this.$router.push('/xueyuanguanli/fenban');
				//				if(this.selectArr.length == 0) {
				//					this.$message.error('请选择学员！！！');
				//					return;
				//				}
				//				this.$confirm("确定对选中的学生进行分班?", "提示", {
				//						confirmButtonText: "确定",
				//						cancelButtonText: "取消",
				//						type: "info"
				//					})
				//					.then(() => {
				//						let arr = [];
				//						var len = this.studentList.length;
				//						for(var i = 0; i < len; i++) {
				//							if(this.selectArr.indexOf(i) >= 0) {
				//								arr.push(this.studentList[i].id);
				//							} else {
				//								console.log(this.selectArr.indexOf(i));
				//							}
				//						};
				//						// alert(arr);
				//						this.$router.push('/xueyuanguanli/fenban/' + arr);
				//
				//					})
				//					.catch(() => {});
			},
			deletestu: function(id) { //删除
				this.$confirm("确定删除该学生?", "警告", {
						confirmButtonText: "确定",
						cancelButtonText: "取消",
						type: "info"
					})
					.then(() => {
						instance.get('/student/removeStudent/' + id).then((res) => {
							if(res.data.errcode == '0') {
								this.$message.info('数据删除成功！');
								this.query();
							} else {
								this.$message.error('操作失败！' + res.data.errmsg);
							}
						})
					})
					.catch(() => {});
			},
			stopClass: function(studentId) { //停课
				this.$confirm("确定对所选择的学生进行停课操作吗?", "警告", {
						confirmButtonText: "确定",
						cancelButtonText: "取消",
						type: "info"
					})
					.then(() => {
						instance.get('/student/pauseLesson/' + studentId).then((res) => {
							if(res.data.errcode == '0') {
								this.$message.info('学员停课成功！');
								this.query();
							} else {
								this.$message.error('操作失败！' + res.data.errmsg);
							}
						})
					})
					.catch(() => {});
			},
			resumeClass: function(studentId) { //复课
				this.$confirm("确定对所选择的学生进行复课操作吗?", "警告", {
						confirmButtonText: "确定",
						cancelButtonText: "取消",
						type: "info"
					})
					.then(() => {
						instance.get('/student/regainLesson/' + studentId).then((res) => {
							if(res.data.errcode == '0') {
								this.$message.info('学员复课成功！');
								this.query();
							} else {
								this.$message.error('操作失败！' + res.data.errmsg);
							}
						})
					})
					.catch(() => {});
			},
			returnClass: function(studentId) { //退班
				this.$router.push('/xueyuanguanli/studentinfo/' + studentId + '/kechengmingxi');
			},
			bxks: function(item) { //补消课时
				this.$router.push('/xueyuanguanli/buxiaokeshi/' + item);
			},
			returnCost: function(id) { //退费
				this.$confirm("确定对所选择的学生进行退费操作吗?", "警告", {
						confirmButtonText: "确定",
						cancelButtonText: "取消",
						type: "info"
					})
					.then(() => {
						this.$router.push('/xueyuanguanli/tuifei/' + id);
					})
					.catch(() => {});
			},
			buyCard: function(item) { //购卡
				this.$router.push('/xueyuanguanli/buyCard/' + item);
			},

			chooseClass: function(item) { //选班
				this.$router.push('/xueyuanguanli/chooseclass/' + item);
			},
			addvisit: function(informationId) {
				this.$router.push('/zhaoshengguanli/adviceinfo/' + informationId + '/addVisit');
			},
			getvisitList: function(informationId) {
				this.$router.push('/zhaoshengguanli/adviceinfo/' + informationId + '/visitList');
			},
			getModuleActions: function() {
				let routeCodes = this.$route.path.split("/");
				let routeCode = routeCodes[routeCodes.length - 1];
				instance.get('/navi/findUserActions2/' + routeCode).then((res) => {
					if(res.data.errcode == '0') {
						this.actionsList = res.data.data;
					} else {
						//this.$message.error('操作失败！' + res.data.info);
					}
					console.info("json:" + res.data);

				})
			},

			dateDiff: function(d1, d2, str) {
				//console.info(d1+"-----"+d2);
				if(d1 == null || d2 == null) return;
				d1 = new Date(d1.replace(/-/g, '/'));
				d2 = new Date(d2.replace(/-/g, '/'));
				var obj = {},
					M1 = d1.getMonth(),
					D1 = d1.getDate(),
					M2 = d2.getMonth(),
					D2 = d2.getDate();
				obj.Y = d2.getFullYear() - d1.getFullYear() + (M1 * 100 + D1 > M2 * 100 + D2 ? -1 : 0);
				obj.M = obj.Y * 12 + M2 - M1 + (D1 > D2 ? -1 : 0);
				obj.s = Math.floor((d2 - d1) / 1000); //差几秒
				obj.m = Math.floor(obj.s / 60); //差几分钟
				obj.h = Math.floor(obj.m / 60); //差几小时
				obj.D = Math.floor(obj.h / 24); //差几天
				return obj.Y;
				//      return str.replace(/\w/g,function(a){
				//          return obj[a] ? obj[a]:a;
				//      });
				// dateDiff("2016-9-30","2016-10-1","相差Y年M月D天");
			}

		},
		mounted: function() {
			this.getSchool(); //校区
			this.getClass(); //课程大类
			//this.getConsult();//咨询师
			// this.getTeacher();//授课教师
			// this.getconsultant();//课程顾问

			//this.getStudent();
			//this.getStudentCount(); //数量
			this.getModuleActions();

		}
	};
</script>
