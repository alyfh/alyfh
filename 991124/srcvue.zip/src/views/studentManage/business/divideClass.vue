<!--<title>分班</title>-->
<style>
	.p_lR_l {
		width: 16%;
		float: left;
		background-color: rgba(255, 255, 255, 0.3);
	}

	.p_lR_r {
		width: 84%;
		display: inline-block;
		background-color: #fff;
	}
</style>
<template>
	<div>
		<section class="p_lR_l">
			<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
            <span>未分班学生</span>
        </h3>
			<div class="h5_iframe1_table_page" name='bb' id="page1">
				<ul>
					<li data-jstree='{ "opened" : true }'>全选
						<ul>
							<li>章三</li>
							<li>里斯</li>
							<li>王五</li>
							<li>安利</li>
							<li>懂事</li>
							<li>路段</li>
						</ul>
					</li>

				</ul>
			</div>
		</section>
		<section class="p_lR_r">
			<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
            <span>分班信息</span>
        </h3>
			<ul class="p_con_sea_list p_clear_float">
				<li>
					<span>所属校区:</span>
					<span>
                                <select name=""  class="p_con_form_select" v-model="findClasses.qSchoolId" @change="query('school')">
              		<option value="">--请选择--</option>
              <option v-for="sName in schoolNames" :value="sName.id">{{ sName.schoolName }}</option>
            </select>
                </span>
				</li>
				<li>
					<span>课程大类:</span>
					<span>
            <select name="" id="" class="p_con_form_select" v-model="findClasses.qCourseId" @change="query('course')">
                		<option value="">--请选择--</option>
               <option v-for="className in classNames" :value="className.id">{{className.courseName}}</option>
            </select>
					</span>
				</li>
				<li>
					<span>课程小类:</span>
					<span>
            <select name="" id="" class="p_con_form_select" v-model="findClasses.qCourseSubId" @change="query()">
             		<option value="">--请选择--</option>
              <option v-for="classNameSub in classNameSubs" :value="classNameSub.id">{{classNameSub.courseSubName}}</option>
            </select>
					</span>
				</li>
				<li>
					<span>授课教师:</span>
					<span>
                      <select name="" id="" class="p_con_form_select" v-model="findClasses.qTeacherId" @change="query()">
             		<option value="">--请选择--</option>
              <option v-for="teacher in teachers" :value="teacher.id">{{teacher.realName}}</option>
            </select>
                </span>
				</li>

				<li>
					<span>班型:</span>
					<span>
                    <select name="" id="" class="p_con_form_select" v-model="findClasses.qClassTypeId" @change="query()">
             		<option value="">--请选择--</option>
              <option v-for="classType in classTypes" :value="classType.id">{{classType.classTypeName}}</option>
            </select>
                </span>
				</li>

				<li>
					<span>授课类型:</span>
					<span>
                     <select name="" id="" class="p_con_form_select" v-model="findClasses.qOneByOne" @change="query()">
					 <option v-for = "(item,key) in classTypeDict" :value="key">{{item}}</option>

					</select>
                </span>
				</li>
				<li>
					<span>班级:</span>
					<span>
                   <select name="" id="" class="p_con_form_select" v-model="classId">

              <option v-for="c in classList" :value="c.id">{{c.className}}</option>
            </select>
                </span>
				</li>
			</ul>
			<div class="p_btn_group p_clear_float">
				<!--<input type="button" value="返回" class="p_btn p_btn_siz_2 p_btn_col_red p_btn_pos_r">-->
				<input type="button" value="返回" @click="$router.go(-1)" class="p_btn p_btn_siz_2 p_btn_col_oran p_btn_pos_r">
				<input type="button" value="保存" @click="saveStudent" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r">

			</div>
			<schedules :class-id="classId"></schedules>
		</section>
	</div>
</template>
<script>
	import instance from '../../../api/index.js';
	import * as util from '../../../assets/util.js';
	import { mapState } from 'vuex';
	export default {
		components: {
			schedules: () =>
				import("./Schedule.vue")
		},
		data() {
			return {
				findClasses: { //查询条件
          'qClassStatus':0
				},
				classList: [], //班级列表
				schoolNames: [], //校区,
				classNames: [],
				classNameSubs: [],
				teachers: [], //授课教师
				classTypes: [], //班型
				classId: "", //选择班级
				studentMenu: {}, //未分班学员列表
				selectedList: this.$route.params.id //选择学员列表

			};
		},
		computed: {
			// Getting Vuex State from store/index
			...mapState({
				classTypeDict: state => state.classTypeDict,
			})
		},
		methods: {
			//查询未分配学员树
			getStudentList: function() {
				$('#page1').jstree("destroy");

				instance.get('/student/findNoAssignClassStudents').then((res) => {
					this.studentMenu = {
						id: "-1",
						text: "全选",
						//"state": { disabled:true },
						children: []
					}; //清空

					let findChildren = function(parentArr, menu) {
						if(Array.isArray(parentArr) && parentArr.length) {
							parentArr.forEach(function(parentNode) {
								let sourceCopy = {};
								sourceCopy['id'] = parentNode.id;
								sourceCopy['text'] = parentNode.studentName;

								menu.push(sourceCopy);

							});
						}
					};

					findChildren(res.data.data, this.studentMenu.children);
					//console.info(this.moduleMenu);
					var vm = this;
					//初始化树
					$('#page1').data('jstree', false).empty();
					$('#page1').jstree({
						'core': {
							'themes': {
								'theme': 'default',
								'dots': false,
								'icons': false
							},
							'data': this.studentMenu
						},
						'plugins': ['types', 'checkbox']
					});

					// 展开节点
					$("#page1").on("loaded.jstree", function(event, data) {
						// 展开所有节点
						$('#page1').jstree('open_all');

						if(vm.selectedList != "") {
							let selectedarray = vm.selectedList.split(",");
							selectedarray.forEach(function(node) { //默认选中复选框
								$('#page1').jstree('select_node', node, true);
							});
						}
					});
				})

			},
			//保存信息
			saveStudent: function() {
				let studentIds = [];
				let studentIdsArray = $('#page1').jstree().get_checked(); //获取所有选中的节点ID
				if(this.classId == "") {
					this.$message.error('操作失败！请选择班级！');
					return;
				} else if(studentIdsArray.length == 0) {
					this.$message.error('操作失败！请选择学员');
					return;
				}
				console.info("moduleIdsArray:" + studentIdsArray);
				//$('#tree').jstree().get_checked(true); //获取所有选中的节点对象
				for(var studentId in studentIdsArray) {
					if(studentIdsArray[studentId] != "-1") { //排除根节点以及导航节点
						let idModel = {
							id: studentIdsArray[studentId]
						};
						studentIds.push(idModel);
					}
				};
				instance.post('/class/assignStudents', {
					id: this.classId,
					students: studentIds
				}).then((res) => {
					if(res.data.errcode == '0') {
						this.$message.info('学员分班成功！');
						this.$router.go(-1);

					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}

				})
			},
			query: function(type) { //查询班级
				if(type == "school") {
					this.getTeacher(this.findClasses.qSchoolId);
				} else if(type == "course") {
					this.getClassSub(this.findClasses.qCourseId);
				}
				instance.post('/class/findSimpleClasses', this.findClasses).then((res) => {
					if(res.data.errcode == '0') {
						this.classList = res.data.data;
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}

				})

			},
			getSchool: function() { //获取校区数据
				//获取当前登录人
				let loginInfo = util.session("loginInfo");
				instance.get('/school/findUserSchools/' + loginInfo.login.userId).then((res) => {
					this.schoolNames = res.data.data;
				})
			},
			getClass: function() { //获取课程大类数据
				// course/findCourses
				// /course/findSimpleCourse
				instance.post('/course/findCourses', {}).then((res) => {
					this.classNames = res.data.data;
				})
			},
			getClassSub: function(id) { //获取课程小类数据
				// /course/findSimpleCourseSubs
				instance.post('/course/findSimpleCourseSubs', {
					qCourseId: id
				}).then((res) => {
					this.classNameSubs = res.data.data;
					// console.info(res.data);
				})
			},
			getTeacher: function(schoolId) { //获取授课教师列表
				instance.post('/teacher/findSimpleTeachers', {
					qSchoolId: schoolId
				}).then((res) => {
					this.teachers = res.data.data;
				})
			},
			getClassType: function() { //获取班型列表
				instance.post('/classtype/findSimpleClassTypes', {}).then((res) => {
					this.classTypes = res.data.data;
				})
			},

		},
		mounted: function() {
			this.getClass();
			this.getSchool();
			this.getClassType();
			this.getStudentList();

		}
	}
</script>
