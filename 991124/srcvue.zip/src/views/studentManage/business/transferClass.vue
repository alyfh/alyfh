<!--<title>转班</title>-->
<style>
	.p_lR_l1 {
		width: 50%;
		float: left;
		background-color: #fff;
	}

	.p_lR_r1 {
		width: 50%;
		display: inline-block;
		background-color: #fff;
	}
</style>
<template>
	<div>
		<div class="p_btn_group p_clear_float">
			<input type="button" value="取消" @click="$router.go(-1)" class="p_btn p_btn_siz_2 p_btn_col_red p_btn_pos_r">
			<input type="button" value="确定" @click="saveInfo" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r">
		</div>
		<section class="p_lR_l1">
			<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
      <span>转出信息</span>
    </h3>
			<ul class="p_con_sea_list p_con_sea_list_l p_clear_float">

				<li>
					<span>所属校区:</span>
					<span>
                    <select name=""  class="p_con_form_select" v-model="findClassesOut.qSchoolId" @change="queryOut('school')">
              		<!--option value="">--请选择--</option-->
              <option v-for="sName in schoolNames" :value="sName.id">{{ sName.schoolName }}</option>
            </select>
                </span>
				</li>
				<li>
					<span>课程大类:</span>
					<span>
                    <select name="" id="" class="p_con_form_select" v-model="findClassesOut.qCourseId" @change="queryOut('course')">
                		<option value="">--请选择--</option>
               <option v-for="className in classNames" :value="className.id">{{className.courseName}}</option>
            </select>
                </span>
				</li>
				<li>
					<span>课程小类:</span>
					<span>
                     <select name="" id="" class="p_con_form_select" v-model="findClassesOut.qCourseSubId" @change="queryOut()">
             		<option value="">--请选择--</option>
              <option v-for="classNameSub in classNameSubsOut" :value="classNameSub.id">{{classNameSub.courseSubName}}</option>
            </select>
                </span>
				</li>
				<li>
					<span>授课教师:</span>
					<span>
                    <select name="" id="" class="p_con_form_select" v-model="findClassesOut.qTeacherId" @change="queryOut()">
             		<option value="">--请选择--</option>
              <option v-for="teacher in teachersOut" :value="teacher.id">{{teacher.realName}}</option>
            </select>
                </span>
				</li>
				<li>
					<span>班型:</span>
					<span>
                    <select name="" id="" class="p_con_form_select" v-model="findClassesOut.qClassTypeId" @change="queryOut()">
             		<option value="">--请选择--</option>
              <option v-for="classType in classTypes" :value="classType.id">{{classType.classTypeName}}</option>
            </select>
                </span>
				</li>
				<li>
					<span>授课类型:</span>
					<span>
                    <select name="" id="" class="p_con_form_select" v-model="findClassesOut.qOneByOne" @change="queryOut()">
					 <option v-for = "(item,key) in classTypeDict" :value="key">{{item}}</option>

					</select>
                </span>
				</li>
				<li>
					<span>班级:</span>
					<span>
                    <select name="" id="" class="p_con_form_select" v-model="classOut" @change="queryOut('class')">

              <option v-for="c in classListOut" :value="c.id">{{c.className}}</option>
            </select>
                </span>
				</li>
				<li class='p_con_sea_list_li_l'>
					<span>学生:</span>
					<span>
                    				<el-select style="width:100%" v-model="selectedOut" @change="changeseleted()" multiple placeholder="请选择">
					<el-option v-for="s in classtAllduent" :key="s.id" :label="s.studentName" :value="s.id">
					</el-option>
				</el-select>
                </span>
				</li>
			</ul>
			<schedulef :class-id="classOut"></schedulef>
			<!--<div id="loadkebiao"></div>-->
		</section>
		<section class="p_lR_r1">
			<h3 class='h5_02_info_per_exportRules_h3 p_clear_float'>
      <span>转入信息</span>
    </h3>
			<ul class="p_con_sea_list p_con_sea_list_l p_clear_float">

				<li>
					<span>所属校区:</span>
					<span>
                    <select name=""  class="p_con_form_select" v-model="findClassesIn.qSchoolId" @change="queryIn('school')">
              		<!--option value="">--请选择--</option-->
              <option v-for="sName in schoolNames" :value="sName.id">{{ sName.schoolName }}</option>
            </select>
                </span>
				</li>
				<li>
					<span>课程大类:</span>
					<span>
                    <select name="" id="" class="p_con_form_select" v-model="findClassesIn.qCourseId" @change="queryIn('course')">
                		<option value="">--请选择--</option>
               <option v-for="className in classNames" :value="className.id">{{className.courseName}}</option>
            </select>
                </span>
				</li>
				<li>
					<span>课程小类:</span>
					<span>
                     <select name="" id="" class="p_con_form_select" v-model="findClassesIn.qCourseSubId" @change="queryIn()">
             		<option value="">--请选择--</option>
              <option v-for="classNameSub in classNameSubsIn" :value="classNameSub.id">{{classNameSub.courseSubName}}</option>
            </select>
                </span>
				</li>
				<li>
					<span>授课教师:</span>
					<span>
                    <select name="" id="" class="p_con_form_select" v-model="findClassesIn.qTeacherId" @change="queryIn()">
             		<option value="">--请选择--</option>
              <option v-for="teacher in teachersIn" :value="teacher.id">{{teacher.realName}}</option>
            </select>
                </span>
				</li>
				<li>
					<span>班型:</span>
					<span>
                    <select name="" id="" class="p_con_form_select" v-model="findClassesIn.qClassTypeId" @change="queryIn()">
             		<option value="">--请选择--</option>
              <option v-for="classType in classTypes" :value="classType.id">{{classType.classTypeName}}</option>
            </select>
                </span>
				</li>
				<li>
					<span>授课类型:</span>
					<span>
                    <select name="" id="" class="p_con_form_select" v-model="findClassesIn.qOneByOne" @change="queryIn()">
					 <option v-for = "(item,key) in classTypeDict" :value="key">{{item}}</option>

					</select>
                </span>
				</li>
				<li>
					<span>班级:</span>
					<span>
                    <select name="" id="" class="p_con_form_select" v-model="classIn">

              <option v-for="c in classListIn" :value="c.id">{{c.className}}</option>
            </select>
                </span>
				</li>
				<li class='p_con_sea_list_li_l'>
					<span>学生:</span>
					<span>
                    {{selectedInLabel}}
                </span>
				</li>
			</ul>
			<!--<div id="loadkebiao1"></div>-->
			<schedules :class-id="classIn"></schedules>
		</section>
	</div>
</template>

<script>
	import instance from '../../../api/index.js';
	import * as util from '../../../assets/util.js';
	import { mapState } from 'vuex';
	export default {
		components: {
			schedulef: () =>
				import("./Schedule.vue"),
			schedules: () =>
				import("./Schedule.vue")
		},
		data() {
			return {
				findClassesOut: { //查询条件
          'qClassStatus':0
				},
				findClassesIn: { //查询条件
          'qClassStatus':0
				},
				classListOut: [], //班级列表
				classListIn: [], //班级列表
				schoolNames: [], //校区,
				classNames: [],
				classNameSubsOut: [],
				classNameSubsIn: [],
				teachersOut: [], //授课教师
				teachersIn: [], //授课教师
				classTypes: [], //班型
				classOut: "", //选择班级
				classIn: "", //选择班级
				selectedOut: [], //选择学员列表
				selectedInLabel: "", //显示选择学员姓名列表
				classtAllduent: [] //班级所有学员
			};
		},
		computed: {
			// Getting Vuex State from store/index
			...mapState({
				classTypeDict: state => state.classTypeDict,
			})
		},
		methods: {
			//保存信息
			saveInfo: function() {
				let studentIds = [];
				if(this.classOut == "") {
					this.$message.error('操作失败！请选择转出班级！');
					return;
				} else if(this.classIn == "") {
					this.$message.error('操作失败！请选择转入班级！');
					return;
				} else if(this.selectedOut.length == 0) {
					this.$message.error('操作失败！请选择转出学员');
					return;
				}
				for(var studentId in this.selectedOut) {
					let idModel = {
						id: this.selectedOut[studentId]
					};
					studentIds.push(idModel);

				};
				instance.post('/class/transferStudents/' + this.classOut, {
					id: this.classIn,
					students: studentIds
				}).then((res) => {
					if(res.data.errcode == '0') {
						this.$message.info('学员转班成功！');
						this.$router.go(-1);

					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}

				})
			},
			queryOut: function(type) { //查询班级
				if(type == "school") {
					this.getTeacherOut(this.findClassesOut.qSchoolId);
				} else if(type == "course") {
					this.getClassSubOut(this.findClassesOut.qCourseId);
				} else if(type == "class") {
					this.getClassAllStudent(this.classOut);
				}
				instance.post('/class/findSimpleClasses', this.findClassesOut).then((res) => {
					if(res.data.errcode == '0') {
						this.classListOut = res.data.data;
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}

				})

			},
			queryIn: function(type) { //查询班级
				if(type == "school") {
					this.getTeacherIn(this.findClassesIn.qSchoolId);
				} else if(type == "course") {
					this.getClassSubIn(this.findClassesIn.qCourseId);
				}
				instance.post('/class/findSimpleClasses', this.findClassesIn).then((res) => {
					if(res.data.errcode == '0') {
						this.classListIn = res.data.data;
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}

				})

			},
			getSchool: function() { //获取校区数据
				//获取当前登录人
				let loginInfo = util.session("loginInfo");
				instance.get('/school/findUserSchools/' + loginInfo.login.userId).then((res) => {
					this.schoolNames = res.data.data;
				})
			},
			getClass: function() { //获取课程大类数据
				// course/findCourses
				// /course/findSimpleCourse
				instance.post('/course/findCourses', {}).then((res) => {
					this.classNames = res.data.data;
				})
			},
			getClassSubOut: function(id) { //获取课程小类数据
				// /course/findSimpleCourseSubs
				instance.post('/course/findSimpleCourseSubs', {
					qCourseId: id
				}).then((res) => {
					this.classNameSubsOut = res.data.data;
					// console.info(res.data);
				})
			},
			getClassSubIn: function(id) { //获取课程小类数据
				// /course/findSimpleCourseSubs
				instance.post('/course/findSimpleCourseSubs', {
					qCourseId: id
				}).then((res) => {
					this.classNameSubsIn = res.data.data;
					// console.info(res.data);
				})
			},
			getTeacherOut: function(schoolId) { //获取授课教师列表
				instance.post('/teacher/findSimpleTeachers', {
					qSchoolId: schoolId
				}).then((res) => {
					this.teachersOut = res.data.data;
				})
			},
			getTeacherIn: function(schoolId) { //获取授课教师列表
				instance.post('/teacher/findSimpleTeachers', {
					qSchoolId: schoolId
				}).then((res) => {
					this.teachersIn = res.data.data;
				})
			},
			getClassType: function() { //获取班型列表
				instance.post('/classtype/findSimpleClassTypes', {}).then((res) => {
					this.classTypes = res.data.data;
				})
			},
			getClassAllStudent: function(classOut) { //学员列表
				instance.get('/student/findClassStudents/' + classOut).then((res) => {
					this.classtAllduent = res.data.data;
				})
			},
			changeseleted: function() {
				let vm = this;
				vm.selectedInLabel = "";
				vm.selectedOut.forEach(function(e, i) {
					vm.classtAllduent.forEach(function(s, j) {
						if(e == s.id) {
							vm.selectedInLabel += s.studentName + ";";
						}
					})
				})

			}

		},
		mounted: function() {
			this.getClass();
			this.getSchool();
			this.getClassType();

		}
	}
</script>
