<!--<title>购课记录</title>-->
<style scoped>
	.p_btn_group {
		border-bottom: solid 1px #e7eaec;
		padding-bottom: 10px;
	}
</style>

<template>
	<section class="p_chi_con">
		<div class="p_con_sea">
			<ul class="p_con_sea_list p_clear_float">
				<li>
					<span>学员姓名:</span>
					<span>
						<input type="text" v-model="findbuyClasses.qStudentName" class="p_con_form_input">
					</span>
				</li>
				<li>
					<span>会员卡号:</span>
					<span>
						<input type="text" v-model="findbuyClasses.qStudentLessonCardCode" class="p_con_form_input">
					</span>
				</li>
				<li>
					<span>所属校区:</span>
					<span>
				 <select name=""  class="p_con_form_select" v-model="findbuyClasses.qSchoolId">
              <option value="">-请选择-</option>
              <option v-for="sName in schoolNames" :value="sName.id">{{ sName.schoolName }}</option>
           </select>					
					</span>
				</li>
				<li>
					<span>支付方式:</span>
					<span>
						<select v-model="findbuyClasses.qPayType" class="p_con_form_select">
							<option value="">-请选择-</option>
							  <option v-for = "(item,key) in paymentDict" :value="key">{{item}}</option>
             
						</select>
					</span>
				</li>
				<li>
					<span>审核状态:</span>
					<span>
						<select name="" id="" v-model="findbuyClasses.qApproveStatus" class="p_con_form_select">
							<option value="">-请选择-</option>
							  <option v-for = "(item,key) in approveStatusDict" :value="key">{{item}}</option>
             
						</select>
					</span>
				</li>
				<li>
					<span>订单号:</span>
					<span>
						<input type="text" v-model="findbuyClasses.qOrderCode" class="p_con_form_input">
					</span>
				</li>
				<li>
					<span>支付状态:</span>
					<span>
						<select v-model="findbuyClasses.qPayStatus" class="p_con_form_select">
							<option value="">-请选择-</option>
							  <option v-for = "(item,key) in payStateDict" :value="key">{{item}}</option>
             
						</select>
					</span>
				</li>
			</ul>
			<div class="p_btn_group p_clear_float">
				<input type="button" value="查询" @click="query" class="p_btn p_btn_siz_2 p_btn_col_k_gre p_btn_pos_r">
			</div>
		</div>
		<div class="p_con_tab">
			<div class="p_table_la_over">
				<table class="p_table_la" cellspacing="0" cellpadding="0">
					<tr>
						<td>订单号</td>
						<td>订单时间</td>
						<td>学员姓名</td>
						<td>购课校区</td>
						<td>会员卡类型</td>
						<td>有效期截止日期</td>
						<td>会员卡号</td>
						<td>原价</td>
						<td>现价</td>
						<td>优惠金额</td>
						<td>实收金额</td>
						<td>课时</td>
						<td>赠送课时</td>
						<td>总课时</td>
						<td>审核状态</td>
						<td>支付方式</td>
						<td>支付状态</td>
						<td>经办人</td>
					</tr>
					<tr v-for="info in buyClassDetail">
						<td>{{info.orderCode}}</td>
						<td>{{info.orderTime}}</td>
						<td>{{info.studentName}}</td>
						<td>{{info.schoolName}}</td>
						<td>{{info.cardName}}</td>
						<td>{{getvalidDate(info.buyCardTime,info.validDate)}}</td>
						<td>{{info.studentLessonCardCode}}</td>
						<td>{{info.sourceMoney}}</td>
						<td>{{info.currentMoney}}</td>
						<td>{{info.discountMoney}}</td>
						<td>{{info.money}}</td>
						<td>{{info.hour}}</td>
						<td>{{info.giveHour}}</td>
						<td>{{info.sumHour}}</td>
						<td>{{approveStatusDict[info.approveStatus]}}</td>
						<td>{{paymentDict[info.payType]}}</td>
						<td>{{payStateDict[info.payStatus]}}</td>
						<td>{{info.creatorName}}</td>
					</tr>

				</table>
			</div>
		</div>
		<div class='h5_page_container' id="con">
			<page :record-count="recordCount" v-on:change-page="changePage">
			</page>
		</div>
	</section>
</template>
<script>
	import instance from '../../../api/index.js';
	import * as util from '../../../assets/util.js';
	import { mapState } from 'vuex';
	export default {
		data() {
			return {
				buyClassDetail: [],
				findbuyClasses: { //查询条件
				},
				schoolNames: [], //校区
				recordCount: 0,
				pageNum: 1, //当前页码
			};
		},
		components: {
			page: () =>
				import("../../common/page.vue")
		},
		computed: {　
			// Getting Vuex State from store/index
			...mapState({
				payStateDict: state => state.payStateDict,
				paymentDict: state => state.paymentDict,
				approveStatusDict: state => state.approveStatusDict,
				pageSize: state => state.pageSize,
				pageLarge: state => state.pageLarge
			})

		},
		methods: {
			query: function() {
				this.getBuyClassList();
				this.getBuyClassCount();
			},
			getBuyClassCount: function() { //获取数量
				var params = {};
				if(!(JSON.stringify(this.findbuyClasses) == "{}")) {
					var result = $.extend(true, params, this.findbuyClasses);
				} else {
					var result = params;
				};
				instance.post('/buycard/findBuyCardsCount', result).then((res) => {
					this.recordCount = res.data.data.count;
				});
			},
			getBuyClassList: function() { //获取购课列表信息
				var params = {
					"beginRow": (this.pageNum - 1) * this.pageSize,
					"pageSize": this.pageSize
				};
				if(!(JSON.stringify(this.findbuyClasses) == "{}")) {
					var result = $.extend(true, params, this.findbuyClasses);
				} else {
					var result = params;
				};
				instance.post('/buycard/findBuyCards', result).then((res) => {
					if(res.data.data == null) {} else {
						this.buyClassDetail = res.data.data;
					}
				})
			},
			changePage: function(pageNum) {
				this.pageNum = pageNum;
				this.query();
			},
			getSchool: function() { //获取校区数据

				//获取当前登录人
				let loginInfo = util.session("loginInfo");
				instance.get('/school/findUserSchools/' + loginInfo.login.userId).then((res) => {

					if(res.data.data != null && res.data.data != "") {
						this.schoolNames = res.data.data;
						if(res.data.data != null && res.data.data.length == 1) {
							this.findbuyClasses.qSchoolId = res.data.data[0].id;
						}
						this.query();

					}

				})
			},
			getvalidDate: function(buyCardTime, validDate) {
				var date = buyCardTime.split("-");
				var lateDate = new Date(date[0], parseInt(date[1]) - 1, parseInt(date[2]) + parseInt(validDate));
				return lateDate.pattern("yyyy-MM-dd");
			}

		},
		mounted: function() {
			//this.query();
			this.getSchool();

		}
	};
</script>