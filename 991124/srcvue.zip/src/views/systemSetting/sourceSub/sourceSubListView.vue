<style scoped>
	.p_btn_group {
		border-bottom: solid 1px #e7eaec;
		padding-bottom: 10px;
	}
</style>

<template>
	<section class="p_chi_con">
		<div class="p_con_sea">
			<ul class="p_con_sea_list p_clear_float">
				<li>
					<span>来源大类:</span>
					<span>
						<select name="" v-model="querySourceId" class="p_con_form_select">
							<option value="">--请选择--</option>
							<option v-for="(entry,index) in simplesourceslist" v-bind:value="entry.id">{{entry.sourceName}}</option>
							
						</select>
					</span>
				</li>
				
			</ul>
			<div class="p_btn_group p_clear_float">
				<input type="button" value="查询" @click="query" class="p_btn p_btn_siz_2 p_btn_col_k_gre p_btn_pos_r">
			</div>
		</div>
		<div class="p_con_tab">
			<div class="p_btn_group p_clear_float">
				<!--input type="button" value="删除" class="p_btn p_btn_siz_2 p_btn_col_red p_btn_pos_r"-->
				<input type="button" value="新增" class="p_btn p_btn_siz_2 p_btn_col_gre p_btn_pos_r" @click="addSourceSub">

			</div>
			<div class="p_table_la_over">
				<!--数据列表-->
				<simple-grid :data-list="gridData" :columns="gridColumns" v-on:load-entry="loadSourceSub" v-on:delete-entry="deleteSourceSub" v-on:edit-entry="editSourceSub">
				</simple-grid>

			</div>
			<!-- 分页 -->
			<div class='h5_page_container' id="con">
				<page :record-count="recordCount" v-on:change-page="changePage">
				</page>
			</div>
		</div>

		<!-- 弹窗 -->
		<modal-dialog :show="layerShow" :action-type="actionType" :sourcesubdetail="sourcesubdetail" :simplesourceslist="simplesourceslist" v-on:save-sourceSub="saveSourceSub">
		</modal-dialog>

		<!-- 查看弹窗 -->
		<modal-dialog2 :show="layerShow" :action-type="actionType" :sourcesubdetail="sourcesubdetail">
		</modal-dialog2>

	</section>

</template>

<script>
	import instance from '../../../api/index.js';
	import { mapState } from 'vuex';
	export default {
		components: {
			simpleGrid: () =>
				import("./listComponent.vue"),
			modalDialog: () =>
				import("./addUpdateComponent.vue"),
			modalDialog2: () =>
				import("./readComponent.vue"),
			page: () =>
				import("../../common/page.vue")
		},
		data() {
			return {
				show: false,
				actionType: "query",
				gridColumns: [{
					code: 'id',
					name: 'id',
					isKey: true
				}, {
					code: 'source.sourceName',
					name: '来源大类名'
				}, {
					code: 'sourceSubName',
					name: '来源小类名'
				}, {
					code: 'descr',
					name: '备注'
				}, {
					code: 'createTime',
					name: '创建时间'
				}],
				gridData: [],
				sourcesubdetail: {source:{"id":""}},
				recordCount: 0,
				pageNum: 1, //当前页码
				simplesourceslist:[],//来源大类字典
				querySourceId:""
			};
		},
		computed: {
			// Getting Vuex State from store/index
			...mapState({
				layerShow: state => state.layerShow,
				pageSize: state => state.pageSize,
				pageLarge: state => state.pageLarge
			})
		},
		watch: {
			$route: function(to, from) {
				// this.activeMenuName = this.$route.name;
				// this.breadcrumbs = (this.$route && this.$route.matched) || [];
			}
		},
		methods: {
			setLayerShow: function() {
				this.$store.commit({
					type: 'setLayerShow',
					layerShow: false
				})
			},
			query:function(){
			this.getSourceSubs();
			this.getSourceSubCount();
			},
			getSourceSubCount: function() {
				var params={};
				if(this.querySourceId!="")
				params.qSourceId=this.querySourceId;
				instance.post('/source/findSourceSubsCount', params).then((res) => {
					this.recordCount = res.data.data.count;
				})

			},
			getSourceSubs: function() {//查询列表
				var params={
					"beginRow": (this.pageNum - 1) * this.pageSize,
					"pageSize": this.pageSize
				};
				if(this.querySourceId!="")
				params.qSourceId=this.querySourceId;
				console.info("querySourceId:"+this.querySourceId);
				instance.post('/source/findSourceSubs',params ).then((res) => {
					this.gridData = res.data.data;
				})
				this.actionType = "query";
			},
			editSourceSub: function(key) {

				this.$store.commit({
					type: 'setLayerShow',
					layerShow: true
				})
				instance.get('/source/findSourceSub/' + key).then((res) => {
					this.sourcesubdetail = res.data.data;
					// this.$set('organizeDetail',res.data.data);
					//console.info( "aaaaaaaaaaaa:"+this.organizeDetail);
				})
				this.actionType = "update";
			},
			loadSourceSub: function(key) {
				this.$store.commit({
					type: 'setLayerShow',
					layerShow: true
				})
				instance.get('/source/findSourceSub/' + key).then((res) => {
					this.sourcesubdetail = res.data.data;
					// this.$set('organizeDetail',res.data.data);
					//console.info( "aaaaaaaaaaaa:"+this.organizeDetail);
				})
				this.actionType = "read";
			},
			addSourceSub: function() {
				this.sourcesubdetail = {source:{"id":""}};
				this.$store.commit({
					type: 'setLayerShow',
					layerShow: true
				})
				this.actionType = "add";
			},
			deleteSourceSub: function(key) {

				this.$confirm("您确定删除吗?", "提示", {
						confirmButtonText: "确定",
						cancelButtonText: "取消",
						type: "info"
					})
					.then(() => {
						instance.get('/source/removeSourceSub/' + key).then((res) => {
							this.$message.info('数据删除成功！');
							this.getSourceSubs();
						})
					})
					.catch(() => {});

				//this.actionType="read";
			},
			saveSourceSub: function(item) {
				//console.info("ggggggggggggggggggg" + item.id);
				item.id ? this.updateSourceSub(item) : this.createSourceSub(item)
			},
			createSourceSub: function(item) {

				instance.post('/source/createSourceSub', item).then((res) => {
					if(res.data.errcode == '0') {
						this.$message.info('信息创建成功！');
						this.getSourceSubs();
						this.setLayerShow(); //关闭窗口
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}

				})
			},
			updateSourceSub: function(item) {
				//console.info("item:"+JSON.stringify(item));
				instance.post('/source/changeSourceSub', item).then((res) => {
					if(res.data.errcode == '0') {
						this.$message.info('信息修改成功！');
						this.getSourceSubs();
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}
					this.setLayerShow(); //关闭窗口
				})
			},
			changePage: function(pageNum) {
				console.info("change-page:" + pageNum);
				this.pageNum = pageNum;
				this.getSourceSubs();
			},
			findSimpleSources:function(){//大类字典
				instance.post('/source/findSimpleSources', {}).then((res) => {
					if(res.data.errcode == '0') {
						this.simplesourceslist=res.data.data;
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}
					
				})
				
			}
			
		},
		created: function() {

		},
		mounted: function() {
			this.getSourceSubs();
			this.getSourceSubCount();
			this.findSimpleSources();
			// newAppend('#con',10,1,5,5,loadpages);
			//弹窗显示调用页面
			$('#ue_addclass').click(function(event) {
				$('#templayer').show();
				$(".big_hiddenBakground").show();
				$('.addlayerBox').load('add.html');
			});
			//弹窗关闭按钮
			$('.h5_layerOFFbtn').click(function(event) {
				$('.addlayer').css('display', 'none');
				$(".big_hiddenBakground").css({
					"display": "none"
				});
			});
		}

	};
</script>