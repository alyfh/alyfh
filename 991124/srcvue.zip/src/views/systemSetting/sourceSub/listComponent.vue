<style scoped>

</style>

<template id="grid-template">
	<table class="p_table_la" cellspacing="0" cellpadding="0">

		<tr>

			<td>
				<span>来源大类名</span>
			</td>
			<td>
				<span>来源小类名</span>
			</td>
			<td>
				<span>备注</span>
			</td>
			<td>
				<span>创建时间</span>
			</td>
			<td>操作</td>
		</tr>

		<tr v-for="(entry,index) in dataList">
			<td>
				<span>{{entry['source'].sourceName}}</span>
			</td>
			<td>
				<span>{{entry['sourceSubName']}}</span>
			</td>
			<td>
				<span>{{entry['descr']}}</span>
			</td>
			<td>
				<span>{{entry['createTime']}}</span>
			</td>
			<td>
				<input type="button" value="删除" @click="deleteEntry(entry[columns[0].code])" class="p_btn p_btn_siz_2 p_btn_col_k_red p_btn_pos_r">
				<input type="button" value="编辑" @click="editEntry(entry[columns[0].code])" class="p_btn p_btn_siz_2 p_btn_col_k_oran p_btn_pos_r">
				<input type="button" value="详情" @click="loadEntry(entry[columns[0].code])" class="p_btn p_btn_siz_2 p_btn_col_k_gre p_btn_pos_r">
			</td>
		</tr>

	</table>
</template>

<script>
	export default {

		props: ['dataList', 'columns'],
		data() {
			return {
				list: [],
				loading: false,
				canReset: false
			};
		},
		methods: {
			loadEntry: function(key) {
				this.$emit('load-entry', key);
			},
			editEntry: function(key) {
				this.$emit('edit-entry', key);
			},
			deleteEntry: function(key) {
				this.$emit('delete-entry', key);
			},
			fetchData: function() {
				let vm = this;
				vm.loading = true;
				goods.request.r(vm.queryParam).then(res => {
					vm.list = res.data.content;
					vm.loading = false;
				});
			},
			requestNotAllowed: function() {
				goods.notAllowed.r();
			}
		},
		created() {

		}
	};
</script>