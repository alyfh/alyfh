<style scoped>
	.h5_02_info_per_exportRules_h3 {
		border-bottom: solid 1px #e7e7e7;
		padding: 10px 20px 10px 30px;
		color: #979494
	}
	
	.ue_time_block {
		border-bottom: solid 1px #e7e7e7;
		margin-bottom: 15px;
		position: relative;
	}
	
	.ue_time_block_btn {
		position: absolute;
		bottom: 5px;
		right: 10px;
		width: 20px;
		height: 20px;
		border-radius: 10px;
		background-color: #424242;
		color: #fff;
		text-align: center;
		line-height: 20px;
		cursor: pointer;
	}
</style>

<template>
	<div class="addlayer" id='templayer' v-show="show&&(actionType==='addModule'||actionType==='updateModule')">
		<header>
			<span class="h5_layerLOGO">模块设置</span>
			<span class="h5_layerOFFbtn" @click="setLayerShow">╳</span>
		</header>
		<div class="addlayerBox">
			<form id="" method="post" action="" class="ue_form_add">
				<h3 class='h5_02_info_per_exportRules_h3'>
        	<span>模块信息(</span>
        	<span class='h5_mark_xx2'>★</span>
        	<span>为必填)</span>
    	</h3>
				<ul class='h5_02_info_per_addlist'>
					<li>
						<span>★</span>
						<span>模块编号:</span>
						<span v-if="(actionType==='addModule')"><input type="text"  v-model="moduleDetail.moduleCode" class='per_addperson_txt'></span>
						<span v-else>{{moduleDetail.moduleCode}}</span>
					
					</li>

					<li class="per_addperson_li_w per_addperson_li_h2">
						<span>★</span>
						<span>模块名称:</span>
						<span>
                   <textarea v-model="moduleDetail.moduleName" cols="30" rows="4" placeholder="" class='per_addperson_texarea'></textarea>
                </span>
					</li>

				</ul>

				<br class="p_zwf">
				<div class="p_btn_group p_clear_float">
					<input type="button" value="取消" class="p_btn p_btn_siz_2 p_btn_col_red p_btn_pos_r" @click="setLayerShow">
					<input type="button" value="确定" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r" @click="saveModule">
				</div>
			</form>
		</div>
	</div>

</template>

<script>
	import instance from '../../../api/index.js';

	export default {
		props: ['show', 'actionType', 'moduleDetail'],
		components: {
			
		},
		data() {
			return {
				
			};
		},
		watch: {
			$route: function(to, from) {
				// this.activeMenuName = this.$route.name;
				//this.breadcrumbs = (this.$route && this.$route.matched) || [];
			}
		},
		methods: {
			setLayerShow: function() {
				this.$store.commit({ //将弹层隐藏
					type: 'setLayerShow',
					layerShow: false
				})
			},
			saveModule: function() {
				//console.info("ggggggggggggggggggg"+this.organizeDetail);

				this.$emit('save-module', this.moduleDetail);
	
			}

		},
		created: function() {
			// console.info("bbbbbbbbbbbb:"+this.organizeDetail);
		},
		mounted: function() {

		}

	};
</script>