<style scoped>
	@import '../../../assets/css/tab.css';
	.zxt {
		width: 80%;
		position: relative;
		margin: auto;
		margin-top: 40px;
	}
	
	.h5_iframe1_table_page {
		width: calc(100% - 30px);
		/*height:200px;*/
		margin-bottom: 15px;
		background-color: #f0f0f0;
		margin-left: 10px;
	}
</style>

<template>
	<div class="zxt">
		<div class='zxt_nav'>
			<div id='zxt_nav1' name='aa' class="zxt_nav_click">导航模块配置</div><span style="float:left;position: absolute;left:200px;top:-10px;color:red">请通过右键菜单进行维护！</span>
		</div>
		<div class="h5_iframe1_table_page" id='page1' name='aa'>
			<!--ul>
				<li v-for="(route, index) in menu.children">22222</li>
				<li>主页</li>
				<li data-jstree='{ "opened" : true }'>招生管理
					<ul>
						<li>新增咨询</li>
						<li>全部咨询</li>
					</ul>
				</li>

			</ul-->
		</div>

		<!--div class="p_btn_group p_clear_float">
			<input type="button" value="取消" class="p_btn p_btn_siz_2 p_btn_col_red p_btn_pos_r">
			<input type="button" value="保存" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r">
		</div-->

		<!-- 导航弹窗 -->
		<nav-dialog :show="layerShow" :action-type="actionType" :nav-detail="navDetail" v-on:save-nav="saveNav">
		</nav-dialog>

		<!-- 模块弹窗 -->
		<module-dialog :show="layerShow" :action-type="actionType" :module-detail="moduleDetail" v-on:save-module="saveModule">
		</module-dialog>
		<!-- 操作弹窗 -->
		<action-dialog :show="layerShow" :action-type="actionType" :action-detail="actionDetail" v-on:save-module="saveAction">
		</action-dialog>

	</div>

</template>

<script>
	import instance from '../../../api/index.js';
	import { mapState } from 'vuex';
	export default {
		components: {
			navDialog: () =>
				import("./addUpdateNavComponent.vue"),
			moduleDialog: () =>
				import("./addUpdateModuleComponent.vue"),
			actionDialog: () =>
				import("./addUpdateActionComponent.vue"),
		},
		data() {
			return {
				show: false,
				menu: {
					id: "-1",
					text: "导航树",
					children: []
				},
				actionType: "query",
				navDetail: {},
				moduleDetail: {},
				actionDetail: {}
			};
		},
		computed: {
			// Getting Vuex State from store/index
			...mapState({
				layerShow: state => state.layerShow
			})
		},
		watch: {
			$route: function(to, from) {
				// this.activeMenuName = this.$route.name;
				// this.breadcrumbs = (this.$route && this.$route.matched) || [];
			}
		},
		methods: {
			setLayerShow: function() {
				this.$store.commit({
					type: 'setLayerShow',
					layerShow: false
				})
			},
			//新增导航
			addNav: function(pid) {
				if(pid) pid = pid.substring(0, pid.length - 1);
				this.navDetail = {};
				this.navDetail.pid = pid ? pid : "";
				this.$store.commit({
					type: 'setLayerShow',
					layerShow: true
				})
				this.actionType = "addNav";
			},
			//保存（修改）导航
			saveNav: function(item) {
				item.id ? this.updateNav(item) : this.createNav(item)
			},
			createNav: function(item) {
				instance.post('/navi/createNavigation', item).then((res) => {
					if(res.data.errcode == '0') {
						this.$message.info('信息创建成功！');
						this.getNavigationModuleActions();
						this.setLayerShow(); //关闭窗口
					} else {
						this.$message.error('操作失败！'+res.data.errmsg);
					}
					
				})
			},
			updateNav: function(item) {
				instance.post('/navi/changeNavigation', item).then((res) => {
					if(res.data.errcode == '0') {
						this.$message.info('信息修改成功！');
						this.getNavigationModuleActions();
						this.setLayerShow(); //关闭窗口
					} else {
						this.$message.error('操作失败！'+res.data.errmsg);
					}
				
				})
			},
			//编辑导航
			editNav: function(key) {
				if(key) key = key.substring(0, key.length - 1);
				this.$store.commit({
					type: 'setLayerShow',
					layerShow: true
				})
				instance.get('/navi/findNavigation/' + key).then((res) => {
					this.navDetail = res.data.data;
				})
				this.actionType = "updateNav";
			},
			//删除导航
			deleteNav: function(key) {
				if(key) key = key.substring(0, key.length - 1);
				this.$confirm("您确定删除吗?", "提示", {
						confirmButtonText: "确定",
						cancelButtonText: "取消",
						type: "info"
					})
					.then(() => {
						instance.get('/navi/removeNavigation/' + key).then((res) => {
							this.$message.info('数据删除成功！');
							this.getNavigationModuleActions();
						})
					})
					.catch(() => {});

				//this.actionType="read";
			},
			//新增模块
			addModule: function(pid) {
				if(pid) pid = pid.substring(0, pid.length - 1);
				this.moduleDetail = {};
				this.moduleDetail.navigationId = pid ? pid : "";
				this.$store.commit({
					type: 'setLayerShow',
					layerShow: true
				})
				this.actionType = "addModule";
			},
			//保存（修改）模块
			saveModule: function(item) {
				item.id ? this.updateModule(item) : this.createModule(item)
			},
			createModule: function(item) {
				instance.post('/module/createModule', item).then((res) => {
					if(res.data.errcode == '0') {
						this.$message.info('信息创建成功！');
						this.getNavigationModuleActions();
						this.setLayerShow(); //关闭窗口
					} else {
						this.$message.error('操作失败！'+res.data.errmsg);
					}
					
				})
			},
			updateModule: function(item) {
				instance.post('/module/changeModule', item).then((res) => {
					if(res.data.errcode == '0') {
						this.$message.info('信息修改成功！');
						this.getNavigationModuleActions();
						this.setLayerShow(); //关闭窗口
					} else {
						this.$message.error('操作失败！'+res.data.errmsg);
					}
					
				})
			},
			//编辑模块
			editModule: function(key) {
				if(key) key = key.substring(0, key.length - 1);
				this.$store.commit({
					type: 'setLayerShow',
					layerShow: true
				})
				instance.get('/module/findModule/' + key).then((res) => {
					this.moduleDetail = res.data.data;
				})
				this.actionType = "updateModule";
			},
			//删除模块
			deleteModule: function(key) {
				if(key) key = key.substring(0, key.length - 1);
				this.$confirm("您确定删除吗?", "提示", {
						confirmButtonText: "确定",
						cancelButtonText: "取消",
						type: "info"
					})
					.then(() => {
						instance.get('/module/removeModule/' + key).then((res) => {
							this.$message.info('数据删除成功！');
							this.getNavigationModuleActions();
						})
					})
					.catch(() => {});

				//this.actionType="read";
			},
			//新增操作
			addAction: function(pid) {
				if(pid) pid = pid.substring(0, pid.length - 1);
				this.actionDetail = {};
				this.actionDetail.moduleId = pid ? pid : "";
				this.$store.commit({
					type: 'setLayerShow',
					layerShow: true
				})
				this.actionType = "addAction";
			},
			//保存（修改）操作
			saveAction: function(item) {
				item.id ? this.updateAction(item) : this.createAction(item)
			},
			createAction: function(item) {
				instance.post('/action/createAction', item).then((res) => {
					if(res.data.errcode == '0') {
						this.$message.info('信息创建成功！');
						this.getNavigationModuleActions();
						this.setLayerShow(); //关闭窗口
					} else {
						this.$message.error('操作失败！'+res.data.errmsg);
					}
					
				})
			},
			updateAction: function(item) {
				instance.post('/action/changeAction', item).then((res) => {
					if(res.data.errcode == '0') {
						this.$message.info('信息修改成功！');
						this.getNavigationModuleActions();
						this.setLayerShow(); //关闭窗口
					} else {
						this.$message.error('操作失败！'+res.data.errmsg);
					}
					
				})
			},
			//编辑操作
			editAction: function(key) {
				if(key) key = key.substring(0, key.length - 1);
				this.$store.commit({
					type: 'setLayerShow',
					layerShow: true
				})
				instance.get('/action/findAction/' + key).then((res) => {
					this.actionDetail = res.data.data;
				})
				this.actionType = "updateAction";
			},
			//删除操作
			deleteAction: function(key) {
				if(key) key = key.substring(0, key.length - 1);
				this.$confirm("您确定删除吗?", "提示", {
						confirmButtonText: "确定",
						cancelButtonText: "取消",
						type: "info"
					})
					.then(() => {
						instance.get('/action/removeAction/' + key).then((res) => {
							this.$message.info('数据删除成功！');
							this.getNavigationModuleActions();
						})
					})
					.catch(() => {});

				//this.actionType="read";
			},
			//查询导航模块树
			getNavigationModuleActions: function() {
				instance.post('/navi/findNavigationModuleActions', {}).then((res) => {
					this.menu = {
						id: "-1",
						text: "导航树",
						children: []
					}; //清空
					let findChildren = function(parentArr, menu) {
						if(Array.isArray(parentArr) && parentArr.length) {
							parentArr.forEach(function(parentNode) {
								let sourceCopy = {};
								sourceCopy['id'] = parentNode.id + "N";
								sourceCopy['text'] = "【导航】"+parentNode.navigationName;
								sourceCopy['children'] = [];
								if(parentNode.modules) {
									parentNode.modules.forEach(function(module) {
										let sourceCopym = {};
										sourceCopym['id'] = module.id + "M";
										sourceCopym['text'] ="【模块】"+ module.moduleName;
										sourceCopym['children'] = [];

										module.actions.forEach(function(action) {
											let sourceCopya = {};
											sourceCopya['id'] = action.id + "A";
											sourceCopya['text'] = "【操作】"+action.actionName;
											sourceCopym.children.push(sourceCopya);

										})
										sourceCopy['children'].push(sourceCopym);
									})
								}
								if(parentNode.navigations) {
									findChildren(parentNode.navigations, sourceCopy.children);
								}
								// console.info("sourceCopy"+sourceCopy);
								menu.push(sourceCopy);

							});
						}
					}

					findChildren(res.data.data, this.menu.children);
					console.info(this.menu);
					var vm = this;
					$('#page1').data('jstree', false).empty();
					$('#page1').jstree({
						'core': {
							'themes': {
								'theme': 'default',
								//'dots' : false,
								'icons': false
							},
							'data': this.menu
						},
						'contextmenu': {
							"items": function(node) {
								var temp = {
									"createmainNav": {
										"label": "创建主导航",
										"separator_after": true,
										"action": function(data) {
											var inst = $.jstree.reference(data.reference),
												obj = inst.get_node(data.reference);
											console.info(obj.id);
											vm.addNav();
										}
									},
									"editNav": {
										"label": "编辑导航",
										"separator_after": true,
										"action": function(data) {
											var inst = $.jstree.reference(data.reference),
												obj = inst.get_node(data.reference);
											vm.editNav(obj.id);
										}
									},
									"deleteNav": {
										"label": "删除导航",
										"separator_after": true,
										"action": function(data) {
											var inst = $.jstree.reference(data.reference),
												obj = inst.get_node(data.reference);
											vm.deleteNav(obj.id);
										}
									},
									"createsubNav": {
										"label": "创建子导航",
										"separator_after": true,
										"action": function(data) {
											var inst = $.jstree.reference(data.reference),
												obj = inst.get_node(data.reference);
											console.info(obj.id);
											vm.addNav(obj.id);
										}
									},
									"createModule": {
										"label": "创建模块",
										"separator_after": true,
										"action": function(data) {
											var inst = $.jstree.reference(data.reference),
												obj = inst.get_node(data.reference);
											console.info(obj.id);
											vm.addModule(obj.id);
										}
									},
									"editModule": {
										"label": "编辑模块",
										"separator_after": true,
										"action": function(data) {
											var inst = $.jstree.reference(data.reference),
												obj = inst.get_node(data.reference);
											vm.editModule(obj.id);
										}
									},
									"deleteModule": {
										"label": "删除模块",
										"separator_after": true,
										"action": function(data) {
											var inst = $.jstree.reference(data.reference),
												obj = inst.get_node(data.reference);
											vm.deleteModule(obj.id);
										}
									},
									"createAction": {
										"label": "创建操作",
										"separator_after": true,
										"action": function(data) {
											var inst = $.jstree.reference(data.reference),
												obj = inst.get_node(data.reference);
											console.info(obj.id);
											vm.addAction(obj.id);
										}
									},
									"editAction": {
										"label": "编辑操作",
										"separator_after": true,
										"action": function(data) {
											var inst = $.jstree.reference(data.reference),
												obj = inst.get_node(data.reference);
											vm.editAction(obj.id);
										}
									},
									"deleteAction": {
										"label": "删除操作",
										"separator_after": true,
										"action": function(data) {
											var inst = $.jstree.reference(data.reference),
												obj = inst.get_node(data.reference);
											vm.deleteAction(obj.id);
										}
									}
								};
								/**
								 * 根据导航模块显示右键菜单
								 */
								var menu = {};
								if(node.id == '-1') {
									delete temp.editNav;
									delete temp.deleteNav;
									delete temp.createsubNav;
									delete temp.createModule;
									delete temp.editModule;
									delete temp.deleteModule;
									delete temp.createAction;
									delete temp.editAction;
									delete temp.deleteAction;
								} else if(node.id.endsWith("N")) {
									delete temp.createmainNav;
									delete temp.editModule;
									delete temp.deleteModule;
									delete temp.createAction;
									delete temp.editAction;
									delete temp.deleteAction;
								} else if(node.id.endsWith("M")) {
									delete temp.createmainNav;
									delete temp.editNav;
									delete temp.deleteNav;
									delete temp.createsubNav;
									delete temp.createModule;
									delete temp.editAction;
									delete temp.deleteAction;
								} else if(node.id.endsWith("A")) {
									delete temp.createmainNav;
									delete temp.editNav;
									delete temp.deleteNav;
									delete temp.createsubNav;
									delete temp.createModule;
									delete temp.editModule;
									delete temp.deleteModule;
									delete temp.createAction;
								}
								(menu = temp);
								return menu;
							},
							"select_node": false
						},
						'plugins': ['contextmenu'] //  'plugins' : [ 'types' ,'checkbox']
					});

				})

			}

		},

		created: function() {

		},
		mounted: function() {
			//加载导航树数据
			this.getNavigationModuleActions();

		}

	};
</script>