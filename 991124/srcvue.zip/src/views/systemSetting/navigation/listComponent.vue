<style scoped>
 @import '../../../assets/css/tab.css';
	  .zxt{
            width:80%;
            position:relative;
            margin:auto;
            margin-top: 40px;

        }
        .h5_iframe1_table_page{
            width:calc(100% - 30px);
            /*height:200px;*/
            margin-bottom: 15px;
       
            background-color: #f0f0f0;
            margin-left: 10px;
        }
</style>

<template id="grid-template">
	<div class="zxt">
    <div class='zxt_nav'>
        <div id='zxt_nav1' name='aa' class="zxt_nav_click">导航模块配置</div>
       <li v-for="(route, index) in menu">{{route.navigationName}}</li>
    </div>
    <div class="h5_iframe1_table_page" id='page1' name='aa'>
        <ul>
            <li v-for="(route, index) in menu">{{route.navigationName}}</li>
            <li>主页</li>
            <li data-jstree='{ "opened" : true }'>招生管理
                <ul>
                    <li>新增咨询</li>
                    <li>全部咨询</li>
                </ul>
            </li>


        </ul>
    </div>
   
    <div class="p_btn_group p_clear_float">
        <input type="button" value="取消" class="p_btn p_btn_siz_2 p_btn_col_red p_btn_pos_r">
        <input type="button" value="保存" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r">
    </div>
</div>
</template>

<script>
	export default {

		props: ['menu', 'columns'],
		data() {
			return {
				list: [],
				loading: false,
				canReset: false
			};
		},
		methods: {
			loadEntry: function(key) {
				this.$emit('load-entry', key);
			},
			editEntry: function(key) {
				this.$emit('edit-entry', key);
			},
			deleteEntry: function(key) {
				this.$emit('delete-entry', key);
			},
			fetchData: function() {
				let vm = this;
				vm.loading = true;
				goods.request.r(vm.queryParam).then(res => {
					vm.list = res.data.content;
					vm.loading = false;
				});
			},
			requestNotAllowed: function() {
				goods.notAllowed.r();
			}
		},
		created() {

		}
	};
</script>