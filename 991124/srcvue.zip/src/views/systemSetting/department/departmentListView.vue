<style scoped>
	.p_btn_group {
		border-bottom: solid 1px #e7eaec;
		padding-bottom: 10px;
	}
</style>

<template>
	<section class="p_chi_con">

		<div class="p_con_tab">
			<div class="p_btn_group p_clear_float">
				<!--input type="button" value="删除" class="p_btn p_btn_siz_2 p_btn_col_red p_btn_pos_r"-->
				<input type="button" value="新增" class="p_btn p_btn_siz_2 p_btn_col_gre p_btn_pos_r" @click="addDepartment">

			</div>
			<div class="p_table_la_over">
				<!--数据列表-->
				<simple-grid :data-list="gridData" :columns="gridColumns" v-on:load-entry="loadDepartment" v-on:delete-entry="deleteDepartment" v-on:edit-entry="editDepartment">
				</simple-grid>

			</div>
			<!-- 分页 -->
			<div class='h5_page_container' id="con">
				<page :record-count="recordCount" v-on:change-page="changePage">
				</page>
			</div>
		</div>

		<!-- 弹窗 -->
		<modal-dialog :show="layerShow" :action-type="actionType" :department-detail="departmentDetail" v-on:save-department="saveDepartment">
		</modal-dialog>

		<!-- 查看弹窗 -->
		<modal-dialog2 :show="layerShow" :action-type="actionType" :department-detail="departmentDetail">
		</modal-dialog2>

	</section>

</template>

<script>
	import instance from '../../../api/index.js';
	import { mapState } from 'vuex';
	export default {
		components: {
			simpleGrid: () =>
				import("./listComponent.vue"),
			modalDialog: () =>
				import("./addUpdateComponent.vue"),
			modalDialog2: () =>
				import("./readComponent.vue"),
			page: () =>
				import("../../common/page.vue")
		},
		data() {
			return {
				show: false,
				actionType: "query",
				gridColumns: [{
					code: 'id',
					name: 'id',
					isKey: true
				}, {
					code: 'departmentName',
					name: '部门名'
				}, {
					code: 'descr',
					name: '备注'
				}, {
					code: 'createTime',
					name: '创建时间'
				}],
				gridData: [],
				departmentDetail: {},
				recordCount: 0,
				pageNum: 1 //当前页码
			};
		},
		computed: {
			// Getting Vuex State from store/index
			...mapState({
				layerShow: state => state.layerShow,
				pageSize: state => state.pageSize,
				pageLarge: state => state.pageLarge
			})
		},
		watch: {
			$route: function(to, from) {
				// this.activeMenuName = this.$route.name;
				// this.breadcrumbs = (this.$route && this.$route.matched) || [];
			}
		},
		methods: {
			setLayerShow: function() {
				this.$store.commit({
					type: 'setLayerShow',
					layerShow: false
				})
			},
			getDepartmentCount: function() {
				instance.post('/dept/findDepartmentsCount', {}).then((res) => {
					this.recordCount = res.data.data.count;
				})

			},
			getDepartments: function() {
				instance.post('/dept/findDepartments', {
					"beginRow": (this.pageNum - 1) * this.pageSize,
					"pageSize": this.pageSize
				}).then((res) => {
					this.gridData = res.data.data;
				})
				this.actionType = "query";
			},
			editDepartment: function(key) {

				this.$store.commit({
					type: 'setLayerShow',
					layerShow: true
				})
				instance.get('/dept/findDept/' + key).then((res) => {
					this.roleDetail = res.data.data;
					// this.$set('organizeDetail',res.data.data);
					//console.info( "aaaaaaaaaaaa:"+this.organizeDetail);
				})
				this.actionType = "update";
			},
			loadDepartment: function(key) {
				this.$store.commit({
					type: 'setLayerShow',
					layerShow: true
				})
				instance.get('/dept/findDept/' + key).then((res) => {
					this.departmentDetail = res.data.data;
					// this.$set('organizeDetail',res.data.data);
					//console.info( "aaaaaaaaaaaa:"+this.organizeDetail);
				})
				this.actionType = "read";
			},
			addDepartment: function() {
				this.departmentDetail = {};
				this.$store.commit({
					type: 'setLayerShow',
					layerShow: true
				})
				this.actionType = "add";
			},
			deleteDepartment: function(key) {

				this.$confirm("您确定删除吗?", "提示", {
						confirmButtonText: "确定",
						cancelButtonText: "取消",
						type: "info"
					})
					.then(() => {
						instance.get('/dept/removeDept/' + key).then((res) => {
							this.$message.info('数据删除成功！');
							this.getDepartments();
						})
					})
					.catch(() => {});

				//this.actionType="read";
			},
			saveDepartment: function(item) {
				console.info("ggggggggggggggggggg" + item.id);
				item.id ? this.updateDepartment(item) : this.createDepartment(item)
			},
			createDepartment: function(item) {
				
				
				instance.post('/dept/createDept', item).then((res) => {
					if(res.data.errcode == '0') {
						this.$message.info('信息创建成功！');
						this.getDepartments();
						this.setLayerShow(); //关闭窗口
					} else {
						this.$message.error('操作失败！'+res.data.errmsg);
					}
					
				})
			},
			updateDepartment: function(item) {
				instance.post('/dept/changeDept', item).then((res) => {
					if(res.data.errcode == '0') {
						this.$message.info('信息修改成功！');
						this.getDepartments();
					} else {
						this.$message.error('操作失败！'+res.data.errmsg);
					}
					this.setLayerShow(); //关闭窗口
				})
			},
			changePage: function(pageNum) {
				console.info("change-page:" + pageNum);
				this.pageNum = pageNum;
				this.getDepartments();
			}
		},
		created: function() {

		},
		mounted: function() {
			this.getDepartments();
			this.getDepartmentCount();
			// newAppend('#con',10,1,5,5,loadpages);
			//弹窗显示调用页面
			$('#ue_addclass').click(function(event) {
				$('#templayer').show();
				$(".big_hiddenBakground").show();
				$('.addlayerBox').load('add.html');
			});
			//弹窗关闭按钮
			$('.h5_layerOFFbtn').click(function(event) {
				$('.addlayer').css('display', 'none');
				$(".big_hiddenBakground").css({
					"display": "none"
				});
			});
		}

	};
</script>