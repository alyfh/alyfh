<style scoped>
	.h5_02_info_per_exportRules_h3 {
		border-bottom: solid 1px #e7e7e7;
		padding: 10px 20px 10px 30px;
		color: #979494
	}
	
	.ue_time_block {
		border-bottom: solid 1px #e7e7e7;
		margin-bottom: 15px;
		position: relative;
	}
	
	.ue_time_block_btn {
		position: absolute;
		bottom: 5px;
		right: 10px;
		width: 20px;
		height: 20px;
		border-radius: 10px;
		background-color: #424242;
		color: #fff;
		text-align: center;
		line-height: 20px;
		cursor: pointer;
	}
</style>

<template>
	<div class="addlayer" id='templayer' v-show="show&&(actionType==='read')">
		<header>
			<span class="h5_layerLOGO">部门</span>
			<span class="h5_layerOFFbtn" @click="setLayerShow">╳</span>
		</header>
		<div class="addlayerBox">
			<form id="" method="post" action="" class="ue_form_add">
				<h3 class='h5_02_info_per_exportRules_h3'>
        	<span>部门信息(</span>
        	<span class='h5_mark_xx2'>★</span>
        	<span>为必填)</span>
    	</h3>
				<ul class='h5_02_info_per_addlist'>
					<li>
						<span>★</span>
						<span>部门名:</span>
						<span>{{departmentDetail.departmentName}}</span>
					</li>

					<li class="per_addperson_li_w per_addperson_li_h2">
						<span></span>
						<span>备注:</span>
						<span>
                  {{departmentDetail.descr}}
                </span>
					</li>

				</ul>

				<br class="p_zwf">
				<div class="p_btn_group p_clear_float">
					<!--input type="button" value="取消" class="p_btn p_btn_siz_2 p_btn_col_red p_btn_pos_r" @click="setLayerShow"-->
					<!--input type="button" value="确定" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r" @click="saveOrganize"-->
				</div>
			</form>
		</div>
	</div>

</template>

<script>
	import instance from '../../../api/index.js';

	export default {
		props: ['show', 'actionType', 'departmentDetail'],
		components: {
			simpleGrid: () =>
				import("./listComponent.vue")
		},
		data() {
			return {
				gridColumns: [{
					code: 'id',
					name: 'id',
					isKey: true
				}, {
					code: 'departmentName',
					name: '部门名'
				}, {
					code: 'descr',
					name: '备注'
				}, {
					code: 'createTime',
					name: '创建时间'
				}],
				gridData: []
			};
		},
		watch: {
			$route: function(to, from) {
				// this.activeMenuName = this.$route.name;
				//this.breadcrumbs = (this.$route && this.$route.matched) || [];
			}
		},
		methods: {
			setLayerShow: function() {
				this.$store.commit({ //将弹层隐藏
					type: 'setLayerShow',
					layerShow: false
				})
			}
		

		},
		created: function() {
			// console.info("bbbbbbbbbbbb:"+this.organizeDetail);
		},
		mounted: function() {

		}

	};
</script>