<style scoped>
	.p_btn_group {
		border-bottom: solid 1px #e7eaec;
		padding-bottom: 10px;
	}
</style>

<template>
	<section class="p_chi_con">
	<div class="p_con_sea">
			<ul class="p_con_sea_list p_clear_float">
				<li>
					<span>角色名称:</span>
					<span>
						<input name="" id="" v-model="qRoleName" class="p_con_form_select"></input>
					</span>
				</li>
				
			</ul>
			<div class="p_btn_group p_clear_float">
				<input type="button" value="查询" @click="query" class="p_btn p_btn_siz_2 p_btn_col_k_gre p_btn_pos_r">
			</div>
		</div>
		
		<div class="p_con_tab">
			<div class="p_btn_group p_clear_float">
				<!--input type="button" value="删除" class="p_btn p_btn_siz_2 p_btn_col_red p_btn_pos_r"-->
				<input type="button" value="新增" class="p_btn p_btn_siz_2 p_btn_col_gre p_btn_pos_r" @click="addRole">

			</div>
			<div class="p_table_la_over">
				<!--数据列表-->
				<simple-grid :data-list="gridData" :columns="gridColumns" v-on:load-entry="loadRole" v-on:delete-entry="deleteRole" v-on:edit-entry="editRole" v-on:setting-entry="settingRole">
				</simple-grid>

			</div>
			<!-- 分页 -->
			<div class='h5_page_container' id="con">
				<page :record-count="recordCount" v-on:change-page="changePage">
				</page>
			</div>
		</div>

		<!-- 弹窗 -->
		<modal-dialog :show="layerShow" :action-type="actionType" :role-detail="roleDetail" v-on:save-role="saveRole">
		</modal-dialog>

		<!-- 查看弹窗 -->
		<modal-dialog2 :show="layerShow" :action-type="actionType" :role-detail="roleDetail">
		</modal-dialog2>
		
<!-- 角色模块配置弹窗 -->
		<modal-dialog3 :show="layerShow" :action-type="actionType" :role-id="roleId">
		</modal-dialog3>
	</section>

</template>

<script>
	import instance from '../../../api/index.js';
	import { mapState } from 'vuex';
	export default {
		components: {
			simpleGrid: () =>
				import("./listComponent.vue"),
			modalDialog: () =>
				import("./addUpdateComponent.vue"),
			modalDialog2: () =>
				import("./readComponent.vue"),
				modalDialog3: () =>
				import("./roleModuleSettings.vue"),
			page: () =>
				import("../../common/page.vue")
		},
		data() {
			return {
				show: false,
				actionType: "query",
				roleId:"",//当前授权角色
				gridColumns: [{
					code: 'id',
					name: 'id',
					isKey: true
				}, {
					code: 'roleCode',
					name: '角色号'
				}, {
					code: 'roleName',
					name: '角色名称'
				}, {
					code: 'createTime',
					name: '创建时间'
				}],
				qRoleName:"",
				gridData: [],
				roleDetail: {},
				recordCount: 0,
				pageNum: 1 //当前页码
			};
		},
		computed: {
			// Getting Vuex State from store/index
			...mapState({
				layerShow: state => state.layerShow,
				pageSize: state => state.pageSize,
				pageLarge: state => state.pageLarge
			})
		},
		watch: {
			$route: function(to, from) {
				// this.activeMenuName = this.$route.name;
				// this.breadcrumbs = (this.$route && this.$route.matched) || [];
			}
		},
		methods: {
			setLayerShow: function() {
				this.$store.commit({
					type: 'setLayerShow',
					layerShow: false
				})
			},
			query:function(){
			this.getRoles();
			this.getRoleCount();
			},
			getRoleCount: function() {
				var params={};
				if(this.qRoleName!="")
				params.qRoleName=this.qRoleName;
				instance.post('/role/findRolesCount', params).then((res) => {
					this.recordCount = res.data.data.count;
				})

			},
			getRoles: function() {
								var params={
					"beginRow": (this.pageNum - 1) * this.pageSize,
					"pageSize": this.pageSize
				};
				if(this.qRoleName!="")
				params.qRoleName=this.qRoleName;
				
				instance.post('/role/findRoles',params ).then((res) => {
					this.gridData = res.data.data;
				})
				this.actionType = "query";
			},
			editRole: function(key) {

				this.$store.commit({
					type: 'setLayerShow',
					layerShow: true
				})
				instance.get('/role/findRole/' + key).then((res) => {
					this.roleDetail = res.data.data;
					// this.$set('organizeDetail',res.data.data);
					//console.info( "aaaaaaaaaaaa:"+this.organizeDetail);
				})
				this.actionType = "update";
			},
			loadRole: function(key) {
				this.$store.commit({
					type: 'setLayerShow',
					layerShow: true
				})
				instance.get('/role/findRole/' + key).then((res) => {
					this.roleDetail = res.data.data;
					// this.$set('organizeDetail',res.data.data);
					//console.info( "aaaaaaaaaaaa:"+this.organizeDetail);
				})
				this.actionType = "read";
			},
			addRole: function() {
				this.roleDetail = {};
				this.$store.commit({
					type: 'setLayerShow',
					layerShow: true
				})
				this.actionType = "add";
			},
			settingRole: function(id) {
				this.roleDetail = {};
				this.roleId=id;
				//console.info("roleId:"+this.roleId);
				this.$store.commit({
					type: 'setLayerShow',
					layerShow: true
				})
				this.actionType = "settingRole";
			},
			deleteRole: function(key) {

				this.$confirm("您确定删除吗?", "提示", {
						confirmButtonText: "确定",
						cancelButtonText: "取消",
						type: "info"
					})
					.then(() => {
						instance.get('/role/removeRole/' + key).then((res) => {
							this.$message.info('数据删除成功！');
							this.getRoles();
						})
					})
					.catch(() => {});

				//this.actionType="read";
			},
			saveRole: function(item) {
				console.info("ggggggggggggggggggg" + item.id);
				item.id ? this.updateRole(item) : this.createRole(item)
			},
			createRole: function(item) {
				
				
				instance.post('/role/createRole', item).then((res) => {
					if(res.data.errcode == '0') {
						this.$message.info('信息创建成功！');
						this.getRoles();
						this.setLayerShow(); //关闭窗口
					} else {
						this.$message.error('操作失败！'+res.data.errmsg);
					}
					
				})
			},
			updateRole: function(item) {
				instance.post('/role/changeRole', item).then((res) => {
					if(res.data.errcode == '0') {
						this.$message.info('信息修改成功！');
						this.getRoles();
					} else {
						this.$message.error('操作失败！'+res.data.errmsg);
					}
					this.setLayerShow(); //关闭窗口
				})
			},
			changePage: function(pageNum) {
				console.info("change-page:" + pageNum);
				this.pageNum = pageNum;
				this.getRoles();
			}
		},
		created: function() {

		},
		mounted: function() {
			this.getRoles();
			this.getRoleCount();
			// newAppend('#con',10,1,5,5,loadpages);
			//弹窗显示调用页面
			$('#ue_addclass').click(function(event) {
				$('#templayer').show();
				$(".big_hiddenBakground").show();
				$('.addlayerBox').load('add.html');
			});
			//弹窗关闭按钮
			$('.h5_layerOFFbtn').click(function(event) {
				$('.addlayer').css('display', 'none');
				$(".big_hiddenBakground").css({
					"display": "none"
				});
			});
		}

	};
</script>