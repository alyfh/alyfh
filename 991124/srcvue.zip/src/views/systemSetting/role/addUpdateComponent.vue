<style scoped>
	.h5_02_info_per_exportRules_h3 {
		border-bottom: solid 1px #e7e7e7;
		padding: 10px 20px 10px 30px;
		color: #979494
	}
	
	.ue_time_block {
		border-bottom: solid 1px #e7e7e7;
		margin-bottom: 15px;
		position: relative;
	}
	
	.ue_time_block_btn {
		position: absolute;
		bottom: 5px;
		right: 10px;
		width: 20px;
		height: 20px;
		border-radius: 10px;
		background-color: #424242;
		color: #fff;
		text-align: center;
		line-height: 20px;
		cursor: pointer;
	}
</style>

<template>
	<div class="addlayer" id='templayer' v-show="show&&(actionType==='add'||actionType==='update')">
		<header>
			<span class="h5_layerLOGO">角色</span>
			<span class="h5_layerOFFbtn" @click="setLayerShow">╳</span>
		</header>
		<div class="addlayerBox">
			<form id="" method="post" action="" class="ue_form_add">
				<h3 class='h5_02_info_per_exportRules_h3'>
        	<span>角色信息(</span>
        	<span class='h5_mark_xx2'>★</span>
        	<span>为必填)</span>
    	</h3>
				<ul class='h5_02_info_per_addlist'>
					<li>
						<span>★</span>
						<span>角色号:</span>
						<span v-if="(actionType==='add')"><input type="text"  v-model="roleDetail.roleCode" class='per_addperson_txt'></span>
						<span v-else>{{roleDetail.roleCode}}</span>
					</li>

					<li class="per_addperson_li_w per_addperson_li_h2">
						<span>★</span>
						<span>角色名称:</span>
						<span>
                   <textarea v-model="roleDetail.roleName" cols="30" rows="4" placeholder="" class='per_addperson_texarea'></textarea>
                </span>
					</li>

				</ul>

				<br class="p_zwf">
				<div class="p_btn_group p_clear_float">
					<input type="button" value="取消" class="p_btn p_btn_siz_2 p_btn_col_red p_btn_pos_r" @click="setLayerShow">
					<input type="button" value="确定" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r" @click="saveRole">
				</div>
			</form>
		</div>
	</div>

</template>

<script>
	import instance from '../../../api/index.js';

	export default {
		props: ['show', 'actionType', 'roleDetail'],
		components: {
			simpleGrid: () =>
				import("./listComponent.vue")
		},
		data() {
			return {
				gridColumns: [{
					code: 'id',
					name: 'id',
					isKey: true
				}, {
					code: 'orgName',
					name: '组织名称'
				}, {
					code: 'descr',
					name: '备注'
				}, {
					code: 'createTime',
					name: '创建时间'
				}],
				gridData: []
			};
		},
		watch: {
			$route: function(to, from) {
				// this.activeMenuName = this.$route.name;
				//this.breadcrumbs = (this.$route && this.$route.matched) || [];
			}
		},
		methods: {
			setLayerShow: function() {
				this.$store.commit({ //将弹层隐藏
					type: 'setLayerShow',
					layerShow: false
				})
			},
			saveRole: function() {
				//console.info("ggggggggggggggggggg"+this.organizeDetail);

				this.$emit('save-role', this.roleDetail);
				/*
	  if(!this.organizeDetail.id){
       instance.post('/org/createOrg',this.organizeDetail ).then((res) => {
	     if(res.data.errcode=='0'){
		  this.$message.info('信息创建成功！');
		 }else{
		 this.$message.info('操作失败，请联系管理员！');
		 }
        this.setLayerShow();//关闭窗口
      })
	  }else{
	         instance.post('/org/changeOrg', this.organizeDetail).then((res) => {
	     if(res.data.errcode=='0'){
		  this.$message.info('信息修改成功！');
		 }else{
		 this.$message.info('操作失败，请联系管理员！');
		 }
        this.setLayerShow();//关闭窗口
      })
	  
	  }
	  */
			}

		},
		created: function() {
			// console.info("bbbbbbbbbbbb:"+this.organizeDetail);
		},
		mounted: function() {

		}

	};
</script>