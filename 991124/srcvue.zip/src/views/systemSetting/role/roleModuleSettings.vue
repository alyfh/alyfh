<style scoped>
	@import '../../../assets/css/tab.css';
	.h5_02_info_per_exportRules_h3 {
		border-bottom: solid 1px #e7e7e7;
		padding: 10px 20px 10px 30px;
		color: #979494
	}
	
	.ue_time_block {
		border-bottom: solid 1px #e7e7e7;
		margin-bottom: 15px;
		position: relative;
	}
	
	.ue_time_block_btn {
		position: absolute;
		bottom: 5px;
		right: 10px;
		width: 20px;
		height: 20px;
		border-radius: 10px;
		background-color: #424242;
		color: #fff;
		text-align: center;
		line-height: 20px;
		cursor: pointer;
	}
	
	.zxt {
		width: 80%;
		position: relative;
		margin: auto;
		margin-top: 40px;
	}
	
	.h5_iframe1_table_page {
		width: calc(100% - 30px);
		/*height:200px;*/
		margin-bottom: 15px;
		background-color: #f0f0f0;
		margin-left: 10px;
	}
</style>

<template>
	<div class="addlayer" id='templayer' v-if="show&&(actionType==='settingRole')">
		<header>
			<span class="h5_layerLOGO">角色</span>
			<span class="h5_layerOFFbtn" @click="setLayerShow">╳</span>
		</header>
		<div class="addlayerBox">

			<div class="zxt">
				<div class='zxt_nav'>
					<div id='zxt_nav1' name='aa' class="zxt_nav_click" @click="showNav(1,$event)">导航模块配置</div>
					<div id='zxt_nav2' name='bb' @click="showNav(2,$event)">角色操作配置</div>
				</div>
				<div class="h5_iframe1_table_page"  id='page1' name='aa' >
					<ul>

						<li>主页</li>
						<li data-jstree='{ "opened" : true }'>招生管理
							<ul>
								<li>新增咨询</li>
								<li>全部咨询</li>
							</ul>
						</li>

					</ul>
				</div>
				<div class="h5_iframe1_table_page"  name='bb' id="page2" style="display:none">
					<ul>
						<li>登陆1</li>
						<li>主页2</li>
						<li>招生管理2
							<ul>
								<li>新增咨询2</li>
								<li>全部咨询2</li>
							</ul>
						</li>

					</ul>
				</div>

				<div class="p_btn_group p_clear_float">
					<input type="button" value="取消" @click="setLayerShow" class="p_btn p_btn_siz_2 p_btn_col_red p_btn_pos_r">
					<input type="button" value="保存" @click="save" class="p_btn p_btn_siz_2 p_btn_col_blu p_btn_pos_r">
					</div>

			</div>
		</div>
	</div>

</template>

<script>
	import instance from '../../../api/index.js';

	export default {
		props: ['show', 'actionType', 'roleId'],
		components: {
			simpleGrid: () =>
				import("./listComponent.vue")
		},
		data() {
			return {
				navName:1,
				moduleMenu: {}, //导航模块树
				actionMenu: {}, //导航模块操作树
				currRoleOfModules: [], //当前角色授权的模块列表
				currRoleOfActions: [], //当前角色授权的操作列表
			};
		},
		computed: {
			status: function() {
				return this.show && (this.actionType === 'settingRole');
			}
		},
		watch: {
			$route: function(to, from) {
				// this.activeMenuName = this.$route.name;
				//this.breadcrumbs = (this.$route && this.$route.matched) || [];
			},
			status: function(newValue) {
				if(newValue == true) {
					this.currRoleOfModules = [];
					this.getCurrRoleOfModules();
					this.getNavigationModules();
					this.navName=1;

				}
			}
		},
		methods: {
			setLayerShow: function() {
				this.$store.commit({ //将弹层隐藏
					type: 'setLayerShow',
					layerShow: false
				})
			},
			showNav:function(name,event){//导航切换
				this.navName=name;
				$('.zxt_nav>div').removeClass('zxt_nav_click');
				$(event.target).addClass('zxt_nav_click');
			//	$('.h5_iframe1_table_page').hide();
			//	$('.h5_iframe1_table_page[name="' + $(event.target).attr('name') + '"]').show();
				if(name==2){
					this.currRoleOfActions = [];
					this.getCurrRoleOfActions();
					this.getNavigationModuleActions();
				}else if(name==1){
					this.currRoleOfModules = [];
					this.getCurrRoleOfModules();
					this.getNavigationModules();
				}
			},
			//查询当前角色授权的模块列表
			getCurrRoleOfModules: function() {
				var vm = this;
				//console.info("ddd:" + vm.roleId);
				instance.get('/module/findRoleModules/' + vm.roleId).then((res) => {
					this.currRoleOfModules = res.data.data;
					//$('#page1').on("open_node.jstree", function(e, data) {

					//data.node.children.forEach(function(e, i) {
					// console.info(e);
					//隐藏导航复选框
					//	if(e.endsWith("N"))
					//		$("#" + e + "_anchor>.jstree-checkbox").css("display", "none");
					//默认选 中已分配模块的复选框							
					//	vm.currRoleOfModules.forEach(function(node){
					//		$('#page1').jstree('select_node', node.id+"M", true);
					//	});

					//});

					//});
				});
			},
				//查询当前角色授权的操作列表
			getCurrRoleOfActions: function() {
				var vm = this;
				instance.get('/navi/findRoleActions/' + vm.roleId).then((res) => {
					this.currRoleOfActions = res.data.data;				
				});
			},
			//查询导航模块树
			getNavigationModules: function() {
				$('#page1').jstree("destroy");

				instance.get('/navi/findNavigationModules').then((res) => {
					this.moduleMenu = {
						id: "-1",
						text: "导航树",
						//"state": { disabled:true },
						children: []
					}; //清空
					
					let findChildren = function(parentArr, menu) {
						if(Array.isArray(parentArr) && parentArr.length) {
							parentArr.forEach(function(parentNode) {
								let sourceCopy = {};
								sourceCopy['id'] = parentNode.id + "N";
								sourceCopy['text'] = "【导航】" + parentNode.navigationName;
								sourceCopy['children'] = [];
								if(parentNode.modules) {
									parentNode.modules.forEach(function(module) {
										let sourceCopym = {};
										sourceCopym['id'] = module.id + "M";
										sourceCopym['text'] = "【模块】" + module.moduleName;
										sourceCopym['children'] = [];

										module.actions.forEach(function(action) {
											let sourceCopya = {};
											sourceCopya['id'] = action.id + "A";
											sourceCopya['text'] = "【操作】" + action.actionName;
											sourceCopym.children.push(sourceCopya);

										})
										sourceCopy['children'].push(sourceCopym);
									})
								}
								if(parentNode.navigations) {
									findChildren(parentNode.navigations, sourceCopy.children);
								}
								// console.info("sourceCopy"+sourceCopy);
								menu.push(sourceCopy);

							});
						}
					};

					findChildren(res.data.data, this.moduleMenu.children);
					//console.info(this.moduleMenu);
					var vm = this;
					//初始化授权模块树
					$('#page1').data('jstree', false).empty();
					$('#page1').jstree({
						'core': {
							'themes': {
								'theme': 'default',
								'dots' : false,
								'icons': false
							},
							'data': this.moduleMenu
						},
						'plugins': ['types', 'checkbox']
					});

					// 展开节点
					$("#page1").on("loaded.jstree", function(event, data) {
						// 展开所有节点
						$('#page1').jstree('open_all');
						$("#-1_anchor>.jstree-checkbox").css("display", "none"); //隐藏根节点复选框
//						for(var i in data.instance._model.data) { //隐藏所有导航复选框 、保留模块
//							if(i.endsWith("N"))
//								$("#" + i + "_anchor>.jstree-checkbox").css("display", "none");
//						}
				
						vm.currRoleOfModules.forEach(function(node) { //默认选中角色授权模块复选框
							$('#page1').jstree('select_node', node.id + "M", true);
							//console.info(node.id);
						});
					});
				})

			},
			//查询导航模块操作树
			getNavigationModuleActions: function() {
				$('#page1').jstree("destroy");
				var vm=this;
				instance.get('/navi/findRoleNavigationModulesActions/'+vm.roleId).then((res) => {
					
					this.actionMenu = {
						id: "-1",
						text: "导航树",
						//"state": { disabled:true },
						children: []
					}; //清空
					let findChildren = function(parentArr, menu) {
						if(Array.isArray(parentArr) && parentArr.length) {
							parentArr.forEach(function(parentNode) {
								let sourceCopy = {};
								sourceCopy['id'] = parentNode.id + "N";
								sourceCopy['text'] = "【导航】" + parentNode.navigationName;
								sourceCopy['children'] = [];
								if(parentNode.modules) {
									parentNode.modules.forEach(function(module) {
										let sourceCopym = {};
										sourceCopym['id'] = module.id + "M";
										sourceCopym['text'] = "【模块】" + module.moduleName;
										sourceCopym['children'] = [];

										module.actions.forEach(function(action) {
											let sourceCopya = {};
											sourceCopya['id'] = action.id + "A";
											sourceCopya['text'] = "【操作】" + action.actionName;
											sourceCopym.children.push(sourceCopya);

										})
										sourceCopy['children'].push(sourceCopym);
									})
								}
								if(parentNode.navigations) {
									findChildren(parentNode.navigations, sourceCopy.children);
								}
								// console.info("sourceCopy"+sourceCopy);
								menu.push(sourceCopy);

							});
						}
					};

					findChildren(res.data.data, this.actionMenu.children);
					//console.info(this.actionMenu);

					$('#page1').data('jstree', false).empty();
					$('#page1').jstree({
						'core': {
							'themes': {
								'theme': 'default',
								'dots' : false,
								'icons': false
							},
							'data': this.actionMenu
						},
						'plugins': ['types', 'checkbox']
					});
						// 展开节点
					$("#page1").on("loaded.jstree", function(event, data) {
						// 展开所有节点
						$('#page1').jstree('open_all');
						$("#-1_anchor>.jstree-checkbox").css("display", "none"); //隐藏根节点复选框
//						for(var i in data.instance._model.data) { //隐藏所有导航复选框 、保留操作
//							if(i.endsWith("N")||i.endsWith("M"))
//								$("#" + i + "_anchor>.jstree-checkbox").css("display", "none");
//						}
				
						vm.currRoleOfActions.forEach(function(node) { //默认选中角色授权模块复选框
							$('#page1').jstree('select_node', node.id + "A", true);
							//console.info(node.id);
						});
					});

				})

			},
			save:function(){
			    if(this.navName==1){//保存模块
			    	this.saveModules();
			    }else if(this.navName==2){//保存操作
			    	this.saveActions();
			    }
			},
			//保存角色授权模块信息
			saveModules: function() {
				let moduleIds = [];
				let moduleIdsArray = $('#page1').jstree().get_checked(); //获取所有选中的节点ID
				console.info("moduleIdsArray:" + moduleIdsArray);
				//$('#tree').jstree().get_checked(true); //获取所有选中的节点对象 
				for(var ModuleId in moduleIdsArray) {
					if(moduleIdsArray[ModuleId] != "-1" && moduleIdsArray[ModuleId].endsWith("M")) { //排除根节点以及导航节点
						let idModel = {
							id: moduleIdsArray[ModuleId].substring(0,moduleIdsArray[ModuleId].length-1)
						};
						moduleIds.push(idModel);
					}
				};
				instance.post('/role/changeRoleModules', {
					id: this.roleId,
					modules: moduleIds
				}).then((res) => {
					if(res.data.errcode == '0') {
						this.$message.info('模块授权成功！');
						//this.setLayerShow(); //关闭窗口
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}

				})
			},
						//保存角色授权模块信息
			saveActions:function(){
				let actionIds = [];
				let actionIdsArray = $('#page1').jstree().get_checked(); //获取所有选中的节点ID
				//console.info("moduleIdsArray:" + actionIdsArray);
				//$('#tree').jstree().get_checked(true); //获取所有选中的节点对象 
				for(var actionId in actionIdsArray) {
					if(actionIdsArray[actionId].endsWith("A")) { //排除根节点以及导航节点
						let idModel = {
							id: actionIdsArray[actionId].substring(0,actionIdsArray[actionId].length-1)
						};
						actionIds.push(idModel);
					}
				};
				instance.post('/role/changeRoleActions', {
					id: this.roleId,
					actions: actionIds
				}).then((res) => {
					if(res.data.errcode == '0') {
						this.$message.info('操作授权成功！');
						//this.setLayerShow(); //关闭窗口
					} else {
						this.$message.error('操作失败！' + res.data.errmsg);
					}

				})
			}

		},
		created: function() {
			// console.info("bbbbbbbbbbbb:"+this.organizeDetail);
		},
		mounted: function() {
			// 展开节点
			$("#page1").on("loaded.jstree", function(event, data) {
				// 展开所有节点
				//$('#page1').jstree('open_all');
				// 展开指定节点
				//data.instance.open_node(1);     // 单个节点 （1 是顶层的id）
				//data.instance.open_node(['-1', '389003416912924672N']); // 多个节点 (展开多个几点只有在一次性装载后所有节点后才可行）		
				//$(".jstree-checkbox").css("display", "none")

			});

		}

	};
</script>