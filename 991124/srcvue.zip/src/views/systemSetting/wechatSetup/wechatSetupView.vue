<style scoped>
.wechat {
  width: calc(100% - 40px);
  height: auto;
  padding: 20px;
  background: white;
}
.wechat ul:after {
  display: block;
  clear: both;
  content: "";
  visibility: hidden;
  height: 0;
}
.wechat li {
  float: left;
  margin: 10px 20px 10px 0;
}
.wechat li span {
  margin-right: 5px;
}
.wechat li input {
  outline: none;
  padding: 3px;
  border: 1px solid #ccc;
  border-radius: 5px;
}
.wechat_top {
  border-bottom: 2px solid #cccccc;
  padding-bottom: 15px;
}
.wechat_cent {
  padding: 30px 0;
  border-bottom: 1px solid #ccc;
}
.wechat_cent button {
  outline: none;
  width: 60px;
  height: 25px;
  margin-right: 20px;
  border: none;
  border-radius: 5px;
  color: white;
}
.upload-demo {
  display: inline-block;
  width: 60px;
  height: 25px;
  text-align: center;
  margin-right: 20px;
  border: none;
  border-radius: 5px;
  color: white;
  background: #009788;
}
.chakan {
  background: #f92055;
}
.wechat_botm {
  padding: 15px 0;
}
.wechat_botm button {
  width: 150px;
  height: 40px;
  border: none;
  border-radius: 5px;
}
</style>
<template>
    <div class="wechat">微信端设置
        <div class="wechat_top">
            <ul>
                <li><span>开发者ID:</span><input type="text" style="width: 300px;"></li>
                <li><span>开发者密码:</span><input type="text" style="width: 200px;"></li>
                <li><span>学员微信端域名:</span><input type="text" style="width: 300px;"></li>
                <li style="width: 100%;"><span>员工微信端域名:</span><input type="text" style="width:calc(100% - 185px);"></li>
            </ul>
        </div>
        <div class="wechat_cent">
            <div>
                <ul>
                    <li><span>消耗课时模板ID:</span><input type="text"></li>
                    <li><span>上课提醒模板ID:</span><input type="text"></li>
                </ul>
            </div>
            <div>
                <ul>
                    <li><span>学员微信端LOGO:</span>
                    <el-upload
                        class="upload-demo"
                        action="https://jsonplaceholder.typicode.com/posts/"
                        :on-preview="handlePreview"
                        :on-remove="handleRemove"
                        :before-remove="beforeRemove"
                        multiple
                        :limit="3"
                        :on-exceed="handleExceed"
                        :file-list="fileList">
                        <el-button size="small" type="primary" style="background: #1ab394;">上传</el-button>
                    </el-upload>
                    <button class="chakan">查看</button></li>
                    <li><span>员工微信端LOGO:</span>
                    <el-upload
                        class="upload-demo"
                        action="https://jsonplaceholder.typicode.com/posts/"
                        :on-preview="handlePreview"
                        :on-remove="handleRemove"
                        :before-remove="beforeRemove"
                        multiple
                        :limit="3"
                        :on-exceed="handleExceed"
                        :file-list="fileList">
                        <el-button size="small" type="primary" style="background: #1ab394;">上传</el-button>
                    </el-upload>
                    <button class="chakan">查看</button></li>
                </ul>
            </div>
        </div>
        <div class="wechat_botm">
            <ul>
                <li style="width:100%;"><span>服务器网址:</span><input type="text" style="width:calc(100% - 160px);"></li>
            </ul>
            <div style="margin:20px auto;width: 600px;overflow: hidden;">
                <button style="float: left;background: #009788;color: white;">保存</button>
                <button style="float:right;background: none;border: 1px solid #009788;">取消</button>
            </div>
        </div>
    </div>
</template>
<script>
export default {
  data() {
    return {
      fileList: [
        
      ]
    };
  },
  methods: {
    handleRemove(file, fileList) {
      console.log(file, fileList);
    },
    handlePreview(file) {
      console.log(file);
    },
    handleExceed(files, fileList) {
      this.$message.warning(
        `当前限制选择 3 个文件，本次选择了 ${
          files.length
        } 个文件，共选择了 ${files.length + fileList.length} 个文件`
      );
    },
    beforeRemove(file, fileList) {
      return this.$confirm(`确定移除 ${file.name}？`);
    }
  }
};
</script>