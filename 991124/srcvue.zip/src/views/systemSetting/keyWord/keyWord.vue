<!-- <title>评论关键字维护</title> -->
<style scoped>
.keyWord_head {
  font-size: 25px;
  font-weight: bold;
  text-align: center;
  line-height: 50px;
}
.container {
  width: 1000px;
  height: 350px;
  position: relative;
  margin: 0 auto;
}
.container button {
  width: 60px;
  height: 30px;
  border: 1px solid;
  border-radius: 5px;
  background: none;
  outline: none;
  margin-left: 10px;
}
.panel_body {
  width: 399px;
  height: 300px;
  border: 1px solid;
  margin-top: 10px;
}
.panel_body ul {
  padding: 10px;
  height: 280px;
  overflow-y: auto;
}
</style>
<template>
    <div class="keyWord_wrap">
      <div class="keyWord_head">
        <h3>评论关键字维护</h3>
      </div>
      <div class="container">
        <div style="float: left;width: 400px;height: 350px;">
          <p style="height: 30px;line-height: 30px;pandding: 10px 0;">增加关键字:</p>
          <div class="panel_body">
            <textarea v-model="addKeyword.title" style="resize: none;width: 379px;height: 280px;border: none;padding: 10px;" placeholder="请输入需增加过滤的关键字，并以半角逗号分隔"></textarea>
          </div>
        </div>
        <div style="position: absolute;top:50%;left:50%;margin-left: -30px;"><button type="button" style="margin-left: 0;" :disabled="!addKeyword.title" @click="addKword">>></button></div>
        <div style="float: right;width: 400px;height: 350px;">
          <p style="height: 30px;line-height: 30px;pandding: 10px 0;">自定义已生效关键字: <button type="button" @click="del" style="float: right;">删除</button><button type="button" style="float: right;" :checked="dataListDel.length===dataList.length"
                   @click="allChecked">全选</button></p>
          <div class="panel_body">
            <ul>
              <li v-for="(item,index) in dataList" style="height: 20px;">
                <div class="checkbox">
                  <label>
                    <input type="checkbox" :id="'id'+item.id" :value="item.id" v-model="dataListDel" style="float:left;"> <span style="float:left;line-height: 10px;">{{item.title}}</span>
                  </label>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div class="" style="text-align: center;padding: 10px 0 0;">
        <el-button style="background: #3fa599;color:white;width: 120px;margin-right: 100px;" @click="cancel()">确认</el-button>
        <el-button style="width: 120px;" @click="cancel()">取消</el-button>
      </div>
      {{dataList}}
    </div>
</template>
<script>
export default {
  data() {
    return {
      dataList: [
        { id: 1, title: "HTML5"},
        { id: 2, title: "CSS3"},
        { id: 3, title: "Angular"},
        { id: 4, title: "Vue"},
        { id: 5, title: "Linux" },
        { id: 6, title: "JavaScript"}
      ],
      dataListDel: [],
      addKeyword: 
        {
          id: 1,
          title: ""
        }, //新增关键字
    };
  },
  methods: {
    //新增关键字
    addKword(){
      // if (this.addKeyword.title != "") {
        this.dataList.push({id:this.addKeyword.id,title: this.addKeyword.title});
        this.addKeyword.title=""; 
      /* } else {
        alert("不能为空")
      } */
    },
    // 全选及反选
    allChecked() {
      if (this.dataListDel.length === this.dataList.length) {
        // 全不选
        this.dataListDel = [];
      } else {
        this.dataListDel = [];
        // 全选
        this.dataList.forEach(item => {
          this.dataListDel.push(item.id); // 与checkbox的value统一
        });
      }
    },
    //删除
    del() {
      this.$confirm("此操作将永久删除该文件, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "再想想",
        type: "warning"
      })
        .then(() => {
          this.$message({
            type: "success",
            message: "删除成功"
          });
          var dataList = this.dataList;
          var dataListDel = this.dataListDel;
          /*循环查找选中项*/
          dataListDel.forEach(function(itemDel, index) {
            dataList.forEach(function(itemList, i) {
              if (itemList.id == itemDel) {
                dataList.splice(i, 1);
              }
            });
          });
          this.dataList = dataList;
          this.dataListDel = [];
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除"
          });
        });
    }
  }
};
</script>