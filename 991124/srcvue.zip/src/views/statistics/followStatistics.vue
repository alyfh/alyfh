<!-- <title>关注统计</title> -->
<style scoped>
.worksStatics_query {
  width: 96%;
  padding: 0 15px 15px 15px;
  margin: 15px 0;
  border: 1px solid #ccc;
  overflow: hidden;
}
.worksStatics_query ul li {
  float: left;
  margin-top: 15px;
  padding-right: 5px;
}
.worksStatics_query ul li input {
  outline: none;
  border: none;
  border-bottom: 1px solid #ccc;
  margin-left: 5px;
}
.worksStatics_query ul li button {
  width: 80px;
  height: 25px;
  outline: none;
  background: none;
  border: 1px solid #ccc;
  float: right;
}
</style>
<template>
    <div class="worksStatics">
        <!-- 15657815108 -->
        <div class="worksStatics_query">
            {{query}}
            <ul>
                <li>
                    <span>关注人昵称</span><input type="text" v-model="query.followPeoplName">
                </li>
                <li>
                    <span>关注日期</span>
                    <el-date-picker
                    value-format="yyyy-MM-dd"
                    v-model="query.followStartDate"
                    type="date"
                    placeholder="选择日期"
                    size="mini">
                    </el-date-picker>
                    <span>至</span>
                    <el-date-picker
                    value-format="yyyy-MM-dd"
                    v-model="query.followEndDate"
                    type="date"
                    placeholder="选择日期"
                    size="mini">
                    </el-date-picker>
                </li>
                <li>
                    <span>关注时间</span>
                    <el-time-select
                     v-model="query.followStartTime"
                     :picker-options="{
                        start: '08:30',
                        step: '00:15',
                        end: '18:30'
                     }"
                     placeholder=""
                     size="mini" 
                     style="width: 95px;">
                    </el-time-select>
                    <span>至</span>
                    <el-time-select
                     v-model="query.followEndTime"
                     :picker-options="{
                        start: '08:30',
                        step: '00:15',
                        end: '18:30'
                     }"
                     placeholder=""
                     size="mini" 
                     style="width: 95px;">
                    </el-time-select>
                </li>
                <li>
                    <span>关注状态</span>
                    <el-select v-model="query.followState" placeholder="请选择" size="mini">
                        <el-option
                        v-for="item in followStateOptions"
                        :key="item.followState"
                        :label="item.label"
                        :value="item.followState">
                        </el-option>
                    </el-select>
                </li>
                <li style="float: right;">
                    <button>查询</button>
                </li>
            </ul>
        </div>
        <div class="worksStatics_table" style="padding-bottom: 15px;">
            <el-table
             :data="followStatistics"
             border
             style="width: 70%"
             height="300">
                <el-table-column
                prop="serialNumber"
                label="序号"
                width="100"
                align="center">
                </el-table-column>
                <el-table-column
                prop="followDate"
                label="关注日期"
                width="140"
                align="center">
                </el-table-column>
                <el-table-column
                prop="followTime"
                label="关注时间"
                width="140"
                align="center">
                </el-table-column>
                <el-table-column
                prop="followPeoplID"
                label="关注人ID"
                width="160"
                align="center">
                </el-table-column>
                <el-table-column
                prop="followPeoplName"
                label="关注人昵称"
                width="140"
                align="center">
                </el-table-column>
                <el-table-column
                prop="followState"
                label="关注状态"
                width="141"
                align="center">
                </el-table-column>
            </el-table>
        </div>
    </div>
</template>
<script>
export default {
  data() {
    return {
      followStateOptions: [
        {
          lable: "关注",
          followState: "关注"
        }
      ],
      query: {},  //查询条件
      followStatistics: [
        {
          serialNumber: "1", //序号
          followDate: "2018-12-10", //关注日期
          followTime: "14:52", //关注时间
          followPeoplID: "1", //关注人ID
          followPeoplName: "零", //关注人昵称
          followState: "关注" //关注状态
        },
        {
          serialNumber: "2", //序号
          followDate: "2018-12-10", //关注日期
          followTime: "14:52", //关注时间
          followPeoplID: "2", //关注人ID
          followPeoplName: "零", //关注人昵称
          followState: "关注" //关注状态
        }
      ]
    };
  }
};
</script>