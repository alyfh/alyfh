<!-- <title>作品统计</title> -->
<style scoped>
.worksStatics_query {
  width: 96%;
  padding: 0 15px 15px 15px;
  margin: 15px 0;
  border: 1px solid #ccc;
  overflow: hidden;
}
.worksStatics_query ul li {
  float: left;
  height: 30px;
  margin-top: 15px;
  padding-right: 5px;
}
.worksStatics_query ul li input {
  outline: none;
  width: 150px;
  border: none;
  border-bottom: 1px solid #ccc;
  margin-left: 5px;
  padding-top: 6px;
}
.worksStatics_query ul li button {
  width: 80px;
  height: 25px;
  outline: none;
  background: none;
  border: 1px solid #ccc;
  float: right;
}
</style>
<template>
    <div class="worksStatics">
        <!-- 15657815108 -->
        <div class="worksStatics_query">
            {{query }}
            <ul>
                <li>{{query .activityNumber}}
                    <span>活动编号</span><input type="text" v-model="query .activityNumber">
                </li>
                <li>
                    <span>活动分类</span>{{query .activityClass}}
                    <el-select v-model="query .activityClass" placeholder="请选择" size="mini">
                        <el-option
                        v-for="item in activityOptions"
                        :key="item.activityClass"
                        :label="item.label"
                        :value="item.activityClass">
                        </el-option>
                    </el-select>
                </li>
                <li>
                    <span>活动名</span><input type="text" v-model="query .activityName">
                </li>
                <li>
                    <span>作品分类</span>
                    <el-select v-model="query .worksClass" placeholder="请选择" size="mini">
                        <el-option
                        v-for="item in worksOptions"
                        :key="item.worksClass"
                        :label="item.label"
                        :value="item.worksClass">
                        </el-option>
                    </el-select>
                </li>
                <li>
                    <span>作品号</span><input type="text" v-model="query .worksNumber">
                </li>
                <li>
                    <span>作品名</span><input type="text" v-model="query .worksName">
                </li>
                <li>
                    <span>作者</span><input type="text" v-model="query .author">
                </li>
                <li>
                    <span>推荐校区</span>
                    <el-select v-model="query .tjCampus" placeholder="请选择" size="mini">
                        <el-option
                        v-for="item in tjCampusOptions"
                        :key="item.tjCampus"
                        :label="item.label"
                        :value="item.tjCampus">
                        </el-option>
                    </el-select>
                </li>
                <li>
                    <span>指导教师</span>
                    <el-select v-model="query .guidanceTeacher" placeholder="请选择" size="mini">
                        <el-option
                        v-for="item in teacherOptions"
                        :key="item.guidanceTeacher"
                        :label="item.label"
                        :value="item.guidanceTeacher">
                        </el-option>
                    </el-select>
                </li>
                <li style="float: right;">
                    <button>查询</button>
                </li>
            </ul>
        </div>
        <div class="worksStatics_table" style="padding-bottom: 15px;">
            <el-table
             :data="worksStatics"
             border
             style="width: 90%"
             height="300">
                <el-table-column
                prop="activityID"
                label="活动ID"
                width="65"
                align="center">
                </el-table-column>
                <el-table-column
                prop="activityNumber"
                label="活动编号"
                width="80"
                align="center">
                </el-table-column>
                <el-table-column
                prop="activityClass"
                label="活动分类"
                width="80"
                align="center">
                </el-table-column>
                <el-table-column
                prop="activityName"
                label="活动名"
                width="126"
                align="center">
                </el-table-column>
                <el-table-column
                prop="worksClass"
                label="作品分类"
                width="80"
                align="center">
                </el-table-column>
                <el-table-column
                prop="worksNumber"
                label="作品号"
                width="65"
                align="center">
                </el-table-column>
                <el-table-column
                prop="worksName"
                label="作品名"
                width="140"
                align="center">
                </el-table-column>
                <el-table-column
                prop="tjCampus"
                label="推荐校区"
                width="160"
                align="center">
                </el-table-column>
                <el-table-column
                prop="guidanceTeacher"
                label="指导教师"
                width="80"
                align="center">
                </el-table-column>
                <el-table-column
                prop="submiPeopl"
                label="提交人"
                width="80"
                align="center">
                </el-table-column>
                <el-table-column
                prop="submiDate"
                label="提交日期"
                width="100"
                align="center">
                </el-table-column>
            </el-table>
        </div>
    </div>
</template>
<script>
export default {
  data() {
    return {
      activityOptions: [
        {
          label: "音乐",
          activityClass: "音乐"
        },
        {
          label: "美术",
          activityClass: "美术"
        }
      ],
      worksOptions: [
        {
          label: "舞蹈",
          worksClass: "舞蹈"
        }
      ],
      tjCampusOptions: [
        {
          label: "本学",
          tjCampus: "本学"
        }
      ],
      teacherOptions: [
        {
          label: "零",
          guidanceTeacher: "零"
        }
      ],
      query: {}, //查询条件
      worksStatics: [
        {
          activityID: "1", //活动ID
          activityNumber: "001", //活动编号
          activityClass: "", //活动分类
          activityName: "音乐", //活动名
          worksClass: "音乐", //作品分类
          worksNumber: "1", //作品号
          worksName: "曲谱", //作品名
          tjCampus: "本学", //推荐校区
          guidanceTeacher: "零", //指导教师
          submiPeopl: "零", //提交人
          submiDate: "2018-12-07", //提交时间
          author: "" //作者
        }
      ]
    };
  }
};
</script>