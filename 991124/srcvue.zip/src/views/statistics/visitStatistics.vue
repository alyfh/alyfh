<!-- <title>访问统计</title> -->
<style scoped>
.worksStatics_query {
  width: 96%;
  padding: 0 15px 15px 15px;
  margin: 15px 0;
  border: 1px solid #ccc;
  overflow: hidden;
}
.worksStatics_query ul li {
  float: left;
  margin-top: 15px;
  padding-right: 5px;
}
.worksStatics_query ul li input {
  outline: none;
  border: none;
  border-bottom: 1px solid #ccc;
  margin-left: 5px;
}
.worksStatics_query ul li button {
  width: 80px;
  height: 25px;
  outline: none;
  background: none;
  border: 1px solid #ccc;
  float: right;
}
</style>
<template>
    <div class="worksStatics">
        <!-- 15657815108 -->
        <div class="worksStatics_query">
            {{query}}
            <ul>
                <li>
                    <span>作品号</span><input type="text" v-model="query.worksNumber">
                </li>
                <li>
                    <span>作品名</span><input type="text" v-model="query.worksName">
                </li>
                <li>
                    <span>作者</span><input type="text" v-model="query.author">
                </li>
                <li>
                    <span>访问人昵称</span><input type="text" v-model="query.visitPeoplName">
                </li>
                <li>
                    <span>访问日期</span>
                    <el-date-picker
                    value-format="yyyy-MM-dd"
                    v-model="query.visitStartDate"
                    type="date"
                    placeholder="选择日期"
                    size="mini">
                    </el-date-picker>
                    <span>至</span>
                    <el-date-picker
                    value-format="yyyy-MM-dd"
                    v-model="query.visitEndDate"
                    type="date"
                    placeholder="选择日期"
                    size="mini">
                    </el-date-picker>
                </li>
                <li>
                    <span>访问时间</span>
                    <el-time-select
                     v-model="query.visitStartTime"
                     :picker-options="{
                        start: '08:30',
                        step: '00:15',
                        end: '18:30'
                     }"
                     placeholder=""
                     size="mini" 
                     style="width: 95px;">
                    </el-time-select>
                    <span>至</span>
                    <el-time-select
                     v-model="query.visitEndTime"
                     :picker-options="{
                        start: '08:30',
                        step: '00:15',
                        end: '18:30'
                     }"
                     placeholder=""
                     size="mini" 
                     style="width: 95px;">
                    </el-time-select>
                </li>
                <li style="float: right;">
                    <button>查询</button>
                </li>
            </ul>
        </div>
        <div class="worksStatics_table" style="padding-bottom: 15px;">
            <el-table
             :data="visitStatistics"
             border
             style="width: 90%"
             height="300">
                <el-table-column
                prop="worksID"
                label="作品ID"
                width="110"
                align="center">
                </el-table-column>
                <el-table-column
                prop="worksNumber"
                label="作品号"
                width="106"
                align="center">
                </el-table-column>
                <el-table-column
                prop="worksName"
                label="作品名"
                width="160"
                align="center">
                </el-table-column>
                <el-table-column
                prop="author"
                label="作者"
                width="160"
                align="center">
                </el-table-column>
                <el-table-column
                prop="visitPeoplID"
                label="访问人ID"
                width="100"
                align="center">
                </el-table-column>
                <el-table-column
                prop="visitPeoplName"
                label="访问人昵称"
                width="140"
                align="center">
                </el-table-column>
                <el-table-column
                prop="visitDate"
                label="访问日期"
                width="140"
                align="center">
                </el-table-column>
                <el-table-column
                prop="visitTime"
                label="访问时间"
                width="140"
                align="center">
                </el-table-column>
            </el-table>
        </div>
    </div>
</template>
<script>
export default {
  data() {
    return {
      query: {}, //查询条件
      visitStatistics: [
        {
          worksID: "1", //作品ID
          worksNumber: "1", //作品号
          worksName: "琴谱", //作品名
          author: "零", //作者
          visitPeoplID: "1", //访问人ID
          visitPeoplName: "零", //访问人昵称
          visitDate: "2015-12-10", //访问日期
          visitTime: "15:44" //访问时间
        }
      ]
    };
  }
};
</script>