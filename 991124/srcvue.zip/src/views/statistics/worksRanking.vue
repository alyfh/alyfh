<!-- <title>作品排行</title> -->
<style scoped>
.worksStatics_query {
  width: 96%;
  padding: 0 15px 15px 15px;
  margin: 15px 0;
  border: 1px solid #ccc;
  overflow: hidden;
}
.worksStatics_query ul li {
  float: left;
  margin-top: 15px;
  height: 30px;
  padding-right: 5px;
}
.worksStatics_query ul li input {
  outline: none;
  width: 140px;
  border: none;
  border-bottom: 1px solid #ccc;
  margin-left: 5px;
  padding-top: 6px;
}
.worksStatics_query ul li button {
  width: 80px;
  height: 25px;
  outline: none;
  background: none;
  border: 1px solid #ccc;
  float: right;
}
</style>
<template>
    <div class="worksStatics">
        <!-- 15657815108 -->
        <div class="worksStatics_query">
            {{query}}
            <ul>
                <li>
                    <span>活动编号</span><input type="text" v-model="query.activityNumber">
                </li>
                <li>
                    <span>活动分类</span>
                    <el-select v-model="query.activityClass" placeholder="请选择" size="mini">
                        <el-option
                        v-for="item in activityOptions"
                        :key="item.activityClass"
                        :label="item.label"
                        :value="item.activityClass">
                        </el-option>
                    </el-select>
                </li>
                <li>
                    <span>活动名</span><input type="text" v-model="query.activityName">
                </li>
                <li>
                    <span>作品分类</span>
                    <el-select v-model="query.worksClass" placeholder="请选择" size="mini">
                        <el-option
                        v-for="item in worksOptions"
                        :key="item.worksClass"
                        :label="item.label"
                        :value="item.worksClass">
                        </el-option>
                    </el-select>
                </li>
                <li>
                    <span>作品号</span><input type="text" v-model="query.worksNumber">
                </li>
                <li>
                    <span>作品名</span><input type="text" v-model="query.worksName">
                </li>
                <li>
                    <span>作者</span><input type="text" v-model="query.author">
                </li>
                <li>
                    <input type="text" style="width: 80px;">
                    <el-select v-model="query.voteNumberMin" placeholder="请选择" size="mini" style="width: 90px;">
                        <el-option
                        v-for="item in voteOptionsMin"
                        :key="item.voteNumberMin"
                        :label="item.label"
                        :value="item.voteNumberMin">
                        </el-option>
                    </el-select>
                    <span>投票数</span>
                    <el-select v-model="query.voteNumberMax" placeholder="请选择" size="mini" style="width: 90px;">
                        <el-option
                        v-for="item in voteOptionsMax"
                        :key="item.voteNumberMax"
                        :label="item.label"
                        :value="item.voteNumberMax">
                        </el-option>
                    </el-select>
                    <input type="text" style="width: 80px;">
                </li>
                <li>
                    <input type="text" style="width: 80px;">
                    <el-select v-model="query.rankingMin" placeholder="请选择" size="mini" style="width: 90px;">
                        <el-option
                        v-for="item in rankingOptionsMin"
                        :key="item.rankingMin"
                        :label="item.label"
                        :value="item.rankingMin">
                        </el-option>
                    </el-select>
                    <span>排行名次</span>
                    <el-select v-model="query.rankingMax" placeholder="请选择" size="mini" style="width: 90px;">
                        <el-option
                        v-for="item in rankingOptionsMax"
                        :key="item.rankingMax"
                        :label="item.label"
                        :value="item.rankingMax">
                        </el-option>
                    </el-select>
                    <input type="text" style="width: 80px;">
                </li>
                <li style="float: right;">
                    <button>查询</button>
                </li>
            </ul>
        </div>
        <div class="worksStatics_table" style="padding-bottom: 15px;">
            <el-table
             :data="worksRanking"
             border
             style="width: 90%"
             height="260">
                <el-table-column
                prop="activityNumber"
                label="活动编号"
                width="100"
                align="center">
                </el-table-column>
                <el-table-column
                prop="activityClass"
                label="活动分类"
                width="120"
                align="center">
                </el-table-column>
                <el-table-column
                prop="activityName"
                label="活动名"
                width="160"
                align="center">
                </el-table-column>
                <el-table-column
                prop="worksClass"
                label="作品分类"
                width="160"
                align="center">
                </el-table-column>
                <el-table-column
                prop="worksNumber"
                label="作品号"
                width="100"
                align="center">
                </el-table-column>
                <el-table-column
                prop="worksName"
                label="作品名"
                width="120"
                align="center">
                </el-table-column>
                <el-table-column
                prop="author"
                label="作者"
                width="120"
                align="center">
                </el-table-column>
                <el-table-column
                prop="voteNumber"
                label="投票数"
                width="96"
                align="center">
                </el-table-column>
                <el-table-column
                prop="ranking"
                label="排行名次"
                width="80"
                align="center">
                </el-table-column>
            </el-table>
        </div>
    </div>
</template>
<script>
export default {
  data() {
    return {
      activityOptions: [
        {
          lable: "音乐",
          activityClass: "音乐"
        },
        {
          lable: "跳舞",
          activityClass: "跳舞"
        }
      ],
      worksOptions: [
        {
          lable: "琴谱",
          worksClass: "琴谱"
        },
        {
          lable: "箫谱",
          worksClass: "箫谱"
        }
      ],
      voteOptionsMin: [
        {
          lable: "<",
          voteNumberMin: "<"
        },
        {
          lable: "=",
          voteNumberMin: "="
        }
      ],
      voteOptionsMax: [
        {
          lable: "<",
          voteNumberMax: "<"
        },
        {
          lable: "=",
          voteNumberMax: "="
        }
      ],
      rankingOptionsMin: [
        {
          lable: "<",
          rankingMin: "<"
        },
        {
          lable: "=",
          rankingMin: "="
        }
      ],
      rankingOptionsMax: [
        {
          lable: "<",
          rankingMax: "<="
        },
        {
          lable: "=",
          rankingMax: "="
        }
      ],
      query: {}, //查询条件
      worksRanking: [
          {
              activityNumber: "1",  //活动号
              activityClass: "音乐",  //活动分类
              activityName: "音乐",  //活动名
              worksClass: "琴谱",  //作品分类
              worksNumber: "1",  //作品号
              worksName: "琴谱",  //作品名
              author: "零",  //作者
              voteNumber: "111",  //投票数
              ranking: "1"   //排行名次
          }
        ]
    };
  }
};
</script>