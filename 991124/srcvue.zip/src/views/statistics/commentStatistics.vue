<!-- <title>评论统计</title> -->
<style scoped>
.worksStatics_query {
  width: 96%;
  padding: 0 15px 15px 15px;
  margin: 15px 0;
  border: 1px solid #ccc;
  overflow: hidden;
}
.worksStatics_query ul li {
  float: left;
  margin-top: 15px;
  padding-right: 5px;
}
.worksStatics_query ul li input {
  outline: none;
  border: none;
  border-bottom: 1px solid #ccc;
  margin-left: 5px;
}
.worksStatics_query ul li button {
  width: 80px;
  height: 25px;
  outline: none;
  background: none;
  border: 1px solid #ccc;
  float: right;
}
</style>
<template>
    <div class="worksStatics">
        <!-- 15657815108 -->
        <div class="worksStatics_query">
            {{query}}
            <ul>
                <li>
                    <span>作品号</span><input type="text" v-model="query.worksNumber">
                </li>
                <li>
                    <span>作品名</span><input type="text" v-model="query.worksName">
                </li>
                <li>
                    <span>作者</span><input type="text" v-model="query.author">
                </li>
                <li>
                    <span>评论人昵称</span><input type="text" v-model="query.commentPeoplName">
                </li>
                <li>
                    <span>显示状态</span>
                    <el-select v-model="query.state" placeholder="请选择" size="mini" style="width: 150px;">
                        <el-option
                        v-for="item in stateOptions"
                        :key="item.state"
                        :label="item.label"
                        :value="item.state">
                        </el-option>
                    </el-select>
                </li>
                <li>
                    <span>评论日期</span>
                    <el-date-picker
                    value-format="yyyy-MM-dd"
                    v-model="query.commentStartDate"
                    type="date"
                    placeholder="选择日期"
                    size="mini"
                    style="width: 150px;">
                    </el-date-picker>
                    <span>至</span>
                    <el-date-picker
                    value-format="yyyy-MM-dd"
                    v-model="query.commentEndDate"
                    type="date"
                    placeholder="选择日期"
                    size="mini"
                    style="width: 150px;">
                    </el-date-picker>
                </li>
                <li>
                    <span>评论时间</span>
                    <el-time-select
                     v-model="query.commentStartTime"
                     :picker-options="{
                        start: '08:30',
                        step: '00:15',
                        end: '18:30'
                     }"
                     placeholder=""
                     size="mini" 
                     style="width: 95px;">
                    </el-time-select>
                    <span>至</span>
                    <el-time-select
                     v-model="query.commentEndTime"
                     :picker-options="{
                        start: '08:30',
                        step: '00:15',
                        end: '18:30'
                     }"
                     placeholder=""
                     size="mini" 
                     style="width: 95px;">
                    </el-time-select>
                </li>
                <li style="float: right;">
                    <button>查询</button>
                </li>
            </ul>
        </div>
        <div class="worksStatics_table" style="padding-bottom: 15px;">
            <el-table
             :data="tableData"
             border
             style="width: 90%"
             height="300">
                <el-table-column
                prop="worksID"
                label="作品ID"
                width="80"
                align="center">
                </el-table-column>
                <el-table-column
                prop="worksNumber"
                label="作品号"
                width="70"
                align="center">
                </el-table-column>
                <el-table-column
                prop="worksName"
                label="作品名"
                width="130"
                align="center">
                </el-table-column>
                <el-table-column
                prop="author"
                label="作者"
                width="100"
                align="center">
                </el-table-column>
                <el-table-column
                prop="commentPeoplID"
                label="评论人ID"
                width="80"
                align="center">
                </el-table-column>
                <el-table-column
                prop="commentPeoplName"
                label="评论人昵称"
                width="100"
                align="center">
                </el-table-column>
                <el-table-column
                prop="commentDate"
                label="评论日期"
                width="120"
                align="center">
                </el-table-column>
                <el-table-column
                prop="commentTime"
                label="评论时间"
                width="120"
                align="center">
                </el-table-column>
                <el-table-column
                prop="commentContent"
                label="评论内容"
                width="176"
                align="center">
                </el-table-column>
                <el-table-column
                prop="state"
                label="显示状态"
                width="80"
                align="center">
                </el-table-column>
            </el-table>
        </div>
    </div>
</template>
<script>
export default {
  data() {
    return {
      stateOptions: [
        {
          lable: "显示",
          state: "显示"
        },
        {
          lable: "隐藏",
          state: "隐藏"
        }
      ],
      query: {},
      tableData: [
          {
              worksID: "1",  //作品ID
              worksNumber: "1",  //作品号
              worksName: "琴谱",  //作品名
              author: "零",  //作者
              commentPeoplID: "1",  //评论人ID
              commentPeoplName: "零",  //评论人
              commentDate: "2018-12-10",  //评论日期
              commentTime: "17:14",  //评论时间
              commentContent: "lanlanlanlan",  //评论内容
              state: "显示"  //显示状态
          }
          ]
    };
  }
};
</script>