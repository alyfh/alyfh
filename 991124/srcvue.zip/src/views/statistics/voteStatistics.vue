<!-- <title>投票统计</title> -->
<style scoped>
.worksStatics_query {
  width: 96%;
  padding: 0 15px 15px 15px;
  margin: 15px 0;
  border: 1px solid #ccc;
  overflow: hidden;
}
.worksStatics_query ul li {
  float: left;
  margin-top: 15px;
  padding-right: 5px;
}
.worksStatics_query ul li input {
  outline: none;
  border: none;
  border-bottom: 1px solid #ccc;
  margin-left: 5px;
}
.worksStatics_query ul li button {
  width: 80px;
  height: 25px;
  outline: none;
  background: none;
  border: 1px solid #ccc;
  float: right;
}
</style>
<template>
    <div class="worksStatics">
        <!-- 15657815108 -->
        <div class="worksStatics_query">
            {{query}}
            <ul>
                <li>
                    <span>作品号</span><input type="text" v-model="query.worksNumber">
                </li>
                <li>
                    <span>作品名</span><input type="text" v-model="query.worksName">
                </li>
                <li>
                    <span>投票日期</span>
                    <el-date-picker
                    value-format="yyyy-MM-dd"
                    v-model="query.voteStartDate"
                    type="date"
                    placeholder="选择日期"
                    size="mini">
                    </el-date-picker>
                    <span>至</span>
                    <el-date-picker
                    value-format="yyyy-MM-dd"
                    v-model="query.voteEndDate"
                    type="date"
                    placeholder="选择日期"
                    size="mini">
                    </el-date-picker>
                </li>
                <li>
                    <span>投票时间</span>
                    <el-time-select
                     v-model="query.voteStartTime"
                     :picker-options="{
                        start: '08:30',
                        step: '00:15',
                        end: '18:30'
                     }"
                     placeholder=""
                     size="mini" 
                     style="width: 95px;">
                    </el-time-select>
                    <span>至</span>
                    <el-time-select
                     v-model="query.voteEndTime"
                     :picker-options="{
                        start: '08:30',
                        step: '00:15',
                        end: '18:30'
                     }"
                     placeholder=""
                     size="mini" 
                     style="width: 95px;">
                    </el-time-select>
                </li>
                <li>
                    <span>投票人昵称</span><input type="text" v-model="query.commentatorName">
                </li>
                <li style="float: right;">
                    <button>查询</button>
                </li>
            </ul>
        </div>
        <div class="worksStatics_table" style="padding-bottom: 15px;">
            <el-table
             :data="voteStatistics.filter(data => !query.worksNumber || data.worksNumber.toLowerCase().includes(query.worksNumber.toLowerCase()))"
             border
             style="width: 90%"
             height="300">
                <el-table-column
                prop="worksID"
                label="作品ID"
                width="100"
                align="center">
                </el-table-column>
                <el-table-column
                prop="worksNumber"
                label="作品号"
                width="100"
                align="center">
                </el-table-column>
                <el-table-column
                prop="worksName"
                label="作品名"
                width="180"
                align="center">
                </el-table-column>
                <el-table-column
                prop="voteDate"
                label="投票日期"
                width="160"
                align="center">
                </el-table-column>
                <el-table-column
                prop="voteTime"
                label="投票时间"
                width="160"
                align="center">
                </el-table-column>
                <el-table-column
                prop="votePeoplID"
                label="投票人ID"
                width="120"
                align="center">
                </el-table-column>
                <el-table-column
                prop="votePeoplName"
                label="投票人昵称"
                width="120"
                align="center">
                </el-table-column>
                <el-table-column
                prop="voteNumber"
                label="投票数"
                width="116"
                align="center">
                </el-table-column>
            </el-table>
        </div>
    </div>
</template>
<script>
export default {
  data() {
    return {
      query: {},  //查询条件
      voteStatistics: [
        {   
            worksID: "1",  //作品ID
            worksNumber: "1",  //作品号
            worksName: "曲谱",  //作品名
            voteDate: "2018-12-10",  //投票日期
            voteTime: "10:10",  //投票时间
            votePeoplID: "1",  //投票人ID
            votePeoplName: "零",  //投票人昵称
            voteNumber: "1"  //投票数
        },
        {   
            worksID: "2",  //作品ID
            worksNumber: "2",  //作品号
            worksName: "曲谱",  //作品名
            voteDate: "2018-12-10",  //投票日期
            voteTime: "10:10",  //投票时间
            votePeoplID: "2",  //投票人ID
            votePeoplName: "零",  //投票人昵称
            voteNumber: "2"  //投票数
        }
      ]
      
    };
  },
  methods:{
      
  }
};
</script>