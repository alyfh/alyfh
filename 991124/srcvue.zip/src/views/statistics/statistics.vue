<!-- <title>投票统计分析</title> -->
<style scoped>
.statistics {
  width: calc(100% - 40px);
  height: auto;
  padding: 0 20px;
  background: white;
}
.statistics_tabs a{
    text-decoration: none;
    color: black;
    display: inline-block;
    width: 100px;
    height: 40px;
    text-align: center;
    line-height: 40px;
    border: 1px solid #ccc;
}
.router-link-active{
  background: #ccc;
}
</style>
<template>
    <div class="statistics">
        <div class="">
            <step></step>
        </div>
        <div class="statistics_mian">
            <div class="statistics_mian_top">
                <div class="statistics_tabs">
                    <router-link v-for="(i,index) in navLists" :to="i.path" :key="index">{{i.text}}</router-link>
                </div>
            </div>
            <router-view></router-view>
        </div>
    </div>
</template>
<script>
import step from "../marketing/step";
export default {
  components: {
    step
  },
  data() {
    return {
      navLists: [
        {
          path: "/tongjibaobiao/toupiaotongjifenxi/zuopintongji",
          text: "作品统计"
        },
        {
          path: "/tongjibaobiao/toupiaotongjifenxi/toupiaotongji",
          text: "投票统计"
        },
        {
          path: '/tongjibaobiao/toupiaotongjifenxi/zuopinpaihang',
          text: "作品排行"
        },
        {
          path: '/tongjibaobiao/toupiaotongjifenxi/guanzhutongji',
          text: "关注统计"
        },
        {
          path: '/tongjibaobiao/toupiaotongjifenxi/fangwentongji',
          text: "访问统计"
        },
        {
          path: '/tongjibaobiao/toupiaotongjifenxi/pingluntongji',
          text: "评论统计"
        } 
      ]
    };
  },
  created() {
      this.xspath()
  },
  methods: {
    xspath(){
        this.$router.push("/tongjibaobiao/toupiaotongjifenxi/zuopintongji")
    }
  }
};
</script>