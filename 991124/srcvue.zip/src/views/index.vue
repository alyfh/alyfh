<style scoped>
	#ue_p_html {
		height: 100%
	}

	.p_container_l {
		width: 100%;
		height: 100%;
	}
  .login_name{
    padding: 0px 5px;
    height: 100%;
    float: right;
    line-height: 50px;
    font-weight: bolder;
    color: #393d49;
    font-size: 0.9rem;
  }
	/**
	#left_icon_1 {
		background-image: url('../assets/img/user.png');
	}

	#left_icon_2 {
		background-image: url('../assets/img/set.png');
	}

	#left_icon_3 {
		background-image: url('../assets/img/stu.png');
	}

	#left_icon_4 {
		background-image: url('../assets/img/class.png');
	}
	**/

	.p_left_user_img {
		background-image: url('../assets/img/tx.jpg');
	}
</style>
<template>
	<section class="p_container_l">
		<div class="p_container_l_left">
			<h1 class="p_mian_l_logo"></h1>
			<div class="p_container_l_left_over" v-show="leftMenuShow">

				<ul v-for="(route, index) in activeMenu.children">
					<template v-if="route.children">
						<li class="p_left_nav_sec" @click="reflushLeftNav($event)">
							<span class="p_mian_l_icon " :style="getImg(route)"></span> {{route.name}}
							<span class="p_mian_l_j"></span>
						</li>
						<li>
							<ul>
								<li class="p_left_nav_h" v-for="(cRoute, cIndex) in route.children">
									<router-link :to="{path:activeMenu.path+'/'+route.path+'/'+cRoute.path}">{{cRoute.name}}</router-link>
								</li>

							</ul>
						</li>

					</template>
					<template v-else>
						<li class="p_left_nav_sec">
							<span class="p_mian_l_icon " :style="getImg(route)"></span>
							<router-link :to="{path:activeMenu.path+'/'+route.path}">{{route.name}}</router-link>
							<!--span class="p_mian_l_j"></span-->
						</li>

					</template>

				</ul>

				<!--ul>
					<li class="p_left_nav_sec">
						<span class="p_mian_l_icon " id="left_icon_2"></span>
						系统设置
						<span class="p_mian_l_j"></span>
					</li>
					<li>
						<ul>
							<li class="p_left_nav_h">课程管理</li>
							<li class="p_left_nav_h">教室管理</li>
							<li class="p_left_nav_h">教师管理</li>
							<li class="p_left_nav_h">会员卡</li>
						</ul>
					</li>
				</ul>
				<ul>
					<li class="p_left_nav_sec" id="ue_temp_nav_fir">
						<span class="p_mian_l_icon" id="left_icon_3"></span>
						班级管理
						<span class="p_mian_l_j"></span>
					</li>
					<li>
						<ul>
							<li class="p_left_nav_h">新增班级</li>
							<li class="p_left_nav_h">班型设置</li>
						</ul>
					</li>
				</ul>
				<ul>
					<li class="p_left_nav_sec">
						<span class="p_mian_l_icon " id="left_icon_4"></span>
						教学管理
						<span class="p_mian_l_j"></span>
					</li>
					<li>
						<ul>
							<li class="p_left_nav_h">校区课表</li>
							<li class="p_left_nav_h">教室课表</li>
							<li class="p_left_nav_h">学员课表</li>
						</ul>
					</li>
				</ul-->
			</div>
			<div class="p_container_l_left_over2" v-show="!leftMenuShow">
				<div class="p_left_user_img"></div>
				<ul class="p_left_user_info">
					<!--li>黄埔校区</li-->
					<li>{{loginInfo.realName}}</li>
					<!--li>系统管理员</li-->
				</ul>
			</div>
		</div>
		<div class="p_container_l_right">
			<header>
				<div class="p_right_nav2">
					<nav>
						<li @click="reflushMenu('index')">首页</li>
						<template v-for="(route, index) in menus">
							<li @click="reflushMenu(route.path)">
								<a>{{route.meta.name || route.name}}</a>
							</li>
						</template>

						<!--li id="ue_temp">教务管理</li>
						<li>人事管理</li>
						<li>财务管理</li>
						<li>进销存管理</li>
						<li>营销管理</li>
						<li>OA</li>
						<li>统计报表</li>
						<li >系统设置</li-->
					</nav>

					<div class="p_right_nav2_btn">
						<ul>
							<!--li>个人资料</li-->
							<li @click="modpwd">修改密码</li>
							<!--li>我的消息</li-->
							<li @click="logout">注销</li>
						</ul>
					</div>
          <div class="login_name">当前用户：{{loginInfo.realName}}</div>
				</div>
				<ul class="p_right_nav1">
					<li v-for="(item,index) in breadcrumbs"> {{ item.meta.name || item.name }}></li>
				</ul>
			</header>
			<div class="p_container_l_right_over">
				<div class="p_load_container">
					<template v-if="$route.path=='/'">
						<dashboard />
					</template>
					<template v-else>
						<router-view id="main"></router-view>
					</template>

				</div>
			</div>
		</div>
		<!-- 弹窗遮罩 -->
		<div class="big_hiddenBakground" v-show="layerShow"></div>
	</section>

</template>
<script>
	import instance from "../api";
	import { changePw } from "../api/account";
	import { mapState } from 'vuex';
	import * as util from '../assets/util.js';
	export default {
		components: {
			dashboard: () =>
				import("../components/dashboard.vue")
		},
		data() {
			return {
				user: {}, //用户菜单
				loginInfo: {}, //用户信息
				activeMenuName: "",
				activeMenu: {},
				leftMenuShow: false,
				menus: [], //用户菜单路由
				breadcrumbs: []
			};
		},
		computed: {
			// Getting Vuex State from store/index
			...mapState({
				layerShow: state => state.layerShow
			})
		},
		watch: {
			$route: function(to, from) {
				this.activeMenuName = this.$route.name;
				this.breadcrumbs = (this.$route && this.$route.matched) || [];
			}
		},
		methods: {
			logout: function() {
				this.$confirm("确定退出?", "提示", {
						confirmButtonText: "确定",
						cancelButtonText: "取消",
						type: "info"
					})
					.then(() => {
						this.$emit("logout");
					})
					.catch(() => {});
			},
			reflushMenu: function(index) {
				let activeMenu = {};
				if(index == 'index') {
					this.leftMenuShow = false;
					activeMenu = {};
					this.$router.push("/"); //首页

				} else {
					this.leftMenuShow = true;
					this.menus.forEach(function(route) {
						if(route.path == index) {
							activeMenu = route;
						}
					});

				}
				this.activeMenu = activeMenu;
			},
			//左侧二级菜单显示隐藏菜单
			reflushLeftNav: function(event) { //console.info(event);
				$('.p_container_l_left_over>ul>li:nth-child(1)').next().slideUp();
				if($(event.target).next().css('display') == 'none') {
					$(event.target).next().slideDown();
				} else {
					$(event.target).next().slideUp();
				};
			},
			getImg: function(route) {
				if(route.meta.icon)
					return "background-image: url('../../static/img/" + route.meta.icon + "')";
				else
					return "background-image: url('../../static/img/user.png')";
			},
			modpwd:function(route){ //修改密码
				this.$router.push("/xiugaimima/xiugaimima");
			}
		},
		created: function() {
			let user = this.$parent.userData;
			if(user) {
				this.user = user;
				this.activeMenuName = this.$route.name;
				this.breadcrumbs = (this.$route && this.$route.matched) || [];
			} else {
				this.$router.push({
					path: "/login"
				});
			}
			let menus = this.$parent.menuData;
			if(menus) {
				this.menus = menus;
			}
			if(util.session('loginInfo'))
				this.loginInfo = util.session('loginInfo').login;
		},
		mounted: function() {
			// MetisMenu
			/*  $('#side-menu').metisMenu();
	    // Minimalize menu
    $('.navbar-minimalize').on('click', function (event) {
        event.preventDefault();
        $("body").toggleClass("mini-navbar");
        SmoothlyMenu();

    });
	*/
			//document.getElementsByTagName("body")[0].style.backgroundColor="#2f4050";
			document.getElementsByTagName("html")[0].style.height = "100%";
			//右侧菜单样式切换
			$('.p_right_nav2>nav>li').click(function(event) {
				$('.p_right_nav2>nav>li').removeClass('p_right_nav2_active');
				$(this).addClass('p_right_nav2_active');
			});
			//右侧设置按钮菜单显示隐藏
			$(".p_right_nav2_btn").mouseover(function(event) {
				$(this).find('ul').removeClass('p_right_nav2_btn_show');
			});
			$(".p_right_nav2_btn>ul>li").click(function(event) {
				$(this).parent().addClass('p_right_nav2_btn_show');
			});
			//左侧二级菜单显示隐藏菜单
			$('.p_container_l_left_over>ul>li:nth-child(1)').click(function(event) {
				$('.p_container_l_left_over>ul>li:nth-child(1)').next().slideUp();
				if($(this).next().css('display') == 'none') {
					$(this).next().slideDown();
				} else {
					$(this).next().slideUp();
				};
			});
		}

	};
</script>
