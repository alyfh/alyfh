<style scoped>
	.p_container_l {
		padding-top: 1px;
	}

	.p_container_login_main {
		width: 360px;
		margin: auto;
		margin-top: 140px;
	}

	.p_login_img {
		width: 100%;
		margin-bottom: 30px
	}

	.p_login_img>img {
		margin-left: 36.5px;
	}

	.p_btn_col_1:hover {
		background-color: #eb6519;
	}
</style>

<template>
	<section class="p_container_l">
		<div class="p_container_login_main">
			<div class="p_login_img">
				<img alt="logo" src="../assets/img/logo.png">
			</div>

			<div class="form-group">
				<input type="text" maxlength="18" v-model="username" class="p_input p_input_siz_1 p_input_col_1" placeholder="用户名">
        <!--span class="pass_eye pass_eye_hide" style="float:right"></span-->
				<input @keyup.enter="login" id="pwd" type="password" v-model="password" class="p_input p_input_siz_1 p_input_col_1 " placeholder="密码(6～20位数字和字母组合)">
        <span class="pass_eye pass_eye_hide" style="float:right"></span>
			</div>
			<input :value="btnText" class="p_btn p_btn_siz_1 p_btn_col_ora" @click="login" type="submit" id="ue_submit">

		</div>
	</section>

</template>

<script>
	import Vue from 'vue';
	import axios from 'axios';
	Vue.prototype.$http = axios;
	import CryptoJS from "crypto-js";
	import * as util from '../assets/util.js';
	import qs from 'qs';
	//登录
	const requestLogin = params => {
		let words = CryptoJS.enc.Utf8.parse(params.password);
		let base64 = CryptoJS.enc.Base64.stringify(words);
		//params.password = base64;
		// axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';
		//axios.defaults.headers.post['Access-Control-Allow-Origin'] = '*';
		//axios.headers.post['Content-Type'] = 'application/json';
		return axios.post('/api/login', params);

	};

	export default {
		data() {
			return {
				username: '',
				password: '',
				isBtnLoading: false
			};
		},
		computed: {
			btnText() {
				if(this.isBtnLoading) return '登录中...';
				return '登录';
			}
		},
		methods: {
			login() {
				var vm = this;
				if(!vm.username) {
					vm.$message.error('请填写用户名！！！');
					return;
				}
				if(!vm.password) {
					vm.$message.error('请填写密码');
					return;
				}

				let loginParams = {
					username: vm.username,
					password: vm.password
				};
				vm.isBtnLoading = true;
				requestLogin(loginParams).then(res => {
					vm.isBtnLoading = false;
					if(res.data) {
						if(res.data.errcode == '0') {
							util.session('loginInfo', res.data.data);
							vm.$emit('login', vm.$router.currentRoute.query.from);
						} else if(res.data.errcode == '1') {
							vm.$message.error(res.data.errmsg);
							return;
						}
					} else {
						return Promise.reject({
							message: '登录异常！'
						});
					}
				}).catch(util.catchError);
			}
		},
		created() {
			sessionStorage.clear();
		},
		mounted() {
			document.getElementsByTagName("body")[0].style.backgroundColor = "#f3f3f4";
				$('.pass_eye').click(function(event){
		if($(this).hasClass('pass_eye_hide')){
			$(this).removeClass('pass_eye_hide');
			$(this).addClass('pass_eye_show');
			$("#pwd").attr('type','text')
		}else{
			$(this).removeClass('pass_eye_show');
			$(this).addClass('pass_eye_hide');
			$("#pwd").attr('type','password')
		}
	})
		}
	};
</script>
