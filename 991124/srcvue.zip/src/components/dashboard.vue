﻿<style scoped>
	.con_bl_6 {
		float: left;
		width: calc(100% - 27px);
		margin: 10px 5px 0px 10px;
		border: solid 1px #c6c6c6;
		border-radius: 3px;
		padding: 5px;
		height: calc(50% - 22px);
		overflow: auto;
	}

	.con_bl_4 {
		float: left;
		width: calc(40% - 27px);
		margin: 10px 10px 0px 5px;
		border: solid 1px #c6c6c6;
		border-radius: 3px;
		padding: 5px;
		height: calc(50% - 22px);
		overflow: auto;
	}

	.con_bl_3 {
		float: left;
		width: calc(100% - 27px);
		margin: 10px 5px 0px 10px;
		border: solid 1px #c6c6c6;
		border-radius: 3px;
		padding: 5px;
		/*height: calc(100% - 22px);*/
		overflow: auto;
	}

	.main_con {
		width: 100%;
		height: calc(100vh - 90px);
		min-height: 500px
	}

	.exportRules_h3 {
		padding: 5px;
		margin-bottom: 1px
	}

	.war_font {
		color: #fc5f5f
	}

	.war_font_size {
		display: inline-block;
		font-size: 1.2rem;
		padding: 10px
	}

	.href_hover:hover {
		cursor: pointer;
		color: #0d8ddb;
	}
</style>

<template>
	<div class="p_clear_float main_con">

		<section class="con_bl_6">
			<h3 class='h5_02_info_per_exportRules_h3 p_clear_float exportRules_h3'>
      			<span>当日回访</span>
    		</h3>
			<table class="p_table_la" cellspacing="0" cellpadding="0">
				<tr>
					<td>姓名</td>
					<td>性别</td>
					<td>年龄</td>
					<td>联系人手机</td>
					<td>与之关系</td>
					<td>所属校区</td>
					<td>课程大类</td>
					<td>课程小类</td>
					<td>回访次数</td>
					<td>预约回访日期</td>
					<td>操作</td>
				</tr>
				<template v-for="visit in visitInfo">
					<tr>
						<td class="href_hover" @click="linkVisitInfo(visit.id)">{{visit.studentName}}</td>
						<td>{{visit.sex}}</td>
						<td>{{visit.age}}</td>
						<td>{{visit.telephone}}</td>
						<td>{{visit.relationShip}}</td>
						<td>{{visit.schoolName}}</td>
						<td>{{visit.courseName}}</td>
						<td>{{visit.courseSubName}}</td>
						<td class="href_hover" @click="linkVisitList(visit.id)">{{visit.visitCount}}</td>
						<td>{{visit.nextVisitTime}}</td>
						<td>
							<input type="button" value="回访" @click="linkVisitAdd(visit.id)" class="p_btn p_btn_siz_2 p_btn_col_k_gre p_btn_pos_r">
						</td>
					</tr>
				</template>
			</table>
		</section>

		<section class="con_bl_6">
			<h3 class='h5_02_info_per_exportRules_h3 p_clear_float exportRules_h3'>
      			<span>预约试听</span>
    		</h3>
			<table class="p_table_la" cellspacing="0" cellpadding="0">
				<tr>
					<td>校区</td>
					<td>课程大类</td>
					<td>课程小类</td>
					<td>上课日期</td>
					<td>教室</td>
					<td>授课教师</td>
					<td>开始时间</td>
					<td>结束时间</td>
					<td>试听类型</td>
					<td>试听时长</td>
					<td>操作</td>
				</tr>
				<template v-for="listen in listenInfo">
					<tr>
						<td>{{listen.schoolName}}</td>
						<td>{{listen.courseName}}</td>
						<td>{{listen.courseSubName}}</td>
						<td>{{listen.listenDate}}</td>
						<td>{{listen.classRoomName}}</td>
						<td>{{listen.teacherName}}</td>
						<td>{{listen.beginTime}}</td>
						<td>{{listen.endTime}}</td>
						<td>{{listenTypeDict[listen.listenType]}}</td>
						<td>{{listenMinuteDict[listen.listenMinute]}}</td>
						<td>
							<input type="button" value="反馈" class="p_btn p_btn_siz_2 p_btn_col_k_gre p_btn_pos_r" @click="linkListenAdd(listen.informationId,listen.id)">
						</td>
					</tr>
				</template>
			</table>
		</section>

		<section class="con_bl_6" v-show="role_kaoqin">
			<h3 class='h5_02_info_per_exportRules_h3 p_clear_float exportRules_h3'>
      			<span>当日考勤</span>
    		</h3>
			<table class="p_table_la" cellspacing="0" cellpadding="0">
				<tr>
					<td>班级名称</td>
					<td>班级类别</td>
					<td>班型</td>
					<td>课程大类</td>
					<td>课程小类</td>
					<td>上课时段</td>
					<td>授课教师</td>
					<td>教室</td>
					<td>所属校区</td>
					<td>操作</td>
				</tr>
				<template v-for="dailyTime in dailyTimeInfo">
					<tr>
						<td>{{dailyTime.className}}</td>
						<td>{{classTypeDict[dailyTime.oneByOne]}}</td>
						<td>{{dailyTime.classTypeName}}</td>
						<td>{{dailyTime.courseName}}</td>
						<td>{{dailyTime.courseSubName}}</td>
						<td>
							<template v-for="lesson in dailyTime.lessons">
								{{weekDay[lesson.weekday-1] +" "+lesson.beginTime +"-"+lesson.endTime}}<br>
							</template>
						</td>
						<td>
							<template v-for="lesson in dailyTime.lessons">
								{{lesson.teacherName}}<br>
							</template>
						</td>
						<td>
							<template v-for="lesson in dailyTime.lessons">
								{{lesson.classRoomName}}<br>
							</template>
						</td>
						<td>{{dailyTime.schoolName}}</td>
						<td>
							<!--<input type="button" value="修改考勤" class="p_btn p_btn_siz_2 p_btn_col_k_gre p_btn_pos_r" @click="editAttendance(dailyTime.id)">-->
							<input type="button" value="考勤" class="p_btn p_btn_siz_2 p_btn_col_k_gre p_btn_pos_r" @click="attendance(dailyTime.id)">
						</td>
					</tr>
				</template>
			</table>
		</section>


		<section class="con_bl_3">
			<h3 class='h5_02_info_per_exportRules_h3 p_clear_float exportRules_h3'>
      			<span>校区课程表</span>
    		</h3>
			<schoolTimetable/>
		</section>
	</div>
</template>

<script>
	import * as goods from '../api/goods';
	import instance from '../api/index.js';
	import * as util from '../assets/util.js';
	import axios from 'axios';
	import { mapState } from 'vuex';
	let myMixin = {
		data: function() {
			return {
				goods
			}
		}
	}

	export default {
		mixins: [myMixin],
		data() {
			return {
				queryParam: {
					qUserId: "",
					qFollowerId: "",
					qTeacherId: "",
					qBeginListenDate: "",
					qEndListenDate: ""
				},
				listenInfo: [],
				visitInfo: [], //当日回访
				dailyTimeInfo: [], //当日考勤
				loginInfo: [],
				role1: false,
				role2: false,
				role3: false,
				role_kaoqin: false,
				weekDay: [
					"星期一",
					"星期二",
					"星期三",
					"星期四",
					"星期五",
					"星期六",
					"星期日"
				],
				teachersList: []
			}
		},
		components: {
			'dashboard-goods': () =>
				import('../components/dashboard-goods.vue'),
			schoolTimetable: () =>
				import("../components/schoolTimetable.vue")
		},
		methods: {
			//获取日期
			GetDateStr: function(AddDayCount) {
				var dd = new Date();
				dd.setDate(dd.getDate() + AddDayCount); //获取AddDayCount天后的日期
				var y = dd.getFullYear();
				var m = dd.getMonth() + 1; //获取当前月份的日期
				m = parseInt(m) < 10 ? "0" + m : m;
				var d = dd.getDate();
				d = parseInt(d) < 10 ? "0" + d : d;
				return y + "-" + m + "-" + d;
			},
			linkVisitInfo: function(id) { //点击跳转我的咨询-基本信息
				this.$router.push('/zhaoshengguanli/adviceinfo/' + id + "/baseInfo");
			},
			linkVisitList: function(id) { //点击跳转我的咨询-回访记录
				this.$router.push('/zhaoshengguanli/adviceinfo/' + id + "/visitList");
			},
			linkVisitAdd: function(id) { //点击跳转我的咨询-新增回访记录
				this.$router.push('/zhaoshengguanli/adviceinfo/' + id + "/addVisit");
			},
			linkListenAdd: function(informationId,id) {
				this.$router.push('/zhaoshengguanli/adviceinfo/' + informationId + "/addListenReply/"+id);
			},

			//考勤
			attendance: function(id) {
				this.$confirm("您确定对该班级进行考勤记录吗?", "提示", {
						confirmButtonText: "确定",
						cancelButtonText: "取消",
						type: "info"
					})
					.then(() => {
						this.$router.push('/jiaowuguanli/xueshengkaoqin/' + id);
					})
					.catch(() => {});
			},

			//修改考勤
			editAttendance: function(id) {
				this.$router.push('/jiaowuguanli/chexiaoxiaoke/' + id);
			}
		},
		computed: {
			// Getting Vuex State from store/index
			...mapState({
				//试听类型
				listenTypeDict: state => state.listenTypeDict,
				//试听时常
				listenMinuteDict: state => state.listenMinuteDict,
				//班型
				classTypeDict: state => state.classTypeDict,
			})
		},
		created() {
			//从session中获取用户登陆json
			this.loginInfo = util.session('loginInfo').login;
			//查询用户角色
			this.loginInfo.roles.forEach(function(r) {
				//管理员、店长、大区经理、总经理、组织管理员
				if(r.roleCode == "admin" || r.roleCode == "schoolmanager" || r.roleCode == "regionmanager" || r.roleCode == "generalmanager" || r.roleCode == "orgadmin") {
					this.role1 = true;
				}

				//咨询师、课程顾问
				if(r.roleCode == "counselor" || r.roleCode == "coursecounselor") {
					this.role2 = true;
				}

				//授课教师
				if(r.roleCode == "teacher") {
					this.role3 = true;
				}
				
				//不包含 patriarch：家长，counselor：咨询师
				if(r.roleCode != "patriarch" && r.roleCode != "counselor") {
					this.role_kaoqin = true;
				}
			}, this);

			if(this.role1) {
				//用户id
				this.queryParam.qUserId = this.loginInfo.userId;
				//客户端今天日期
				this.queryParam.qBeginListenDate = this.GetDateStr(0);

				instance.post('/listen/findMainPageListens', this.queryParam).then((res) => {
					this.listenInfo = res.data.data;
				});
			} else if(this.role2) {
				//跟进人id
				this.queryParam.qFollowerId = this.loginInfo.userId;
				//客户端今天日期
				this.queryParam.qBeginListenDate = this.GetDateStr(0);

				instance.post('/listen/findMainPageListens', this.queryParam).then((res) => {
					this.listenInfo = res.data.data;
				});

			} else if(this.role3) {
				//授课教师id
				this.queryParam.qTeacherId = this.loginInfo.userId;
				//客户端今天日期
				this.queryParam.qBeginListenDate = this.GetDateStr(0);
				//客户端后天日期
				this.queryParam.qEndListenDate = this.GetDateStr(2);

				instance.post('/listen/findMainPageListens', this.queryParam).then((res) => {
					this.listenInfo = res.data.data;
				});

			}

			//当日回访
			instance.get('/infor/findTodayInformations', null).then((res) => {
				this.visitInfo = res.data.data;
			});

			//当日考勤
			instance.get('/class/findTodayInClasses', null).then((res) => {
				let vm = this;
				this.dailyTimeInfo = res.data.data;

				//对 授课教师、教室 去重复的问题
				/*
				this.dailyTimeInfo.forEach(function(dailyTime, i) {
					var object_lesson = {
						"lessons": ""
					};

					var arr_lesson = [];
					dailyTime.lessons.forEach(function(lesson, j) {

						let flag = false; //默认不存在

						arr_lesson.forEach(function(teacher, k) {
							console.info(j + " teacherName=" + lesson.teacherName);
							if(teacher.teacherName == lesson.teacherName) {
								flag = true;
								console.info("=----111");
							} else {
								console.info("=----222");
								arr_lesson.push(lesson);
							}

						});

						if(!flag) {
							arr_lesson.push(lesson);
						}
						object_lesson.lessons = arr_lesson;
					});

					vm.teachersList.push(object_lesson);
				});
				*/
				//console.info("=---------teacher=" + JSON.stringify(vm.teachersList));
			});

		}
	};
</script>
