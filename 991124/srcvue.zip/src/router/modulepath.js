import Abstract from '../views/common/abstract.vue';
export default [{
			path: '/xiugaimima',
			name: '首页',
			meta: {
				icon: 'stu.png'
			},
			component: (resolve) => require(['../views/index.vue'], resolve),
			children: [{
					path: 'xiugaimima',
					name: '修改密码',
					meta: {
						icon: 'stu.png'
					},
					component: (resolve) => require(['../views/password.vue'], resolve)
			}
			]
		},{
		path: '/xueyuanguanli',
		name: '学员管理',
		meta: {
			name: '学员管理',
			icon: '&#xe62e;'
		},
		component: (resolve) => require(['../views/index.vue'], resolve),
		children: [{
				path: 'addStudent/:adviceId',
				name: '新增学员',
				meta: {
					icon: '&#xe62e;'
				},
				component: (resolve) => require(['../views/studentManage/addStudent/add.vue'], resolve)
			},
			{
				path: 'editStudent/:studentId',
				name: '编辑学员',
				meta: {
					icon: '&#xe62e;'
				},
				component: (resolve) => require(['../views/studentManage/addStudent/add.vue'], resolve)
			},
			{
				path: 'buycard/:id',
				name: '购卡',
				component: (resolve) => require(['../views/studentManage/addStudent/buyCard.vue'], resolve)
			},
			{
				path: 'chooseclass/:id',
				name: '选班',
				component: (resolve) => require(['../views/studentManage/addStudent/chooseClass.vue'], resolve)
			},
			{
				path: 'studentinfo/:id',
				name: '学员信息',
				component: (resolve) => require(['../views/studentManage/allStudent/studentInfo.vue'], resolve),
				children: [{
						path: 'baseInfo',
						name: '基本信息',
						component: (resolve) => require(['../views/studentManage/allStudent/info.vue'], resolve)
					},
					{
						path: 'buyClassInfo',
						name: '购课信息',
						component: (resolve) => require(['../views/studentManage/allStudent/buyClassInfo.vue'], resolve)
					},
					{
						path: 'consultInfo',
						name: '咨询信息',
						component: (resolve) => require(['../views/studentManage/allStudent/consultInfo.vue'], resolve)
					},
					{
						path: 'kechengmingxi',
						name: '课程明细',
						component: (resolve) => require(['../views/studentManage/allStudent/curriculumInfo.vue'], resolve)
					},
					{
						path: 'keshixiaohao',
						name: '课时消耗',
						component: (resolve) => require(['../views/studentManage/allStudent/keshixiaohao.vue'], resolve)
					},
					{
						path: 'returnVisitInfo',
						name: '回访记录',
						component: (resolve) => require(['../views/studentManage/allStudent/returnVisitInfo.vue'], resolve)
					},
					{
						path: 'Schedule',
						name: '课表',
						component: (resolve) => require(['../views/studentManage/allStudent/Schedule.vue'], resolve)
					}
				]
			},
			{
				path: 'fenban',
				name: '分班',
				component: (resolve) => require(['../views/studentManage/business/divideClass.vue'], resolve)
			},
			{
				path: 'tuifei/:id',
				name: '退费',
				component: (resolve) => require(['../views/studentManage/business/returnCost.vue'], resolve)
			},
			{
				path: 'zhuanban',
				name: '转班',
				component: (resolve) => require(['../views/studentManage/business/transferClass.vue'], resolve)
			},
			{
				path: 'buxiaokeshi/:id',
				name: '补消课时',
				component: (resolve) => require(['../views/studentManage/business/buxiaoKeshi.vue'], resolve)
			},
			{
				path: '/xueyuanguanli/feedbackDetails/:id',
				name: '反馈及意见详情',
				component: (resolve) => require(['../views/studentManage/feedback/feedbackDetails.vue'], resolve)
			}
		]
	},
	{
		path: '/zhaoshengguanli',
		name: '招生管理',
		meta: {
			name: '招生管理',
			icon: '&#xe62e;'
		},
		component: (resolve) => require(['../views/index.vue'], resolve),
		children: [{
			path: 'updateAdvice/:id',
			name: '编辑咨询',
			component: (resolve) => require(['../views/adviceManagement/allAdvice/updateAdviceView.vue'], resolve),
			props: true
		}, {
			path: 'readAdvice/:id',
			name: '咨询详情',
			component: (resolve) => require(['../views/adviceManagement/allAdvice/readAdviceView.vue'], resolve),
			props: true
		}, {
			path: 'adviceinfo/:id',
			name: '咨询信息',
			component: (resolve) => require(['../views/adviceManagement/myAdvice/adviceInfo.vue'], resolve),
			children: [{
					path: 'baseInfo',
					name: '基本信息',
					component: (resolve) => require(['../views/adviceManagement/myAdvice/info.vue'], resolve)
				},
				{
					path: 'visitList',
					name: '回访记录',
					component: (resolve) => require(['../views/adviceManagement/myAdvice/visit/visitList.vue'], resolve)
				},
				{
					path: 'addVisit',
					name: '回访信息',
					component: (resolve) => require(['../views/adviceManagement/myAdvice/visit/addUpdate.vue'], resolve)
				},
				{
					path: 'editVisit/:visitId',
					name: '回访信息',
					component: (resolve) => require(['../views/adviceManagement/myAdvice/visit/addUpdate.vue'], resolve)
				},
				{
					path: 'listenList',
					name: '试听记录',
					component: (resolve) => require(['../views/adviceManagement/myAdvice/listen/listenList.vue'], resolve)
				},
				{
					path: 'addListen',
					name: '试听信息',
					component: (resolve) => require(['../views/adviceManagement/myAdvice/listen/addUpdate.vue'], resolve)
				},
				{
					path: 'editListen/:listenId',
					name: '试听信息',
					component: (resolve) => require(['../views/adviceManagement/myAdvice/listen/addUpdate.vue'], resolve)
				},
				{
					path: 'listenReplyList',
					name: '反馈记录',
					component: (resolve) => require(['../views/adviceManagement/myAdvice/listenReply/listenReplyList.vue'], resolve)
				}, {
					path: 'addListenReply/:listenId',
					name: '反馈信息',
					component: (resolve) => require(['../views/adviceManagement/myAdvice/listenReply/addUpdate.vue'], resolve)
				}, {
					path: 'editListenReply/:listenReplyId',
					name: '反馈信息',
					component: (resolve) => require(['../views/adviceManagement/myAdvice/listenReply/addUpdate.vue'], resolve)
				},
			]
		}]
	},
	{
		path: '/caiwuguanli',
		name: '财务管理',
		meta: {
			name: '财务管理',
			icon: '&#xe62e;'
		},
		component: (resolve) => require(['../views/index.vue'], resolve),
		children: [{
			path: 'dingdanshenhe',
			name: '订单审核',
			meta: {
				icon: '&#xe62e;'
			},
			component: (resolve) => require(['../views/financialManagement/dingdanshenhe/dingDanShenHeBlank.vue'], resolve),
			children: [{
					path: 'approvebuycard/:id',
					name: '审核',
					meta: {
						icon: '&#xe62e;'
					},
					component: (resolve) => require(['../views/financialManagement/dingdanshenhe/approveBuyCard.vue'], resolve)
				},
				{
					path: 'linkdetails/:id',
					name: '详情',
					meta: {
						icon: '&#xe62e;'
					},
					component: (resolve) => require(['../views/financialManagement/dingdanshenhe/linkdetails.vue'], resolve)
				},
				{
					path: 'editbuycard/:id',
					name: '修改',
					meta: {
						icon: '&#xe62e;'
					},
					component: (resolve) => require(['../views/financialManagement/dingdanshenhe/editBuyCard.vue'], resolve)
				},
				{
					path: 'cancelbuycard/:id',
					name: '取消',
					meta: {
						icon: '&#xe62e;'
					},
					component: (resolve) => require(['../views/financialManagement/dingdanshenhe/approveBuyCard.vue'], resolve)
				},
				{
					//退费修改
					path: 'editrefund/:id',
					name: '修改',
					meta: {
						icon: '&#xe62e;'
					},
					component: (resolve) => require(['../views/financialManagement/dingdanshenhe/editRefund.vue'], resolve)
				}
			]
		},
		{
			path: 'jiaoyijilu',
			name: '交易记录',
			meta: {
				icon: '&#xe62e;'
			},
			component: (resolve) => require(['../views/financialManagement/dingdanshenhe/dingDanShenHeBlank.vue'], resolve),
			children: [{
					path: 'findbuycard/:id',
					name: '查看',
					meta: {
						icon: '&#xe62e;'
					},
					component: (resolve) => require(['../views/financialManagement/jiaoyijilu/cardInfo.vue'], resolve)
			}]
		},
		{
				path: 'studentinfo/:id',
				name: '学员信息',
				component: (resolve) => require(['../views/financialManagement/keshixiaohaotongji/studentInfo.vue'], resolve),
				children: [{
						path: 'baseInfo',
						name: '基本信息',
						component: (resolve) => require(['../views/studentManage/allStudent/info.vue'], resolve)
					},
					{
						path: 'buyClassInfo',
						name: '购课信息',
						component: (resolve) => require(['../views/studentManage/allStudent/buyClassInfo.vue'], resolve)
					},
					{
						path: 'consultInfo',
						name: '咨询信息',
						component: (resolve) => require(['../views/studentManage/allStudent/consultInfo.vue'], resolve)
					},
					{
						path: 'kechengmingxi',
						name: '课程明细',
						component: (resolve) => require(['../views/studentManage/allStudent/curriculumInfo.vue'], resolve)
					},
					{
						path: 'keshixiaohao',
						name: '课时消耗',
						component: (resolve) => require(['../views/studentManage/allStudent/keshixiaohao.vue'], resolve)
					},
					{
						path: 'returnVisitInfo',
						name: '回访记录',
						component: (resolve) => require(['../views/studentManage/allStudent/returnVisitInfo.vue'], resolve)
					},
					{
						path: 'Schedule',
						name: '课表',
						component: (resolve) => require(['../views/studentManage/allStudent/Schedule.vue'], resolve)
					}
				]
			}
		]
	},
	{
		path: '/renshiguanli',
		name: '人事管理',
     	meta: {
        	name: '人事管理',
        	icon: '&#xe62e;'
      	},
		component: (resolve) => require(['../views/index.vue'], resolve),
		children: [{
			path: 'updateEmployee/:id',
			name: '编辑员工',
			component: (resolve) => require(['../views/personnelManagement/staffManagement/updateEmployeeView.vue'], resolve),
			props: true
		},{
			path: 'updateSubEmployee/:id',
			name: '编辑分店员工',
			component: (resolve) => require(['../views/personnelManagement/substaffManagement/updateEmployeeView.vue'], resolve),
			props: true
		},{
			path: 'readEmployee/:id',
			name: '查看员工',
			component: (resolve) => require(['../views/personnelManagement/staffManagement/readEmployeeView.vue'], resolve),
			props: true
		},{
			path: 'readSubEmployee/:id',
			name: '查看员工',
			component: (resolve) => require(['../views/personnelManagement/substaffManagement/readEmployeeView.vue'], resolve),
			props: true
		}
		]
	},
  {
    path: '/jiaowuguanli',
    name: '教务管理',
    meta: {
      name: '班级管理',
      icon: '&#xe62e;'
    },
    component: (resolve) => require(['../views/index.vue'], resolve),
    children: [{
      path: 'bianjibanji/:id',
      name: '编辑班级',
      component: (resolve) => require(['../views/educationalManage/classManage/editClass.vue'], resolve),
      props: true
    }, {
      path: 'banjixiangqing/:id',
      name: '班级详情',
      component: (resolve) => require(['../views/educationalManage/classManage/classInfo.vue'], resolve),
      props: true
    },
      {
        path: 'chexiaoxiaoke/:id',
        name: '修改考勤',
        component: (resolve) => require(['../views/educationalManage/classManage/chexiaoXiaoke.vue'], resolve),
        props: true
      },
      {
        path: 'banjijiake/:id',
        name: '加课',
        component: (resolve) => require(['../views/educationalManage/classManage/addCurriculum.vue'], resolve),
        props: true
      },
      {
        path: 'xueshengkaoqin/:id',
        name: '学生考勤',
        component: (resolve) => require(['../views/educationalManage/classManage/studentAttendance.vue'], resolve),
        props: true
      }
    ]
  },
  {
		path: '/jiaowuguanli',
		name: '教务管理',
		meta: {
			name: '教务管理',
			icon: '&#xe62e;'
		},
		component: (resolve) => require(['../views/index.vue'], resolve),
		children: [{
			path: 'adviceinfo/:id',
			name: '教师管理',
			component: (resolve) => require(['../views/educationalManage/teacher/adviceInfo.vue'], resolve),
			children: [{
					path: 'baseInfo',
					name: '基本信息',
					component: (resolve) => require(['../views/educationalManage/teacher/info.vue'], resolve)
				},
				{
					path: 'visitList',
					name: '工作时间',
					component: (resolve) => require(['../views/educationalManage/teacher/visit/visitList.vue'], resolve)
				},
				{
					path: 'addVisit',
					name: '工作时间新增',
					component: (resolve) => require(['../views/educationalManage/teacher/visit/addUpdate.vue'], resolve)
				},
				{
					path: 'editVisit',
					name: '修改工作时间',
					component: (resolve) => require(['../views/educationalManage/teacher/visit/gztiemUpdate.vue'], resolve)
				},
				{
					path: 'teachkc',
					name: '教授课程',
					component: (resolve) => require(['../views/educationalManage/teacher/teachKc.vue'], resolve)
				}

			]
		}]
	},{
		path: '/jiaowuguanli',
		name: '教务管理',
     	meta: {
        	name: '校区管理',
        	icon: '&#xe62e;'
      	},
		component: (resolve) => require(['../views/index.vue'], resolve),
		children: [{
			path: '/xiaoquguanli/addSchool',
			name: '新增校区',
			component: (resolve) => require(['../views/educationalManage/schoolsManage/addSchoolView.vue'], resolve),
			props: true
		},{
			path: '/xiaoquguanli/updateSchool/:id',
			name: '编辑校区',
			component: (resolve) => require(['../views/educationalManage/schoolsManage/updateSchoolView.vue'], resolve),
			props: true
		}, {
			path: '/xiaoquguanli/readSchool/:id',
			name: '查看校区',
			component: (resolve) => require(['../views/educationalManage/schoolsManage/readSchoolView.vue'], resolve),
			props: true
		}]
	},{
		path: '/jiaowuguanli',
		name: '教务管理',
     	meta: {
        	name: '通知管理',
			icon: '&#xe62e;',
		},
		component: (resolve) => require(['../views/index.vue'], resolve),
		children: [{
			path: '/tongzhiguanli/fajianguanli/addNotice',
			name: '新建通知',
			component: (resolve) => require(['../views/educationalManage/notice/addNotice.vue'], resolve)
		}]
	},
	{
		path: '/yingxiaoguanli',
		name: '营销管理',
		meta: {
			name: '活动管理',
			icon: "&#xe62e;",
		},
		component: (resolve) => require(['../views/index.vue'], resolve),
		children: [{
			path: '/toupiaoguanli/huodongguanli/addActivity',
			name: '新增活动',
			component: (resolve) => require(['../views/marketing/activity/addActivity.vue'], resolve)
		},{
			path: '/toupiaoguanli/huodongguanli/activityClass',
			name: '编辑活动分类',
			component: (resolve) => require(['../views/marketing/activity/activityClass.vue'], resolve)
		}]
	},
	{
		path: '/yingxiaoguanli',
		name: '营销管理',
		meta: {
			name: '作品管理',
			icon: "&#xe62e;",
		},
		component: (resolve) => require(['../views/index.vue'], resolve),
		children: [{
			path: '/toupiaoguanli/zuopinguanli/releaseWorks',
			name: '发布作品',
			component: (resolve) => require(['../views/marketing/works/releaseWorks.vue'], resolve)
		}]
	},
	{
		path: '/yingxiaoguanli',
		name: '营销管理',
		meta: {
			name: '作品管理',
			icon: "&#xe62e;",
		},
		component: (resolve) => require(['../views/index.vue'], resolve),
		children: [{
			path: '/toupiaoguanli/zuopinguanli/comment',
			name: '作品评论管理',
			component: (resolve) => require(['../views/marketing/works/comment.vue'], resolve)
		}]
	},
	{
		path: '/tongjibaobiao',
		name: '统计报表',
		meta: {
			name: '投票统计分析',
			icon: "&#xe62e;",
		},
		component: (resolve) => require(['../views/index.vue'], resolve),
		children: [{
				path: '/tongjibaobiao/toupiaotongjifenxi',
				name: '投票统计分析',
				component: (resolve) => require(['../views/statistics/statistics.vue'], resolve),
				children: [{
						path: '/tongjibaobiao/toupiaotongjifenxi/zuopintongji',
						name: '作品统计',
						component: (resolve) => require(['../views/statistics/worksStatistics.vue'], resolve)
					},
					{
						path: '/tongjibaobiao/toupiaotongjifenxi/toupiaotongji',
						name: '投票统计',
						component: (resolve) => require(['../views/statistics/voteStatistics.vue'], resolve)
					},
					{
						path: '/tongjibaobiao/toupiaotongjifenxi/zuopinpaihang',
						name: '作品排行',
						component: (resolve) => require(['../views/statistics/worksRanking.vue'], resolve)
					},
					{
						path: '/tongjibaobiao/toupiaotongjifenxi/guanzhutongji',
						name: '关注统计',
						component: (resolve) => require(['../views/statistics/followStatistics.vue'], resolve)
					},
					{
						path: '/tongjibaobiao/toupiaotongjifenxi/fangwentongji',
						name: '访问统计',
						component: (resolve) => require(['../views/statistics/visitStatistics.vue'], resolve)
					},
					{
						path: '/tongjibaobiao/toupiaotongjifenxi/pingluntongji',
						name: '评论统计',
						component: (resolve) => require(['../views/statistics/commentStatistics.vue'], resolve)
					}
				]
			}
		]
	}
]
