import Abstract from '../views/common/abstract.vue';

export default [{
	path: '/',
	name: '首页',
	component: (resolve) => require(['../views/index.vue'], resolve),
	children: [{
			path: '/zhaoshengguanli',
			name: '招生管理',
			meta: {
				icon: 'stu.png'
			},
			component: Abstract,
			children: [{
					path: 'zhaoshengguanli_xinzengzixun',
					name: '新增咨询',
					meta: {
						icon: 'stu.png'
					},
					component: (resolve) => require(['../views/adviceManagement/addAdvice/addView.vue'], resolve)
				},
				{
					path: 'zhaoshengguanli_quanbuzixun',
					name: '全部咨询',
					meta: {
						icon: 'stu.png'
					},
					component: (resolve) => require(['../views/adviceManagement/allAdvice/allAdviceList.vue'], resolve)
				},
				{
					path: 'zhaoshengguanli_wodezixun',
					name: '我的咨询',
					meta: {
						icon: 'stu.png'
					},
					component: (resolve) => require(['../views/adviceManagement/myAdvice/adviceList.vue'], resolve)
				},
				{
					path: 'zhaoshengguanli_xiaoshouchi',
					name: '销售池',
					meta: {
						icon: 'stu.png'
					},
					component: (resolve) => require(['../views/adviceManagement/advicePool/adviceList.vue'], resolve)
				}
			]
		},
		{
			path: '/xueyuanguanli',
			name: '学员管理',
			meta: {
				name: '学员管理',
				icon: 'user.png'
			},
			component: Abstract,
			children: [{
					path: 'xueyuanguanli_quanbuxueyuan',
					name: '全部学员',
					meta: {
						icon: 'user.png'
					},
					component: (resolve) => require(['../views/studentManage/allStudent/allStudenList.vue'], resolve)
				},
				{
					path: 'xueyuanguanli_yewubanlis',
					name: '业务办理',
					meta: {
						icon: 'user.png'
					},
					component: (resolve) => require(['../views/studentManage/business/allStudenList.vue'], resolve)
				},
				{
					path: 'xueyuanguanli_goukejilu',
					name: '购课记录',
					meta: {
						icon: 'user.png'
					},
					component: (resolve) => require(['../views/studentManage/buyClass/buyCardList.vue'], resolve)
				},
				{
					path: 'xueyuanguanli_fankuijiyijian',
					name: '反馈及意见',
					meta: {
						icon: 'user.png'
					},
					component: (resolve) => require(['../views/studentManage/feedback/feedback.vue'], resolve)
				}
			]
		},
		{
			path: '/jiaowuguanli',
			name: '教务管理',
			meta: {
				name: '教务管理',
				icon: 'stu.png'
			},
			component: Abstract,
			children: [{
					path: 'xiaoquguanli',
					name: '校区管理',
					meta: {
						icon: 'stu.png'
					},
					component: (resolve) => require(['../views/educationalManage/schoolsManage/schoolsListView.vue'], resolve)
				},
				{
					path: 'systemsz',
					name: '基础信息',
					meta: {
						icon: 'stu.png'
					},
					component: Abstract,
					children: [{
							path: 'kechengdaleiguanli',
							name: '课程大类管理',
							meta: {
								icon: 'stu.png'
							},
							component: (resolve) => require(['../views/educationalManage/course/coursedlList.vue'], resolve)
						},
						{
							path: 'kechengxiaoleiguanli',
							name: '课程小类管理',
							meta: {
								icon: 'stu.png'
							},
							component: (resolve) => require(['../views/educationalManage/course/coursexlList.vue'], resolve)
						},
						{
							path: 'jiaoshiguanli',
							name: '教室管理',
							meta: {
								icon: 'stu.png'
							},
							component: (resolve) => require(['../views/educationalManage/classroom/classroomlist.vue'], resolve)
						},
						{
							path: 'teachergl',
							name: '教师管理',
							meta: {
								icon: 'stu.png'
							},
							component: (resolve) => require(['../views/educationalManage/teacher/teacherList.vue'], resolve)
						},
						{
							path: 'huiyuankaguanli',
							name: '会员卡管理',
							meta: {
								icon: 'stu.png'
							},
							component: (resolve) => require(['../views/educationalManage/membershipCard/vipcardList.vue'], resolve)
						}
					]
				},
				{
					path: 'banjiguanli',
					name: '班级管理',
					meta: {
						icon: 'stu.png'
					},
					component: Abstract,
					children: [{
							path: 'xinzengbanji',
							name: '新增班级',
							meta: {
								icon: 'stu.png'
							},
							component: (resolve) => require(['../views/educationalManage/classManage/addClass.vue'], resolve)
						},
						{
							path: 'banxingshezhi',
							name: '班型设置',
							meta: {
								icon: 'stu.png'
							},
							component: (resolve) => require(['../views/educationalManage/classManage/classType.vue'], resolve)
						},
						{
							path: 'banjiliebiao',
							name: '班级列表',
							meta: {
								icon: 'stu.png'
							},
							component: (resolve) => require(['../views/educationalManage/classManage/classList.vue'], resolve)
						}
					]
				},
				{
					path: 'jiaoxueguanli',
					name: '教学管理',
					meta: {
						icon: 'stu.png'
					},
					component: Abstract,
					children: [{
							path: 'xiaoqukebiao',
							name: '校区课表',
							meta: {
								icon: 'stu.png'
							},
							component: (resolve) => require(['../views/educationalManage/teachingManage/mySchoolTimetable.vue'], resolve)
						},
						{
							path: 'jiaoshikebiao',
							name: '教师课表',
							meta: {
								icon: 'stu.png'
							},
							component: (resolve) => require(['../views/educationalManage/teachingManage/teacherTimetable.vue'], resolve)
						},
						{
							path: 'xueyuankebiao',
							name: '课表查询',
							meta: {
								icon: 'stu.png'
							},
							component: (resolve) => require(['../views/educationalManage/teachingManage/studentTimetable.vue'], resolve)
						}
					]
				},
				{
					path: 'tongzhiguanli',
					name: '通知管理',
					meta: {
						icon: 'stu.png'
					},
					component: Abstract,
					children: [{
							path: 'fajianguanli',
							name: '发件管理',
							meta: {
								icon: 'stu.png'
							},
							component: (resolve) => require(['../views/educationalManage/notice/hairBox.vue'], resolve)
						},
						{
							path: 'shoujianguanli',
							name: '收件管理',
							meta: {
								icon: 'stu.png'
							},
							component: (resolve) => require(['../views/educationalManage/notice/inBox.vue'], resolve)
						}
					]
				}
			]
		},
		{
			path: '/caiwuguanli',
			name: '财务管理',
			meta: {
				name: '财务管理',
				icon: 'stu.png'
			},
			component: Abstract,
			children: [{
					path: 'dingdanshenhe',
					name: '订单审核',
					meta: {
						icon: 'stu.png'
					},
					component: Abstract,
					children: [{
							path: 'goukedingdan',
							name: '购课订单',
							meta: {
								icon: 'stu.png'
							},
							component: (resolve) => require(['../views/financialManagement/dingdanshenhe/buyCardList.vue'], resolve)
						},
						{
							path: 'tuifeidingdan',
							name: '退费订单',
							meta: {
								icon: 'stu.png'
							},
							component: (resolve) => require(['../views/financialManagement/dingdanshenhe/refundList.vue'], resolve)
						}
					]
				},
				{
					path: 'jiaoyijilu',
					name: '交易记录',
					meta: {
						icon: 'stu.png'
					},
					component: Abstract,
					children: [{
							path: 'jiaofeijilu',
							name: '交费记录',
							meta: {
								icon: 'stu.png'
							},
							component: (resolve) => require(['../views/financialManagement/jiaoyijilu/payFeeList.vue'], resolve)
						},
						{
							path: 'tuifeijilu',
							name: '退费记录',
							meta: {
								icon: 'stu.png'
							},
							component: (resolve) => require(['../views/financialManagement/jiaoyijilu/refundRecordList.vue'], resolve)
						}
					]
				},
				{
					path: 'keshixiaohaotongji',
					name: '课时消耗统计',
					meta: {
						icon: 'stu.png'
					},
					component: Abstract,
					children: [{
						path: 'xueyuankeshixiaohao',
						name: '学员课时消耗',
						meta: {
							icon: 'stu.png'
						},
						component: (resolve) => require(['../views/financialManagement/keshixiaohaotongji/allStudenList.vue'], resolve)
					}]
				}
			]
		},
		{
			path: '/renshiguanli',
			name: '人事管理',
			meta: {
				name: '人事管理',
				icon: 'stu.png'
			},
			component: Abstract,
			children: [{
				path: 'yuangongguanli',
				name: '员工管理',
				meta: {
					icon: 'stu.png'
				},
				component: Abstract,
				children: [{
						path: 'xinzengyuangong',
						name: '新增员工',
						meta: {
							icon: 'stu.png'
						},
						component: (resolve) => require(['../views/personnelManagement/staffManagement/addEmployeeView.vue'], resolve)
					},
					{
						path: 'quanbuyuangong',
						name: '全部员工',
						meta: {
							icon: 'stu.png'
						},
						component: (resolve) => require(['../views/personnelManagement/staffManagement/employeeList.vue'], resolve)
					}
				]
			},
			{
					path: 'fendian',
					name: '分店员工管理',
					meta: {
						icon: 'stu.png'
					},
					component: Abstract,
					children: [{
							path: 'addyuangong',
							name: '新增员工',
							meta: {
								icon: 'stu.png'
							},
							component: (resolve) => require(['../views/personnelManagement/substaffManagement/subAddEmployeeView.vue'], resolve)
						},
						{
							path: 'allyuangong',
							name: '全部员工',
							meta: {
								icon: 'stu.png'
							},
							component: (resolve) => require(['../views/personnelManagement/substaffManagement/subEmployeeLIst.vue'], resolve)
						}
					]
				}
			]
		},
		{
			path: '/yingxiaoguanli',
			name: '营销管理',
			meta: {
				name: '营销管理',
				icon: 'stu.png'
			},
			component: Abstract,
			children: [{
					path: 'toupiaoguanli',
					name: '投票管理',
					meta: {
						icon: 'stu.png'
					},
					component:Abstract,
					children: [{
							path: 'huodongguanli',
							name: '活动管理',
							meta: {
								icon: 'stu.png'
							},
							component: (resolve) => require(['../views/marketing/activity/activity.vue'], resolve)
						},
						{
							path: 'tpzuopinguanli',
							name: '作品管理',
							meta: {
								icon: 'stu.png'
							},
							component: (resolve) => require(['../views/marketing/works/works.vue'], resolve)
						}
					]
				}
			]
		},
		{
			path: "/tongjibaobiao",
			name: "统计报表",
			meta: {
				name: "统计报表",
				icon: "stu.png"
			},
			component: Abstract,
			children: [{
					path: "toupiaotongjifenxi",
					name: "投票统计分析",
					meta: {
						icon: "stu.png"
					},
					component: (resolve) => require(['../views/statistics/statistics.vue'], resolve)
				}
			]
		},
		{
			path: '/xitongshezhi',
			name: '系统设置',
			meta: {
				name: '系统设置',
				icon: 'set.png'
			},
			component: Abstract,
			children: [{
					path: 'xitongshezhi_zuzhijigouguanli',
					name: '组织机构管理',
					meta: {
						icon: 'set.png'
					},
					component: (resolve) => require(['../views/systemSetting/organize/organizeListView.vue'], resolve)
				},
				{
					path: 'xitongshezhi_bumenguanli',
					name: '部门管理',
					meta: {
						icon: 'set.png'
					},
					component: (resolve) => require(['../views/systemSetting/department/departmentListView.vue'], resolve)
				},
				{
					path: 'xitongshezhi_zhiwuguanli',
					name: '职务管理',
					meta: {
						icon: 'set.png'
					},
					component: (resolve) => require(['../views/systemSetting/position/positionListView.vue'], resolve)
				},
				{
					path: 'xitongshezhi_jueseguanli',
					name: '角色管理',
					meta: {
						icon: 'set.png'
					},
					component: (resolve) => require(['../views/systemSetting/role/roleListView.vue'], resolve)
				},
				{
					path: 'xitongshezhi_zixunlaiyuanguanli',
					name: '咨询来源管理',
					meta: {
						icon: 'set.png'
					},
					component: Abstract,
					children: [{
							path: 'zixunlaiyuanguanli_zixunlaiyuandaleiguanli',
							name: '咨询来源大类管理',
							meta: {
								icon: 'set.png'
							},
							component: (resolve) => require(['../views/systemSetting/source/sourceListView.vue'], resolve)
						},
						{
							path: 'zixunlaiyuanguanli_zixunlaiyuanxiaoleiguanli',
							name: '咨询来源小类管理',
							meta: {
								icon: 'set.png'
							},
							component: (resolve) => require(['../views/systemSetting/sourceSub/sourceSubListView.vue'], resolve)
						}
					]
				},
				{
					path: 'xitongshezhi_daohangguanli',
					name: '导航管理',
					meta: {
						icon: 'set.png'
					},
					component: (resolve) => require(['../views/systemSetting/navigation/navigationListView.vue'], resolve)
				},
				{
					path: 'xitongshezhi_weixinduanshezhi',
					name: '微信端设置',
					meta: {
						icon: 'set.png'
					},
					component: (resolve) => require(['../views/systemSetting/wechatSetup/wechatSetupView.vue'], resolve)
				},
				{
					path: 'xitongshezhi_pinlunguanjianziweihu',
					name: '评论关键字维护',
					meta: {
						icon: 'set.png'
					},
					component: (resolve) => require(['../views/systemSetting/keyWord/keyWord.vue'], resolve)
				}
			]
		}

	]
}];