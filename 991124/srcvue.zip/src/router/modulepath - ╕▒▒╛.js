import Abstract from '../views/common/abstract.vue';
export default [{
		path: '/xueyuanguanli',
		name: '学员管理',
		meta: {
			name: '学员管理',
			icon: '&#xe62e;'
		},
		component: (resolve) => require(['../views/index.vue'], resolve),
		children: [{
			path: 'buycard/:id',
			name: '购卡',
			component: (resolve) => require(['../views/studentManage/addStudent/buyCard.vue'], resolve)
		}]
	},
	{
		path: '/zhaoshengguanli',
		name: '招生管理',
		meta: {
			name: '招生管理',
			icon: '&#xe62e;'
		},
		component: (resolve) => require(['../views/index.vue'], resolve),
		children: [{
			path: 'updateAdvice/:id',
			name: '编辑咨询',
			component: (resolve) => require(['../views/adviceManagement/allAdvice/updateAdviceView.vue'], resolve),
			props: true
		},{
			path: 'readAdvice/:id',
			name: '咨询详情',
			component: (resolve) => require(['../views/adviceManagement/allAdvice/readAdviceView.vue'], resolve),
			props: true
		}]
	},
	{
		path: '/chooseclass',
		name: '选班',
		component: (resolve) => require(['../views/studentManage/addStudent/chooseClass.vue'], resolve)
	}
]