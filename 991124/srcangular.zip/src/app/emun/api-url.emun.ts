export declare const enum ApiUrl {
  EFormAttach = 'eform/getEFormAttach.dbe',
  DownloadAttach = 'eform/downloadAttach.dbe',
  EformOpen = 'eform/open.dbe',
  Query = 'dbform/query.dbe',
  SaveReadComment = 'saveReadComment.dbe',
  ChangeAccount = 'changeAccount.dbe', // 切换账号
  Logout = 'logout.dbe', // 注销当前账号
  Login = 'login.dbe', // 登陆
  GetAccounts = 'getAccounts.dbe', // 获取当前用户账号信息
  GetUsers = 'ou/getUsers.dbe',
  GetDepartments = 'ou/getDepartments.dbe',
  // -----------------------------------------------------------
  SaveWorkComment = 'workflow/saveWorkComment.dbe', // 保存办理意见
  GetWorkActLog = 'workflow/getWorkActLog.dbe', // 获取办理意见
  GetReadActLog = 'workflow/getReadActLog.dbe', // 获取阅读意见
  SubmitWork = 'workflow/submitWork.dbe', // 提交工作
  SubmitRoutes = 'workflow/submitRoutes.dbe', // 提交到路由
  /**
   * 获取当前操作人可访问的表单额外操作，
   * return-退回；
   * change-转办；
   * redo-重办；
   * assemble-会签情况；
   * subflow-子流程情况；
   * aid-协办情况；
   * multi-并发办理情况
   */
  GetNodeControlRight = 'workflow/getNodeControlRight.dbe',
  BackRoutes = 'workflow/backRoutes.dbe'
}
