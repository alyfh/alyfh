import {Pipe, PipeTransform} from '@angular/core';
import {SearchService} from './search.service';

@Pipe({
  name: 'search',
  pure: false
})
export class SearchPipe implements PipeTransform {

  constructor(public searchService: SearchService) {
  }

  transform(value: any, args?: any): any {
    if (value === undefined || value === []) {
      return value;
    }
    value = value.filter(object => {
      let flag = false;
      Object.keys(object).forEach(key => {
        // console.log(object[key]);
        if (this.searchService.text === undefined
          || this.searchService.text === ''
          || (object[key] != null && object[key].toString().indexOf(this.searchService.text) >= 0)) {
          flag = true;
        }
      });
      return flag;
    });
    // console.log('search', value);
    return value;
  }
}
