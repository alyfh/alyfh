import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SearchService {
  text;
  isSearch = false;
  value;
  constructor() { }
}
