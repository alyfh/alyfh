import {ChangeDetectorRef, Component, OnInit} from '@angular/core';
import {SearchService} from './search.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  constructor(public searchService: SearchService, public cdr: ChangeDetectorRef) {
  }

  search() {
    // this.cdr.detectChanges();
    this.searchService.isSearch = true;
    setTimeout(() => {
      this.searchService.isSearch = false;
    }, 1000);

    // console.log('search');
  }


  ngOnInit(): void {
  }
}
