import {Component, Input, OnChanges, OnInit, SimpleChanges} from '@angular/core';

@Component({
  selector: 'app-badge',
  templateUrl: './badge.component.html'
})
export class BadgeComponent implements OnInit, OnChanges {
  @Input('src') src = 'assets/img/wait.png';
  @Input('name') name = '待办';
  @Input('actsrc') actsrc;
  @Input('isactive') isactive = false;
  @Input('count') count = 0;

  ngOnChanges(changes: SimpleChanges): void {
    // console.log('count', this.count);
    // console.log(changes);
  }

  ngOnInit(): void {
  }
}
