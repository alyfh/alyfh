export class Record {
/*"N"*/
public ACTIONTYPE: string ;
public ACTOR: string ; // "zhangqun"
public ACTORNAME: string ; // "张群"
public APPDATA: string ; // null
public ARCHIVED: string ; // "N"
public ASSIGNER: string ; // "吕秀彬"
public ASSIGNTYPE: string ; // "N"
public COMMENTS: string ; // null
public DEPTID: string ; // "0007.0002"
public DEPTNAME: string ; // "项目二部"
public DEPTNAMEPATH: string ; // null
public FLOWBEGIN: string ; // "2018-05-29 17:02:57"
public FLOWEND: string ; // null
public FLOWEVAL: string ; // null
public FLOWID: string ; // "swsplc"
public FLOWNAME: string ; // "收文审批流程"
public FLOWORG: string ; // "root"
public FLOWSTATE: string ; // "N"
public FLOWVER: string ; // "13"
public FLOWVORGCODE: string ; // null
public INITIATOR: string ; // "zhangqun"
public INITIATORNAME: string ; // "张群"
public INSTANCEID: string ; // "2091"
public NID: string ; // "5358"
public NODEBEGIN: string ; // "2018-05-30 09: string ; //51: string ; //53"
public NODEEND: string ; // "2018-09-07 16: string ; //42: string ; //32"
public NODEEVAL: string ; // null
// "25"
public NODEID: string ;
/*节点名称 如："返收文员"*/
public NODENAME: string ;
public NODETYPE: string ; // "A"
public ORGID: string ; // "root"
public ORGNAME: string ; // "北京普巴软件有限公司"
public PARENTNID: string ; // "5352"
public REDOFLAG: string ; // "Y"
public REDOITEM: string ; // "0"
public SCORE: string ; // "0"
public SRCNODE: string ; // null
public SUPERINSTANCE: string ; // "0"
public SUPERNID: string ; // "0"
public TITLE: string ; // "【收文】iOS测试多附件多正文情况"
public TRANSACTOR: string ; // null
public USERPK: string ; // "32"
public VORGCODE: string ; // null
public WORKTYPE: string ; // "A"
}

