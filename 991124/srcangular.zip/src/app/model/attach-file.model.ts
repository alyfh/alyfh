export class AttachFile {
  public FID: number ; // 0,
  public SAVEFILE: string ; // "201806/20180615103802165930241.jpg",
  public FIELDNAME: string ; // "gwzw",
  public FILESIZE: number ; // 131270,
  public ID: number ; // 1665,
  public DONETIME: string ; // "2018-06-15 10:38:02",
  public STATUS: string ; // "N",
  public SOURCEFILE: string ; // "timg.jpg",
  public TYPE: string ; // "F",
  public FIELDID: string ; // "gwzw"
}
