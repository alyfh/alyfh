export class Notice {
  public profile?: string;
  public title?: string;
  public userName?: string;
  public department?: string;
  public time?: Date;


  constructor(profile: string, title: string, userName: string, department: string, time: Date) {
    this.profile = profile;
    this.title = title;
    this.userName = userName;
    this.department = department;
    this.time = time;
  }
}
