export class BodyAttach {
  public CREATOR: string;
  public DONETIME: string;
  public FID: number;
  public FILESIZE: number;
  public ID: number;
  public SAVEFILE: string;
  public SOURCEFILE: string;
  public STATUS: string;
  public TYPE: string;
}
