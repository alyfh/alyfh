export class Item {
  public id?: string;
  public profile?: string;
  public title?: string;
  public userName?: string;
  public department?: string;
  public time?: Date;
  public nid?: string;
  public instanceid?: string;


  constructor(profile: string, title: string, userName: string, department: string, time: Date, nid: string,
  instanceid: string) {
    this.profile = profile;
    this.title = title;
    this.userName = userName;
    this.department = department;
    this.time = time;
    this.nid = nid;
    this.instanceid = instanceid;
  }
}
