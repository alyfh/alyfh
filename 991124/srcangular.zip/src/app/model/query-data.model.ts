import {Record} from './record.model';

/**
 * 后台请求返回的数据
 */
export class QueryData {
  public actionid: string ; // ""
  public actions: string ; // [{actionid: string ; // "action1", actionname: string ; // "查看", actions: string ; // [], bind: string ; // "title", dlgHeight: string ; // "", dlgWidth: string ; // "",…},…]
  public clause: string ; // [,…]
  public currentpage: string ; // 1
  public fromrow: string ; // 1
  public message: string ; // ""
  public modid: string ; // "yibangongzuo"
  public modname: string ; // "已办工作"
  /*主键名称*/
  public pkey: string ; // "instanceid"
  public recordset: Record[] ; // [,…]
  public result: string ; // ""
  public subsysid: string ; // "liuchengbanli"
  public subsysname: string ; // "liuchengbanli"
  public systemid: string ; // "gerenbangong"
  public systemname: string ; // "个人办公"
  public titles: string ; // [["title", "工作标题"], ["flowname", "流程名称"], ["nodename", "办理环节"], ["nodeend", "办理日期"],…]
  public torow: string ; // 84
  public totalpage: string ; // 1
  public totalrow: string ; // 84
}
