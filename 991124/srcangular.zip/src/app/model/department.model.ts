import {User} from './user.model';

export class Department {
  public adminId: string = '';
  public adminName: string = '';
  public beginTime: string = '2016-06-29 12:49:45';
  public code: string = '0001';
  public createTime: string = '2016-06-29';
  public departLevel: number = 1;
  public departName: string = '总裁办公室';
  public departType: string = '0';
  public descr: string = '0001';
  public endTime: string = '2050-01-01 00:00:00';
  public id: number = 2;
  public orgCode: string = 'root';
  public orgPK: number = 1;
  public parentCode: string = '';
  public roles: string = '';
  public seqNo: number = 2;
  public status: string = '1';
  public users: User[] = [];
  public active: boolean = false; // 是否激活
}
