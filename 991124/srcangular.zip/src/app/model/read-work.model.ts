export class ReadWork {
  public ACTOR: string = 'zhangqun';
  public ACTORNAME: string = '张群';
  public DONETIME: string = '2017-03-10 18:08:28';
  public FLOWID: string = 'qjlcspce';
  public FLOWNAME: string = '请假申请（测试）';
  public INSTANCEID: string = '1375';
  public NID: string = '3032';
  public NODENAME: string = '主管领导';
  public ORGID: string = 'root';
  public READSCOPE: string = '<ORG.root.U.lvxiubin>吕秀彬;<ORG.root.U.zhangqun>张群;<ORG.root.U.liuyong>刘勇';
  public TITLE: string = '请假审批';
}
