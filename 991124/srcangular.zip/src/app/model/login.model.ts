export class Login {
  public ca_id: string; // ""
  public creator: string; // ""
  public deadTime: string; // 0
  public dept1_id: string; // ""
  public dept1_name: string; // ""
  public dept_PK: string; // 10
  public dept_id: string; // "0007.0002"
  public dept_name: string; // "项目二部"
  public depts: string; // "'0007.0002'"
  public employee_id: string; // ""
  public groups: string; // "''"
  public id: string; // "zhangqun"
  public ip: string; // ""
  public languageId: string; // "zh-cn"
  public last_login_time: string; // ""
  public levels: string; // ""
  public login_time: string; // "2018-09-07 13: string; //54: string; //53"
  public mode: string; // "N"
  public name: string; // "张群"
  public order_no: string; // ""
  public org_PK: string; // 1
  public org_id: string; // "root"
  public password: string; // "MTIzNDU2Nzg="
  public person_PK: string; // 30
  public plurality: string; // ""
  public posts: string; // "''"
  public rank: string; // ""
  public reg_date: string; // ""
  public roles: string; // "'demoadmin','archive','eformadmin','imadmin','everyone','admin','sa','webreleaser','webapprover','webcontent','webcreater','webmsgboard','webmanager','forum','workflow','portal','xiangmujingli','csydjs'"
  public skin_id: string; // "default"
  public state: string; // "1"
  public templet_id: string; // "default"
  public timePoint: string; // ""
  public type: string; // "0"
  public user_PK: string; // 32
  public vorgCode: string; // ""
}
