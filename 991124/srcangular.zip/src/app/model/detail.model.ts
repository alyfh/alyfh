/**
 * 详情
 */
import {Field} from './field.model';
import {AttachFile} from './attach-file.model';

export class Detail {
  data: {}; // 详情的数据
  fields: Field[]; // 详情字段
  bodyAttach: AttachFile[]; // 正文附件
}
