import {QueryData} from './query-data.model';

export class Result {
  public errcode: number; // 0,
  // 请求返回数据
  public data: QueryData | any; //
  // 错误信息
  public errmsg: string; // "success"
}
