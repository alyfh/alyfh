export class Approve {
  public profile?: string;
  public title?: string;
  public roleName?: string;
  public roleIcon?: string;
  public timeIcon?: string;
  public time?: Date;
  // 当前环节图标
  public chainIcon?: string;
  public nid?: string;
  public instanceid?: string;
  // 节点名称
  public nodename?: string;

  constructor(profile: string, title: string, roleName: string, roleIcon: string,
              timeIcon: string, time: Date, nid: string, instanceid: string) {
    this.profile = profile;
    this.title = title;
    this.roleName = roleName;
    this.roleIcon = roleIcon;
    this.timeIcon = timeIcon;
    this.time = time;
    this.nid = nid;
    this.instanceid = instanceid;
  }
}
