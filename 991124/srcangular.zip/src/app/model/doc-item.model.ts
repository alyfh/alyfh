import {Item} from './item.model';
import {AttachFile} from './attach-file.model';

export class DocItem extends Item {
  public CFWZ: string ; // '存放位置';
  public DEPTID: string ; // '0007.0002';
  public DEPTNAME: string ; // '项目二部';
  public GDDATE: string ; // '2018-06-06';
  public GDUSERID: string ; // 'zhangqun';
  public GDUSERNAME: string ; // '张群';
  public GJC: string ; // '关键词';
  public GWZW: string ; // '1665';
  public INSTANCEID: string ; // null;
  public JUANZONG: string ; // '卷宗';
  public MIJI: string ; // '普通';
  public MULUNAME: string ; // null;
  public MULUSNO: string ; // null;
  public NIANXIAN: string ; // '5';
  public ORGCODE: string ; // 'root';
  public SNO: string ; // '6';
  public TITLE: string ; // '标题';
  public WENHAO: string ; // '文号';
  public YEAR: string ; // '年份';
  public ZBUSERID: string ; // 'zhangqun';
  public ZBUSERNAME: string ; // '张群';
  public files: AttachFile[] = [];
}
