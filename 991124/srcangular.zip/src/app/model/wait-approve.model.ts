import {Approve} from './approve.model';

export class WaitApprove extends Approve {
}
