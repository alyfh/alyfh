export class WorkActLog {
  public ACTIONTYPE: string; // "N";
  public ACTOR: string; // "lvxiubin";
  public ACTORNAME: string; // "吕秀彬";
  public ASSIGNER: string; // "张群";
  public ASSIGNTYPE: string; // "N";
  public BEGINTIME: string; // "2018-05-29 17:05:string ; //34";
  public DEPTID: string; // "0007.0002";
  public DEPTNAME: string; // "项目二部";
  public ENDTIME: string; // "2018-05-30 09: //51:string ; //53";
  public FLOWID: string; // "swsplc";
  public INSTANCEID: string; // 2091;
  public NID: string; // 5352;
  public NODEID: string; // "22";
  public NODENAME: string; // "部门负责人审批";
  public NODETYPE: string; // "A";
  public ORGID: string; // "root";
  public ORGNAME: string; // "北京普巴软件有限公司";
  public PARENTNID: string; // 5351;
  public REDOITEM: string; // "0";
  public SCORE: string; // 0;
  public USERPK: string; // 2;
  public WORKTYPE: string; // "A";
}
