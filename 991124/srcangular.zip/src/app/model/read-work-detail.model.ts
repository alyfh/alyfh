export class ReadWorkDetail {
  public archiveflag: string = '';
  public instanceid: string = '';
  public orgcode: string = '';
  public qjmx: string = null;
  public qjsm: string = 'b';
  public sno: string = '';
  public spyj: string = '';
  public sqdate: string = null;
  public sqnum: string = '2';
  public squserid: string = 'zhangqun';
  public squsername: string = '张群';
  public status: string = 'a;b';
  public yjbh: string = '';
  public yjlb: string = null;
}
