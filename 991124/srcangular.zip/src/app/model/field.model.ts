/**
 * 列字段说明
 */
export class Field {
  public accessible: string ; // '';

  public ajaxParam1: string[] ; // [];

  public ajaxparam: string[] ; // [];

  public alias: string ; // '';

  public align: string ; // '';

  public associable: string ; // 'N';

  public bind: string ; // 'Y';

  public ctlStyle: string ; // '';

  public defaultvalue: string ; // '';

  public dictid: string ; // '';

  public fieldid: string ; // 'sno';

  public fieldname: string ; // '流水号';

  public fields: string[] ; // [];

  public fields1: string[] ; // [];

  public fieldsize: string ; // '22';

  public keyClickScript: string ; // '';

  public language: string[] ; // [];

  public mapping: string ; // '';

  public maxvalue: string ; // '';

  public minvalue: string ; // '';

  public modifyscript: string ; // '';

  public multitle: string ; // '';

  public notnullable: string ; // 'NO';

  public onKeyClick: string ; // '';

  public onchange: string ; // '';

  public param: string ; // '';

  public parentnode: string ; // '';

  public showWidth: string ; // '';

  public showtype: string ; // 'HIDDEN';

  public textStyle: string ; // '';

  public valuetype: string ; // 'DOUBLE';
}
