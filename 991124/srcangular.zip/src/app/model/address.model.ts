import {User} from './user.model';

export class Address {
  public SEQNO: string; // "18";
  public HPHONE1: string; // null;
  public NAME: string; // "张耀伟";
  public HPHONE3: string; // null;
  public HPHONE2: string; // null;
  public OTHERS3: string; // null;
  public OPHONE1: string; // null;
  public SORTNO: string; // "18";
  public OPHONE2: string; // null;
  public DEPTNAME: string; // "项目二部";
  public ORGID: string; // "root";
  public OPHONE3: string; // null;
  public POSTID: string; // null;
  public POSTNAME: string; // null;
  public OTHERS2: string; // null;
  public OTHERS1: string; // null;
  public ID: string; // "18";
  public DEPTID: string; // "0007.0002";
  public MPHONE1: string; // null;
  public MPHONE2: string; // null;
  public MPHONE3: string; // null;
  public CODE: string; // "zhangyaowei"
  public user: User;
}
