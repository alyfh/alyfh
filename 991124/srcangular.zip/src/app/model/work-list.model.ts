import {Approve} from './approve.model';

export class WorkList {
  public name:  '待办'|'待阅'|'已办';
  public list: Approve[];
}
