export class DoWork {
  /**
   * 角色
   */
  public ACTOR: string = 'zhangqun'; // 角色
  public ACTORNAME: string = '张群'; // 角色名称
  public AGENTITEM: string = '1';
  public APPDATA: string = null;
  public ARCHIVED: string = 'N';
  public ASSIGNER: string = '张群';
  public ASSIGNTYPE: string = 'N';
  public CHANGEFLAG: string = 'Y';
  public CHANGEITEM: string = '0';
  public COMMENTS: string = null;
  public DEPTID: string = '0007.0002';
  public DEPTNAME: string = '项目二部';
  public DEPTNAMEPATH: string = null;
  public FLOWBEGIN: string = '2018-08-22 14:06:56';
  public FLOWEVAL: string = null;
  public FLOWID: string = 'fwsplc';
  public FLOWNAME: string = '公司发文审批流程';
  public FLOWORG: string = 'root';
  public FLOWSTATE: string = 'N';
  public FLOWVER: string = '16';
  public FLOWVORGCODE: string = null;
  public HANGUPFLAG: string = 'Y';
  public INITIATOR: string = 'zhangqun';
  public INITIATORNAME: string = '张群';
  public INSTANCEID: string = '2196';
  public NID: string = '5723';
  public NODEBEGIN: string = '2018-08-22 14:09:42';
  public NODEEND: string = null;
  public NODEID: string = '3';
  public NODENAME: string = '部门会签';
  public NODETYPE: string = 'A';
  public ORGID: string = 'root';
  public ORGNAME: string = '北京普巴软件有限公司';
  public PARENTNID: string = '5722';
  public RETURNFLAG: string = 'Y';
  public RETURNITEM: string = '0';
  public SRCNODE: string = null;
  public SUPERINSTANCE: string = '0';
  public SUPERNID: string = '0';
  public SUPNUM: string = '0';
  public TITLE: string = '【发文】app测试用';
  public TRANSACTOR: string = null;
  public UNDOFLAG: string = 'Y';
  public URGEFLAG: string = 'N';
  public URGEITEM: string = '0';
  public USERPK: string = '32';
  public VORGCODE: string = null;
  public WORKTYPE: string = 'G';
}
