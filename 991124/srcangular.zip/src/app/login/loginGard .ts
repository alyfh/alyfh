import {ActivatedRouteSnapshot, CanActivate, CanDeactivate, Router, RouterStateSnapshot} from '@angular/router';
import {Injectable} from '@angular/core';

@Injectable()
export class LoginGard implements CanActivate {
  // constructor(private router: Router) {
  //
  // }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    // console.log('route', route);
    // console.log('state', state);
    return true;
  }
}
