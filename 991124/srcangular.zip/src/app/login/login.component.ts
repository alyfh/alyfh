import {Component, OnInit} from '@angular/core';
import {
  AbstractControl,
  FormBuilder,
  FormGroup,
  Validators
} from '@angular/forms';
import {AjaxService} from '../service/ajax.service';
import {NzModalService} from 'ng-zorro-antd';
import {Router} from '@angular/router';
import {LoginService} from './login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  validateForm: FormGroup;
  usercode;
  password;

  constructor(private fb: FormBuilder,
              public ajax: AjaxService,
              private nzModal: NzModalService,
              public router: Router,
              public loginService: LoginService
  ) {
  }

  submitForm(): void {
    for (const i in this.validateForm.controls) {
      this.validateForm.controls[i].markAsDirty();
      this.validateForm.controls[i].updateValueAndValidity();
    }
    // console.log(this.validateForm.status);
    if (this.validateForm.status === 'VALID') {
      console.log('====valid====');
      this.ajax.login('login.dbe', {usercode: this.usercode, pwd: this.password, orgcode: 'root'}).subscribe(
        data => {
          const res = data.response.valueOf();
          let json;
          if (typeof res === 'string') {
            json = JSON.parse(res);
          } else {
            json = res;
          }

          if (json.errcode === 0) {
            this.ajax.token = json.data.access_token;
            this.loginService.login = json.data.login;
            this.router.navigate(['/approve/content/待办']);
          } else {
            // 弹出失败提示
            this.nzModal.error({
              nzTitle: '登陆失败',
              nzContent: json.errmsg
            });
          }
        }
      );
    }
  }

  ngOnInit(): void {
    this.validateForm = this.fb.group({
      userName: [null, [Validators.required]],
      password: [null, [Validators.required]],
      remember: [true]
    });
  }
}
