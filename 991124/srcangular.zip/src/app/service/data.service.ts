import {Injectable} from '@angular/core';

import {Observable} from 'rxjs';
// import {Condition} from "../../model/condition";
import * as $ from 'jquery';
import {environment} from '../../environments/environment';
import {HttpClient} from '@angular/common/http';

@Injectable()
export class DataService {
  sessionid;
  basepath;
  daqpath;

  constructor(public  http: HttpClient) {
    this.basepath = environment.pobaurl;
    // $.ajax({
    //   type: 'GET',
    //   async: false,
    //   url: 'data/ip-config.json'
    //   // @ts-ignore
    // }).success((data) => {
    //   this.basepath = data.ip;
    //   this.daqpath = data.daqip;
    // });
    // this.basepath=environment.ip;
    // this.daqpath=environment.daqip;
  }

  getData(url, condition?: any): Observable<any> {
    const headers1 = new Headers({'Content-Type': 'application/json', 'Authorization': this.sessionid});
    if (condition === undefined) {
      return this.http.get(this.basepath + url);
    } else {
      return this.http.post(this.basepath + url,
        condition);
    }
  }

  post(url, data): Observable<any> {
    const headers1 = new Headers({'Content-Type': 'application/json', 'Authorization': this.sessionid});
    return this.http.post(this.basepath + url, data);

  }

  /*  postToDAQ(url, data): Observable<any> {
      const headers1 = new Headers({'Content-Type': 'application/json', 'Authorization': this.sessionid});
      return this.http.post(
        this.daqpath + url,
        JSON.stringify(data),
        {headers: headers1});

    }

    getDataByString(url, str): Observable<any> {
      const headers1 = new Headers({'Content-Type': 'application/json'});
      return this.http.post(this.basepath + url,
        str,
        {headers: headers1});

    }


    saveData(url, condition?: any): Observable<any> {
      const headers1 = new Headers({'Content-Type': 'application/json', 'Authorization': this.sessionid});
      if (condition === undefined) {
        return this.http.get(this.basepath + url,
          {headers: headers1});
      } else {
        return this.http.post(this.basepath + url,
          JSON.stringify(condition),
          {headers: headers1});
      }
    }*/
}
