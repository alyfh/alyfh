import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {environment} from '../../environments/environment';
import {ajax, AjaxResponse} from 'rxjs/ajax';
import {map} from 'rxjs/operators';
import {Result} from '../model/result.model';

@Injectable()
export class AjaxService {
  token;

  constructor() {
  }

  login(url, condition): Observable<AjaxResponse> {
    const total_url = environment.pobaurl + url;
    // const total_url = '/api/' + url ;
    return ajax.post(total_url, condition);
  }

  post(url, condition): Observable<AjaxResponse> {
    if (condition.access_token === undefined) {
      condition.access_token = this.token;
    }
    // console.log('start post!!!!');
    let total_url;
    if (url.substr(0, 4) === 'http') {
      total_url = url;
    } else {
      total_url = environment.pobaurl + url;
    }
    return ajax.post(total_url, condition);
  }

  getTongz(url) {
    return ajax.get(url);
  }

  get(url, condition): Observable<AjaxResponse> {
    if (condition.access_token === undefined) {
      condition.access_token = this.token;
    }
    console.log('start get!!!!');
    const total_url = environment.pobaurl + url;
    return ajax.get(total_url, condition);
  }

  saveData(url, data) {
    // const headers1 = new Headers({ 'Content-Type': 'application/json' });
    // return this.http.post('http://localhost:8080/'+url,
    //   JSON.stringify(data),
    //   { headers: headers1 });
  }

  postData(url, condition): Observable<Result> {
    if (condition.access_token === undefined) {
      condition.access_token = this.token;
    }
    let total_url;
    if (url.substr(0, 4) === 'http') {
      total_url = url;
    } else {
      total_url = environment.pobaurl + url;
    }
    return ajax.post(total_url, condition).pipe(map(data => data.response.valueOf()));
  }
}
