import { Injectable } from '@angular/core';
import {Observable} from 'rxjs';
import {ApiUrl} from '../../emun/api-url.emun';
import {map} from 'rxjs/operators';
import {AjaxService} from '../../service/ajax.service';
import {NzModalService} from 'ng-zorro-antd';

/**
 * 处理工作流相关方法
 */
@Injectable({
  providedIn: 'root'
})
export class WorkflowService {

  constructor(private ajaxService: AjaxService,
              private modalService: NzModalService) { }
  /**
   * 提交工作
   */
  submitWork(nid, userCode): Observable<any> {
    return this.ajaxService.post(ApiUrl.SubmitWork, {
      nid: nid, actors: userCode
    }).pipe(map(data => {
      const res = data.response.valueOf();
      if (res.errcode === 0) {
        if (res.data.result === '0') {
          this.modalService.success({
            nzTitle: '提交成功',
            nzContent: res.data.message
          });
        } else {
          this.modalService.error({
            nzTitle: '提交失败',
            nzContent: res.data.message
          });
        }
      } else {
        this.modalService.error({
          nzTitle: '提交失败',
          nzContent: res.errmsg
        });
      }
    }));
  }
}
