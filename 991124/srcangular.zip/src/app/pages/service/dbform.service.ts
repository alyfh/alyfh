import {Injectable} from '@angular/core';
import {forkJoin, from, Observable} from 'rxjs';
import {WorkList} from '../../model/work-list.model';
import {ApiUrl} from '../../emun/api-url.emun';
import {map} from 'rxjs/operators';
import {Approve} from '../../model/approve.model';
import * as moment from 'moment';
import {WaitApprove} from '../../model/wait-approve.model';
import {Detail} from '../../model/detail.model';
import {AjaxService} from '../../service/ajax.service';
import {AjaxResponse} from 'rxjs/ajax';
import * as _ from 'lodash';
import {Result} from '../../model/result.model';

@Injectable({
  providedIn: 'root'
})
export class DbformService {
  approveList: Approve[] = [];
  title: string;
  timeIcon = 'assets/img/head-portrait/time@2x.png';
  items: string[][]; // 可选择的列表：String[][0]--号，String[][1]--名
  nid; // 当前节点id // 当前被激活的文书档案
  activeDoc: any;
  activeItem: any;
  activeDetail: Detail; // 当前细节
  allWork: WorkList[];

  constructor(public ajaxService: AjaxService) {
  }

  /**
   * 获取待办工作列表
   * http://oa.pobasoft.com/oa/api/dbform/query.dbe
   * access_token 04ABCE1897AE47E2AF2C8B79986C51C7
   * systemid gerenbangong
   * subsysid liuchengbanli
   * modid daibangongzuo
   * pageNo 1
   * pageSize 2
   */
  getToDoWork(): Observable<WorkList> {
    const url = ApiUrl.Query;
    const condition = {
      systemid: 'gerenbangong',
      subsysid: 'liuchengbanli',
      modid: 'daibangongzuo',
      pageNo: '1',
      pageSize: '1000'
    };
    return this.ajaxService.postData(url, condition).pipe(map(data => {
      const approveList: Approve[] = [];
      data.data.recordset.forEach(e => {
        const date: Date = moment(e.NODEBEGIN, 'YYYY-MM-DD HH:mm:ss').toDate();
        approveList.push(new WaitApprove('assets/img/head-portrait/per@2x.png',
          e.TITLE, e.ACTORNAME, 'assets/img/head-portrait/account@2x.png', this.timeIcon,
          date, e.NID, e.INSTANCEID
        ));
      });
      return {list: approveList, name: '待办'} as WorkList;
    }));
  }

  /**
   * 获取待阅工作列表
   */
  getToReadWork(): Observable<WorkList> {
    const url = ApiUrl.Query;
    const condition = {
      systemid: 'gerenbangong',
      subsysid: 'liuchengbanli',
      modid: 'daiyuegongzuo',
      pageNo: '1',
      pageSize: '1000'
    };
    return this.ajaxService.postData(url, condition).pipe(map(data => {
      const approveList: Approve[] = [];
      data.data.recordset.forEach(e => {
        const date: Date = moment(e.DONETIME, 'YYYY-MM-DD HH:mm:ss').toDate();
        approveList.push(new WaitApprove('assets/img/head-portrait/per@2x.png',
          e.TITLE, e.ACTORNAME, 'assets/img/head-portrait/account@2x.png', this.timeIcon,
          date, e.NID, e.INSTANCEID
        ));
      });
      return {list: approveList, name: '待阅'} as WorkList;
    }));
  }

  /**
   * 获取已办工作列表
   */
  getDoneWork(): Observable<WorkList> {
    const url = ApiUrl.Query;
    const condition = {
      systemid: 'gerenbangong',
      subsysid: 'liuchengbanli',
      modid: 'yibangongzuo',
      pageNo: '1',
      pageSize: '1000'
    };
    return this.ajaxService.postData(url, condition).pipe(map<Result, WorkList>(data => {
      const approveList: Approve[] = [];
      data.data.recordset.forEach(e => {
        const date: Date = moment(e.NODEBEGIN, 'YYYY-MM-DD HH:mm:ss').toDate();
        const approve = new WaitApprove('assets/img/head-portrait/per@2x.png',
          e.TITLE, e.ACTORNAME, 'assets/img/head-portrait/account@2x.png', this.timeIcon,
          date, e.NID, e.INSTANCEID
        );
        approve.chainIcon = '';
        approve.nodename = e.NODENAME;
        approveList.push(approve);
      });
      return {list: approveList, name: '已办'} as WorkList;
    }));
  }

  getWorkList(): Observable<WorkList[]> {
    return forkJoin<WorkList>(this.getToDoWork(), this.getToReadWork(), this.getDoneWork()).pipe(
      map(works => {
        this.allWork = works;
        return works;
      })
    );
  }

  /**
   * 获取通知列表
   */
  getNoticeList(): Observable<AjaxResponse> {
    const url = ApiUrl.Query;
    const condition = {
      systemid: 'xinxiguanli',
      subsysid: 'tongzhigonggao',
      modid: 'gonggaochakan',
      pageNo: '1',
      pageSize: '1000'
    };
    return this.ajaxService.post(url, condition);
  }

  /**
   * 获取文书档案
   */
  getDocumentList(): Observable<AjaxResponse> {
    const url = ApiUrl.Query;
    const condition = {
      systemid: 'danganguanli',
      subsysid: 'gongwendangan',
      modid: 'danganchakan',
      pageNo: '1',
      pageSize: '1000'
    };
    return this.ajaxService.post(url, condition);
  }

  /**
   * 获取已阅工作
   */
  getReadList(): Observable<AjaxResponse> {
    const url = ApiUrl.Query;
    const condition = {
      systemid: 'gerenbangong',
      subsysid: 'liuchengbanli',
      modid: 'yiyuegongzuo',
      pageNo: '1',
      pageSize: '1000'
    };
    return this.ajaxService.post(url, condition);
  }

  /**
   * 获取通讯录
   */
  getAddressList(): Observable<AjaxResponse> {
    const url = ApiUrl.Query;
    const condition = {
      systemid: 'gerenbangong',
      subsysid: 'tongxunlu',
      modid: 'danweitongxunlu',
      pageNo: '1',
      pageSize: '1000'
    };
    return this.ajaxService.post(url, condition);
  }

  getApproveList(name: '待办' | '待阅' | '已办'): Observable<Approve[]> {
    if (this.allWork === undefined) {
      return this.getWorkList().pipe(map(allWork => {
        this.allWork = allWork;
        return _.keyBy(allWork, 'name')[name].list;
      }));
    } else {
      return Observable.create((obs) => {
        obs.next(_.keyBy(this.allWork, 'name')[name].list);
      });
    }
  }

  getActiveDetail() {
    return this.activeDetail;
  }

  setActiveDetail(detail) {
    this.activeDetail = detail;
  }
}
