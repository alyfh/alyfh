import { Injectable } from '@angular/core';
import {User} from '../../model/user.model';
import {BehaviorSubject} from 'rxjs';
import {Department} from '../../model/department.model';
import {Detail} from '../../model/detail.model';
import {AjaxService} from '../../service/ajax.service';
import {ApiUrl} from '../../emun/api-url.emun';

@Injectable({
  providedIn: 'root'
})
export class OuService {
  title: string;
  timeIcon = 'assets/img/head-portrait/time@2x.png';
  departmentsSubject: BehaviorSubject<Department[]> = new BehaviorSubject(null);
  items: string[][]; // 可选择的列表：String[][0]--号，String[][1]--名
  nid; // 当前节点id
  // 当前被激活的文书档案
  activeDoc: any;
  activeItem: any;
  activeDetail: Detail; // 当前细节
  constructor(public ajaxService: AjaxService) { }
  /**
   * 获取所有部门及人员信息
   * @param departments
   */
  getAllDepartment() {
    let departments;
    let i = 0;
    this.ajaxService.postData(ApiUrl.GetDepartments, {
    }).subscribe(data => {
      departments = data.data;
      const subscribtions = [];
      departments.forEach(e => {
        subscribtions.push(this.ajaxService.post(ApiUrl.GetUsers, {
          departmentCode: e.code
        }).subscribe(res => {
          e.users = res.response.valueOf().data;
          i++;
          if (i === departments.length) {
            this.departmentsSubject.next(departments);
          }
        }));
      });
    });
    return this.departmentsSubject;
  }

  getDepartmentByItems() {
    this.items.forEach((e: string[]) => {
      const code = e[0];
    });
  }

  getAllUsersByItems(): User[] {
    const users: User[] = [];
    this.items[0].forEach((e: string, i) => {
      const user: User = new User();
      user.code = e;
      user.userName = this.items[1][i];
      user.check = false;
      users.push(user);
    });
    return users;
  }
}
