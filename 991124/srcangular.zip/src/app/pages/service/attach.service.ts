import {Injectable} from '@angular/core';
import {Detail} from '../../model/detail.model';
import * as Rx from 'rxjs';
import * as _ from 'lodash';
import {ApiUrl} from '../../emun/api-url.emun';
import {map} from 'rxjs/operators';
import {AjaxService} from '../../service/ajax.service';
import {Observable} from 'rxjs';
import {AttachFile} from '../../model/attach-file.model';
import {environment} from '../../../environments/environment';

/**
 * 用于处理附件相关的方法
 */
@Injectable({
  providedIn: 'root'
})
export class AttachService {

  constructor(public ajaxService: AjaxService) {
  }

  /**
   * 获取详情里面的附件(发文正文+发文附件)
   * @param detail
   */
  getBodyAttach(detail: Detail): Observable<AttachFile[]> {
    const obs = [];
    // 查找附件
    detail.fields.forEach(e => {
      if (e.fieldname.indexOf('发文正文') >= 0
        || e.fieldname.indexOf('发文附件') >= 0
        || e.fieldname.indexOf('来文正文') >= 0
        || e.fieldname.indexOf('来文附件') >= 0) {
        const fileids = detail.data[e.fieldid];
        if (fileids && fileids !== '') {
          obs.push(this.getAttachFiles(fileids));
        }
      }
    });
    return Rx.forkJoin(obs).pipe(map(files => _.flattenDeep(files)));
  }

  /**
   * 根据id串获取附件信息
   * @param GWZW
   */
  getAttachFiles(GWZW: string) {
    const fileids = GWZW.split(',');
    const obs = [];
    fileids.forEach(e => {
      obs.push(this.ajaxService.post(ApiUrl.EFormAttach, {id: GWZW}));
    });
    return Rx.forkJoin(obs).pipe(map(
      ajaxobs => {
        return ajaxobs.map(e => e.response.valueOf().data);
      }
    ));
  }
  /**
   * 下载附件
   * @param id
   */
  download(id: any) {
    window.open(`${environment.pobaurl}${ApiUrl.DownloadAttach}?id=${id}&access_token=${this.ajaxService.token}`);
  }
}
