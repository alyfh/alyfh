import {Injectable} from '@angular/core';
import {ApiUrl} from '../../emun/api-url.emun';
import {AjaxService} from '../../service/ajax.service';
import {Result} from '../../model/result.model';
import {NzModalService} from 'ng-zorro-antd';
import {Observable} from 'rxjs';
import {map} from 'rxjs/operators';
import {WorkActLog} from '../../model/work-act-log.model';

/**
 * 意见接口访问
 */
@Injectable({
  providedIn: 'root'
})
export class CommentService {

  constructor(public ajaxService: AjaxService,
              public modalService: NzModalService) {
  }

  /**
   * 保存阅读意见/api/workflow/saveReadComment.dbe
   */
  saveReadComment(comment: string, nid: string) {
    this.ajaxService.postData(ApiUrl.SaveReadComment,
      {comment: comment, nid: nid})
      .subscribe(res => {
        if (res.errcode === 0) {
          this.modalService.success({
            nzTitle: '保存成功'
          });
        } else {
          this.modalService.error({
            nzTitle: '保存失败',
            nzContent: res.errmsg
          });
        }
      });
  }

  /**
   * 获取阅读意见
   * @param instanceid
   */
  getReadComment(instanceid: string): Observable<Result> {
    return this.ajaxService.postData(ApiUrl.GetReadActLog, {instanceid: instanceid})
      .pipe(map(data => data.data));
  }

  /**
   * 保存办理意见
   * @param comment
   * @param nid
   */
  saveWorkComment(comment: string, nid: string): void {
    this.ajaxService.postData(ApiUrl.SaveWorkComment,
      {comment: comment, nid: nid})
      .subscribe(res => {
        if (res.errcode === 0) {
          this.modalService.success({
            nzTitle: '办理意见保存成功'
          });
        } else {
          this.modalService.error({
            nzTitle: '办理意见保存失败',
            nzContent: res.errmsg
          });
        }
      });
  }

  /**
   * 获取办理意见
   * @param instanceid
   */
  getWorkComment(instanceid: string): Observable<WorkActLog[]> {
    return this.ajaxService.postData(ApiUrl.GetWorkActLog, {instanceid: instanceid})
      .pipe(map(data => data.data));
  }
}
