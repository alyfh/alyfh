import {Component, OnDestroy, OnInit} from '@angular/core';

import {ActivatedRoute, Router} from '@angular/router';
import {DbformService} from '../../service/dbform.service';
import {Subscription} from 'rxjs';

@Component({
  selector: 'app-content',
  templateUrl: './content.component.html',
  styleUrls: ['./content.component.css']
})
export class ContentComponent implements OnInit, OnDestroy {
  timeIcon = 'assets/img/head-portrait/time@2x.png';
  title = '待办工作';
  subscription: Subscription;
  switchCases = [
    {name: '待办工作', route: '/todo/'},
    {name: '待阅工作', route: '/read-detail/'},
    {name: '已办工作', route: '/show-detail/已办工作/'}
  ];
  approveList;

  constructor(public dbformService: DbformService,
              public activedRoute: ActivatedRoute,
              public router: Router) {
  }

  ngOnInit(): void {
    this.activedRoute.params.subscribe((params) => {
      const name = params['name'];
      this.title = `${name}工作`;
      this.subscription = this.dbformService.getApproveList(name)
        .subscribe(approveList => this.approveList = approveList);
    });
  }

  /**
   * 跳转到详情页面
   * @param scase
   * @param item approve
   */
  goDetail(scase, item) {
    this.dbformService.activeItem = item;
    this.router.navigate([`${scase.route}${item.nid}`]);
  }

  ngOnDestroy(): void {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }
}
