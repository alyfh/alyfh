import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import * as _ from 'lodash';
import {WorkList} from '../../model/work-list.model';
import {DbformService} from '../service/dbform.service';


@Component({
  selector: 'app-approve',
  templateUrl: './approve.component.html',
  styleUrls: ['./approve.component.css']
})
export class ApproveComponent implements OnInit {

  constructor(public router: Router, public dbformService: DbformService) {
  }

  badgeopts ;
  title;

  /**
   * 点击底部图标切换菜单
   * @param opt badgeopts中的一个条目
   */
  search(opt) {
    // 激活当前点击图标
    this.badgeopts.forEach(e => e.isactive = false);
    opt.isactive = true;
    // head标题
    this.dbformService.title = `${opt.name}工作`;
    if (opt.name !== '更多') {
      this.router.navigate([`approve/content/${opt.name}`]);
    } else {
      this.router.navigate(['approve/content-more']);
    }
  }

  ngOnInit(): void {
    this.dbformService.getWorkList().subscribe((works) => {
      const keyWorks: _.Dictionary<WorkList> = _.keyBy<WorkList>(works, 'name');
      this.setBadgeopts(keyWorks);
    });
  }

  /**
   * 设置徽标数
   */
  setBadgeopts(keyWorks: _.Dictionary<WorkList>) {
    this.badgeopts = [{
      name: '待办',
      src: 'assets/img/bottom_icon/daiban_@2x.png',
      actsrc: 'assets/img/bottom_icon/daiban@2x.png',
      isactive: true, count: keyWorks['待办'].list.length
    }, {
      name: '待阅',
      src: 'assets/img/bottom_icon/daiyue_@2x.png',
      actsrc: 'assets/img/bottom_icon/daiyue@2x.png',
      isactive: false, count: keyWorks['待阅'].list.length
    },
      {
        name: '已办',
        src: 'assets/img/bottom_icon/yiban_@2x.png',
        actsrc: 'assets/img/bottom_icon/yiban@2x.png',
        isactive: false, count: 0
      },
      {
        name: '更多',
        src: 'assets/img/bottom_icon/other_@2x.png',
        actsrc: 'assets/img/bottom_icon/other@2x.png',
        isactive: false, count: 0
      }
    ];
  }
}
