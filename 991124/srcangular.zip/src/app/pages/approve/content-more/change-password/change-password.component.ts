import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {NzModalService} from 'ng-zorro-antd';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {

  validateForm: FormGroup;
  oldpassword;
  newpassword;
  confirmNewpassword;

  submitForm(): void {
    for (const i in this.validateForm.controls) {
      this.validateForm.controls[i].markAsDirty();
      this.validateForm.controls[i].updateValueAndValidity();
    }
    if (this.validateForm.status === 'VALID') {
      if (this.confirmNewpassword !== this.newpassword) {
        this.nzModal.error({
          nzTitle: '新密码与确认密码不一致',
          nzContent: ''
        });
      } else {
        /*      this.ajax.login('login.dbe', {usercode: this.usercode, pwd: this.password, orgcode: 'root'}).subscribe(
                data => {
                  const res = data.response.valueOf();
                  let json;
                  if (typeof res === 'string') {
                    json = JSON.parse(res);
                  } else {
                    json = res;
                  }

                  if (json.errcode === 0) {
                    this.ajax.token = json.data.access_token;
                    this.router.navigate(['/approve/content/待办']);
                  } else {
                    // 弹出失败提示
                    this.nzModal.error({
                      nzTitle: '登陆失败',
                      nzContent: json.errmsg
                    });
                  }
                }
              );*/
      }
    }


  }

  constructor(private fb: FormBuilder, private nzModal: NzModalService,) {
  }

  ngOnInit(): void {
    this.validateForm = this.fb.group({
      userName: [null, [Validators.required]],
      password: [null, [Validators.required]],
      remember: [true]
    });
  }
}
