import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {LoginService} from '../../../login/login.service';
import {Login} from '../../../model/login.model';
import {DbformService} from '../../service/dbform.service';

/**
 * 更多组件
 */
@Component({
  selector: 'app-content-more',
  templateUrl: './content-more.component.html',
  styleUrls: ['./content-more.component.css']
})
export class ContentMoreComponent implements OnInit {
  moreButtons = [{
    name: '通知公告',
    src: 'assets/img/more/buttons/notice@2x.png',
  }, {
    name: '文书档案',
    src: 'assets/img/more/buttons/documents@2x.png',
  },
    {
      name: '已阅工作',
      src: 'src/assets/img/more/buttons/read@2x.png',
    },
    {
      name: '通讯录',
      src: 'assets/img/more/buttons/book@2x.png',
    }
  ];
  login: Login;

  constructor(public router: Router,
              public dbformService: DbformService,
              public loginService: LoginService) {
  }

  search(opt) {
    this.dbformService.title = opt.name;
    this.router.navigate([`list/${opt.name}`]);
  }

  ngOnInit() {
    this.login = this.loginService.login;
  }

  logout() {
    this.router.navigate(['login']);
  }
}
