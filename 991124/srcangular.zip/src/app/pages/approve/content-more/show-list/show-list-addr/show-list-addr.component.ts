import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';

import * as _ from 'lodash';
import {Department} from '../../../../../model/department.model';
import {User} from '../../../../../model/user.model';
import {DbformService} from '../../../../service/dbform.service';

/**
 * 通讯录
 */
@Component({
  selector: 'app-show-list-addr',
  templateUrl: './show-list-addr.component.html',
  styleUrls: ['./show-list-addr.component.css']
})
export class ShowListAddrComponent implements OnInit {

  constructor(public dbformService: DbformService,
              public router: Router) {
  }

  list;

  ngOnInit() {
    this.dbformService.getAddressList().subscribe(data => {
      const addresslist = data.response.valueOf().data.recordset;
      this.list = [];
      const dpt = _.groupBy(addresslist, 'DEPTNAME');
      // console.log(dpt);
      _.forEach(dpt, (value, key) => {
        // console.log(key);
        const department = new Department();
        department.departName = key;
        department.active = true;
        value.forEach(e => {
          const user = new User();
          user.id = e.ID;
          user.code = e.CODE;
          user.userName = e.NAME;
          user.phonenumber = e.HPHONE1;
          user.QQ = e.QQ;
          user.home = e.home;
          user.departName = e.DEPTNAME;
          department.users.push(user);
        });
        this.list.push(department);
      });
    });
  }
  goDetail(item) {
    this.dbformService.activeItem = item;
    this.router.navigate(['/address-detail']);
  }
}
