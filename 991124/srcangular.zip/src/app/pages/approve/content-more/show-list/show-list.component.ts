import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {DbformService} from '../../../service/dbform.service';


@Component({
  selector: 'app-show-list',
  templateUrl: './show-list.component.html',
  styleUrls: ['./show-list.component.css']
})
export class ShowListComponent implements OnInit {
  constructor(public dbformService: DbformService, public router: Router) {
  }

  ngOnInit() {
  }
}
