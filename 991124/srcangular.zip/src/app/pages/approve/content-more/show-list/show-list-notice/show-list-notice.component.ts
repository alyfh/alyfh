import {Component, OnInit} from '@angular/core';
import * as moment from 'moment';
import {Item} from '../../../../../model/item.model';
import {DbformService} from '../../../../service/dbform.service';

@Component({
  selector: 'app-show-list-notice',
  templateUrl: './show-list-notice.component.html',
  styleUrls: ['./show-list-notice.component.css']
})
export class ShowListNoticeComponent implements OnInit {

  constructor(public dbformService: DbformService) {
  }

  list;

  ngOnInit() {
    this.dbformService.getNoticeList().subscribe(data => {
      const noticelist = data.response.valueOf().data.recordset;
      this.list = [];
      noticelist.forEach(e => {
        const date: Date = moment(e.SENDTIME, 'YYYY-MM-DD HH:mm:ss').toDate();
        const item = new Item('assets/img/head-portrait/per@2x.png', e.TITLE,
          e.CREATER, e.DEPTNAME, date, e.nid, '0');
        item.id = e.ID;
        this.list.push(item);
      });
    });
  }

}
