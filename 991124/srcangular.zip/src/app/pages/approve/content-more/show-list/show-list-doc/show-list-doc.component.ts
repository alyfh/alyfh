import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';

import {Router} from '@angular/router';
import {DocItem} from '../../../../../model/doc-item.model';
import {DbformService} from '../../../../service/dbform.service';

/**
 * 文书档案列表展示组件
 */
@Component({
  selector: 'app-show-list-doc',
  templateUrl: './show-list-doc.component.html',
  styleUrls: ['./show-list-doc.component.css']
})
export class ShowListDocComponent implements OnInit {

  constructor(public dbformService: DbformService,
              public router: Router) { }
  list;
  ngOnInit() {
    this.dbformService.getDocumentList().subscribe(data => {
      const doclist = data.response.valueOf().data.recordset;
      this.list = [];
      doclist.forEach(e => {
        const date: Date = moment(e.GDDATE, 'YYYY-MM-DD').toDate();
        const item: DocItem = e;
        item.profile = 'assets/img/head-portrait/per@2x.png';
        item.title = e.TITLE;
        item.userName = e.GDUSERNAME;
        item.department = e.DEPTNAME;
        item.time = date;
        item.instanceid = e.INSTANCEID;
        this.list.push(item);
      });
    });
  }
  goWensda(tlist) {
    console.log(tlist);
    this.dbformService.activeDoc = tlist;
    this.router.navigate(['/show-detail-doc/文书档案/0']);
  }
}
