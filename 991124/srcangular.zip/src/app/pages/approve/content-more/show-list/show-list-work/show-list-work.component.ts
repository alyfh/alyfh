import {Component, OnInit} from '@angular/core';
import * as moment from 'moment';
import {Item} from '../../../../../model/item.model';
import {Router} from '@angular/router';
import {DbformService} from '../../../../service/dbform.service';

/**
 * 已阅工作
 */
@Component({
  selector: 'app-show-list-work',
  templateUrl: './show-list-work.component.html',
  styleUrls: ['./show-list-work.component.css']
})
export class ShowListWorkComponent implements OnInit {

  constructor(public dbformService: DbformService, public router: Router) {
  }

  list;

  ngOnInit() {
    this.dbformService.getReadList().subscribe(data => {
      const worklist = data.response.valueOf().data.recordset;
      this.list = [];
      worklist.forEach(e => {
        const date: Date = moment(e.DONETIME, 'YYYY-MM-DD HH:mm:ss').toDate();
        const item = new Item('assets/img/head-portrait/per@2x.png',
          e.TITLE, e.ACTORNAME, e.NODENAME, date, e.NID, '0');
        item.instanceid = e.INSTANCEID;
        this.list.push(item);
      });
    });
  }

  goDetail(item) {
    this.dbformService.activeItem = item;
    this.router.navigate([`/show-detail/已阅工作/${item.nid}`]);
  }
}
