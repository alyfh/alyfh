import {Component, OnInit} from '@angular/core';
import {DocItem} from '../../../../model/doc-item.model';
import {AttachService} from '../../../service/attach.service';
import {DbformService} from '../../../service/dbform.service';

/**
 * 显示文书档案详情组件
 */
@Component({
  selector: 'app-show-detail-doc',
  templateUrl: './show-detail-doc.component.html',
  styleUrls: ['./show-detail-doc.component.css']
})
export class ShowDetailDocComponent implements OnInit {
  title = '文书档案';

  constructor(public dbformService: DbformService,
              public attachService: AttachService) {
  }

  doc: DocItem;

  ngOnInit() {
    this.doc = this.dbformService.activeDoc;
    if (this.doc.GWZW) {
      this.attachService.getAttachFiles(this.doc.GWZW).subscribe(files => {
        // console.log('文书档案附件信息', file);
        this.doc.files = files;
      });
    }
  }

  download(file) {
    this.attachService.download(file.ID);
  }
}
