import {Component, OnInit} from '@angular/core';
import {User} from '../../../../model/user.model';
import {DbformService} from '../../../service/dbform.service';

/**
 * 通讯录详情组件
 */
@Component({
  selector: 'app-address-detail',
  templateUrl: './address-detail.component.html',
  styleUrls: ['./address-detail.component.css']
})
export class AddressDetailComponent implements OnInit {
  user: User;

  constructor(public dbformService: DbformService) {
  }

  ngOnInit() {
    this.user = this.dbformService.activeItem;
  }

}
