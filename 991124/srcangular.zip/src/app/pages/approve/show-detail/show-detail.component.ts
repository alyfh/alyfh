import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Params} from '@angular/router';
import {AjaxService} from '../../../service/ajax.service';
import {Item} from '../../../model/item.model';
import {AttachFile} from '../../../model/attach-file.model';
import {AttachService} from '../../service/attach.service';
import {ApiUrl} from '../../../emun/api-url.emun';
import {Observable} from 'rxjs';
import {Result} from '../../../model/result.model';
import {flatMap} from 'rxjs/operators';
import {DbformService} from '../../service/dbform.service';

/**
 * 显示详情组件
 */
@Component({
  selector: 'app-show-detail',
  templateUrl: './show-detail.component.html',
  styleUrls: ['./show-detail.component.css']
})
export class ShowDetailComponent implements OnInit {
  title = '已阅工作';
  date = new Date();
  nid;
  fields;
  doneWorkDetail;
  id;
  item: Item = {};
  files: AttachFile[] = [];

  constructor(public activatedRoute: ActivatedRoute,
              public ajaxService: AjaxService,
              public dbformService: DbformService,
              public attachService: AttachService) {
  }

  /**
   * 发文正文，发文附件
   */
  ngOnInit() {
    const opt1 = flatMap<Params, Observable<Result>>(params => { // 路由参数
      this.nid = params['nid'];
      this.title = params['name'];
      this.item = this.dbformService.activeItem;
      if (this.title !== '文书档案') {
        return this.ajaxService.postData(ApiUrl.EformOpen, {nid: this.nid});
      }
    });
    const opt2 = flatMap<Result, Observable<AttachFile[]>>(data => {
      const res = data.data;
      this.fields = res.fields;
      this.doneWorkDetail = res.data;
      return this.attachService.getBodyAttach(res);
    });
    const observer = (files => {
      this.files = files;
    });
    this.activatedRoute.params.pipe(opt1, opt2).subscribe(observer);
  }

  download(file: AttachFile) {
    this.attachService.download(file.ID);
  }
}
