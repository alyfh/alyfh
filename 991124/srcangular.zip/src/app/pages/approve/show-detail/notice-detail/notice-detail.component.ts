import {Component, OnInit} from '@angular/core';

/**
 * 通知详情
 */
@Component({
  selector: 'app-notice-detail',
  templateUrl: './notice-detail.component.html',
  styleUrls: ['./notice-detail.component.css']
})
export class NoticeDetailComponent implements OnInit {
  date = new Date();

  constructor() {
  }

  ngOnInit() {
  }

}
