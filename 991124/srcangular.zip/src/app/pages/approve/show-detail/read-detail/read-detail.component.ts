import {Component, OnInit} from '@angular/core';
import {NzModalService} from 'ng-zorro-antd';
import {ActivatedRoute} from '@angular/router';
import {AjaxService} from '../../../../service/ajax.service';
import {Field} from '../../../../model/field.model';
import {Item} from '../../../../model/item.model';
import {ApiUrl} from '../../../../emun/api-url.emun';
import {DbformService} from '../../../service/dbform.service';

/**
 * 待阅工作详情
 */
@Component({
  selector: 'app-read-detail',
  templateUrl: './read-detail.component.html',
  styleUrls: ['./read-detail.component.css']
})
export class ReadDetailComponent implements OnInit {

  constructor(private modalService: NzModalService,
              public ajaxService: AjaxService,
              public activatedRoute: ActivatedRoute,
              public dbformService: DbformService) {
  }

  readWorkDetail: any;
  fields: Field[];
  id: number; // 表单流水号
  nid: number; // 流程节点id
  item: Item;

  ngOnInit() {
    this.activatedRoute.params.subscribe((params) => { // 路由参数
      this.item = this.dbformService.activeItem;
      this.nid = params['nid'];
      this.ajaxService.post(ApiUrl.EformOpen, {
        nid: this.nid
      }).subscribe(data => {
        const res = data.response.valueOf().data;
        this.fields = res.fields;
        this.readWorkDetail = res.data;
        this.id = res.id;
      });
    });
  }

  success(): void {
    this.ajaxService.post('workflow/readWork.dbe', {nid: this.nid}).subscribe((data) => {
      const res = data.response;
      if (res.errcode === 0) {
        this.modalService.success({
          nzTitle: '<h1>阅读完毕</h1>',
        });
      } else {
        this.modalService.error({
          nzTitle: res.errmsg,
        });
      }
    });

  }

  back() {
    window.history.go(-1);
  }
}
