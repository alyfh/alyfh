import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Params, Router} from '@angular/router';
import {NzModalService} from 'ng-zorro-antd';
import {AjaxService} from '../../../../service/ajax.service';
import {Field} from '../../../../model/field.model';
import {CommentService} from '../../../service/comment.service';
import {Item} from '../../../../model/item.model';
import {ApiUrl} from '../../../../emun/api-url.emun';
import {DbformService} from '../../../service/dbform.service';

/**
 * 待办工作明细
 */
@Component({
  selector: 'app-todo-work',
  templateUrl: './todo-work.component.html',
  styleUrls: ['./todo-work.component.css']
})
export class TodoWorkComponent implements OnInit {

  doWorkDetail: any;
  fields: Field[];
  nid;
  id; // 表单流水号
  loading = true;
  comment: string;

  constructor(public dbformService: DbformService,
              public activeRoute: ActivatedRoute,
              public ajaxService: AjaxService,
              public modalService: NzModalService,
              public router: Router,
              public commentService: CommentService) {
  }

  ngOnInit() {
    this.getExtOprate();
    const observer = (params => { // 路由参数
      const item: Item = this.dbformService.activeItem;
      this.commentService.getWorkComment(item.instanceid).subscribe(data => { // 获取评论
        console.log('comment', data);
      });
      this.nid = params['nid'];
      this.ajaxService.postData(ApiUrl.EformOpen, {
        nid: this.nid
      }).subscribe(data => {
        const res = data.data;
        this.dbformService.activeDetail = res;
        this.fields = res.fields;
        this.doWorkDetail = res.data;
        this.dbformService.activeDetail = res;
        this.id = res.id;
        this.loading = false;
      });
    });
    this.activeRoute.params.subscribe(observer);
  }

  /**
   * workflow/submitRoutes.dbe
   * 提交工作到下一个路由
   * errcode  int
   *接口调用状态码：0 成功，1 异常，-1 会话超时或令牌以失效
   *
   *errmsg  String
   *接口调用提示文：errcode为0时，提示"success"；errcode为1时，提示相应的异常提示文
   *
   *data  String
   *接口调用返回数据
   *
   *nid  String
   *操作的工作实例号
   *
   *result  String
   *操作返回结果，SUCCESS：成功；FAIL：失败；
   * ROUTE：选择路由；
   * ACTOR：选择单人办理人，如果items为空， 从组织架构选；
   * ACTORS：选择多人办理人，如果items为空，从组织架构选；
   * ACTORSORDER：选择多人排序的办理人，如果items为空，从组织架构选；
   * OPERATORS：用于竞争办理格式的人员选择；
   * GATHER：提交汇集人的工作，这时nid为汇集人的工作实例号，
   * message为汇集人的用户ID；
   *
   *items  String[][]
   *可选择的列表：String[][0]--号，String[][1]--名
   *
   *message  String
   *处理结果
   *
   *nextNodeId  String
   *下一路由节点名称
   */
  submit() {
    // 保存办理意见
    this.commentService.saveWorkComment(this.comment, this.nid);
    this.ajaxService.postData(ApiUrl.SubmitRoutes, {nid: this.nid})
      .subscribe(data => {
        const res = data.data;
        this.dbformService.items = res.items;
        switch (res.result) {
          case 'SUCCESS' : {
            this.modalService.success({
              nzTitle: '提交成功',
              nzContent: res.message
            });
            break;
          }
          case 'FAIL' : {
            this.modalService.error({
              nzTitle: '提交失败',
              nzContent: res.message
            });
            break;
          }
          case 'ACTOR' : {
            this.router.navigate([`/select-actor/${this.nid}`]);
            break;
          }
          case 'ACTORS' : {
            this.router.navigate([`/select-actors/${this.nid}`]);
            break;
          }
          case 'ROUTE' : {
            let nextNodeId = res.nextNodeId;
            if (nextNodeId === '') {
              nextNodeId = '0';
            }
            this.router.navigate([`/select-routing/${this.nid}/${nextNodeId}`]);
            break;
          }
        }
      });
  }

  reject() {
    this.ajaxService.postData(ApiUrl.BackRoutes, {
      nid: this.nid
    }).subscribe((data) => {
      const res = data.data;
      this.dbformService.items = res.items;
      this.router.navigate([`/reject-routing/${this.nid}`]);
    });
  }

  /**
   * 获取当前操作人可访问的表单额外操作，return-退回；change-转办；redo-重办；
   * assemble-会签情况；subflow-子流程情况；aid-协办情况；multi-并发办理情况
   */
  getExtOprate() {
    this.ajaxService.post(ApiUrl.GetNodeControlRight, {nid: this.nid}).subscribe(
      (data) => {
        console.log('getExtOprate', data);
      }
    );
  }

  goHandleProcess() {
    this.router.navigate([`/handle-process`]);
  }
}
