import {Component, OnInit} from '@angular/core';
import {DbformService} from '../../../../service/dbform.service';
import {Item} from '../../../../../model/item.model';
import {CommentService} from '../../../../service/comment.service';
import {WorkActLog} from '../../../../../model/work-act-log.model';

/**
 * 流程查看组件
 */
@Component({
  selector: 'app-handle-process',
  templateUrl: './handle-process.component.html',
  styleUrls: ['./handle-process.component.css']
})
export class HandleProcessComponent implements OnInit {
  date: Date = new Date();
  item: Item;
  workActLogs: WorkActLog[];

  constructor(public dbform: DbformService,
              public comment: CommentService) {
  }

  ngOnInit() {
    this.item = this.dbform.activeItem;
    // 获取办理意见
    this.comment.getWorkComment(this.item.instanceid).subscribe(data => {
      this.workActLogs = data;
    });
  }

}
