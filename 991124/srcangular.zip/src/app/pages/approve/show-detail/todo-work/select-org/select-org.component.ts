import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-select-org',
  templateUrl: './select-org.component.html',
  styleUrls: ['./select-org.component.css']
})
export class SelectOrgComponent implements OnInit {
  panels = [
    {
      active    : true,
      name      : '董事会',
      disabled  : false
    },
    {
      active  : false,
      disabled: false,
      name    : '财务部'
    },
    {
      active  : false,
      disabled: true,
      name    : '人事部'
    }
  ];
  constructor() { }

  ngOnInit() {
  }

}
