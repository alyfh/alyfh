import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {AjaxService} from '../../../../../service/ajax.service';
import {NzModalService} from 'ng-zorro-antd';
import {DbformService} from '../../../../service/dbform.service';

@Component({
  selector: 'app-select-routing',
  templateUrl: './select-routing.component.html',
  styleUrls: ['./select-routing.component.css']
})
export class SelectRoutingComponent implements OnInit {

  constructor(public activatedRoute: ActivatedRoute,
              public dbformService: DbformService,
              public router: Router,
              public ajaxService: AjaxService,
              public modalService: NzModalService) {
  }

  nid;
  nextNodeId;
  deptCode;

  ngOnInit() {
    this.activatedRoute.params.subscribe((params) => {
      this.nid = params['nid'];
    });
  }

  submit() {
    this.ajaxService.post('workflow/submitActors.dbe', {
      nid: this.nid, nextNodeId: this.nextNodeId
    }).subscribe(data => {
      const res = data.response.valueOf().data;
      // res.result = 'ACTOR';
      this.dbformService.items = res.items;
      switch (res.result) {
        case 'SUCCESS' : {
          this.modalService.success({
            nzTitle: '提交成功',
            nzContent: res.message
          });
          break;
        }
        case 'FAIL' : {
          this.modalService.error({
            nzTitle: '提交失败',
            nzContent: res.message
          });
          break;
        }
        case 'ACTOR' : {
          this.router.navigate([`/select-actor/${this.nid}`]);
          break;
        }
        case 'ACTORS' : {
          this.router.navigate([`/select-actors/${this.nid}`]);
          break;
        }
        case 'ROUTE' : {
          this.router.navigate([`/select-routing/${this.nid}/${res.nextNodeId}`]);
          break;
        }
      }
      // this.fields = res.fields;
      // this.doWorkDetail = res.data;
    });
  }
}
