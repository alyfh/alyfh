import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {AjaxService} from '../../../../../service/ajax.service';
import {NzModalService} from 'ng-zorro-antd';
import {DbformService} from '../../../../service/dbform.service';

/**
 * 驳回组件
 */
@Component({
  selector: 'app-reject-routing',
  templateUrl: './reject-routing.component.html',
  styleUrls: ['./reject-routing.component.css']
})
export class RejectRoutingComponent implements OnInit {

  constructor(public activatedRoute: ActivatedRoute,
              public dbformService: DbformService,
              public router: Router,
              public ajaxService: AjaxService,
              public modalService: NzModalService) {
  }

  nid;
  nextNodeId;
  deptCode;

  ngOnInit() {
    this.activatedRoute.params.subscribe((params) => {
      this.nid = params['nid'];
    });
  }

  reject() {
    this.ajaxService.post('workflow/backWork.dbe', {
      nid: this.nid, nextNodeId: this.nextNodeId
    }).subscribe(data => {
      const res = data.response.valueOf().data;
      // res.result = 'ACTOR';
      this.dbformService.items = res.items;
      switch (res.result) {
        case 'SUCCESS' : {
          this.modalService.success({
            nzTitle: '提交成功',
            nzContent: res.message
          });
          this.router.navigate(['/approve/content/待办']);
          break;
        }
        case 'FAIL' : {
          this.modalService.error({
            nzTitle: '提交失败',
            nzContent: res.message
          });
          break;
        }
        case 'ACTOR' : {
          this.router.navigate([`/select-actor/${this.nid}`]);
          break;
        }
        case 'ACTORS' : {
          this.router.navigate([`/select-actors/${this.nid}`]);
          break;
        }
        case 'ROUTE' : {
          this.router.navigate([`/select-routing/${this.nid}/${res.nextNodeId}`]);
          break;
        }
      }
      // this.fields = res.fields;
      // this.doWorkDetail = res.data;
    });
  }

}
