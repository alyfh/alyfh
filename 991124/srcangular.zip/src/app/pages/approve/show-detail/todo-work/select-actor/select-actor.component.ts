import {Component, OnDestroy, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {Department} from '../../../../../model/department.model';
import {Subscription} from 'rxjs';
import {User} from '../../../../../model/user.model';
import {WorkflowService} from '../../../../service/workflow.service';
import {DbformService} from '../../../../service/dbform.service';
import {OuService} from '../../../../service/ou.service';

@Component({
  selector: 'app-select-actor',
  templateUrl: './select-actor.component.html',
  styleUrls: ['./select-actor.component.css']
})
export class SelectActorComponent implements OnInit, OnDestroy {

  constructor(public activatedRoute: ActivatedRoute,
              public dbformService: DbformService,
              public router: Router, public ou: OuService,
              public workflow: WorkflowService) {
  }

  nid;
  departments: Department[];
  userCode;
  subscription: Subscription;
  users: User[];

  ngOnInit() {
    this.activatedRoute.params.subscribe((params) => {
      this.nid = params['nid'];
      if (this.dbformService.items !== null && this.dbformService.items.length !== 0) {
        // 根据items的人员
        this.users = this.ou.getAllUsersByItems();
        this.ou.getDepartmentByItems();
      } else {// 组织架构
        this.subscription = this.ou.getAllDepartment().subscribe((data) => {
          if (data !== null) {
            this.departments = data;
          }
        });
      }

    });
  }

  submit() {
    this.workflow.submitWork(this.nid, this.userCode).subscribe(data => {
      this.dbformService.getWorkList().subscribe(works => {
        this.router.navigate(['/approve/content/待办']);
      });
    });
  }

  ngOnDestroy(): void {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }
}
