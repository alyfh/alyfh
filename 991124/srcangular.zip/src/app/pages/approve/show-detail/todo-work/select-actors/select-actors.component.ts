import {Component, OnDestroy, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {Department} from '../../../../../model/department.model';
import * as _ from 'lodash';
import {User} from '../../../../../model/user.model';
import {Subscription} from 'rxjs';
import {WorkflowService} from '../../../../service/workflow.service';
import {DbformService} from '../../../../service/dbform.service';
import {OuService} from '../../../../service/ou.service';

@Component({
  selector: 'app-select-actors',
  templateUrl: './select-actors.component.html',
  styleUrls: ['./select-actors.component.css']
})
export class SelectActorsComponent implements OnInit, OnDestroy {
  nid;
  departments: Department[];
  userCodes = [];
  subscription: Subscription;
  users: User[];

  constructor(public activatedRoute: ActivatedRoute,
              public dbformService: DbformService,
              public ou: OuService,
              public router: Router,
              private workflow: WorkflowService) {
  }

  ngOnInit() {
    this.activatedRoute.params.subscribe((params) => {
      this.nid = params['nid'];
      if (this.dbformService.items !== null && this.dbformService.items.length !== 0) {
        // 根据items的人员
        // this.users = this.dbformService.getAllUsersByItems();
        // this.dbformService.getDepartmentByItems();
        this.dbformService.items.forEach(item => {
          const user: User = new User();
          user.code = item[0];
          user.userName = item[1];
          user.check = false;
        });
      } else {// 组织架构
        this.subscription = this.ou.getAllDepartment().subscribe((data) => {
          if (data !== null) {
            this.departments = data;
          }
        });
      }
    });
  }

  submit() {
    this.workflow.submitWork(this.nid, this.userCodes.join(',')).subscribe((data) => {
      console.log('content/待办');
      this.router.navigate(['/approve/content/待办']);
    });
  }

  isCheck(user) {
    // console.log(this.userCodes);
    if (user.check) {
      this.userCodes.push(user.code);
    } else {
      _.pull(this.userCodes, user.code);
    }
    // console.log(this.userCodes);
  }

  ngOnDestroy(): void {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }
}
