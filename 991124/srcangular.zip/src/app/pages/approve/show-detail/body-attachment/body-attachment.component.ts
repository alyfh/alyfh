import {Component, OnInit} from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {AjaxService} from '../../../../service/ajax.service';
import {NzModalService} from 'ng-zorro-antd';
import {Detail} from '../../../../model/detail.model';
import {AttachService} from '../../../service/attach.service';
import {Item} from '../../../../model/item.model';
import {DbformService} from '../../../service/dbform.service';

/**
 * 待办工作:发文正文,发文附件
 */
@Component({
  selector: 'app-body-attachment',
  templateUrl: './body-attachment.component.html',
  styleUrls: ['./body-attachment.component.css']
})
export class BodyAttachmentComponent implements OnInit {
  date = new Date();

  constructor(public activatedRoute: ActivatedRoute, public ajax: AjaxService,
              public modalService: NzModalService,
              public dbformService: DbformService,
              public attachService: AttachService) {
  }

  detail: Detail;
  item: Item;

  ngOnInit() {
    this.activatedRoute.params.subscribe(params => {
      this.detail = this.dbformService.getActiveDetail();
      this.item = this.dbformService.activeItem;
      this.attachService.getBodyAttach(this.detail).subscribe(files => {
        this.detail.bodyAttach = files;
      });
    });
  }

  back() {
    window.history.go(-1);
  }

}
