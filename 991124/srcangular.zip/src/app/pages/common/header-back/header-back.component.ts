import {Component, EventEmitter, Input, OnInit} from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'app-header-back',
  templateUrl: './header-back.component.html',
  styleUrls: ['./header-back.component.css']
})
export class HeaderBackComponent implements OnInit {
  @Input() title;
  @Input() backLink;
  @Input() goback = new EventEmitter();

  constructor(public router: Router) {
  }

  ngOnInit() {
  }

  back() {
    // if (this.backLink !== undefined) {
    //   // this.goback.emit();
    //   this.router.navigate([this.backLink]);
    //   console.log('this.goback.emit();');
    // } else {
      window.history.go(-1);
    // }

  }
}
