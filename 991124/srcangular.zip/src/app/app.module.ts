import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';

import {AppComponent} from './app.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {NgZorroAntdModule, NZ_I18N, zh_CN} from 'ng-zorro-antd';
import {registerLocaleData} from '@angular/common';
import zh from '@angular/common/locales/zh';
import {LoginComponent} from './login/login.component';
import {routing} from './app.routing';
import {BadgeComponent} from './common/badge/badge.component';
import {SearchComponent} from './common/search/search.component';
import {ApproveComponent} from './pages/approve/approve.component';
import {HandleProcessComponent} from './pages/approve/show-detail/todo-work/handle-process/handle-process.component';
import {BodyAttachmentComponent} from './pages/approve/show-detail/body-attachment/body-attachment.component';
import {SelectRoutingComponent} from './pages/approve/show-detail/todo-work/select-routing/select-routing.component';
import {SelectOrgComponent} from './pages/approve/show-detail/todo-work/select-org/select-org.component';
import {ChangePasswordComponent} from './pages/approve/content-more/change-password/change-password.component';
import {AboutUsComponent} from './pages/approve/content-more/about-us/about-us.component';
import {AddressDetailComponent} from './pages/approve/show-detail/address-detail/address-detail.component';
import {HeaderBackComponent} from './pages/common/header-back/header-back.component';
import {DataService} from './service/data.service';
import {AjaxService} from './service/ajax.service';
import { SelectActorComponent } from './pages/approve/show-detail/todo-work/select-actor/select-actor.component';
import {SelectActorsComponent} from './pages/approve/show-detail/todo-work/select-actors/select-actors.component';
import {LoginGard} from './login/loginGard ';
import { RejectRoutingComponent } from './pages/approve/show-detail/todo-work/reject-routing/reject-routing.component';
import {ContentComponent} from './pages/approve/content/content.component';
import {ContentMoreComponent} from './pages/approve/content-more/content-more.component';
import {ShowListComponent} from './pages/approve/content-more/show-list/show-list.component';
import {ListContentComponent} from './pages/approve/content/list-content/list-content.component';
import {ShowListDocComponent} from './pages/approve/content-more/show-list/show-list-doc/show-list-doc.component';
import {ShowListWorkComponent} from './pages/approve/content-more/show-list/show-list-work/show-list-work.component';
import {ShowListNoticeComponent} from './pages/approve/content-more/show-list/show-list-notice/show-list-notice.component';
import {ShowListAddrComponent} from './pages/approve/content-more/show-list/show-list-addr/show-list-addr.component';
import {ReadDetailComponent} from './pages/approve/show-detail/read-detail/read-detail.component';
import {NoticeDetailComponent} from './pages/approve/show-detail/notice-detail/notice-detail.component';
import {ShowDetailComponent} from './pages/approve/show-detail/show-detail.component';
import {ShowDetailDocComponent} from './pages/approve/show-detail/show-detail-doc/show-detail-doc.component';
import {TodoWorkComponent} from './pages/approve/show-detail/todo-work/todo-work.component';
import { SearchPipe } from './common/search/search.pipe';
import {LoginService} from './login/login.service';
import {CommentService} from './pages/service/comment.service';


registerLocaleData(zh);

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    BadgeComponent,
    SearchComponent,
    ContentComponent,
    ContentMoreComponent,
    ApproveComponent,
    ShowListComponent,
    TodoWorkComponent,
    HandleProcessComponent,
    BodyAttachmentComponent,
    SelectRoutingComponent,
    SelectActorsComponent,
    SelectOrgComponent,
    ReadDetailComponent,
    NoticeDetailComponent,
    ChangePasswordComponent,
    AboutUsComponent,
    ShowDetailComponent,
    AddressDetailComponent,
    HeaderBackComponent,
    ListContentComponent,
    SelectActorComponent,
    RejectRoutingComponent,
    ShowDetailDocComponent,
    ShowListDocComponent,
    ShowListAddrComponent,
    ShowListNoticeComponent,
    ShowListWorkComponent,
    SearchPipe
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    NgZorroAntdModule, ReactiveFormsModule, routing, HttpClientModule
  ],
  providers: [{provide: NZ_I18N, useValue: zh_CN}, DataService, AjaxService, LoginGard,
    LoginService, CommentService
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
}
