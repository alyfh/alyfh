import {Routes, RouterModule} from '@angular/router';
import {ModuleWithProviders} from '@angular/core';
import {LoginComponent} from './login/login.component';
import {ApproveComponent} from './pages/approve/approve.component';
import {HandleProcessComponent} from './pages/approve/show-detail/todo-work/handle-process/handle-process.component';
import {BodyAttachmentComponent} from './pages/approve/show-detail/body-attachment/body-attachment.component';
import {SelectRoutingComponent} from './pages/approve/show-detail/todo-work/select-routing/select-routing.component';
import {SelectOrgComponent} from './pages/approve/show-detail/todo-work/select-org/select-org.component';
import {ChangePasswordComponent} from './pages/approve/content-more/change-password/change-password.component';
import {AboutUsComponent} from './pages/approve/content-more/about-us/about-us.component';
import {AddressDetailComponent} from './pages/approve/show-detail/address-detail/address-detail.component';
import {SelectActorsComponent} from './pages/approve/show-detail/todo-work/select-actors/select-actors.component';
import {SelectActorComponent} from './pages/approve/show-detail/todo-work/select-actor/select-actor.component';
import {LoginGard} from './login/loginGard ';
import {RejectRoutingComponent} from './pages/approve/show-detail/todo-work/reject-routing/reject-routing.component';
import {ContentComponent} from './pages/approve/content/content.component';
import {ContentMoreComponent} from './pages/approve/content-more/content-more.component';
import {ShowListComponent} from './pages/approve/content-more/show-list/show-list.component';
import {ShowListDocComponent} from './pages/approve/content-more/show-list/show-list-doc/show-list-doc.component';
import {ShowListAddrComponent} from './pages/approve/content-more/show-list/show-list-addr/show-list-addr.component';
import {ShowListWorkComponent} from './pages/approve/content-more/show-list/show-list-work/show-list-work.component';
import {ShowListNoticeComponent} from './pages/approve/content-more/show-list/show-list-notice/show-list-notice.component';
import {ReadDetailComponent} from './pages/approve/show-detail/read-detail/read-detail.component';
import {NoticeDetailComponent} from './pages/approve/show-detail/notice-detail/notice-detail.component';
import {ShowDetailComponent} from './pages/approve/show-detail/show-detail.component';
import {ShowDetailDocComponent} from './pages/approve/show-detail/show-detail-doc/show-detail-doc.component';
import {TodoWorkComponent} from './pages/approve/show-detail/todo-work/todo-work.component';

export const routes: Routes = [
  // { path: 'login', redirectTo: 'pages', pathMatch: 'full' },
  {path: 'login', component: LoginComponent, canActivate: [LoginGard]}, // 登陆
  {
    path: 'approve', component: ApproveComponent, // 审批
    children: [
      {path: '', component: ContentComponent},
      {path: 'content/:name', component: ContentComponent}, // 待办列表 已办列表 待阅列表;name:待办 已办 待阅
      {path: 'content-more', component: ContentMoreComponent} // 更多
    ]
    , canActivate: [LoginGard]
  },
  {path: 'show-list/:name', component: ShowListComponent, canActivate: [LoginGard]}, // 显示列表
  {path: 'handle-process', component: HandleProcessComponent, canActivate: [LoginGard]}, // 22
  {path: 'body-attachment/:nid/:id', component: BodyAttachmentComponent, canActivate: [LoginGard]}, // 正文-附件
  {path: 'select-routing/:nid/:nextNodeId', component: SelectRoutingComponent, canActivate: [LoginGard]}, // 选择路由
  {path: 'reject-routing/:nid', component: RejectRoutingComponent, canActivate: [LoginGard]}, // 返回路由
  {path: 'select-actor/:nid', component: SelectActorComponent, canActivate: [LoginGard]}, // 选择联系人
  {path: 'select-actors/:nid', component: SelectActorsComponent, canActivate: [LoginGard]}, // 多选联系人
  {path: 'select-org', component: SelectOrgComponent, canActivate: [LoginGard]}, // 选择组织
  {path: 'read-detail/:nid', component: ReadDetailComponent, canActivate: [LoginGard]}, // 待阅详情
  {path: 'notice-detail', component: NoticeDetailComponent, canActivate: [LoginGard]}, // 通知详情
  {path: 'change-password', component: ChangePasswordComponent, canActivate: [LoginGard]}, // 修改密码
  {path: 'about-us', component: AboutUsComponent, canActivate: [LoginGard]}, // 关于我们
  {path: 'show-detail/:name/:nid', component: ShowDetailComponent, canActivate: [LoginGard]}, // 显示详情
  {
    path: 'list', component: ShowListComponent,
    children: [
      {path: '文书档案', component: ShowListDocComponent},
      {path: '通讯录', component: ShowListAddrComponent},
      {path: '已阅工作', component: ShowListWorkComponent},
      {path: '通知公告', component: ShowListNoticeComponent}
    ]
  }, // 显示详情
  {path: 'show-detail-doc/:name/:nid', component: ShowDetailDocComponent, canActivate: [LoginGard]}, // 显示详情
  {path: 'address-detail', component: AddressDetailComponent, canActivate: [LoginGard]}, // 地址详情
  {path: 'todo/:nid', component: TodoWorkComponent, canActivate: [LoginGard]}, // 待办工作详情
  // {path: '**', redirectTo: 'login'},
];

export const routing: ModuleWithProviders = RouterModule.forRoot(routes, {useHash: true});
